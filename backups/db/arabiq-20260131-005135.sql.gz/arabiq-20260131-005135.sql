--
-- PostgreSQL database dump
--

\restrict 6OPkjHiCzpQtr6F6JdVuF2zKcE0k2iNC81bAhbRS2HF38mNmfDGFDneGlQkqAfX

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: about_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.about_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    mission_title character varying(255),
    mission_text text,
    vision_title character varying(255),
    vision_text text,
    values_title character varying(255),
    value_1_title character varying(255),
    value_1_text text,
    value_2_title character varying(255),
    value_2_text text,
    value_3_title character varying(255),
    value_3_text text,
    team_title character varying(255),
    team_subtitle text,
    cta_title character varying(255),
    cta_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.about_pages OWNER TO arabiq;

--
-- Name: about_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.about_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.about_pages_id_seq OWNER TO arabiq;

--
-- Name: about_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.about_pages_id_seq OWNED BY public.about_pages.id;


--
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_permissions OWNER TO arabiq;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_id_seq OWNER TO arabiq;

--
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.admin_permissions_role_lnk OWNER TO arabiq;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNER TO arabiq;

--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_roles OWNER TO arabiq;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_roles_id_seq OWNER TO arabiq;

--
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_users OWNER TO arabiq;

--
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_id_seq OWNER TO arabiq;

--
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


ALTER TABLE public.admin_users_roles_lnk OWNER TO arabiq;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNER TO arabiq;

--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- Name: case_studies; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.case_studies (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    title character varying(255),
    client character varying(255),
    industry character varying(255),
    summary text,
    description text,
    body text,
    allowed_roles jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.case_studies OWNER TO arabiq;

--
-- Name: case_studies_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.case_studies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_studies_id_seq OWNER TO arabiq;

--
-- Name: case_studies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.case_studies_id_seq OWNED BY public.case_studies.id;


--
-- Name: case_studies_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.case_studies_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    filter_all character varying(255),
    filter_retail character varying(255),
    filter_real_estate character varying(255),
    filter_tourism character varying(255),
    filter_events character varying(255),
    filter_education character varying(255),
    results_label character varying(255),
    read_more_button character varying(255),
    cta_title character varying(255),
    cta_subtitle text,
    cta_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.case_studies_pages OWNER TO arabiq;

--
-- Name: case_studies_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.case_studies_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_studies_pages_id_seq OWNER TO arabiq;

--
-- Name: case_studies_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.case_studies_pages_id_seq OWNED BY public.case_studies_pages.id;


--
-- Name: contact_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.contact_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    form_title character varying(255),
    name_label character varying(255),
    email_label character varying(255),
    phone_label character varying(255),
    message_label character varying(255),
    submit_button character varying(255),
    info_title character varying(255),
    address text,
    email character varying(255),
    phone character varying(255),
    hours_title character varying(255),
    hours_text text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.contact_pages OWNER TO arabiq;

--
-- Name: contact_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.contact_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.contact_pages_id_seq OWNER TO arabiq;

--
-- Name: contact_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.contact_pages_id_seq OWNED BY public.contact_pages.id;


--
-- Name: demos; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.demos (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    title character varying(255),
    demo_type character varying(255),
    summary text,
    description text,
    body text,
    icon character varying(255),
    allowed_roles jsonb,
    access_level character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.demos OWNER TO arabiq;

--
-- Name: demos_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.demos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.demos_id_seq OWNER TO arabiq;

--
-- Name: demos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.demos_id_seq OWNED BY public.demos.id;


--
-- Name: demos_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.demos_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    filter_all character varying(255),
    filter_matterport character varying(255),
    filter_ai character varying(255),
    filter_vfair character varying(255),
    access_public character varying(255),
    access_auth character varying(255),
    access_enterprise character varying(255),
    try_now_button character varying(255),
    request_access_button character varying(255),
    cta_title character varying(255),
    cta_subtitle text,
    cta_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.demos_pages OWNER TO arabiq;

--
-- Name: demos_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.demos_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.demos_pages_id_seq OWNER TO arabiq;

--
-- Name: demos_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.demos_pages_id_seq OWNED BY public.demos_pages.id;


--
-- Name: faqs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.faqs (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    category character varying(255),
    "order" integer,
    question character varying(255),
    answer text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.faqs OWNER TO arabiq;

--
-- Name: faqs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.faqs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.faqs_id_seq OWNER TO arabiq;

--
-- Name: faqs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.faqs_id_seq OWNED BY public.faqs.id;


--
-- Name: features; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.features (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    description text,
    icon character varying(255),
    "order" integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.features OWNER TO arabiq;

--
-- Name: features_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.features_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.features_id_seq OWNER TO arabiq;

--
-- Name: features_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.features_id_seq OWNED BY public.features.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text text,
    caption text,
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url text,
    preview_url text,
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.files OWNER TO arabiq;

--
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


ALTER TABLE public.files_folder_lnk OWNER TO arabiq;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_folder_lnk_id_seq OWNER TO arabiq;

--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO arabiq;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


ALTER TABLE public.files_related_mph OWNER TO arabiq;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_related_mph_id_seq OWNER TO arabiq;

--
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- Name: homepages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.homepages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    hero_primary_cta character varying(255),
    hero_secondary_cta character varying(255),
    hero_badge character varying(255),
    trust_award character varying(255),
    trust_global character varying(255),
    trust_fast character varying(255),
    show_stats_section boolean,
    show_trusted_by_section boolean,
    trusted_by_title character varying(255),
    show_how_it_works_section boolean,
    how_it_works_title character varying(255),
    how_it_works_subtitle text,
    show_features_section boolean,
    features_title character varying(255),
    features_subtitle text,
    show_solutions_section boolean,
    solutions_title character varying(255),
    solutions_subtitle text,
    show_industries_section boolean,
    industries_title character varying(255),
    industries_subtitle text,
    show_case_studies_section boolean,
    case_studies_title character varying(255),
    case_studies_subtitle text,
    show_demos_section boolean,
    demos_title character varying(255),
    demos_subtitle text,
    show_cta_section boolean,
    cta_title character varying(255),
    cta_subtitle text,
    cta_primary_button character varying(255),
    cta_secondary_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.homepages OWNER TO arabiq;

--
-- Name: homepages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.homepages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.homepages_id_seq OWNER TO arabiq;

--
-- Name: homepages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.homepages_id_seq OWNED BY public.homepages.id;


--
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.i18n_locale OWNER TO arabiq;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.i18n_locale_id_seq OWNER TO arabiq;

--
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- Name: industries; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.industries (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    title character varying(255),
    summary text,
    description text,
    body text,
    icon character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.industries OWNER TO arabiq;

--
-- Name: industries_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.industries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.industries_id_seq OWNER TO arabiq;

--
-- Name: industries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.industries_id_seq OWNED BY public.industries.id;


--
-- Name: industries_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.industries_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    stats_title character varying(255),
    cta_title character varying(255),
    cta_subtitle text,
    cta_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.industries_pages OWNER TO arabiq;

--
-- Name: industries_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.industries_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.industries_pages_id_seq OWNER TO arabiq;

--
-- Name: industries_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.industries_pages_id_seq OWNED BY public.industries_pages.id;


--
-- Name: nav_items; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.nav_items (
    id integer NOT NULL,
    document_id character varying(255),
    label character varying(255),
    href character varying(255),
    location character varying(255),
    "order" integer,
    is_external boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.nav_items OWNER TO arabiq;

--
-- Name: nav_items_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.nav_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.nav_items_id_seq OWNER TO arabiq;

--
-- Name: nav_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.nav_items_id_seq OWNED BY public.nav_items.id;


--
-- Name: partners; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.partners (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    "order" integer,
    partner_type character varying(255),
    logo_url character varying(255),
    website_url character varying(255),
    name character varying(255),
    description text,
    partnership character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.partners OWNER TO arabiq;

--
-- Name: partners_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.partners_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.partners_id_seq OWNER TO arabiq;

--
-- Name: partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.partners_id_seq OWNED BY public.partners.id;


--
-- Name: pricing_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.pricing_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    monthly_label character varying(255),
    annual_label character varying(255),
    annual_discount character varying(255),
    popular_badge character varying(255),
    features_title character varying(255),
    feature_1 character varying(255),
    feature_2 character varying(255),
    feature_3 character varying(255),
    feature_4 character varying(255),
    feature_5 character varying(255),
    comparison_title character varying(255),
    enterprise_title character varying(255),
    enterprise_subtitle text,
    enterprise_cta character varying(255),
    faq_title character varying(255),
    guarantee_title character varying(255),
    guarantee_text text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.pricing_pages OWNER TO arabiq;

--
-- Name: pricing_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.pricing_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pricing_pages_id_seq OWNER TO arabiq;

--
-- Name: pricing_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.pricing_pages_id_seq OWNED BY public.pricing_pages.id;


--
-- Name: pricing_plans; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.pricing_plans (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    "order" integer,
    popular boolean,
    name character varying(255),
    price character varying(255),
    currency character varying(255),
    period character varying(255),
    description text,
    features text,
    limitations text,
    cta character varying(255),
    ideal_for text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.pricing_plans OWNER TO arabiq;

--
-- Name: pricing_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.pricing_plans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pricing_plans_id_seq OWNER TO arabiq;

--
-- Name: pricing_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.pricing_plans_id_seq OWNED BY public.pricing_plans.id;


--
-- Name: process_steps; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.process_steps (
    id integer NOT NULL,
    document_id character varying(255),
    step integer,
    title character varying(255),
    description text,
    icon character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.process_steps OWNER TO arabiq;

--
-- Name: process_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.process_steps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.process_steps_id_seq OWNER TO arabiq;

--
-- Name: process_steps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.process_steps_id_seq OWNED BY public.process_steps.id;


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.site_settings (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    description text,
    contact_email character varying(255),
    contact_phone character varying(255),
    footer_company_title character varying(255),
    footer_products_title character varying(255),
    footer_resources_title character varying(255),
    footer_connect_title character varying(255),
    copyright_text character varying(255),
    login_button_text character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.site_settings OWNER TO arabiq;

--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.site_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_settings_id_seq OWNER TO arabiq;

--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: solutions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.solutions (
    id integer NOT NULL,
    document_id character varying(255),
    slug character varying(255),
    title character varying(255),
    summary text,
    description text,
    body text,
    icon character varying(255),
    allowed_roles jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.solutions OWNER TO arabiq;

--
-- Name: solutions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.solutions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.solutions_id_seq OWNER TO arabiq;

--
-- Name: solutions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.solutions_id_seq OWNED BY public.solutions.id;


--
-- Name: solutions_pages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.solutions_pages (
    id integer NOT NULL,
    document_id character varying(255),
    hero_title character varying(255),
    hero_subtitle text,
    filter_all character varying(255),
    filter_platforms character varying(255),
    filter_services character varying(255),
    filter_ai character varying(255),
    cta_title character varying(255),
    cta_subtitle text,
    cta_button character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.solutions_pages OWNER TO arabiq;

--
-- Name: solutions_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.solutions_pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.solutions_pages_id_seq OWNER TO arabiq;

--
-- Name: solutions_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.solutions_pages_id_seq OWNED BY public.solutions_pages.id;


--
-- Name: stats; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.stats (
    id integer NOT NULL,
    document_id character varying(255),
    value character varying(255),
    label character varying(255),
    "order" integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.stats OWNER TO arabiq;

--
-- Name: stats_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.stats_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stats_id_seq OWNER TO arabiq;

--
-- Name: stats_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.stats_id_seq OWNED BY public.stats.id;


--
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_localization_jobs OWNER TO arabiq;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNER TO arabiq;

--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_token_permissions OWNER TO arabiq;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNER TO arabiq;

--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


ALTER TABLE public.strapi_api_token_permissions_token_lnk OWNER TO arabiq;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_tokens OWNER TO arabiq;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNER TO arabiq;

--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- Name: strapi_audit_logs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_audit_logs (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    date timestamp(6) without time zone,
    payload jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_audit_logs OWNER TO arabiq;

--
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_audit_logs_id_seq OWNER TO arabiq;

--
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_audit_logs_id_seq OWNED BY public.strapi_audit_logs.id;


--
-- Name: strapi_audit_logs_user_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_audit_logs_user_lnk (
    id integer NOT NULL,
    audit_log_id integer,
    user_id integer
);


ALTER TABLE public.strapi_audit_logs_user_lnk OWNER TO arabiq;

--
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_audit_logs_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_audit_logs_user_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_audit_logs_user_lnk_id_seq OWNED BY public.strapi_audit_logs_user_lnk.id;


--
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.strapi_core_store_settings OWNER TO arabiq;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNER TO arabiq;

--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


ALTER TABLE public.strapi_database_schema OWNER TO arabiq;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_database_schema_id_seq OWNER TO arabiq;

--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


ALTER TABLE public.strapi_history_versions OWNER TO arabiq;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_history_versions_id_seq OWNER TO arabiq;

--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations OWNER TO arabiq;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_id_seq OWNER TO arabiq;

--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations_internal OWNER TO arabiq;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNER TO arabiq;

--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


ALTER TABLE public.strapi_release_actions OWNER TO arabiq;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_id_seq OWNER TO arabiq;

--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


ALTER TABLE public.strapi_release_actions_release_lnk OWNER TO arabiq;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_releases OWNER TO arabiq;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_releases_id_seq OWNER TO arabiq;

--
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_sessions OWNER TO arabiq;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_sessions_id_seq OWNER TO arabiq;

--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_token_permissions OWNER TO arabiq;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNER TO arabiq;

--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk OWNER TO arabiq;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_tokens OWNER TO arabiq;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNER TO arabiq;

--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO arabiq;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_webhooks_id_seq OWNER TO arabiq;

--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows OWNER TO arabiq;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_id_seq OWNER TO arabiq;

--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk OWNER TO arabiq;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows_stages OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_permissions_lnk OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_workflow_lnk OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNER TO arabiq;

--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.team_members (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    "position" character varying(255),
    bio text,
    "order" integer,
    linkedin_url character varying(255),
    twitter_url character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.team_members OWNER TO arabiq;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.team_members_id_seq OWNER TO arabiq;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.testimonials (
    id integer NOT NULL,
    document_id character varying(255),
    "order" integer,
    rating integer,
    featured boolean,
    quote text,
    author character varying(255),
    role character varying(255),
    company character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.testimonials OWNER TO arabiq;

--
-- Name: testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.testimonials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.testimonials_id_seq OWNER TO arabiq;

--
-- Name: testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.testimonials_id_seq OWNED BY public.testimonials.id;


--
-- Name: trusted_companies; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.trusted_companies (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    logo character varying(255),
    website character varying(255),
    "order" integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.trusted_companies OWNER TO arabiq;

--
-- Name: trusted_companies_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.trusted_companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trusted_companies_id_seq OWNER TO arabiq;

--
-- Name: trusted_companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.trusted_companies_id_seq OWNED BY public.trusted_companies.id;


--
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_permissions OWNER TO arabiq;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_id_seq OWNER TO arabiq;

--
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.up_permissions_role_lnk OWNER TO arabiq;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNER TO arabiq;

--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- Name: up_roles; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_roles OWNER TO arabiq;

--
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_roles_id_seq OWNER TO arabiq;

--
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- Name: up_users; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    phone character varying(255),
    country character varying(255),
    company character varying(255),
    sales_contact_allowed boolean DEFAULT true,
    display_name character varying(255),
    account_status character varying(255) DEFAULT 'pending'::character varying
);


ALTER TABLE public.up_users OWNER TO arabiq;

--
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_id_seq OWNER TO arabiq;

--
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


ALTER TABLE public.up_users_role_lnk OWNER TO arabiq;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNER TO arabiq;

--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.upload_folders OWNER TO arabiq;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_id_seq OWNER TO arabiq;

--
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


ALTER TABLE public.upload_folders_parent_lnk OWNER TO arabiq;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNER TO arabiq;

--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- Name: user_audit_logs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.user_audit_logs (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    ip_address character varying(255),
    user_agent text,
    metadata jsonb,
    success boolean,
    error_message text,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.user_audit_logs OWNER TO arabiq;

--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.user_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_audit_logs_id_seq OWNER TO arabiq;

--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.user_audit_logs_id_seq OWNED BY public.user_audit_logs.id;


--
-- Name: user_audit_logs_target_demo_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.user_audit_logs_target_demo_lnk (
    id integer NOT NULL,
    user_audit_log_id integer,
    demo_id integer
);


ALTER TABLE public.user_audit_logs_target_demo_lnk OWNER TO arabiq;

--
-- Name: user_audit_logs_target_demo_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.user_audit_logs_target_demo_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_audit_logs_target_demo_lnk_id_seq OWNER TO arabiq;

--
-- Name: user_audit_logs_target_demo_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.user_audit_logs_target_demo_lnk_id_seq OWNED BY public.user_audit_logs_target_demo_lnk.id;


--
-- Name: user_audit_logs_user_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.user_audit_logs_user_lnk (
    id integer NOT NULL,
    user_audit_log_id integer,
    user_id integer
);


ALTER TABLE public.user_audit_logs_user_lnk OWNER TO arabiq;

--
-- Name: user_audit_logs_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.user_audit_logs_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_audit_logs_user_lnk_id_seq OWNER TO arabiq;

--
-- Name: user_audit_logs_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.user_audit_logs_user_lnk_id_seq OWNED BY public.user_audit_logs_user_lnk.id;


--
-- Name: values; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public."values" (
    id integer NOT NULL,
    document_id character varying(255),
    title character varying(255),
    description text,
    icon character varying(255),
    "order" integer,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public."values" OWNER TO arabiq;

--
-- Name: values_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.values_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.values_id_seq OWNER TO arabiq;

--
-- Name: values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.values_id_seq OWNED BY public."values".id;


--
-- Name: about_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.about_pages ALTER COLUMN id SET DEFAULT nextval('public.about_pages_id_seq'::regclass);


--
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- Name: case_studies id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies ALTER COLUMN id SET DEFAULT nextval('public.case_studies_id_seq'::regclass);


--
-- Name: case_studies_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies_pages ALTER COLUMN id SET DEFAULT nextval('public.case_studies_pages_id_seq'::regclass);


--
-- Name: contact_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.contact_pages ALTER COLUMN id SET DEFAULT nextval('public.contact_pages_id_seq'::regclass);


--
-- Name: demos id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos ALTER COLUMN id SET DEFAULT nextval('public.demos_id_seq'::regclass);


--
-- Name: demos_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos_pages ALTER COLUMN id SET DEFAULT nextval('public.demos_pages_id_seq'::regclass);


--
-- Name: faqs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.faqs ALTER COLUMN id SET DEFAULT nextval('public.faqs_id_seq'::regclass);


--
-- Name: features id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.features ALTER COLUMN id SET DEFAULT nextval('public.features_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- Name: homepages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.homepages ALTER COLUMN id SET DEFAULT nextval('public.homepages_id_seq'::regclass);


--
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- Name: industries id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries ALTER COLUMN id SET DEFAULT nextval('public.industries_id_seq'::regclass);


--
-- Name: industries_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries_pages ALTER COLUMN id SET DEFAULT nextval('public.industries_pages_id_seq'::regclass);


--
-- Name: nav_items id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.nav_items ALTER COLUMN id SET DEFAULT nextval('public.nav_items_id_seq'::regclass);


--
-- Name: partners id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.partners ALTER COLUMN id SET DEFAULT nextval('public.partners_id_seq'::regclass);


--
-- Name: pricing_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_pages ALTER COLUMN id SET DEFAULT nextval('public.pricing_pages_id_seq'::regclass);


--
-- Name: pricing_plans id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_plans ALTER COLUMN id SET DEFAULT nextval('public.pricing_plans_id_seq'::regclass);


--
-- Name: process_steps id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.process_steps ALTER COLUMN id SET DEFAULT nextval('public.process_steps_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: solutions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions ALTER COLUMN id SET DEFAULT nextval('public.solutions_id_seq'::regclass);


--
-- Name: solutions_pages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions_pages ALTER COLUMN id SET DEFAULT nextval('public.solutions_pages_id_seq'::regclass);


--
-- Name: stats id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.stats ALTER COLUMN id SET DEFAULT nextval('public.stats_id_seq'::regclass);


--
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- Name: strapi_audit_logs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.strapi_audit_logs_id_seq'::regclass);


--
-- Name: strapi_audit_logs_user_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_audit_logs_user_lnk_id_seq'::regclass);


--
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: testimonials id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.testimonials ALTER COLUMN id SET DEFAULT nextval('public.testimonials_id_seq'::regclass);


--
-- Name: trusted_companies id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.trusted_companies ALTER COLUMN id SET DEFAULT nextval('public.trusted_companies_id_seq'::regclass);


--
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- Name: user_audit_logs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.user_audit_logs_id_seq'::regclass);


--
-- Name: user_audit_logs_target_demo_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_target_demo_lnk ALTER COLUMN id SET DEFAULT nextval('public.user_audit_logs_target_demo_lnk_id_seq'::regclass);


--
-- Name: user_audit_logs_user_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.user_audit_logs_user_lnk_id_seq'::regclass);


--
-- Name: values id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public."values" ALTER COLUMN id SET DEFAULT nextval('public.values_id_seq'::regclass);


--
-- Data for Name: about_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.about_pages (id, document_id, hero_title, hero_subtitle, mission_title, mission_text, vision_title, vision_text, values_title, value_1_title, value_1_text, value_2_title, value_2_text, value_3_title, value_3_text, team_title, team_subtitle, cta_title, cta_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	vbf6jma6n21ku5zgcr6ee324	Pioneering Virtual Experiences in the Middle East	We transform physical spaces into stunning digital twins, making them accessible to anyone, anywhere in the world.	Our Mission	To democratize access to immersive 3D technology, empowering MENA businesses to reach global audiences while preserving cultural authenticity and delivering exceptional customer experiences.	Our Vision	A world where every physical space has a digital twin, enabling limitless virtual exploration and transforming how people discover, shop, learn, and connect.	Our Core Values	Arabic-First	Built from the ground up for Arabic language and RTL design. We don't translate—we create native Arabic experiences.	Innovation	We push the boundaries of what's possible with 3D, AI, and immersive technology.	Excellence	We deliver photorealistic quality, enterprise-grade security, and 99.9% uptime.	Leadership Team	Visionaries and experts driving innovation in virtual experiences	Join Our Journey	Get in Touch	2026-01-30 18:18:42.885	2026-01-30 18:18:42.885	2026-01-30 18:18:42.884	\N	\N	en
2	vbf6jma6n21ku5zgcr6ee324	رواد التجارب الافتراضية في الشرق الأوسط	نحوّل المساحات الفعلية إلى توائم رقمية مذهلة، ونجعلها في متناول أي شخص في أي مكان في العالم.	مهمتنا	إتاحة الوصول إلى تقنية ثلاثية الأبعاد الغامرة، وتمكين شركات الشرق الأوسط من الوصول لجماهير عالمية مع الحفاظ على الأصالة الثقافية.	رؤيتنا	عالم حيث كل مساحة فعلية لها توأم رقمي، يتيح استكشافاً افتراضياً بلا حدود.	قيمنا الأساسية	العربية أولاً	مبني من الأساس للغة العربية وتصميم RTL. لا نترجم — ننشئ تجارب عربية أصلية.	الابتكار	ندفع حدود الممكن مع تقنية 3D والذكاء الاصطناعي والتقنية الغامرة.	التميز	نقدم جودة فوتوغرافية وأمان على مستوى المؤسسات ووقت تشغيل 99.9%.	فريق القيادة	أصحاب رؤية وخبراء يقودون الابتكار في التجارب الافتراضية	انضم لرحلتنا	تواصل معنا	2026-01-30 18:18:42.907	2026-01-30 18:18:42.907	2026-01-30 18:18:42.903	\N	\N	ar
\.


--
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_permissions (id, document_id, action, action_parameters, subject, properties, conditions, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	izp6tnrs2rv535f4nvk3axfp	plugin::upload.read	{}	\N	{}	[]	2026-01-29 17:06:07.779	2026-01-29 17:06:07.779	2026-01-29 17:06:07.779	\N	\N	\N
2	al6yzaq8hgd3phwo1jtg2dsa	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:07.79	2026-01-29 17:06:07.79	2026-01-29 17:06:07.79	\N	\N	\N
3	ux8jw44qtw553c3my50ehiqf	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:07.8	2026-01-29 17:06:07.8	2026-01-29 17:06:07.8	\N	\N	\N
4	gct3fh42ruj926oezgvjjay0	plugin::upload.assets.update	{}	\N	{}	[]	2026-01-29 17:06:07.809	2026-01-29 17:06:07.809	2026-01-29 17:06:07.809	\N	\N	\N
5	soalf3svooid38mludbggprw	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:07.819	2026-01-29 17:06:07.819	2026-01-29 17:06:07.819	\N	\N	\N
6	n4m7y52h5nbnh2j3yzu5u6bi	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:07.83	2026-01-29 17:06:07.83	2026-01-29 17:06:07.83	\N	\N	\N
7	oeixn75rtpes1i0t2wrs53lu	plugin::upload.read	{}	\N	{}	["admin::is-creator"]	2026-01-29 17:06:07.842	2026-01-29 17:06:07.842	2026-01-29 17:06:07.842	\N	\N	\N
8	fiwkr78j74duo7e91fsg61vm	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:07.855	2026-01-29 17:06:07.855	2026-01-29 17:06:07.855	\N	\N	\N
9	u4qpwhoo9zfjaoada447ivgg	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:07.867	2026-01-29 17:06:07.867	2026-01-29 17:06:07.867	\N	\N	\N
10	d9scw8nepl1jn34xij2rrjuo	plugin::upload.assets.update	{}	\N	{}	["admin::is-creator"]	2026-01-29 17:06:07.878	2026-01-29 17:06:07.878	2026-01-29 17:06:07.878	\N	\N	\N
11	rjcwqagkn3y8neg0fmn735v7	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:07.887	2026-01-29 17:06:07.887	2026-01-29 17:06:07.887	\N	\N	\N
12	q0fl894v0ct5l4xtv2u9c4oe	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:07.899	2026-01-29 17:06:07.899	2026-01-29 17:06:07.899	\N	\N	\N
13	l2b3abbckyf0hsllz60ugd4z	plugin::content-manager.explorer.create	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-01-29 17:06:07.929	2026-01-29 17:06:07.929	2026-01-29 17:06:07.929	\N	\N	\N
14	j50wrwnbqfwa9u5jmgwq4061	plugin::content-manager.explorer.read	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-01-29 17:06:07.941	2026-01-29 17:06:07.941	2026-01-29 17:06:07.941	\N	\N	\N
15	tts0931oqy298ph61ryq1sst	plugin::content-manager.explorer.update	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role"]}	[]	2026-01-29 17:06:07.949	2026-01-29 17:06:07.949	2026-01-29 17:06:07.95	\N	\N	\N
16	od5htowq2z60lfqhsoou4ryq	plugin::content-manager.explorer.delete	{}	plugin::users-permissions.user	{}	[]	2026-01-29 17:06:07.959	2026-01-29 17:06:07.959	2026-01-29 17:06:07.959	\N	\N	\N
17	qqfqyl3higzs74et5uybi5md	plugin::content-manager.explorer.publish	{}	plugin::users-permissions.user	{}	[]	2026-01-29 17:06:07.97	2026-01-29 17:06:07.97	2026-01-29 17:06:07.97	\N	\N	\N
18	v7yj7s3fzmjs5b1vsdidiquf	plugin::content-releases.read	{}	\N	{}	[]	2026-01-29 17:06:07.98	2026-01-29 17:06:07.98	2026-01-29 17:06:07.98	\N	\N	\N
19	seddlvcb93dmimtuity26ifm	plugin::content-releases.create	{}	\N	{}	[]	2026-01-29 17:06:07.992	2026-01-29 17:06:07.992	2026-01-29 17:06:07.992	\N	\N	\N
20	ek1zw3xf2c8uszyqm53ik46i	plugin::content-releases.update	{}	\N	{}	[]	2026-01-29 17:06:08.001	2026-01-29 17:06:08.001	2026-01-29 17:06:08.001	\N	\N	\N
21	xccn46mqvby4ul2o4ig89o6t	plugin::content-releases.delete	{}	\N	{}	[]	2026-01-29 17:06:08.013	2026-01-29 17:06:08.013	2026-01-29 17:06:08.013	\N	\N	\N
22	xekcgaq3qj3cohzhvfcvagzl	plugin::content-releases.publish	{}	\N	{}	[]	2026-01-29 17:06:08.026	2026-01-29 17:06:08.026	2026-01-29 17:06:08.026	\N	\N	\N
23	v5oa6w1lotjkf5luskz0ro3o	plugin::content-releases.delete-action	{}	\N	{}	[]	2026-01-29 17:06:08.037	2026-01-29 17:06:08.037	2026-01-29 17:06:08.037	\N	\N	\N
24	ucifjxw381f5ppvdhcgt81cb	plugin::content-releases.create-action	{}	\N	{}	[]	2026-01-29 17:06:08.048	2026-01-29 17:06:08.048	2026-01-29 17:06:08.048	\N	\N	\N
25	qbs4775ue72msdvfa392xkh9	plugin::content-releases.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.059	2026-01-29 17:06:08.059	2026-01-29 17:06:08.059	\N	\N	\N
26	prq8ti151pqfz6cc6vq3js49	plugin::content-releases.settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.068	2026-01-29 17:06:08.068	2026-01-29 17:06:08.068	\N	\N	\N
27	fzlnjc1b94j59i9ntmvxd312	plugin::content-manager.single-types.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.077	2026-01-29 17:06:08.077	2026-01-29 17:06:08.077	\N	\N	\N
28	mrw35wjwak5b4bdsh0aq053i	plugin::content-manager.collection-types.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.086	2026-01-29 17:06:08.086	2026-01-29 17:06:08.086	\N	\N	\N
29	v9geh26mrv3fivo4q0rb7b5q	plugin::content-manager.components.configure-layout	{}	\N	{}	[]	2026-01-29 17:06:08.096	2026-01-29 17:06:08.096	2026-01-29 17:06:08.096	\N	\N	\N
30	p3uwbnil51rzgxic88i499fv	plugin::content-type-builder.read	{}	\N	{}	[]	2026-01-29 17:06:08.107	2026-01-29 17:06:08.107	2026-01-29 17:06:08.107	\N	\N	\N
31	fcyhus8hczpprjkn68pjjx4a	plugin::email.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.116	2026-01-29 17:06:08.116	2026-01-29 17:06:08.116	\N	\N	\N
32	h4xb4uy1ef6qjwd7ld2g93th	plugin::upload.read	{}	\N	{}	[]	2026-01-29 17:06:08.128	2026-01-29 17:06:08.128	2026-01-29 17:06:08.128	\N	\N	\N
33	jgetb6xr867ecvt79o8t319r	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:08.137	2026-01-29 17:06:08.137	2026-01-29 17:06:08.137	\N	\N	\N
34	ocqispu40x63bspajczjcyqh	plugin::upload.assets.update	{}	\N	{}	[]	2026-01-29 17:06:08.146	2026-01-29 17:06:08.146	2026-01-29 17:06:08.146	\N	\N	\N
35	qhvfrhb5rr3aybiydicdnulo	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:08.157	2026-01-29 17:06:08.157	2026-01-29 17:06:08.157	\N	\N	\N
36	r6xi8x1t4p1y4zn78np55pqp	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:08.166	2026-01-29 17:06:08.166	2026-01-29 17:06:08.166	\N	\N	\N
37	wsh6vsvtokoa3rzabk49decc	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.176	2026-01-29 17:06:08.176	2026-01-29 17:06:08.176	\N	\N	\N
38	gff3p1ulaffug3kmbkn4778w	plugin::upload.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.185	2026-01-29 17:06:08.185	2026-01-29 17:06:08.186	\N	\N	\N
39	amfi69epn3818wx0y3om6tqk	plugin::i18n.locale.create	{}	\N	{}	[]	2026-01-29 17:06:08.199	2026-01-29 17:06:08.199	2026-01-29 17:06:08.199	\N	\N	\N
40	ecguy48rj1zr1o7y7c22q81s	plugin::i18n.locale.read	{}	\N	{}	[]	2026-01-29 17:06:08.209	2026-01-29 17:06:08.209	2026-01-29 17:06:08.209	\N	\N	\N
41	jhfis9jccroyoxjixz18h1q9	plugin::i18n.locale.update	{}	\N	{}	[]	2026-01-29 17:06:08.217	2026-01-29 17:06:08.217	2026-01-29 17:06:08.217	\N	\N	\N
42	xgi5iya8fvvseqn6j0d167yh	plugin::i18n.locale.delete	{}	\N	{}	[]	2026-01-29 17:06:08.226	2026-01-29 17:06:08.226	2026-01-29 17:06:08.227	\N	\N	\N
43	pot730pher7lirmf80q8z4vj	plugin::users-permissions.roles.create	{}	\N	{}	[]	2026-01-29 17:06:08.236	2026-01-29 17:06:08.236	2026-01-29 17:06:08.236	\N	\N	\N
44	pu1gsmmedc64xzgxq0bnvhnb	plugin::users-permissions.roles.read	{}	\N	{}	[]	2026-01-29 17:06:08.245	2026-01-29 17:06:08.245	2026-01-29 17:06:08.245	\N	\N	\N
45	ogmpy8yx0fictkfgfe2o4qb2	plugin::users-permissions.roles.update	{}	\N	{}	[]	2026-01-29 17:06:08.26	2026-01-29 17:06:08.26	2026-01-29 17:06:08.26	\N	\N	\N
46	awwe4hb0uoppf40jyxm4id0j	plugin::users-permissions.roles.delete	{}	\N	{}	[]	2026-01-29 17:06:08.269	2026-01-29 17:06:08.269	2026-01-29 17:06:08.269	\N	\N	\N
47	gvlizriiswnxspf4086p0q5h	plugin::users-permissions.providers.read	{}	\N	{}	[]	2026-01-29 17:06:08.279	2026-01-29 17:06:08.279	2026-01-29 17:06:08.279	\N	\N	\N
48	sc3olw11pcbo2lgpu8jl0w90	plugin::users-permissions.providers.update	{}	\N	{}	[]	2026-01-29 17:06:08.291	2026-01-29 17:06:08.291	2026-01-29 17:06:08.291	\N	\N	\N
49	uioi711d682dxp8tkqxymlh5	plugin::users-permissions.email-templates.read	{}	\N	{}	[]	2026-01-29 17:06:08.301	2026-01-29 17:06:08.301	2026-01-29 17:06:08.301	\N	\N	\N
50	c83n9dhtww693bi8bgwbcdwz	plugin::users-permissions.email-templates.update	{}	\N	{}	[]	2026-01-29 17:06:08.31	2026-01-29 17:06:08.31	2026-01-29 17:06:08.31	\N	\N	\N
51	g4o7c358u08n9ei10jn00e5l	plugin::users-permissions.advanced-settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.318	2026-01-29 17:06:08.318	2026-01-29 17:06:08.318	\N	\N	\N
52	z7lblyolv1tqz0awf7aruv39	plugin::users-permissions.advanced-settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.326	2026-01-29 17:06:08.326	2026-01-29 17:06:08.326	\N	\N	\N
53	x0b45iyo0at61pypj86prekv	admin::provider-login.read	{}	\N	{}	[]	2026-01-29 17:06:08.335	2026-01-29 17:06:08.335	2026-01-29 17:06:08.335	\N	\N	\N
54	vh7zmk9e8j1alpp2csemd9yx	admin::provider-login.update	{}	\N	{}	[]	2026-01-29 17:06:08.344	2026-01-29 17:06:08.344	2026-01-29 17:06:08.345	\N	\N	\N
55	tpwq1gfop87wwdqmhevf8crq	admin::marketplace.read	{}	\N	{}	[]	2026-01-29 17:06:08.354	2026-01-29 17:06:08.354	2026-01-29 17:06:08.354	\N	\N	\N
56	jlneooynrnb9zo19pzfu880o	admin::webhooks.create	{}	\N	{}	[]	2026-01-29 17:06:08.366	2026-01-29 17:06:08.366	2026-01-29 17:06:08.366	\N	\N	\N
57	wwiphnxzvhsf7vmgu4dkwe27	admin::webhooks.read	{}	\N	{}	[]	2026-01-29 17:06:08.377	2026-01-29 17:06:08.377	2026-01-29 17:06:08.377	\N	\N	\N
58	om1jy44phkyd5tqd0n214w1l	admin::webhooks.update	{}	\N	{}	[]	2026-01-29 17:06:08.386	2026-01-29 17:06:08.386	2026-01-29 17:06:08.387	\N	\N	\N
59	g260ugrov60c6on3j1tz67yi	admin::webhooks.delete	{}	\N	{}	[]	2026-01-29 17:06:08.396	2026-01-29 17:06:08.396	2026-01-29 17:06:08.396	\N	\N	\N
60	fqdu0rn2hxkvkvpmb33cy87g	admin::users.create	{}	\N	{}	[]	2026-01-29 17:06:08.405	2026-01-29 17:06:08.405	2026-01-29 17:06:08.406	\N	\N	\N
61	j19csikzyid75mmimd0oc1oq	admin::users.read	{}	\N	{}	[]	2026-01-29 17:06:08.414	2026-01-29 17:06:08.414	2026-01-29 17:06:08.415	\N	\N	\N
62	duvpr92wus6585bkpk6uqq5l	admin::users.update	{}	\N	{}	[]	2026-01-29 17:06:08.432	2026-01-29 17:06:08.432	2026-01-29 17:06:08.432	\N	\N	\N
63	toruapj34xhp7ipr7lperu0g	admin::users.delete	{}	\N	{}	[]	2026-01-29 17:06:08.445	2026-01-29 17:06:08.445	2026-01-29 17:06:08.446	\N	\N	\N
64	sppm844antalzft9fwlut8j5	admin::roles.create	{}	\N	{}	[]	2026-01-29 17:06:08.456	2026-01-29 17:06:08.456	2026-01-29 17:06:08.456	\N	\N	\N
65	lqeyoq5okfp546jlwhl4zhh8	admin::roles.read	{}	\N	{}	[]	2026-01-29 17:06:08.468	2026-01-29 17:06:08.468	2026-01-29 17:06:08.468	\N	\N	\N
66	oxl3m9rkv1bx42xq1glrje98	admin::roles.update	{}	\N	{}	[]	2026-01-29 17:06:08.479	2026-01-29 17:06:08.479	2026-01-29 17:06:08.479	\N	\N	\N
67	docbysryzsufid1zt31xl0hs	admin::roles.delete	{}	\N	{}	[]	2026-01-29 17:06:08.491	2026-01-29 17:06:08.491	2026-01-29 17:06:08.491	\N	\N	\N
68	muosuqy1otyjpuj77yt9uha9	admin::api-tokens.access	{}	\N	{}	[]	2026-01-29 17:06:08.501	2026-01-29 17:06:08.501	2026-01-29 17:06:08.501	\N	\N	\N
69	z4mv0uzc2rdt962m5jyo6tns	admin::api-tokens.create	{}	\N	{}	[]	2026-01-29 17:06:08.512	2026-01-29 17:06:08.512	2026-01-29 17:06:08.512	\N	\N	\N
70	ahl6g1d7ocb9xzm6l6c0i4n0	admin::api-tokens.read	{}	\N	{}	[]	2026-01-29 17:06:08.522	2026-01-29 17:06:08.522	2026-01-29 17:06:08.522	\N	\N	\N
71	kzzx4105euv9s5bjhiy5l97s	admin::api-tokens.update	{}	\N	{}	[]	2026-01-29 17:06:08.531	2026-01-29 17:06:08.531	2026-01-29 17:06:08.532	\N	\N	\N
72	wyl3ox196dy1etpjme660prm	admin::api-tokens.regenerate	{}	\N	{}	[]	2026-01-29 17:06:08.54	2026-01-29 17:06:08.54	2026-01-29 17:06:08.541	\N	\N	\N
73	y0d7kd7o16jj444md3o11n5m	admin::api-tokens.delete	{}	\N	{}	[]	2026-01-29 17:06:08.551	2026-01-29 17:06:08.551	2026-01-29 17:06:08.552	\N	\N	\N
74	qq9a6v96haviqgbwdayn1ex6	admin::project-settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.562	2026-01-29 17:06:08.562	2026-01-29 17:06:08.562	\N	\N	\N
75	f567xbdt933z63cz8k43c13j	admin::project-settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.571	2026-01-29 17:06:08.571	2026-01-29 17:06:08.571	\N	\N	\N
76	tgaqzh4738nf85w9qy3fgih9	admin::transfer.tokens.access	{}	\N	{}	[]	2026-01-29 17:06:08.582	2026-01-29 17:06:08.582	2026-01-29 17:06:08.582	\N	\N	\N
77	ufvn1cbpgucl84uotjiwvtp4	admin::transfer.tokens.create	{}	\N	{}	[]	2026-01-29 17:06:08.591	2026-01-29 17:06:08.591	2026-01-29 17:06:08.591	\N	\N	\N
78	nfs4n9cowptjjl4z6qknpmt9	admin::transfer.tokens.read	{}	\N	{}	[]	2026-01-29 17:06:08.6	2026-01-29 17:06:08.6	2026-01-29 17:06:08.6	\N	\N	\N
79	ddnkn90akh26bzicv1tl3co1	admin::transfer.tokens.update	{}	\N	{}	[]	2026-01-29 17:06:08.61	2026-01-29 17:06:08.61	2026-01-29 17:06:08.61	\N	\N	\N
80	wtsu6uak50q49ns6jed0yzys	admin::transfer.tokens.regenerate	{}	\N	{}	[]	2026-01-29 17:06:08.62	2026-01-29 17:06:08.62	2026-01-29 17:06:08.62	\N	\N	\N
81	m9ltlbyq69rc1mbrejqdme3m	admin::transfer.tokens.delete	{}	\N	{}	[]	2026-01-29 17:06:08.628	2026-01-29 17:06:08.628	2026-01-29 17:06:08.629	\N	\N	\N
242	e95dp7eqn40n0o9fk2fbcyoi	plugin::content-manager.explorer.create	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.874	2026-01-29 18:15:40.874	2026-01-29 18:15:40.874	\N	\N	\N
243	cxnws3bso9ggd6g8xy0sqfec	plugin::content-manager.explorer.create	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.887	2026-01-29 18:15:40.887	2026-01-29 18:15:40.887	\N	\N	\N
244	f04d5soin62pqkrcctc708m5	plugin::content-manager.explorer.create	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.897	2026-01-29 18:15:40.897	2026-01-29 18:15:40.897	\N	\N	\N
245	mjmwizikd7or6ydk3qy7p9q2	plugin::content-manager.explorer.create	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.907	2026-01-29 18:15:40.907	2026-01-29 18:15:40.907	\N	\N	\N
246	t7jc7vnyetw27hx35vhia2rc	plugin::content-manager.explorer.create	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.918	2026-01-29 18:15:40.918	2026-01-29 18:15:40.918	\N	\N	\N
247	r79kdfarjm7aat8af8un6wpz	plugin::content-manager.explorer.create	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.931	2026-01-29 18:15:40.931	2026-01-29 18:15:40.931	\N	\N	\N
248	f0g4uzcq7fb1ndowokudfugx	plugin::content-manager.explorer.create	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.947	2026-01-29 18:15:40.947	2026-01-29 18:15:40.948	\N	\N	\N
249	t469372m5k1u2pm5bjmewww7	plugin::content-manager.explorer.create	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.969	2026-01-29 18:15:40.969	2026-01-29 18:15:40.969	\N	\N	\N
250	pqw32ods8eds8dposq1sy297	plugin::content-manager.explorer.create	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.991	2026-01-29 18:15:40.991	2026-01-29 18:15:40.991	\N	\N	\N
251	eva8cluj7dtwfhzpi01czdgf	plugin::content-manager.explorer.create	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.01	2026-01-29 18:15:41.01	2026-01-29 18:15:41.011	\N	\N	\N
252	uw9mrrqmhw34rlzne0blbcmp	plugin::content-manager.explorer.create	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.025	2026-01-29 18:15:41.025	2026-01-29 18:15:41.025	\N	\N	\N
253	ejyg1sxidfl1y8gw3ge981a4	plugin::content-manager.explorer.create	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.042	2026-01-29 18:15:41.042	2026-01-29 18:15:41.043	\N	\N	\N
254	rqkyy2tn5l8pyq3g7z89dbx6	plugin::content-manager.explorer.create	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.064	2026-01-29 18:15:41.064	2026-01-29 18:15:41.064	\N	\N	\N
255	b1zynsj2ajwd9nrcozqmfuwc	plugin::content-manager.explorer.create	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.081	2026-01-29 18:15:41.081	2026-01-29 18:15:41.081	\N	\N	\N
256	ij89zqt0ny3fwjp3okypya2n	plugin::content-manager.explorer.create	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.096	2026-01-29 18:15:41.096	2026-01-29 18:15:41.097	\N	\N	\N
257	tlmv2jxrp8o567mp2jx3flhj	plugin::content-manager.explorer.create	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.11	2026-01-29 18:15:41.11	2026-01-29 18:15:41.11	\N	\N	\N
258	j5aukz0efl9d6pyubjl5xmct	plugin::content-manager.explorer.read	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.124	2026-01-29 18:15:41.124	2026-01-29 18:15:41.124	\N	\N	\N
259	mu18momhjk31hinirv174laq	plugin::content-manager.explorer.read	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.134	2026-01-29 18:15:41.134	2026-01-29 18:15:41.134	\N	\N	\N
260	yf4jyl3lhnxdinwdlgavqlf4	plugin::content-manager.explorer.read	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.143	2026-01-29 18:15:41.143	2026-01-29 18:15:41.143	\N	\N	\N
261	zg0g20jq9uhqyaipm72x4vvy	plugin::content-manager.explorer.read	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.153	2026-01-29 18:15:41.153	2026-01-29 18:15:41.153	\N	\N	\N
262	gakhpoma79lxphm9qklabdhb	plugin::content-manager.explorer.read	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.163	2026-01-29 18:15:41.163	2026-01-29 18:15:41.163	\N	\N	\N
263	oavkw3jpylfrottn6i7ko5k0	plugin::content-manager.explorer.read	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.172	2026-01-29 18:15:41.172	2026-01-29 18:15:41.172	\N	\N	\N
264	zsjdfo2z0oyct2mzf42816he	plugin::content-manager.explorer.read	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.183	2026-01-29 18:15:41.183	2026-01-29 18:15:41.183	\N	\N	\N
265	djc7ahowjlnrzcqeevonk5h1	plugin::content-manager.explorer.read	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.197	2026-01-29 18:15:41.197	2026-01-29 18:15:41.197	\N	\N	\N
266	dn55t1bpuusohtrd4bqzz86j	plugin::content-manager.explorer.read	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.21	2026-01-29 18:15:41.21	2026-01-29 18:15:41.211	\N	\N	\N
267	kr9vua3aeoevg1hjzl004lmx	plugin::content-manager.explorer.read	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.225	2026-01-29 18:15:41.225	2026-01-29 18:15:41.225	\N	\N	\N
268	wk1jkm71xbl1nbj4tmtt7fwo	plugin::content-manager.explorer.read	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.242	2026-01-29 18:15:41.242	2026-01-29 18:15:41.242	\N	\N	\N
269	fb6h61pvr5kxjm97xkdwnwku	plugin::content-manager.explorer.read	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.255	2026-01-29 18:15:41.255	2026-01-29 18:15:41.255	\N	\N	\N
270	bjmu4loht35a205u4xlbj2q1	plugin::content-manager.explorer.read	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.27	2026-01-29 18:15:41.27	2026-01-29 18:15:41.27	\N	\N	\N
271	hmgjxnkm8s0yhnn6f871ot0a	plugin::content-manager.explorer.read	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.28	2026-01-29 18:15:41.28	2026-01-29 18:15:41.28	\N	\N	\N
272	b6z45bby1z1kumgrzp9gjdnr	plugin::content-manager.explorer.read	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.289	2026-01-29 18:15:41.289	2026-01-29 18:15:41.29	\N	\N	\N
273	lr42y4qw2f6f23dijcfkhomz	plugin::content-manager.explorer.read	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.299	2026-01-29 18:15:41.299	2026-01-29 18:15:41.299	\N	\N	\N
274	kysiabmdswkr0k8ugedz25gp	plugin::content-manager.explorer.update	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.308	2026-01-29 18:15:41.308	2026-01-29 18:15:41.308	\N	\N	\N
275	rwxb2hiyupt10lgr6r3a1nyh	plugin::content-manager.explorer.update	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.318	2026-01-29 18:15:41.318	2026-01-29 18:15:41.318	\N	\N	\N
306	vxu7zbbkmxrmej96k57c4500	plugin::content-manager.explorer.publish	{}	api::about-page.about-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.699	2026-01-29 18:15:41.699	2026-01-29 18:15:41.699	\N	\N	\N
276	etid1ba4p45n9mc4yube68hv	plugin::content-manager.explorer.update	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.328	2026-01-29 18:15:41.328	2026-01-29 18:15:41.328	\N	\N	\N
277	c24ibbqboaoxhs03wq74g28r	plugin::content-manager.explorer.update	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.337	2026-01-29 18:15:41.337	2026-01-29 18:15:41.337	\N	\N	\N
278	bx98t7asitex3ydybehsw9yd	plugin::content-manager.explorer.update	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.346	2026-01-29 18:15:41.346	2026-01-29 18:15:41.347	\N	\N	\N
279	gp14zgu1uyi95mrnn9wupqxi	plugin::content-manager.explorer.update	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.356	2026-01-29 18:15:41.356	2026-01-29 18:15:41.356	\N	\N	\N
280	b9prpmdx7xb07xy6li8hu5go	plugin::content-manager.explorer.update	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.367	2026-01-29 18:15:41.367	2026-01-29 18:15:41.368	\N	\N	\N
281	c0m6854hbbhosek0nikn926l	plugin::content-manager.explorer.update	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.384	2026-01-29 18:15:41.384	2026-01-29 18:15:41.384	\N	\N	\N
282	o3oq9rmxfnub33v4xjx3hfgy	plugin::content-manager.explorer.update	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.397	2026-01-29 18:15:41.397	2026-01-29 18:15:41.397	\N	\N	\N
283	r02tgtil3otjq2x7qlom6e6c	plugin::content-manager.explorer.update	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.413	2026-01-29 18:15:41.413	2026-01-29 18:15:41.413	\N	\N	\N
284	hflwdj8gvmzmalbn84ly7bmk	plugin::content-manager.explorer.update	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.425	2026-01-29 18:15:41.425	2026-01-29 18:15:41.426	\N	\N	\N
285	y99thxikw3wc2yvscthyli3h	plugin::content-manager.explorer.update	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.437	2026-01-29 18:15:41.437	2026-01-29 18:15:41.437	\N	\N	\N
286	wu1kkxkyoumik4r75t50mksh	plugin::content-manager.explorer.update	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.448	2026-01-29 18:15:41.448	2026-01-29 18:15:41.448	\N	\N	\N
287	dmi8l0u5eg6x997st977uo2q	plugin::content-manager.explorer.update	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.457	2026-01-29 18:15:41.457	2026-01-29 18:15:41.457	\N	\N	\N
288	up0top4w6fxfa01fzqij0qfp	plugin::content-manager.explorer.update	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.468	2026-01-29 18:15:41.468	2026-01-29 18:15:41.468	\N	\N	\N
289	n8ixeua0ylsp5pbanzkidnqx	plugin::content-manager.explorer.update	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.479	2026-01-29 18:15:41.479	2026-01-29 18:15:41.479	\N	\N	\N
290	clg2kn29dw7y2ue5josd38oz	plugin::content-manager.explorer.delete	{}	api::about-page.about-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.489	2026-01-29 18:15:41.489	2026-01-29 18:15:41.489	\N	\N	\N
291	cuqxf1lbhurdarzz1r8qfg8f	plugin::content-manager.explorer.delete	{}	api::case-study.case-study	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.501	2026-01-29 18:15:41.501	2026-01-29 18:15:41.501	\N	\N	\N
292	o4hridkz4r30k9k74pky2gbk	plugin::content-manager.explorer.delete	{}	api::contact-page.contact-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.516	2026-01-29 18:15:41.516	2026-01-29 18:15:41.516	\N	\N	\N
293	bf9jnhn52kj632v7pudttw6k	plugin::content-manager.explorer.delete	{}	api::demo.demo	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.528	2026-01-29 18:15:41.528	2026-01-29 18:15:41.528	\N	\N	\N
294	nf1l7f0mdoaz18rbiy46g382	plugin::content-manager.explorer.delete	{}	api::feature.feature	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.539	2026-01-29 18:15:41.539	2026-01-29 18:15:41.539	\N	\N	\N
295	xrhfj699xsgudx9wvz65yal8	plugin::content-manager.explorer.delete	{}	api::homepage.homepage	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.553	2026-01-29 18:15:41.553	2026-01-29 18:15:41.554	\N	\N	\N
296	d9kaahf5m3j3iwre8il722ta	plugin::content-manager.explorer.delete	{}	api::industry.industry	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.566	2026-01-29 18:15:41.566	2026-01-29 18:15:41.566	\N	\N	\N
297	vdznpag9kkc4jxvtd5u8y7xh	plugin::content-manager.explorer.delete	{}	api::nav-item.nav-item	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.579	2026-01-29 18:15:41.579	2026-01-29 18:15:41.579	\N	\N	\N
298	slg7j9qu10ffefetiqgccj9q	plugin::content-manager.explorer.delete	{}	api::process-step.process-step	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.59	2026-01-29 18:15:41.59	2026-01-29 18:15:41.59	\N	\N	\N
299	tmx2kjqke57r2mtdg6bykrxu	plugin::content-manager.explorer.delete	{}	api::site-setting.site-setting	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.602	2026-01-29 18:15:41.602	2026-01-29 18:15:41.603	\N	\N	\N
300	eoiybxbhowlqfn8hogfi2n9z	plugin::content-manager.explorer.delete	{}	api::solution.solution	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.617	2026-01-29 18:15:41.617	2026-01-29 18:15:41.617	\N	\N	\N
301	q9s12yknfupu1ei1wr6kmdah	plugin::content-manager.explorer.delete	{}	api::stat.stat	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.629	2026-01-29 18:15:41.629	2026-01-29 18:15:41.629	\N	\N	\N
302	xk8hfdqkgpfqy6j363z431jz	plugin::content-manager.explorer.delete	{}	api::team-member.team-member	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.641	2026-01-29 18:15:41.641	2026-01-29 18:15:41.641	\N	\N	\N
303	t3d5zxjzezn0kmo3cuzh9ubh	plugin::content-manager.explorer.delete	{}	api::trusted-company.trusted-company	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.658	2026-01-29 18:15:41.658	2026-01-29 18:15:41.659	\N	\N	\N
304	jfdzivlafn3blgk6dwpvpuix	plugin::content-manager.explorer.delete	{}	api::user-audit-log.user-audit-log	{}	[]	2026-01-29 18:15:41.67	2026-01-29 18:15:41.67	2026-01-29 18:15:41.67	\N	\N	\N
305	t7jsm8d2mu950fbm04cw75w5	plugin::content-manager.explorer.delete	{}	api::value.value	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.686	2026-01-29 18:15:41.686	2026-01-29 18:15:41.687	\N	\N	\N
307	hoqd2iap0m45hsy3q5gzh41l	plugin::content-manager.explorer.publish	{}	api::case-study.case-study	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.711	2026-01-29 18:15:41.711	2026-01-29 18:15:41.712	\N	\N	\N
308	szme4dgwm1j9ialahbpklvwa	plugin::content-manager.explorer.publish	{}	api::contact-page.contact-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.725	2026-01-29 18:15:41.725	2026-01-29 18:15:41.725	\N	\N	\N
309	slaa1rdnhekdtxdvxqpcd8hj	plugin::content-manager.explorer.publish	{}	api::demo.demo	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.739	2026-01-29 18:15:41.739	2026-01-29 18:15:41.739	\N	\N	\N
310	vusfuzp91jfphpxafiz1inpv	plugin::content-manager.explorer.publish	{}	api::feature.feature	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.753	2026-01-29 18:15:41.753	2026-01-29 18:15:41.753	\N	\N	\N
311	ct52eq3tk7btt6jkg8fgngcu	plugin::content-manager.explorer.publish	{}	api::homepage.homepage	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.765	2026-01-29 18:15:41.765	2026-01-29 18:15:41.765	\N	\N	\N
312	m7l92naunxwmnumtawgyghl6	plugin::content-manager.explorer.publish	{}	api::industry.industry	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.777	2026-01-29 18:15:41.777	2026-01-29 18:15:41.777	\N	\N	\N
313	udknctti756kmw6e6m2lnqmf	plugin::content-manager.explorer.publish	{}	api::nav-item.nav-item	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.794	2026-01-29 18:15:41.794	2026-01-29 18:15:41.794	\N	\N	\N
314	h29olcelzhz4yodr5jem4qc7	plugin::content-manager.explorer.publish	{}	api::process-step.process-step	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.809	2026-01-29 18:15:41.809	2026-01-29 18:15:41.81	\N	\N	\N
315	y7gy5zbrol8bxoft3b45v6d8	plugin::content-manager.explorer.publish	{}	api::site-setting.site-setting	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.825	2026-01-29 18:15:41.825	2026-01-29 18:15:41.825	\N	\N	\N
316	kzi1tyq6mqidfg7u7rvlvxfj	plugin::content-manager.explorer.publish	{}	api::solution.solution	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.839	2026-01-29 18:15:41.839	2026-01-29 18:15:41.84	\N	\N	\N
317	l865sua2rqmubiz1p5k2hb5p	plugin::content-manager.explorer.publish	{}	api::stat.stat	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.854	2026-01-29 18:15:41.854	2026-01-29 18:15:41.854	\N	\N	\N
318	xxsboeh5cpjylcdijyyb047h	plugin::content-manager.explorer.publish	{}	api::team-member.team-member	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.868	2026-01-29 18:15:41.868	2026-01-29 18:15:41.868	\N	\N	\N
319	gzrvyiwzr28kz95x8q0eprmv	plugin::content-manager.explorer.publish	{}	api::trusted-company.trusted-company	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.883	2026-01-29 18:15:41.883	2026-01-29 18:15:41.883	\N	\N	\N
320	tpbyfk34hlhr1yxl7rmyd4tz	plugin::content-manager.explorer.publish	{}	api::user-audit-log.user-audit-log	{}	[]	2026-01-29 18:15:41.897	2026-01-29 18:15:41.897	2026-01-29 18:15:41.897	\N	\N	\N
321	ic5xbnbp8i0gfw36o2hg1kkh	plugin::content-manager.explorer.publish	{}	api::value.value	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.914	2026-01-29 18:15:41.914	2026-01-29 18:15:41.914	\N	\N	\N
322	v6kfjtqxdfr5hdztvuvbi240	plugin::content-manager.explorer.create	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.476	2026-01-30 13:26:27.476	2026-01-30 13:26:27.477	\N	\N	\N
323	nb79ns36ng8ncqx4egkaypjv	plugin::content-manager.explorer.read	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.497	2026-01-30 13:26:27.497	2026-01-30 13:26:27.497	\N	\N	\N
324	alw1hp9fc04u1lcl5xuh7wek	plugin::content-manager.explorer.update	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.506	2026-01-30 13:26:27.506	2026-01-30 13:26:27.507	\N	\N	\N
325	m348468gslb2miyxcdd5ns1b	plugin::content-manager.explorer.delete	{}	api::faq.faq	{"locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.516	2026-01-30 13:26:27.516	2026-01-30 13:26:27.516	\N	\N	\N
326	g6f84h0evcod4f449fvdjy7v	plugin::content-manager.explorer.publish	{}	api::faq.faq	{"locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.526	2026-01-30 13:26:27.526	2026-01-30 13:26:27.526	\N	\N	\N
327	ixg9lq3113p0e4w07xx5v5e5	plugin::content-manager.explorer.create	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:13.99	2026-01-30 13:28:13.99	2026-01-30 13:28:13.991	\N	\N	\N
328	pjok6wgt2nt4iw5icp2es4zo	plugin::content-manager.explorer.create	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.001	2026-01-30 13:28:14.001	2026-01-30 13:28:14.001	\N	\N	\N
329	y6nqvrb1cwk0grr9mqbzvouj	plugin::content-manager.explorer.create	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.01	2026-01-30 13:28:14.01	2026-01-30 13:28:14.011	\N	\N	\N
330	epdyehbzhwjr36g65qyyo95g	plugin::content-manager.explorer.create	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.022	2026-01-30 13:28:14.022	2026-01-30 13:28:14.022	\N	\N	\N
331	kdl6hxoh2zd3aj817ifg24wv	plugin::content-manager.explorer.create	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.03	2026-01-30 13:28:14.03	2026-01-30 13:28:14.03	\N	\N	\N
332	qszvlc3p03oclivp9ss4ml9s	plugin::content-manager.explorer.create	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.04	2026-01-30 13:28:14.04	2026-01-30 13:28:14.04	\N	\N	\N
333	w526jsfrtpd14ye87vk3ilb9	plugin::content-manager.explorer.create	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.051	2026-01-30 13:28:14.051	2026-01-30 13:28:14.051	\N	\N	\N
334	zfgwux1sai66zhz0we014ngb	plugin::content-manager.explorer.create	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.062	2026-01-30 13:28:14.062	2026-01-30 13:28:14.062	\N	\N	\N
335	q0ilwk760s9np6n6z17c1ham	plugin::content-manager.explorer.read	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.071	2026-01-30 13:28:14.071	2026-01-30 13:28:14.071	\N	\N	\N
362	p86mgk78lgi30g30ji84prgb	plugin::content-manager.explorer.publish	{}	api::partner.partner	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.38	2026-01-30 13:28:14.38	2026-01-30 13:28:14.38	\N	\N	\N
336	qfwa3ztr63lfgarbfu4wjbnl	plugin::content-manager.explorer.read	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.081	2026-01-30 13:28:14.081	2026-01-30 13:28:14.081	\N	\N	\N
337	nho6llz83t88rtjo2lm8cj63	plugin::content-manager.explorer.read	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.091	2026-01-30 13:28:14.091	2026-01-30 13:28:14.092	\N	\N	\N
338	ftbfb06l0qmqzfp1j37xeznc	plugin::content-manager.explorer.read	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.101	2026-01-30 13:28:14.101	2026-01-30 13:28:14.102	\N	\N	\N
339	s8s5zgfkjam2osi9xcrp9c75	plugin::content-manager.explorer.read	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.11	2026-01-30 13:28:14.11	2026-01-30 13:28:14.11	\N	\N	\N
340	eqn2ep8pem0738x1ef8xiqvd	plugin::content-manager.explorer.read	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.121	2026-01-30 13:28:14.121	2026-01-30 13:28:14.121	\N	\N	\N
341	kxzrcx7lvweninnbmglhjg5m	plugin::content-manager.explorer.read	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.13	2026-01-30 13:28:14.13	2026-01-30 13:28:14.13	\N	\N	\N
342	drdqn6w7ukrb5607reajq7cw	plugin::content-manager.explorer.read	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.139	2026-01-30 13:28:14.139	2026-01-30 13:28:14.139	\N	\N	\N
343	gna8sktg7uqnt0epof5nlfzi	plugin::content-manager.explorer.update	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.15	2026-01-30 13:28:14.15	2026-01-30 13:28:14.15	\N	\N	\N
344	lbhbfj42ti4rte29b37u9s32	plugin::content-manager.explorer.update	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.164	2026-01-30 13:28:14.164	2026-01-30 13:28:14.164	\N	\N	\N
345	j6a2vsotsha21bghx679r9e7	plugin::content-manager.explorer.update	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.175	2026-01-30 13:28:14.175	2026-01-30 13:28:14.175	\N	\N	\N
346	hst8h0nvr9a5juzjngy2o1e3	plugin::content-manager.explorer.update	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.189	2026-01-30 13:28:14.189	2026-01-30 13:28:14.189	\N	\N	\N
347	nrvxauwnggdoqu4qq21d6ho5	plugin::content-manager.explorer.update	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.209	2026-01-30 13:28:14.209	2026-01-30 13:28:14.209	\N	\N	\N
348	ixjflm9if5qm64gt6nz4va6y	plugin::content-manager.explorer.update	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.239	2026-01-30 13:28:14.239	2026-01-30 13:28:14.239	\N	\N	\N
349	gp79rjsvw6gkgm34flls531q	plugin::content-manager.explorer.update	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.252	2026-01-30 13:28:14.252	2026-01-30 13:28:14.252	\N	\N	\N
350	mh266nyrd6mrydxtqozh21r1	plugin::content-manager.explorer.update	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.261	2026-01-30 13:28:14.261	2026-01-30 13:28:14.261	\N	\N	\N
351	s914xkn0h5dq79e3b5v7vhdi	plugin::content-manager.explorer.delete	{}	api::case-studies-page.case-studies-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.269	2026-01-30 13:28:14.269	2026-01-30 13:28:14.269	\N	\N	\N
352	fwryuyr3599e3eci24hrjo6n	plugin::content-manager.explorer.delete	{}	api::demos-page.demos-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.278	2026-01-30 13:28:14.278	2026-01-30 13:28:14.278	\N	\N	\N
353	xygn0bu157gz7oba6pkrk2ds	plugin::content-manager.explorer.delete	{}	api::industries-page.industries-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.288	2026-01-30 13:28:14.288	2026-01-30 13:28:14.289	\N	\N	\N
354	hvf3t7tytymifaw9pe1utwzm	plugin::content-manager.explorer.delete	{}	api::partner.partner	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.298	2026-01-30 13:28:14.298	2026-01-30 13:28:14.298	\N	\N	\N
355	u5dbo4x5yf195a0uae7j5bml	plugin::content-manager.explorer.delete	{}	api::pricing-page.pricing-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.307	2026-01-30 13:28:14.307	2026-01-30 13:28:14.307	\N	\N	\N
356	z80hje7oscezb1o49ldwy0qn	plugin::content-manager.explorer.delete	{}	api::pricing-plan.pricing-plan	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.317	2026-01-30 13:28:14.317	2026-01-30 13:28:14.317	\N	\N	\N
357	bl5sljtf1x7395kstwdz2o3q	plugin::content-manager.explorer.delete	{}	api::solutions-page.solutions-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.328	2026-01-30 13:28:14.328	2026-01-30 13:28:14.328	\N	\N	\N
358	w96qrybtnkauhayp2yqlo4ao	plugin::content-manager.explorer.delete	{}	api::testimonial.testimonial	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.337	2026-01-30 13:28:14.337	2026-01-30 13:28:14.337	\N	\N	\N
359	uql4x1ei5w52wdxlav0m7rxr	plugin::content-manager.explorer.publish	{}	api::case-studies-page.case-studies-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.347	2026-01-30 13:28:14.347	2026-01-30 13:28:14.347	\N	\N	\N
360	a929wvqvffpofosdgrqlpvnc	plugin::content-manager.explorer.publish	{}	api::demos-page.demos-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.359	2026-01-30 13:28:14.359	2026-01-30 13:28:14.359	\N	\N	\N
361	ksshxe3k7la1zzcyesk3apgq	plugin::content-manager.explorer.publish	{}	api::industries-page.industries-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.37	2026-01-30 13:28:14.37	2026-01-30 13:28:14.37	\N	\N	\N
363	yfjmkckl9f341i9icbe285cc	plugin::content-manager.explorer.publish	{}	api::pricing-page.pricing-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.394	2026-01-30 13:28:14.394	2026-01-30 13:28:14.394	\N	\N	\N
364	lscd47a09gyvbxcu0m9r5yie	plugin::content-manager.explorer.publish	{}	api::pricing-plan.pricing-plan	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.408	2026-01-30 13:28:14.408	2026-01-30 13:28:14.408	\N	\N	\N
365	blajmy3ztt1vh3jhcp3r0lle	plugin::content-manager.explorer.publish	{}	api::solutions-page.solutions-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.421	2026-01-30 13:28:14.421	2026-01-30 13:28:14.422	\N	\N	\N
366	bni7anyy15q7kczl3p2li88y	plugin::content-manager.explorer.publish	{}	api::testimonial.testimonial	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.434	2026-01-30 13:28:14.434	2026-01-30 13:28:14.435	\N	\N	\N
\.


--
-- Data for Name: admin_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	2	1
2	2	2	2
3	3	2	3
4	4	2	4
5	5	2	5
6	6	2	6
7	7	3	1
8	8	3	2
9	9	3	3
10	10	3	4
11	11	3	5
12	12	3	6
13	13	1	1
14	14	1	2
15	15	1	3
16	16	1	4
17	17	1	5
18	18	1	6
19	19	1	7
20	20	1	8
21	21	1	9
22	22	1	10
23	23	1	11
24	24	1	12
25	25	1	13
26	26	1	14
27	27	1	15
28	28	1	16
29	29	1	17
30	30	1	18
31	31	1	19
32	32	1	20
33	33	1	21
34	34	1	22
35	35	1	23
36	36	1	24
37	37	1	25
38	38	1	26
39	39	1	27
40	40	1	28
41	41	1	29
42	42	1	30
43	43	1	31
44	44	1	32
45	45	1	33
46	46	1	34
47	47	1	35
48	48	1	36
49	49	1	37
50	50	1	38
51	51	1	39
52	52	1	40
53	53	1	41
54	54	1	42
55	55	1	43
56	56	1	44
57	57	1	45
58	58	1	46
59	59	1	47
60	60	1	48
61	61	1	49
62	62	1	50
63	63	1	51
64	64	1	52
65	65	1	53
66	66	1	54
67	67	1	55
68	68	1	56
69	69	1	57
70	70	1	58
71	71	1	59
72	72	1	60
73	73	1	61
74	74	1	62
75	75	1	63
76	76	1	64
77	77	1	65
78	78	1	66
79	79	1	67
80	80	1	68
81	81	1	69
242	242	1	70
243	243	1	71
244	244	1	72
245	245	1	73
246	246	1	74
247	247	1	75
248	248	1	76
249	249	1	77
250	250	1	78
251	251	1	79
252	252	1	80
253	253	1	81
254	254	1	82
255	255	1	83
256	256	1	84
257	257	1	85
258	258	1	86
259	259	1	87
260	260	1	88
261	261	1	89
262	262	1	90
263	263	1	91
264	264	1	92
265	265	1	93
266	266	1	94
267	267	1	95
268	268	1	96
269	269	1	97
270	270	1	98
271	271	1	99
272	272	1	100
273	273	1	101
274	274	1	102
275	275	1	103
276	276	1	104
277	277	1	105
278	278	1	106
279	279	1	107
280	280	1	108
281	281	1	109
282	282	1	110
283	283	1	111
284	284	1	112
285	285	1	113
286	286	1	114
287	287	1	115
288	288	1	116
289	289	1	117
290	290	1	118
291	291	1	119
292	292	1	120
293	293	1	121
294	294	1	122
295	295	1	123
296	296	1	124
297	297	1	125
298	298	1	126
299	299	1	127
300	300	1	128
301	301	1	129
302	302	1	130
303	303	1	131
304	304	1	132
305	305	1	133
306	306	1	134
307	307	1	135
308	308	1	136
309	309	1	137
310	310	1	138
311	311	1	139
312	312	1	140
313	313	1	141
314	314	1	142
315	315	1	143
316	316	1	144
317	317	1	145
318	318	1	146
319	319	1	147
320	320	1	148
321	321	1	149
322	322	1	150
323	323	1	151
324	324	1	152
325	325	1	153
326	326	1	154
327	327	1	155
328	328	1	156
329	329	1	157
330	330	1	158
331	331	1	159
332	332	1	160
333	333	1	161
334	334	1	162
335	335	1	163
336	336	1	164
337	337	1	165
338	338	1	166
339	339	1	167
340	340	1	168
341	341	1	169
342	342	1	170
343	343	1	171
344	344	1	172
345	345	1	173
346	346	1	174
347	347	1	175
348	348	1	176
349	349	1	177
350	350	1	178
351	351	1	179
352	352	1	180
353	353	1	181
354	354	1	182
355	355	1	183
356	356	1	184
357	357	1	185
358	358	1	186
359	359	1	187
360	360	1	188
361	361	1	189
362	362	1	190
363	363	1	191
364	364	1	192
365	365	1	193
366	366	1	194
\.


--
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_roles (id, document_id, name, code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	kuv1jr6f9f8r4w9m7grm9e4r	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2026-01-29 17:06:07.756	2026-01-29 17:06:07.756	2026-01-29 17:06:07.756	\N	\N	\N
2	n2hzdehwdu2nxw3yqopksayr	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2026-01-29 17:06:07.765	2026-01-29 17:06:07.765	2026-01-29 17:06:07.765	\N	\N	\N
3	il0jllpjtfih6dt7694d6t72	Author	strapi-author	Authors can manage the content they have created.	2026-01-29 17:06:07.772	2026-01-29 17:06:07.772	2026-01-29 17:06:07.772	\N	\N	\N
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_users (id, document_id, firstname, lastname, username, email, password, reset_password_token, registration_token, is_active, blocked, prefered_language, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	j7hyeueiz7kgq2v2u5lu7k07	Admin	User	\N	admin@arabiq.tech	$2a$10$EcjPOngbVn/TNYyKRGXBteNHPGdyuUE1Tqj7ryobLdJaRcdpBxrVu	\N	\N	t	f	\N	2026-01-29 17:09:23.188	2026-01-29 17:09:23.188	2026-01-29 17:09:23.188	\N	\N	\N
\.


--
-- Data for Name: admin_users_roles_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_users_roles_lnk (id, user_id, role_id, role_ord, user_ord) FROM stdin;
1	1	1	1	1
\.


--
-- Data for Name: case_studies; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.case_studies (id, document_id, slug, title, client, industry, summary, description, body, allowed_roles, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	skq1yjxd7770pz5in55zfgg7	suites-egypt-furniture-showroom	Suites Egypt: 340% Sales Growth with Virtual Showrooms	Suites Egypt	Retail	Premium furniture retailer transformed their sales approach with immersive virtual showrooms.	## The Challenge\n\nSuites Egypt faced challenges reaching customers outside Cairo and Alexandria.\n\n## The Solution\n\nArabiq created comprehensive virtual showrooms using Matterport Pro3 technology.\n\n## The Results\n\n- 340% increase in online sales\n- 12,000+ virtual visitors monthly\n- 45% reduction in return rates	\N	[]	2026-01-30 18:18:47.084	2026-01-30 18:18:47.084	\N	\N	\N	en
2	skq1yjxd7770pz5in55zfgg7	suites-egypt-furniture-showroom	Suites Egypt: 340% Sales Growth with Virtual Showrooms	Suites Egypt	Retail	Premium furniture retailer transformed their sales approach with immersive virtual showrooms.	## The Challenge\n\nSuites Egypt faced challenges reaching customers outside Cairo and Alexandria.\n\n## The Solution\n\nArabiq created comprehensive virtual showrooms using Matterport Pro3 technology.\n\n## The Results\n\n- 340% increase in online sales\n- 12,000+ virtual visitors monthly\n- 45% reduction in return rates	\N	[]	2026-01-30 18:18:47.084	2026-01-30 18:18:47.084	2026-01-30 18:18:47.087	\N	\N	en
4	gatf4vjguywsjam79sw73bsn	cairo-fashion-hub-virtual-mall	Cairo Fashion Hub: $2.1M Revenue in Year One	Cairo Fashion Hub	Retail	A 50-vendor fashion marketplace achieved remarkable success with virtual shopping mall.	## The Challenge\n\nCairo Fashion Hub wanted to create a unified online presence for 50+ independent fashion vendors.\n\n## The Solution\n\nArabiq designed a complete virtual mall experience.\n\n## The Results\n\n- $2.1M in sales in the first year\n- 200% increase in daily visitors	\N	[]	2026-01-30 18:18:47.118	2026-01-30 18:18:47.118	\N	\N	\N	en
5	gatf4vjguywsjam79sw73bsn	cairo-fashion-hub-virtual-mall	Cairo Fashion Hub: $2.1M Revenue in Year One	Cairo Fashion Hub	Retail	A 50-vendor fashion marketplace achieved remarkable success with virtual shopping mall.	## The Challenge\n\nCairo Fashion Hub wanted to create a unified online presence for 50+ independent fashion vendors.\n\n## The Solution\n\nArabiq designed a complete virtual mall experience.\n\n## The Results\n\n- $2.1M in sales in the first year\n- 200% increase in daily visitors	\N	[]	2026-01-30 18:18:47.118	2026-01-30 18:18:47.118	2026-01-30 18:18:47.121	\N	\N	en
7	qj6gtnln0t7cdf0691h03fkf	alexandria-national-museum	Alexandria Museum: 500K+ Global Visitors	Alexandria National Museum	Tourism	Egypt's historic museum achieved UNESCO recognition for digital preservation.	## The Challenge\n\nThe museum wanted to preserve treasures digitally while expanding global access.\n\n## The Solution\n\nArabiq conducted comprehensive 3D documentation with AI narration.\n\n## The Results\n\n- 500,000+ virtual visitors from 89 countries\n- UNESCO recognition for digital heritage	\N	[]	2026-01-30 18:18:47.149	2026-01-30 18:18:47.149	\N	\N	\N	en
8	qj6gtnln0t7cdf0691h03fkf	alexandria-national-museum	Alexandria Museum: 500K+ Global Visitors	Alexandria National Museum	Tourism	Egypt's historic museum achieved UNESCO recognition for digital preservation.	## The Challenge\n\nThe museum wanted to preserve treasures digitally while expanding global access.\n\n## The Solution\n\nArabiq conducted comprehensive 3D documentation with AI narration.\n\n## The Results\n\n- 500,000+ virtual visitors from 89 countries\n- UNESCO recognition for digital heritage	\N	[]	2026-01-30 18:18:47.149	2026-01-30 18:18:47.149	2026-01-30 18:18:47.151	\N	\N	en
10	ipj2ah2vev2rppewt3d0fycn	riyadh-motors-automotive	Riyadh Motors: 65% Faster Sales Cycle	Riyadh Motors	Retail	Premium automotive dealership achieved faster sales through virtual showrooms.	## The Challenge\n\nBusy executives couldn't visit the showroom, and international customers had no way to inspect cars.\n\n## The Solution\n\nArabiq created detailed virtual showrooms with interior exploration.\n\n## The Results\n\n- 65% faster sales cycle\n- SAR 4.2M in virtual showroom leads	\N	[]	2026-01-30 18:18:47.182	2026-01-30 18:18:47.182	\N	\N	\N	en
11	ipj2ah2vev2rppewt3d0fycn	riyadh-motors-automotive	Riyadh Motors: 65% Faster Sales Cycle	Riyadh Motors	Retail	Premium automotive dealership achieved faster sales through virtual showrooms.	## The Challenge\n\nBusy executives couldn't visit the showroom, and international customers had no way to inspect cars.\n\n## The Solution\n\nArabiq created detailed virtual showrooms with interior exploration.\n\n## The Results\n\n- 65% faster sales cycle\n- SAR 4.2M in virtual showroom leads	\N	[]	2026-01-30 18:18:47.182	2026-01-30 18:18:47.182	2026-01-30 18:18:47.184	\N	\N	en
13	u7b7vlfvpfl6eyam7oxml33d	gulf-tech-summit	Gulf Tech Summit: 10,000 Attendees	Gulf Tech Summit	Events	Annual technology conference transformed into a hybrid event.	## The Challenge\n\nThe conference was limited to 2,000 in-person attendees.\n\n## The Solution\n\nArabiq built a comprehensive virtual event platform.\n\n## The Results\n\n- 10,000 total attendees\n- 60% cost reduction vs physical events	\N	[]	2026-01-30 18:18:47.217	2026-01-30 18:18:47.217	\N	\N	\N	en
14	u7b7vlfvpfl6eyam7oxml33d	gulf-tech-summit	Gulf Tech Summit: 10,000 Attendees	Gulf Tech Summit	Events	Annual technology conference transformed into a hybrid event.	## The Challenge\n\nThe conference was limited to 2,000 in-person attendees.\n\n## The Solution\n\nArabiq built a comprehensive virtual event platform.\n\n## The Results\n\n- 10,000 total attendees\n- 60% cost reduction vs physical events	\N	[]	2026-01-30 18:18:47.217	2026-01-30 18:18:47.217	2026-01-30 18:18:47.22	\N	\N	en
\.


--
-- Data for Name: case_studies_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.case_studies_pages (id, document_id, hero_title, hero_subtitle, filter_all, filter_retail, filter_real_estate, filter_tourism, filter_events, filter_education, results_label, read_more_button, cta_title, cta_subtitle, cta_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	k1g4t5kgflzg3fxy6mtz4yqu	Success Stories	See how businesses across the region are achieving remarkable results with Arabiq	All Industries	Retail	Real Estate	Tourism	Events	Education	Key Results	Read Full Case Study	Ready to Write Your Success Story?	Join the growing list of businesses transforming their customer experience with Arabiq.	Start Your Transformation	2026-01-30 18:18:43.236	2026-01-30 18:18:43.236	\N	\N	\N	en
2	k1g4t5kgflzg3fxy6mtz4yqu	Success Stories	See how businesses across the region are achieving remarkable results with Arabiq	All Industries	Retail	Real Estate	Tourism	Events	Education	Key Results	Read Full Case Study	Ready to Write Your Success Story?	Join the growing list of businesses transforming their customer experience with Arabiq.	Start Your Transformation	2026-01-30 18:18:43.236	2026-01-30 18:18:43.236	2026-01-30 18:18:43.238	\N	\N	en
3	k1g4t5kgflzg3fxy6mtz4yqu	قصص النجاح	شاهد كيف تحقق الشركات عبر المنطقة نتائج ملحوظة مع Arabiq	جميع الصناعات	التجزئة	العقارات	السياحة	الفعاليات	التعليم	النتائج الرئيسية	اقرأ دراسة الحالة كاملة	جاهز لكتابة قصة نجاحك؟	انضم للقائمة المتزايدة من الشركات التي تحوّل تجربة عملائها مع Arabiq.	ابدأ تحولك	2026-01-30 18:18:43.261	2026-01-30 18:18:43.261	\N	\N	\N	ar
4	k1g4t5kgflzg3fxy6mtz4yqu	قصص النجاح	شاهد كيف تحقق الشركات عبر المنطقة نتائج ملحوظة مع Arabiq	جميع الصناعات	التجزئة	العقارات	السياحة	الفعاليات	التعليم	النتائج الرئيسية	اقرأ دراسة الحالة كاملة	جاهز لكتابة قصة نجاحك؟	انضم للقائمة المتزايدة من الشركات التي تحوّل تجربة عملائها مع Arabiq.	ابدأ تحولك	2026-01-30 18:18:43.261	2026-01-30 18:18:43.261	2026-01-30 18:18:43.264	\N	\N	ar
\.


--
-- Data for Name: contact_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.contact_pages (id, document_id, hero_title, hero_subtitle, form_title, name_label, email_label, phone_label, message_label, submit_button, info_title, address, email, phone, hours_title, hours_text, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	zdj851gva7noajn8sr0udmkv	Let's Create Something Amazing Together	Have a project in mind? We'd love to hear about it and show you what's possible.	Send Us a Message	Full Name	Email Address	Phone Number	Tell Us About Your Project	Send Message	Contact Information	King Fahd Road, Al Olaya District\nRiyadh 12211, Saudi Arabia	hello@arabiq.tech	+966 11 234 5678	Business Hours	Sunday - Thursday: 9:00 AM - 6:00 PM (AST)\nFriday - Saturday: Closed	2026-01-30 18:18:42.929	2026-01-30 18:18:42.929	2026-01-30 18:18:42.927	\N	\N	en
2	zdj851gva7noajn8sr0udmkv	لننشئ شيئاً رائعاً معاً	لديك مشروع في ذهنك؟ نحب أن نسمع عنه ونريك ما هو ممكن.	أرسل لنا رسالة	الاسم الكامل	البريد الإلكتروني	رقم الهاتف	أخبرنا عن مشروعك	إرسال الرسالة	معلومات التواصل	طريق الملك فهد، حي العليا\nالرياض 12211، المملكة العربية السعودية	hello@arabiq.tech	+966 11 234 5678	ساعات العمل	الأحد - الخميس: 9:00 صباحاً - 6:00 مساءً\nالجمعة - السبت: مغلق	2026-01-30 18:18:42.951	2026-01-30 18:18:42.951	2026-01-30 18:18:42.945	\N	\N	ar
\.


--
-- Data for Name: demos; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.demos (id, document_id, slug, title, demo_type, summary, description, body, icon, allowed_roles, access_level, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	j112ribw4k841vuisw962l9s	virtual-furniture-showroom	Virtual Furniture Showroom	matterport	Explore a fully interactive 3D furniture showroom with click-to-buy functionality	Experience how Arabiq transforms retail spaces into immersive shopping experiences.	\N	🏬	[]	public	2026-01-30 18:18:46.875	2026-01-30 18:18:46.875	\N	\N	\N	en
2	j112ribw4k841vuisw962l9s	virtual-furniture-showroom	Virtual Furniture Showroom	matterport	Explore a fully interactive 3D furniture showroom with click-to-buy functionality	Experience how Arabiq transforms retail spaces into immersive shopping experiences.	\N	🏬	[]	public	2026-01-30 18:18:46.875	2026-01-30 18:18:46.875	2026-01-30 18:18:46.879	\N	\N	en
4	l7pvfpt36e6lpyzs1h2ams5e	ai-shopping-assistant	Arabic AI Shopping Assistant	ai-chat	Chat with our intelligent Arabic assistant that understands dialects	Try our Arabic-first AI shopping assistant with dialect support.	\N	🤖	[]	public	2026-01-30 18:18:46.91	2026-01-30 18:18:46.91	\N	\N	\N	en
5	l7pvfpt36e6lpyzs1h2ams5e	ai-shopping-assistant	Arabic AI Shopping Assistant	ai-chat	Chat with our intelligent Arabic assistant that understands dialects	Try our Arabic-first AI shopping assistant with dialect support.	\N	🤖	[]	public	2026-01-30 18:18:46.91	2026-01-30 18:18:46.91	2026-01-30 18:18:46.913	\N	\N	en
7	vrpeuc4o1es5bixrakcojgbw	virtual-hotel-tour	Luxury Hotel Virtual Tour	matterport	Walk through a 5-star hotel and explore rooms and amenities	See how hotels use Arabiq to showcase their properties.	\N	🏨	[]	public	2026-01-30 18:18:46.943	2026-01-30 18:18:46.943	\N	\N	\N	en
8	vrpeuc4o1es5bixrakcojgbw	virtual-hotel-tour	Luxury Hotel Virtual Tour	matterport	Walk through a 5-star hotel and explore rooms and amenities	See how hotels use Arabiq to showcase their properties.	\N	🏨	[]	public	2026-01-30 18:18:46.943	2026-01-30 18:18:46.943	2026-01-30 18:18:46.946	\N	\N	en
10	zeeuzedqjrhzp8gmkkki41de	virtual-event-platform	Virtual Event Platform	vfair	Experience our VFair platform with virtual booths and networking	Explore our complete virtual event solution.	\N	🎪	[]	authenticated	2026-01-30 18:18:46.977	2026-01-30 18:18:46.977	\N	\N	\N	en
11	zeeuzedqjrhzp8gmkkki41de	virtual-event-platform	Virtual Event Platform	vfair	Experience our VFair platform with virtual booths and networking	Explore our complete virtual event solution.	\N	🎪	[]	authenticated	2026-01-30 18:18:46.977	2026-01-30 18:18:46.977	2026-01-30 18:18:46.979	\N	\N	en
13	a66vegjhpjstd93rnenqgv2x	real-estate-property-tour	Luxury Villa Property Tour	matterport	Explore a premium residential property with detailed walkthrough	See how real estate professionals use Arabiq to sell properties faster.	\N	🏠	[]	public	2026-01-30 18:18:47.008	2026-01-30 18:18:47.008	\N	\N	\N	en
14	a66vegjhpjstd93rnenqgv2x	real-estate-property-tour	Luxury Villa Property Tour	matterport	Explore a premium residential property with detailed walkthrough	See how real estate professionals use Arabiq to sell properties faster.	\N	🏠	[]	public	2026-01-30 18:18:47.008	2026-01-30 18:18:47.008	2026-01-30 18:18:47.015	\N	\N	en
16	i6mc8bb1lpjpgg2nxe3f9ptc	museum-virtual-gallery	Museum Virtual Gallery	matterport	Experience a cultural heritage site with AI-powered narration	Discover how museums use Arabiq for digital preservation.	\N	🏛️	[]	public	2026-01-30 18:18:47.048	2026-01-30 18:18:47.048	\N	\N	\N	en
17	i6mc8bb1lpjpgg2nxe3f9ptc	museum-virtual-gallery	Museum Virtual Gallery	matterport	Experience a cultural heritage site with AI-powered narration	Discover how museums use Arabiq for digital preservation.	\N	🏛️	[]	public	2026-01-30 18:18:47.048	2026-01-30 18:18:47.048	2026-01-30 18:18:47.051	\N	\N	en
\.


--
-- Data for Name: demos_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.demos_pages (id, document_id, hero_title, hero_subtitle, filter_all, filter_matterport, filter_ai, filter_vfair, access_public, access_auth, access_enterprise, try_now_button, request_access_button, cta_title, cta_subtitle, cta_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ykxxlf848bgvbfirle8citsp	Experience the Technology	Try our interactive demos and see how Arabiq can transform your business	All Demos	3D Tours	AI Features	Virtual Events	Public Demo	Login Required	Enterprise Only	Try Now	Request Access	Want a Custom Demo?	We'll create a personalized demo showing exactly how Arabiq works for your specific use case.	Request Custom Demo	2026-01-30 18:18:43.18	2026-01-30 18:18:43.18	\N	\N	\N	en
2	ykxxlf848bgvbfirle8citsp	Experience the Technology	Try our interactive demos and see how Arabiq can transform your business	All Demos	3D Tours	AI Features	Virtual Events	Public Demo	Login Required	Enterprise Only	Try Now	Request Access	Want a Custom Demo?	We'll create a personalized demo showing exactly how Arabiq works for your specific use case.	Request Custom Demo	2026-01-30 18:18:43.18	2026-01-30 18:18:43.18	2026-01-30 18:18:43.184	\N	\N	en
3	ykxxlf848bgvbfirle8citsp	جرّب التقنية	جرب عروضنا التفاعلية وشاهد كيف يمكن لـ Arabiq تحويل عملك	جميع العروض	جولات ثلاثية الأبعاد	ميزات الذكاء الاصطناعي	الفعاليات الافتراضية	عرض عام	يتطلب تسجيل الدخول	للمؤسسات فقط	جرب الآن	اطلب الوصول	تريد عرضاً مخصصاً؟	سننشئ عرضاً مخصصاً يُظهر بالضبط كيف يعمل Arabiq لحالتك المحددة.	اطلب عرضاً مخصصاً	2026-01-30 18:18:43.213	2026-01-30 18:18:43.213	\N	\N	\N	ar
4	ykxxlf848bgvbfirle8citsp	جرّب التقنية	جرب عروضنا التفاعلية وشاهد كيف يمكن لـ Arabiq تحويل عملك	جميع العروض	جولات ثلاثية الأبعاد	ميزات الذكاء الاصطناعي	الفعاليات الافتراضية	عرض عام	يتطلب تسجيل الدخول	للمؤسسات فقط	جرب الآن	اطلب الوصول	تريد عرضاً مخصصاً؟	سننشئ عرضاً مخصصاً يُظهر بالضبط كيف يعمل Arabiq لحالتك المحددة.	اطلب عرضاً مخصصاً	2026-01-30 18:18:43.213	2026-01-30 18:18:43.213	2026-01-30 18:18:43.217	\N	\N	ar
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.faqs (id, document_id, slug, category, "order", question, answer, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	tu18q591jjftd3d8raojpd16	what-is-matterport	technology	1	What is Matterport and how does it work?	Matterport is the industry-leading 3D capture technology that creates photorealistic digital twins of physical spaces. Our team uses Matterport Pro3 cameras to scan your space, capturing millions of data points that are processed into an immersive 3D model. The result is a virtual experience where visitors can navigate your space as if they were physically present, with the ability to look in any direction and move through the environment freely.	2026-01-30 18:18:46.096	2026-01-30 18:18:46.096	\N	\N	\N	en
2	tu18q591jjftd3d8raojpd16	what-is-matterport	technology	1	What is Matterport and how does it work?	Matterport is the industry-leading 3D capture technology that creates photorealistic digital twins of physical spaces. Our team uses Matterport Pro3 cameras to scan your space, capturing millions of data points that are processed into an immersive 3D model. The result is a virtual experience where visitors can navigate your space as if they were physically present, with the ability to look in any direction and move through the environment freely.	2026-01-30 18:18:46.096	2026-01-30 18:18:46.096	2026-01-30 18:18:46.098	\N	\N	en
3	tu18q591jjftd3d8raojpd16	what-is-matterport	technology	1	ما هي تقنية Matterport وكيف تعمل؟	Matterport هي التقنية الرائدة في الصناعة لالتقاط المساحات ثلاثية الأبعاد وإنشاء توائم رقمية فوتوغرافية للمساحات الفعلية. يستخدم فريقنا كاميرات Matterport Pro3 لمسح مساحتك، والتقاط ملايين نقاط البيانات التي تُعالج لإنشاء نموذج ثلاثي الأبعاد غامر. النتيجة هي تجربة افتراضية حيث يمكن للزوار التنقل في مساحتك كأنهم حاضرون فعلياً، مع القدرة على النظر في أي اتجاه والتحرك عبر البيئة بحرية.	2026-01-30 18:18:46.116	2026-01-30 18:18:46.116	\N	\N	\N	ar
4	tu18q591jjftd3d8raojpd16	what-is-matterport	technology	1	ما هي تقنية Matterport وكيف تعمل؟	Matterport هي التقنية الرائدة في الصناعة لالتقاط المساحات ثلاثية الأبعاد وإنشاء توائم رقمية فوتوغرافية للمساحات الفعلية. يستخدم فريقنا كاميرات Matterport Pro3 لمسح مساحتك، والتقاط ملايين نقاط البيانات التي تُعالج لإنشاء نموذج ثلاثي الأبعاد غامر. النتيجة هي تجربة افتراضية حيث يمكن للزوار التنقل في مساحتك كأنهم حاضرون فعلياً، مع القدرة على النظر في أي اتجاه والتحرك عبر البيئة بحرية.	2026-01-30 18:18:46.116	2026-01-30 18:18:46.116	2026-01-30 18:18:46.118	\N	\N	ar
5	e5va2j1ibgljs74b05z81k82	how-long-does-scanning-take	process	2	How long does the 3D scanning process take?	Scanning time depends on the size and complexity of your space. As a general guide: a small retail store (100-200 sqm) takes 1-2 hours, a medium showroom (200-500 sqm) takes 2-4 hours, and a large space (500+ sqm) may take 4-8 hours. Post-production and enhancement typically adds 24-48 hours. Our standard delivery is within 48 hours of scanning completion, though rush delivery can be arranged for urgent projects.	2026-01-30 18:18:46.136	2026-01-30 18:18:46.136	\N	\N	\N	en
6	e5va2j1ibgljs74b05z81k82	how-long-does-scanning-take	process	2	How long does the 3D scanning process take?	Scanning time depends on the size and complexity of your space. As a general guide: a small retail store (100-200 sqm) takes 1-2 hours, a medium showroom (200-500 sqm) takes 2-4 hours, and a large space (500+ sqm) may take 4-8 hours. Post-production and enhancement typically adds 24-48 hours. Our standard delivery is within 48 hours of scanning completion, though rush delivery can be arranged for urgent projects.	2026-01-30 18:18:46.136	2026-01-30 18:18:46.136	2026-01-30 18:18:46.138	\N	\N	en
7	e5va2j1ibgljs74b05z81k82	how-long-does-scanning-take	process	2	كم يستغرق المسح ثلاثي الأبعاد؟	يعتمد وقت المسح على حجم وتعقيد مساحتك. كدليل عام: متجر تجزئة صغير (100-200 متر مربع) يستغرق 1-2 ساعة، صالة عرض متوسطة (200-500 متر مربع) تستغرق 2-4 ساعات، والمساحات الكبيرة (500+ متر مربع) قد تستغرق 4-8 ساعات. ما بعد الإنتاج والتحسين يضيف عادة 24-48 ساعة. تسليمنا القياسي خلال 48 ساعة من اكتمال المسح، رغم أن التسليم السريع يمكن ترتيبه للمشاريع العاجلة.	2026-01-30 18:18:46.154	2026-01-30 18:18:46.154	\N	\N	\N	ar
8	e5va2j1ibgljs74b05z81k82	how-long-does-scanning-take	process	2	كم يستغرق المسح ثلاثي الأبعاد؟	يعتمد وقت المسح على حجم وتعقيد مساحتك. كدليل عام: متجر تجزئة صغير (100-200 متر مربع) يستغرق 1-2 ساعة، صالة عرض متوسطة (200-500 متر مربع) تستغرق 2-4 ساعات، والمساحات الكبيرة (500+ متر مربع) قد تستغرق 4-8 ساعات. ما بعد الإنتاج والتحسين يضيف عادة 24-48 ساعة. تسليمنا القياسي خلال 48 ساعة من اكتمال المسح، رغم أن التسليم السريع يمكن ترتيبه للمشاريع العاجلة.	2026-01-30 18:18:46.154	2026-01-30 18:18:46.154	2026-01-30 18:18:46.157	\N	\N	ar
9	v7ywhj37cvl764cezauz0f5b	pricing-model	pricing	3	How is Arabiq priced?	We offer flexible pricing to match your needs. One-time scanning projects start at SAR 5,000 for spaces up to 200 sqm, including scanning, post-production, and one year of hosting. Monthly platform subscriptions start at SAR 2,500/month and include unlimited updates, AI features, e-commerce integration, and analytics. Enterprise packages with custom requirements are quoted individually. All plans include our 30-day money-back guarantee.	2026-01-30 18:18:46.175	2026-01-30 18:18:46.175	\N	\N	\N	en
10	v7ywhj37cvl764cezauz0f5b	pricing-model	pricing	3	How is Arabiq priced?	We offer flexible pricing to match your needs. One-time scanning projects start at SAR 5,000 for spaces up to 200 sqm, including scanning, post-production, and one year of hosting. Monthly platform subscriptions start at SAR 2,500/month and include unlimited updates, AI features, e-commerce integration, and analytics. Enterprise packages with custom requirements are quoted individually. All plans include our 30-day money-back guarantee.	2026-01-30 18:18:46.175	2026-01-30 18:18:46.175	2026-01-30 18:18:46.177	\N	\N	en
11	v7ywhj37cvl764cezauz0f5b	pricing-model	pricing	3	كيف يتم تسعير خدمات Arabiq؟	نقدم تسعيراً مرناً يتناسب مع احتياجاتك. مشاريع المسح لمرة واحدة تبدأ من 5,000 ريال للمساحات حتى 200 متر مربع، شاملة المسح وما بعد الإنتاج وسنة واحدة من الاستضافة. اشتراكات المنصة الشهرية تبدأ من 2,500 ريال/شهرياً وتشمل تحديثات غير محدودة وميزات الذكاء الاصطناعي وتكامل التجارة الإلكترونية والتحليلات. باقات المؤسسات ذات المتطلبات المخصصة يتم تسعيرها بشكل فردي. جميع الخطط تشمل ضمان استرداد الأموال خلال 30 يوماً.	2026-01-30 18:18:46.189	2026-01-30 18:18:46.189	\N	\N	\N	ar
12	v7ywhj37cvl764cezauz0f5b	pricing-model	pricing	3	كيف يتم تسعير خدمات Arabiq؟	نقدم تسعيراً مرناً يتناسب مع احتياجاتك. مشاريع المسح لمرة واحدة تبدأ من 5,000 ريال للمساحات حتى 200 متر مربع، شاملة المسح وما بعد الإنتاج وسنة واحدة من الاستضافة. اشتراكات المنصة الشهرية تبدأ من 2,500 ريال/شهرياً وتشمل تحديثات غير محدودة وميزات الذكاء الاصطناعي وتكامل التجارة الإلكترونية والتحليلات. باقات المؤسسات ذات المتطلبات المخصصة يتم تسعيرها بشكل فردي. جميع الخطط تشمل ضمان استرداد الأموال خلال 30 يوماً.	2026-01-30 18:18:46.189	2026-01-30 18:18:46.189	2026-01-30 18:18:46.191	\N	\N	ar
17	ipjdyql10frdiatc57uf0y3p	integration-existing-website	technology	5	Can I integrate the virtual tour into my existing website?	Absolutely! We provide multiple integration options to fit your technical setup. The simplest method is an iframe embed code that works with any website platform including WordPress, Shopify, Wix, or custom HTML. For advanced integrations, we offer a JavaScript SDK that allows deeper customization, analytics tracking, and e-commerce connections. Our team provides full documentation and technical support to ensure smooth implementation.	2026-01-30 18:18:46.246	2026-01-30 18:18:46.246	\N	\N	\N	en
18	ipjdyql10frdiatc57uf0y3p	integration-existing-website	technology	5	Can I integrate the virtual tour into my existing website?	Absolutely! We provide multiple integration options to fit your technical setup. The simplest method is an iframe embed code that works with any website platform including WordPress, Shopify, Wix, or custom HTML. For advanced integrations, we offer a JavaScript SDK that allows deeper customization, analytics tracking, and e-commerce connections. Our team provides full documentation and technical support to ensure smooth implementation.	2026-01-30 18:18:46.246	2026-01-30 18:18:46.246	2026-01-30 18:18:46.248	\N	\N	en
29	gpr95kfdlvaugfr2br39ro41	data-security	security	8	How do you handle data security and privacy?	Security is fundamental to our platform. We maintain SOC 2 Type II compliance and offer data residency options in Saudi Arabia and UAE to meet local regulations. All data is encrypted in transit and at rest. We provide role-based access control, single sign-on (SSO) integration, and comprehensive audit logs. For enterprise customers, we offer dedicated infrastructure, custom security configurations, and compliance documentation for regulatory requirements.	2026-01-30 18:18:46.356	2026-01-30 18:18:46.356	\N	\N	\N	en
30	gpr95kfdlvaugfr2br39ro41	data-security	security	8	How do you handle data security and privacy?	Security is fundamental to our platform. We maintain SOC 2 Type II compliance and offer data residency options in Saudi Arabia and UAE to meet local regulations. All data is encrypted in transit and at rest. We provide role-based access control, single sign-on (SSO) integration, and comprehensive audit logs. For enterprise customers, we offer dedicated infrastructure, custom security configurations, and compliance documentation for regulatory requirements.	2026-01-30 18:18:46.356	2026-01-30 18:18:46.356	2026-01-30 18:18:46.358	\N	\N	en
31	gpr95kfdlvaugfr2br39ro41	data-security	security	8	كيف تتعاملون مع أمان البيانات والخصوصية؟	الأمان أساسي لمنصتنا. نحافظ على امتثال SOC 2 Type II ونقدم خيارات إقامة البيانات في السعودية والإمارات لتلبية اللوائح المحلية. جميع البيانات مشفرة أثناء النقل والتخزين. نوفر التحكم في الوصول المبني على الأدوار وتكامل تسجيل الدخول الموحد (SSO) وسجلات تدقيق شاملة. لعملاء المؤسسات، نقدم بنية تحتية مخصصة وتكوينات أمان مخصصة ووثائق امتثال للمتطلبات التنظيمية.	2026-01-30 18:18:46.371	2026-01-30 18:18:46.371	\N	\N	\N	ar
32	gpr95kfdlvaugfr2br39ro41	data-security	security	8	كيف تتعاملون مع أمان البيانات والخصوصية؟	الأمان أساسي لمنصتنا. نحافظ على امتثال SOC 2 Type II ونقدم خيارات إقامة البيانات في السعودية والإمارات لتلبية اللوائح المحلية. جميع البيانات مشفرة أثناء النقل والتخزين. نوفر التحكم في الوصول المبني على الأدوار وتكامل تسجيل الدخول الموحد (SSO) وسجلات تدقيق شاملة. لعملاء المؤسسات، نقدم بنية تحتية مخصصة وتكوينات أمان مخصصة ووثائق امتثال للمتطلبات التنظيمية.	2026-01-30 18:18:46.371	2026-01-30 18:18:46.371	2026-01-30 18:18:46.372	\N	\N	ar
37	q6hnl9m0dha5oj4z85bea7ib	roi-expectations	general	10	What kind of ROI can I expect?	ROI varies by industry and use case, but our clients typically see significant returns. Retail clients report 200-400% increases in online sales, 30-45% reduction in return rates, and expanded geographic reach. Real estate clients see 40-65% faster sales cycles and 2-3x more international inquiries. Event organizers reduce costs by 60-70% while reaching 5-10x more attendees. We provide analytics dashboards to track your specific ROI metrics, and our team can share relevant case studies from your industry during consultation.	2026-01-30 18:18:46.435	2026-01-30 18:18:46.435	\N	\N	\N	en
38	q6hnl9m0dha5oj4z85bea7ib	roi-expectations	general	10	What kind of ROI can I expect?	ROI varies by industry and use case, but our clients typically see significant returns. Retail clients report 200-400% increases in online sales, 30-45% reduction in return rates, and expanded geographic reach. Real estate clients see 40-65% faster sales cycles and 2-3x more international inquiries. Event organizers reduce costs by 60-70% while reaching 5-10x more attendees. We provide analytics dashboards to track your specific ROI metrics, and our team can share relevant case studies from your industry during consultation.	2026-01-30 18:18:46.435	2026-01-30 18:18:46.435	2026-01-30 18:18:46.437	\N	\N	en
13	qf5pq80t9a507yj8aj21zhn2	supported-countries	general	4	Which countries do you serve?	We operate across the entire MENA region with scanning teams based in Saudi Arabia (Riyadh, Jeddah), UAE (Dubai, Abu Dhabi), and Egypt (Cairo, Alexandria). We also serve Qatar, Kuwait, Bahrain, Oman, Jordan, Lebanon, Morocco, Tunisia, and Iraq through our regional partner network. For locations outside our direct coverage, we can arrange scanning through certified local partners or travel our team to your location.	2026-01-30 18:18:46.209	2026-01-30 18:18:46.209	\N	\N	\N	en
14	qf5pq80t9a507yj8aj21zhn2	supported-countries	general	4	Which countries do you serve?	We operate across the entire MENA region with scanning teams based in Saudi Arabia (Riyadh, Jeddah), UAE (Dubai, Abu Dhabi), and Egypt (Cairo, Alexandria). We also serve Qatar, Kuwait, Bahrain, Oman, Jordan, Lebanon, Morocco, Tunisia, and Iraq through our regional partner network. For locations outside our direct coverage, we can arrange scanning through certified local partners or travel our team to your location.	2026-01-30 18:18:46.209	2026-01-30 18:18:46.209	2026-01-30 18:18:46.211	\N	\N	en
15	qf5pq80t9a507yj8aj21zhn2	supported-countries	general	4	ما هي الدول التي تخدمونها؟	نعمل في جميع أنحاء منطقة الشرق الأوسط وشمال أفريقيا مع فرق مسح مقرها السعودية (الرياض، جدة) والإمارات (دبي، أبوظبي) ومصر (القاهرة، الإسكندرية). نخدم أيضاً قطر والكويت والبحرين وعُمان والأردن ولبنان والمغرب وتونس والعراق من خلال شبكة شركائنا الإقليميين. للمواقع خارج تغطيتنا المباشرة، يمكننا ترتيب المسح من خلال شركاء محليين معتمدين أو سفر فريقنا لموقعك.	2026-01-30 18:18:46.224	2026-01-30 18:18:46.224	\N	\N	\N	ar
16	qf5pq80t9a507yj8aj21zhn2	supported-countries	general	4	ما هي الدول التي تخدمونها؟	نعمل في جميع أنحاء منطقة الشرق الأوسط وشمال أفريقيا مع فرق مسح مقرها السعودية (الرياض، جدة) والإمارات (دبي، أبوظبي) ومصر (القاهرة، الإسكندرية). نخدم أيضاً قطر والكويت والبحرين وعُمان والأردن ولبنان والمغرب وتونس والعراق من خلال شبكة شركائنا الإقليميين. للمواقع خارج تغطيتنا المباشرة، يمكننا ترتيب المسح من خلال شركاء محليين معتمدين أو سفر فريقنا لموقعك.	2026-01-30 18:18:46.224	2026-01-30 18:18:46.224	2026-01-30 18:18:46.226	\N	\N	ar
21	ol7pspiirafqq04g4ary8rkp	arabic-ai-dialects	technology	6	Which Arabic dialects does your AI support?	Our Arabic AI Suite supports six major Arabic dialects: Gulf Arabic (Saudi, Emirati, Kuwaiti, Qatari, Bahraini), Egyptian Arabic, Levantine Arabic (Syrian, Lebanese, Jordanian, Palestinian), Iraqi Arabic, Maghrebi Arabic (Moroccan, Algerian, Tunisian), and Modern Standard Arabic (Fusha). The AI automatically detects which dialect a user is speaking and responds appropriately, creating a natural conversational experience for users across the region.	2026-01-30 18:18:46.282	2026-01-30 18:18:46.282	\N	\N	\N	en
22	ol7pspiirafqq04g4ary8rkp	arabic-ai-dialects	technology	6	Which Arabic dialects does your AI support?	Our Arabic AI Suite supports six major Arabic dialects: Gulf Arabic (Saudi, Emirati, Kuwaiti, Qatari, Bahraini), Egyptian Arabic, Levantine Arabic (Syrian, Lebanese, Jordanian, Palestinian), Iraqi Arabic, Maghrebi Arabic (Moroccan, Algerian, Tunisian), and Modern Standard Arabic (Fusha). The AI automatically detects which dialect a user is speaking and responds appropriately, creating a natural conversational experience for users across the region.	2026-01-30 18:18:46.282	2026-01-30 18:18:46.282	2026-01-30 18:18:46.285	\N	\N	en
23	ol7pspiirafqq04g4ary8rkp	arabic-ai-dialects	technology	6	ما هي اللهجات العربية التي يدعمها ذكاؤكم الاصطناعي؟	تدعم مجموعة الذكاء الاصطناعي العربية لدينا ست لهجات عربية رئيسية: العربية الخليجية (السعودية، الإماراتية، الكويتية، القطرية، البحرينية)، العربية المصرية، العربية الشامية (السورية، اللبنانية، الأردنية، الفلسطينية)، العربية العراقية، العربية المغاربية (المغربية، الجزائرية، التونسية)، والعربية الفصحى الحديثة. يكتشف الذكاء الاصطناعي تلقائياً أي لهجة يتحدث بها المستخدم ويستجيب بشكل مناسب، مما يخلق تجربة محادثة طبيعية للمستخدمين عبر المنطقة.	2026-01-30 18:18:46.298	2026-01-30 18:18:46.298	\N	\N	\N	ar
24	ol7pspiirafqq04g4ary8rkp	arabic-ai-dialects	technology	6	ما هي اللهجات العربية التي يدعمها ذكاؤكم الاصطناعي؟	تدعم مجموعة الذكاء الاصطناعي العربية لدينا ست لهجات عربية رئيسية: العربية الخليجية (السعودية، الإماراتية، الكويتية، القطرية، البحرينية)، العربية المصرية، العربية الشامية (السورية، اللبنانية، الأردنية، الفلسطينية)، العربية العراقية، العربية المغاربية (المغربية، الجزائرية، التونسية)، والعربية الفصحى الحديثة. يكتشف الذكاء الاصطناعي تلقائياً أي لهجة يتحدث بها المستخدم ويستجيب بشكل مناسب، مما يخلق تجربة محادثة طبيعية للمستخدمين عبر المنطقة.	2026-01-30 18:18:46.298	2026-01-30 18:18:46.298	2026-01-30 18:18:46.3	\N	\N	ar
39	q6hnl9m0dha5oj4z85bea7ib	roi-expectations	general	10	ما نوع العائد على الاستثمار الذي يمكن أن أتوقعه؟	يختلف العائد على الاستثمار حسب الصناعة وحالة الاستخدام، لكن عملاءنا يرون عادة عوائد كبيرة. عملاء التجزئة يبلغون عن زيادات 200-400% في المبيعات الإلكترونية، وتقليل 30-45% في معدلات الإرجاع، وتوسع الوصول الجغرافي. عملاء العقارات يرون دورات مبيعات أسرع 40-65% واستفسارات دولية 2-3 أضعاف. منظمو الفعاليات يقللون التكاليف 60-70% بينما يصلون لـ 5-10 أضعاف الحاضرين. نوفر لوحات تحليلات لتتبع مقاييس عائدك المحددة، ويمكن لفريقنا مشاركة دراسات حالة ذات صلة من صناعتك خلال الاستشارة.	2026-01-30 18:18:46.451	2026-01-30 18:18:46.451	\N	\N	\N	ar
19	ipjdyql10frdiatc57uf0y3p	integration-existing-website	technology	5	هل يمكنني دمج الجولة الافتراضية في موقعي الحالي؟	بالتأكيد! نوفر خيارات تكامل متعددة لتناسب إعدادك التقني. الطريقة الأبسط هي كود تضمين iframe الذي يعمل مع أي منصة موقع شاملة WordPress و Shopify و Wix أو HTML المخصص. للتكاملات المتقدمة، نقدم JavaScript SDK الذي يسمح بتخصيص أعمق وتتبع التحليلات واتصالات التجارة الإلكترونية. يوفر فريقنا توثيقاً كاملاً ودعماً تقنياً لضمان التطبيق السلس.	2026-01-30 18:18:46.263	2026-01-30 18:18:46.263	\N	\N	\N	ar
20	ipjdyql10frdiatc57uf0y3p	integration-existing-website	technology	5	هل يمكنني دمج الجولة الافتراضية في موقعي الحالي؟	بالتأكيد! نوفر خيارات تكامل متعددة لتناسب إعدادك التقني. الطريقة الأبسط هي كود تضمين iframe الذي يعمل مع أي منصة موقع شاملة WordPress و Shopify و Wix أو HTML المخصص. للتكاملات المتقدمة، نقدم JavaScript SDK الذي يسمح بتخصيص أعمق وتتبع التحليلات واتصالات التجارة الإلكترونية. يوفر فريقنا توثيقاً كاملاً ودعماً تقنياً لضمان التطبيق السلس.	2026-01-30 18:18:46.263	2026-01-30 18:18:46.263	2026-01-30 18:18:46.265	\N	\N	ar
25	jb4wfle7qm7svvk4sbhqy0hq	ecommerce-integration	technology	7	How does e-commerce integration work?	Our e-commerce integration connects your virtual space with your existing online store. When you tag a product in the 3D environment, it links directly to your product database. Customers can view product details, check real-time availability, see pricing, and add items to their cart—all without leaving the virtual experience. We support direct integration with Shopify, WooCommerce, Magento, Salla, and Zid. For other platforms, we provide API connections for custom integration.	2026-01-30 18:18:46.318	2026-01-30 18:18:46.318	\N	\N	\N	en
26	jb4wfle7qm7svvk4sbhqy0hq	ecommerce-integration	technology	7	How does e-commerce integration work?	Our e-commerce integration connects your virtual space with your existing online store. When you tag a product in the 3D environment, it links directly to your product database. Customers can view product details, check real-time availability, see pricing, and add items to their cart—all without leaving the virtual experience. We support direct integration with Shopify, WooCommerce, Magento, Salla, and Zid. For other platforms, we provide API connections for custom integration.	2026-01-30 18:18:46.318	2026-01-30 18:18:46.318	2026-01-30 18:18:46.32	\N	\N	en
27	jb4wfle7qm7svvk4sbhqy0hq	ecommerce-integration	technology	7	كيف يعمل تكامل التجارة الإلكترونية؟	يربط تكامل التجارة الإلكترونية لدينا مساحتك الافتراضية بمتجرك الإلكتروني الحالي. عندما تضع علامة على منتج في البيئة ثلاثية الأبعاد، يرتبط مباشرة بقاعدة بيانات منتجاتك. يمكن للعملاء عرض تفاصيل المنتج والتحقق من التوفر الفوري ورؤية الأسعار وإضافة العناصر لسلتهم — كل ذلك دون مغادرة التجربة الافتراضية. ندعم التكامل المباشر مع Shopify و WooCommerce و Magento وسلة وزد. للمنصات الأخرى، نوفر اتصالات API للتكامل المخصص.	2026-01-30 18:18:46.337	2026-01-30 18:18:46.337	\N	\N	\N	ar
28	jb4wfle7qm7svvk4sbhqy0hq	ecommerce-integration	technology	7	كيف يعمل تكامل التجارة الإلكترونية؟	يربط تكامل التجارة الإلكترونية لدينا مساحتك الافتراضية بمتجرك الإلكتروني الحالي. عندما تضع علامة على منتج في البيئة ثلاثية الأبعاد، يرتبط مباشرة بقاعدة بيانات منتجاتك. يمكن للعملاء عرض تفاصيل المنتج والتحقق من التوفر الفوري ورؤية الأسعار وإضافة العناصر لسلتهم — كل ذلك دون مغادرة التجربة الافتراضية. ندعم التكامل المباشر مع Shopify و WooCommerce و Magento وسلة وزد. للمنصات الأخرى، نوفر اتصالات API للتكامل المخصص.	2026-01-30 18:18:46.337	2026-01-30 18:18:46.337	2026-01-30 18:18:46.339	\N	\N	ar
33	eg3xmm6xkmgwsikgq0x6whr1	update-virtual-space	process	9	Can I update my virtual space after it's created?	Yes! Virtual spaces can be updated in two ways. For minor changes like updating product information, prices, or hotspot content, you can make changes yourself through our content management dashboard—no technical skills required. For physical changes to your space (new layout, renovations, new products on display), we offer re-scanning services at discounted rates for existing customers. Many clients on our subscription plans include quarterly or annual re-scans as part of their package.	2026-01-30 18:18:46.398	2026-01-30 18:18:46.398	\N	\N	\N	en
34	eg3xmm6xkmgwsikgq0x6whr1	update-virtual-space	process	9	Can I update my virtual space after it's created?	Yes! Virtual spaces can be updated in two ways. For minor changes like updating product information, prices, or hotspot content, you can make changes yourself through our content management dashboard—no technical skills required. For physical changes to your space (new layout, renovations, new products on display), we offer re-scanning services at discounted rates for existing customers. Many clients on our subscription plans include quarterly or annual re-scans as part of their package.	2026-01-30 18:18:46.398	2026-01-30 18:18:46.398	2026-01-30 18:18:46.401	\N	\N	en
35	eg3xmm6xkmgwsikgq0x6whr1	update-virtual-space	process	9	هل يمكنني تحديث مساحتي الافتراضية بعد إنشائها؟	نعم! يمكن تحديث المساحات الافتراضية بطريقتين. للتغييرات الطفيفة مثل تحديث معلومات المنتج أو الأسعار أو محتوى النقاط التفاعلية، يمكنك إجراء التغييرات بنفسك من خلال لوحة إدارة المحتوى لدينا — لا تحتاج مهارات تقنية. للتغييرات الفعلية في مساحتك (تخطيط جديد، تجديدات، منتجات جديدة معروضة)، نقدم خدمات إعادة المسح بأسعار مخفضة للعملاء الحاليين. العديد من العملاء على خطط الاشتراك لدينا يضمنون إعادة المسح الربعية أو السنوية كجزء من باقتهم.	2026-01-30 18:18:46.413	2026-01-30 18:18:46.413	\N	\N	\N	ar
36	eg3xmm6xkmgwsikgq0x6whr1	update-virtual-space	process	9	هل يمكنني تحديث مساحتي الافتراضية بعد إنشائها؟	نعم! يمكن تحديث المساحات الافتراضية بطريقتين. للتغييرات الطفيفة مثل تحديث معلومات المنتج أو الأسعار أو محتوى النقاط التفاعلية، يمكنك إجراء التغييرات بنفسك من خلال لوحة إدارة المحتوى لدينا — لا تحتاج مهارات تقنية. للتغييرات الفعلية في مساحتك (تخطيط جديد، تجديدات، منتجات جديدة معروضة)، نقدم خدمات إعادة المسح بأسعار مخفضة للعملاء الحاليين. العديد من العملاء على خطط الاشتراك لدينا يضمنون إعادة المسح الربعية أو السنوية كجزء من باقتهم.	2026-01-30 18:18:46.413	2026-01-30 18:18:46.413	2026-01-30 18:18:46.415	\N	\N	ar
40	q6hnl9m0dha5oj4z85bea7ib	roi-expectations	general	10	ما نوع العائد على الاستثمار الذي يمكن أن أتوقعه؟	يختلف العائد على الاستثمار حسب الصناعة وحالة الاستخدام، لكن عملاءنا يرون عادة عوائد كبيرة. عملاء التجزئة يبلغون عن زيادات 200-400% في المبيعات الإلكترونية، وتقليل 30-45% في معدلات الإرجاع، وتوسع الوصول الجغرافي. عملاء العقارات يرون دورات مبيعات أسرع 40-65% واستفسارات دولية 2-3 أضعاف. منظمو الفعاليات يقللون التكاليف 60-70% بينما يصلون لـ 5-10 أضعاف الحاضرين. نوفر لوحات تحليلات لتتبع مقاييس عائدك المحددة، ويمكن لفريقنا مشاركة دراسات حالة ذات صلة من صناعتك خلال الاستشارة.	2026-01-30 18:18:46.451	2026-01-30 18:18:46.451	2026-01-30 18:18:46.453	\N	\N	ar
\.


--
-- Data for Name: features; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.features (id, document_id, title, description, icon, "order", created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	midl6kjouzvf0w346s7eehce	Arabic-First AI	Native Arabic language understanding with support for Gulf, Egyptian, Levantine, and Maghrebi dialects. Our AI was trained on Arabic data and understands cultural context, not just translation.	🤖	1	2026-01-30 18:18:45.333	2026-01-30 18:18:45.333	\N	\N	\N	en
2	midl6kjouzvf0w346s7eehce	Arabic-First AI	Native Arabic language understanding with support for Gulf, Egyptian, Levantine, and Maghrebi dialects. Our AI was trained on Arabic data and understands cultural context, not just translation.	🤖	1	2026-01-30 18:18:45.333	2026-01-30 18:18:45.333	2026-01-30 18:18:45.335	\N	\N	en
3	midl6kjouzvf0w346s7eehce	ذكاء اصطناعي عربي أولاً	فهم لغة عربية أصلي مع دعم اللهجات الخليجية والمصرية والشامية والمغاربية. ذكاؤنا الاصطناعي مدرب على بيانات عربية ويفهم السياق الثقافي، وليس مجرد الترجمة.	🤖	1	2026-01-30 18:18:45.353	2026-01-30 18:18:45.353	\N	\N	\N	ar
4	midl6kjouzvf0w346s7eehce	ذكاء اصطناعي عربي أولاً	فهم لغة عربية أصلي مع دعم اللهجات الخليجية والمصرية والشامية والمغاربية. ذكاؤنا الاصطناعي مدرب على بيانات عربية ويفهم السياق الثقافي، وليس مجرد الترجمة.	🤖	1	2026-01-30 18:18:45.353	2026-01-30 18:18:45.353	2026-01-30 18:18:45.356	\N	\N	ar
5	jnbpf3xbfwd8s6mkrrv4qojl	Photorealistic 3D Capture	Industry-leading Matterport Pro3 technology captures spaces with millimeter precision and stunning visual fidelity. Every detail, every texture, every lighting nuance preserved in digital form.	📸	2	2026-01-30 18:18:45.375	2026-01-30 18:18:45.375	\N	\N	\N	en
6	jnbpf3xbfwd8s6mkrrv4qojl	Photorealistic 3D Capture	Industry-leading Matterport Pro3 technology captures spaces with millimeter precision and stunning visual fidelity. Every detail, every texture, every lighting nuance preserved in digital form.	📸	2	2026-01-30 18:18:45.375	2026-01-30 18:18:45.375	2026-01-30 18:18:45.377	\N	\N	en
7	jnbpf3xbfwd8s6mkrrv4qojl	التقاط ثلاثي الأبعاد فوتوغرافي	تقنية Matterport Pro3 الرائدة في الصناعة تلتقط المساحات بدقة ملليمترية ودقة بصرية مذهلة. كل تفصيل وكل ملمس وكل فارق إضاءة محفوظ في شكل رقمي.	📸	2	2026-01-30 18:18:45.391	2026-01-30 18:18:45.391	\N	\N	\N	ar
8	jnbpf3xbfwd8s6mkrrv4qojl	التقاط ثلاثي الأبعاد فوتوغرافي	تقنية Matterport Pro3 الرائدة في الصناعة تلتقط المساحات بدقة ملليمترية ودقة بصرية مذهلة. كل تفصيل وكل ملمس وكل فارق إضاءة محفوظ في شكل رقمي.	📸	2	2026-01-30 18:18:45.391	2026-01-30 18:18:45.391	2026-01-30 18:18:45.395	\N	\N	ar
9	t6u90g9zii4cf007q64e5ao9	48-Hour Delivery	From on-site scanning to fully enhanced virtual experience in just 48 hours. Our streamlined pipeline and regional presence ensure the fastest turnaround in the industry.	⚡	3	2026-01-30 18:18:45.411	2026-01-30 18:18:45.411	\N	\N	\N	en
10	t6u90g9zii4cf007q64e5ao9	48-Hour Delivery	From on-site scanning to fully enhanced virtual experience in just 48 hours. Our streamlined pipeline and regional presence ensure the fastest turnaround in the industry.	⚡	3	2026-01-30 18:18:45.411	2026-01-30 18:18:45.411	2026-01-30 18:18:45.413	\N	\N	en
11	t6u90g9zii4cf007q64e5ao9	تسليم خلال 48 ساعة	من المسح في الموقع إلى التجربة الافتراضية المحسنة بالكامل في 48 ساعة فقط. خط إنتاجنا المبسط وحضورنا الإقليمي يضمنان أسرع تسليم في الصناعة.	⚡	3	2026-01-30 18:18:45.425	2026-01-30 18:18:45.425	\N	\N	\N	ar
12	t6u90g9zii4cf007q64e5ao9	تسليم خلال 48 ساعة	من المسح في الموقع إلى التجربة الافتراضية المحسنة بالكامل في 48 ساعة فقط. خط إنتاجنا المبسط وحضورنا الإقليمي يضمنان أسرع تسليم في الصناعة.	⚡	3	2026-01-30 18:18:45.425	2026-01-30 18:18:45.425	2026-01-30 18:18:45.427	\N	\N	ar
13	q6sz4zmgh5g7vwrzivuqxy6t	MENA Payment Integration	Pre-integrated with regional payment gateways including PayTabs, Moyasar, PayFort, Tap, and Fawry. Cash on delivery, installments, and all local payment methods supported.	💳	4	2026-01-30 18:18:45.449	2026-01-30 18:18:45.449	\N	\N	\N	en
14	q6sz4zmgh5g7vwrzivuqxy6t	MENA Payment Integration	Pre-integrated with regional payment gateways including PayTabs, Moyasar, PayFort, Tap, and Fawry. Cash on delivery, installments, and all local payment methods supported.	💳	4	2026-01-30 18:18:45.449	2026-01-30 18:18:45.449	2026-01-30 18:18:45.451	\N	\N	en
15	q6sz4zmgh5g7vwrzivuqxy6t	تكامل بوابات دفع المنطقة	متكامل مسبقاً مع بوابات الدفع الإقليمية شاملة PayTabs و Moyasar و PayFort و Tap و فوري. الدفع عند الاستلام والتقسيط وجميع طرق الدفع المحلية مدعومة.	💳	4	2026-01-30 18:18:45.463	2026-01-30 18:18:45.463	\N	\N	\N	ar
16	q6sz4zmgh5g7vwrzivuqxy6t	تكامل بوابات دفع المنطقة	متكامل مسبقاً مع بوابات الدفع الإقليمية شاملة PayTabs و Moyasar و PayFort و Tap و فوري. الدفع عند الاستلام والتقسيط وجميع طرق الدفع المحلية مدعومة.	💳	4	2026-01-30 18:18:45.463	2026-01-30 18:18:45.463	2026-01-30 18:18:45.465	\N	\N	ar
17	lzx4x43kzzh1ty3qy5yo3hry	Advanced Analytics	Understand visitor behavior with heatmaps, attention tracking, conversion funnels, and ROI measurement. Know exactly which products get attention and optimize accordingly.	📊	5	2026-01-30 18:18:45.484	2026-01-30 18:18:45.484	\N	\N	\N	en
18	lzx4x43kzzh1ty3qy5yo3hry	Advanced Analytics	Understand visitor behavior with heatmaps, attention tracking, conversion funnels, and ROI measurement. Know exactly which products get attention and optimize accordingly.	📊	5	2026-01-30 18:18:45.484	2026-01-30 18:18:45.484	2026-01-30 18:18:45.486	\N	\N	en
19	lzx4x43kzzh1ty3qy5yo3hry	تحليلات متقدمة	افهم سلوك الزوار بخرائط الحرارة وتتبع الانتباه ومسارات التحويل وقياس العائد. اعرف بالضبط أي المنتجات تحصل على الانتباه وحسّن وفقاً لذلك.	📊	5	2026-01-30 18:18:45.5	2026-01-30 18:18:45.5	\N	\N	\N	ar
20	lzx4x43kzzh1ty3qy5yo3hry	تحليلات متقدمة	افهم سلوك الزوار بخرائط الحرارة وتتبع الانتباه ومسارات التحويل وقياس العائد. اعرف بالضبط أي المنتجات تحصل على الانتباه وحسّن وفقاً لذلك.	📊	5	2026-01-30 18:18:45.5	2026-01-30 18:18:45.5	2026-01-30 18:18:45.502	\N	\N	ar
21	gn0lthbliz56shcl2yjnlgw2	Mobile & AR Ready	Fully responsive on all devices with native iOS and Android AR support. Customers can visualize products in their space before purchasing using augmented reality.	📱	6	2026-01-30 18:18:45.521	2026-01-30 18:18:45.521	\N	\N	\N	en
22	gn0lthbliz56shcl2yjnlgw2	Mobile & AR Ready	Fully responsive on all devices with native iOS and Android AR support. Customers can visualize products in their space before purchasing using augmented reality.	📱	6	2026-01-30 18:18:45.521	2026-01-30 18:18:45.521	2026-01-30 18:18:45.523	\N	\N	en
23	gn0lthbliz56shcl2yjnlgw2	جاهز للجوال والواقع المعزز	متجاوب بالكامل على جميع الأجهزة مع دعم AR أصلي لـ iOS و Android. يمكن للعملاء تصور المنتجات في مساحتهم قبل الشراء باستخدام الواقع المعزز.	📱	6	2026-01-30 18:18:45.537	2026-01-30 18:18:45.537	\N	\N	\N	ar
24	gn0lthbliz56shcl2yjnlgw2	جاهز للجوال والواقع المعزز	متجاوب بالكامل على جميع الأجهزة مع دعم AR أصلي لـ iOS و Android. يمكن للعملاء تصور المنتجات في مساحتهم قبل الشراء باستخدام الواقع المعزز.	📱	6	2026-01-30 18:18:45.537	2026-01-30 18:18:45.537	2026-01-30 18:18:45.539	\N	\N	ar
25	qaagrpp7iu495nq6rhigp911	Enterprise Security	SOC 2 compliant infrastructure with data residency options in Saudi Arabia and UAE. Role-based access, SSO integration, and comprehensive audit logs.	🔒	7	2026-01-30 18:18:45.561	2026-01-30 18:18:45.561	\N	\N	\N	en
26	qaagrpp7iu495nq6rhigp911	Enterprise Security	SOC 2 compliant infrastructure with data residency options in Saudi Arabia and UAE. Role-based access, SSO integration, and comprehensive audit logs.	🔒	7	2026-01-30 18:18:45.561	2026-01-30 18:18:45.561	2026-01-30 18:18:45.563	\N	\N	en
27	qaagrpp7iu495nq6rhigp911	أمان على مستوى المؤسسات	بنية تحتية متوافقة مع SOC 2 مع خيارات إقامة البيانات في السعودية والإمارات. وصول مبني على الأدوار وتكامل SSO وسجلات تدقيق شاملة.	🔒	7	2026-01-30 18:18:45.576	2026-01-30 18:18:45.576	\N	\N	\N	ar
28	qaagrpp7iu495nq6rhigp911	أمان على مستوى المؤسسات	بنية تحتية متوافقة مع SOC 2 مع خيارات إقامة البيانات في السعودية والإمارات. وصول مبني على الأدوار وتكامل SSO وسجلات تدقيق شاملة.	🔒	7	2026-01-30 18:18:45.576	2026-01-30 18:18:45.576	2026-01-30 18:18:45.579	\N	\N	ar
29	vxcazdvukyt62ad8ozwmvntk	Global CDN Delivery	Lightning-fast load times worldwide with edge servers across MENA, Europe, and Asia. 99.9% uptime SLA with automatic failover and redundancy.	🌐	8	2026-01-30 18:18:45.598	2026-01-30 18:18:45.598	\N	\N	\N	en
30	vxcazdvukyt62ad8ozwmvntk	Global CDN Delivery	Lightning-fast load times worldwide with edge servers across MENA, Europe, and Asia. 99.9% uptime SLA with automatic failover and redundancy.	🌐	8	2026-01-30 18:18:45.598	2026-01-30 18:18:45.598	2026-01-30 18:18:45.6	\N	\N	en
31	vxcazdvukyt62ad8ozwmvntk	توصيل CDN عالمي	أوقات تحميل سريعة للغاية حول العالم مع خوادم حافة في الشرق الأوسط وأوروبا وآسيا. اتفاقية وقت تشغيل 99.9% مع تجاوز فشل تلقائي وتكرار.	🌐	8	2026-01-30 18:18:45.613	2026-01-30 18:18:45.613	\N	\N	\N	ar
32	vxcazdvukyt62ad8ozwmvntk	توصيل CDN عالمي	أوقات تحميل سريعة للغاية حول العالم مع خوادم حافة في الشرق الأوسط وأوروبا وآسيا. اتفاقية وقت تشغيل 99.9% مع تجاوز فشل تلقائي وتكرار.	🌐	8	2026-01-30 18:18:45.613	2026-01-30 18:18:45.613	2026-01-30 18:18:45.615	\N	\N	ar
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files (id, document_id, name, alternative_text, caption, width, height, formats, hash, ext, mime, size, url, preview_url, provider, provider_metadata, folder_path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: files_folder_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files_folder_lnk (id, file_id, folder_id, file_ord) FROM stdin;
\.


--
-- Data for Name: files_related_mph; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files_related_mph (id, file_id, related_id, related_type, field, "order") FROM stdin;
\.


--
-- Data for Name: homepages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.homepages (id, document_id, hero_title, hero_subtitle, hero_primary_cta, hero_secondary_cta, hero_badge, trust_award, trust_global, trust_fast, show_stats_section, show_trusted_by_section, trusted_by_title, show_how_it_works_section, how_it_works_title, how_it_works_subtitle, show_features_section, features_title, features_subtitle, show_solutions_section, solutions_title, solutions_subtitle, show_industries_section, industries_title, industries_subtitle, show_case_studies_section, case_studies_title, case_studies_subtitle, show_demos_section, demos_title, demos_subtitle, show_cta_section, cta_title, cta_subtitle, cta_primary_button, cta_secondary_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	fd3ws4k73m7nfjicvtb0jr6l	Transform Your Business Into a Virtual Experience	Create immersive 3D spaces for retail, real estate, events, and more. Powered by Matterport and Arabic AI.	Book a Demo	Explore Solutions	#1 Platform in the Region	2024 MENA Tech Award Winner	Serving 12 countries	48-hour delivery	t	t	Trusted by Leading Brands	t	How It Works	From concept to launch in 4 simple steps	t	Why Choose Arabiq	The most comprehensive virtual experience platform for MENA	t	Our Solutions	Tailored virtual experiences for every industry	t	Industries We Serve	Virtual transformation across all sectors	t	Success Stories	Real results from real businesses	t	Try Our Demos	Experience the technology firsthand	t	Ready to Go Virtual?	Join 100+ businesses transforming their customer experience	Schedule a Demo	Contact Sales	2026-01-30 18:18:42.809	2026-01-30 18:18:42.809	\N	\N	\N	en
2	fd3ws4k73m7nfjicvtb0jr6l	Transform Your Business Into a Virtual Experience	Create immersive 3D spaces for retail, real estate, events, and more. Powered by Matterport and Arabic AI.	Book a Demo	Explore Solutions	#1 Platform in the Region	2024 MENA Tech Award Winner	Serving 12 countries	48-hour delivery	t	t	Trusted by Leading Brands	t	How It Works	From concept to launch in 4 simple steps	t	Why Choose Arabiq	The most comprehensive virtual experience platform for MENA	t	Our Solutions	Tailored virtual experiences for every industry	t	Industries We Serve	Virtual transformation across all sectors	t	Success Stories	Real results from real businesses	t	Try Our Demos	Experience the technology firsthand	t	Ready to Go Virtual?	Join 100+ businesses transforming their customer experience	Schedule a Demo	Contact Sales	2026-01-30 18:18:42.809	2026-01-30 18:18:42.809	2026-01-30 18:18:42.817	\N	\N	en
3	fd3ws4k73m7nfjicvtb0jr6l	حوّل أعمالك إلى تجربة افتراضية مذهلة	أنشئ مساحات ثلاثية الأبعاد تفاعلية للتجزئة والعقارات والفعاليات — مدعومة بتقنية Matterport والذكاء الاصطناعي العربي	احجز عرضاً توضيحياً	اكتشف حلولنا	المنصة الأولى في المنطقة	الفائز بجائزة التقنية للشرق الأوسط 2024	نخدم 12 دولة	تسليم خلال 48 ساعة	t	t	موثوق به من قبل العلامات التجارية الرائدة	t	كيف نعمل	من الفكرة إلى الإطلاق في 4 خطوات بسيطة	t	لماذا تختار Arabiq	مبنية خصيصاً للسوق العربي بأحدث التقنيات	t	حلولنا	أدوات تحول رقمي شاملة لأعمالك	t	الصناعات التي نخدمها	التحول الافتراضي عبر جميع القطاعات	t	قصص النجاح	نتائج حقيقية من شركات حقيقية	t	جرّب عروضنا	اختبر التقنية بنفسك	t	مستعد لتحويل أعمالك؟	انضم إلى 100+ شركة تستخدم Arabiq بالفعل لإنشاء تجارب رقمية غامرة.	احصل على مسح 3D مجاني	جدولة عرض	2026-01-30 18:18:42.857	2026-01-30 18:18:42.857	\N	\N	\N	ar
4	fd3ws4k73m7nfjicvtb0jr6l	حوّل أعمالك إلى تجربة افتراضية مذهلة	أنشئ مساحات ثلاثية الأبعاد تفاعلية للتجزئة والعقارات والفعاليات — مدعومة بتقنية Matterport والذكاء الاصطناعي العربي	احجز عرضاً توضيحياً	اكتشف حلولنا	المنصة الأولى في المنطقة	الفائز بجائزة التقنية للشرق الأوسط 2024	نخدم 12 دولة	تسليم خلال 48 ساعة	t	t	موثوق به من قبل العلامات التجارية الرائدة	t	كيف نعمل	من الفكرة إلى الإطلاق في 4 خطوات بسيطة	t	لماذا تختار Arabiq	مبنية خصيصاً للسوق العربي بأحدث التقنيات	t	حلولنا	أدوات تحول رقمي شاملة لأعمالك	t	الصناعات التي نخدمها	التحول الافتراضي عبر جميع القطاعات	t	قصص النجاح	نتائج حقيقية من شركات حقيقية	t	جرّب عروضنا	اختبر التقنية بنفسك	t	مستعد لتحويل أعمالك؟	انضم إلى 100+ شركة تستخدم Arabiq بالفعل لإنشاء تجارب رقمية غامرة.	احصل على مسح 3D مجاني	جدولة عرض	2026-01-30 18:18:42.857	2026-01-30 18:18:42.857	2026-01-30 18:18:42.861	\N	\N	ar
\.


--
-- Data for Name: i18n_locale; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.i18n_locale (id, document_id, name, code, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	rbegwf4a7cpxlujauiepgr2c	English (en)	en	2026-01-29 17:06:07.632	2026-01-29 17:06:07.632	2026-01-29 17:06:07.633	\N	\N	\N
2	uvciv9hntfaf9ihm3kz2v1cj	Arabic (ar)	ar	2026-01-29 18:03:56.991	2026-01-29 18:03:56.991	2026-01-29 18:03:56.992	1	1	\N
\.


--
-- Data for Name: industries; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.industries (id, document_id, slug, title, summary, description, body, icon, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	bn3pijiba064cpswricg4tyj	retail-ecommerce	Retail & E-commerce	Virtual showrooms, 3D product displays, and immersive shopping experiences.	## Revolutionize Your Retail Experience\n\nThe retail landscape is evolving. Arabiq helps retailers create immersive shopping experiences.	\N	🛍️	2026-01-30 18:18:47.453	2026-01-30 18:18:47.453	\N	\N	\N	en
2	bn3pijiba064cpswricg4tyj	retail-ecommerce	Retail & E-commerce	Virtual showrooms, 3D product displays, and immersive shopping experiences.	## Revolutionize Your Retail Experience\n\nThe retail landscape is evolving. Arabiq helps retailers create immersive shopping experiences.	\N	🛍️	2026-01-30 18:18:47.453	2026-01-30 18:18:47.453	2026-01-30 18:18:47.455	\N	\N	en
4	mxl9hxj99r2zpiiqb4kmu1mv	real-estate	Real Estate	Virtual property tours, off-plan visualization, and digital twin listings.	## Transform Property Sales\n\nReal estate is inherently visual. Arabiq helps developers showcase properties in the most compelling way.	\N	🏢	2026-01-30 18:18:47.484	2026-01-30 18:18:47.484	\N	\N	\N	en
5	mxl9hxj99r2zpiiqb4kmu1mv	real-estate	Real Estate	Virtual property tours, off-plan visualization, and digital twin listings.	## Transform Property Sales\n\nReal estate is inherently visual. Arabiq helps developers showcase properties in the most compelling way.	\N	🏢	2026-01-30 18:18:47.484	2026-01-30 18:18:47.484	2026-01-30 18:18:47.487	\N	\N	en
7	fjz0xzgvdm0hkx4tv4knpeev	tourism-hospitality	Tourism & Hospitality	Hotel virtual tours, restaurant previews, and destination marketing.	## Inspire Travelers to Book\n\nIn hospitality, the experience is the product. Arabiq helps showcase offerings in immersive 3D.	\N	✈️	2026-01-30 18:18:47.517	2026-01-30 18:18:47.517	\N	\N	\N	en
8	fjz0xzgvdm0hkx4tv4knpeev	tourism-hospitality	Tourism & Hospitality	Hotel virtual tours, restaurant previews, and destination marketing.	## Inspire Travelers to Book\n\nIn hospitality, the experience is the product. Arabiq helps showcase offerings in immersive 3D.	\N	✈️	2026-01-30 18:18:47.517	2026-01-30 18:18:47.517	2026-01-30 18:18:47.519	\N	\N	en
10	ahi4chuql6uq3voxc68rybjd	events-exhibitions	Events & Exhibitions	Virtual trade shows, hybrid conferences, and digital exhibition halls.	## Reimagine Your Events\n\nPhysical events have limitations. Arabiq's virtual event solutions remove these barriers.	\N	🎪	2026-01-30 18:18:47.563	2026-01-30 18:18:47.563	\N	\N	\N	en
11	ahi4chuql6uq3voxc68rybjd	events-exhibitions	Events & Exhibitions	Virtual trade shows, hybrid conferences, and digital exhibition halls.	## Reimagine Your Events\n\nPhysical events have limitations. Arabiq's virtual event solutions remove these barriers.	\N	🎪	2026-01-30 18:18:47.563	2026-01-30 18:18:47.563	2026-01-30 18:18:47.569	\N	\N	en
13	q25s86r5acs1poy2jjp1glw7	education	Education	Virtual campus tours, immersive learning environments, and lab simulations.	## Transform Educational Experiences\n\nEducation is evolving beyond the traditional classroom. Arabiq helps create immersive learning experiences.	\N	🎓	2026-01-30 18:18:47.612	2026-01-30 18:18:47.612	\N	\N	\N	en
14	q25s86r5acs1poy2jjp1glw7	education	Education	Virtual campus tours, immersive learning environments, and lab simulations.	## Transform Educational Experiences\n\nEducation is evolving beyond the traditional classroom. Arabiq helps create immersive learning experiences.	\N	🎓	2026-01-30 18:18:47.612	2026-01-30 18:18:47.612	2026-01-30 18:18:47.615	\N	\N	en
16	y6jskmvdb2f7ac83uglzuqxn	healthcare	Healthcare	Hospital virtual tours, patient wayfinding, and medical training simulations.	## Improving Healthcare Experiences\n\nNavigating healthcare facilities can be stressful. Arabiq helps create welcoming digital experiences.	\N	⚕️	2026-01-30 18:18:47.643	2026-01-30 18:18:47.643	\N	\N	\N	en
17	y6jskmvdb2f7ac83uglzuqxn	healthcare	Healthcare	Hospital virtual tours, patient wayfinding, and medical training simulations.	## Improving Healthcare Experiences\n\nNavigating healthcare facilities can be stressful. Arabiq helps create welcoming digital experiences.	\N	⚕️	2026-01-30 18:18:47.643	2026-01-30 18:18:47.643	2026-01-30 18:18:47.646	\N	\N	en
\.


--
-- Data for Name: industries_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.industries_pages (id, document_id, hero_title, hero_subtitle, stats_title, cta_title, cta_subtitle, cta_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ifdaxgwgkmwhyqnymx4jr7cj	Virtual Solutions for Every Industry	We've helped businesses across all sectors transform their customer experiences with immersive 3D technology	Industry Impact	Ready to Transform Your Industry?	Join the leading businesses in your sector who are already using Arabiq.	Get Industry-Specific Demo	2026-01-30 18:18:43.135	2026-01-30 18:18:43.135	\N	\N	\N	en
2	ifdaxgwgkmwhyqnymx4jr7cj	Virtual Solutions for Every Industry	We've helped businesses across all sectors transform their customer experiences with immersive 3D technology	Industry Impact	Ready to Transform Your Industry?	Join the leading businesses in your sector who are already using Arabiq.	Get Industry-Specific Demo	2026-01-30 18:18:43.135	2026-01-30 18:18:43.135	2026-01-30 18:18:43.138	\N	\N	en
3	ifdaxgwgkmwhyqnymx4jr7cj	حلول افتراضية لكل صناعة	ساعدنا الشركات عبر جميع القطاعات في تحويل تجارب عملائها بتقنية ثلاثية الأبعاد الغامرة	التأثير على الصناعة	جاهز لتحويل صناعتك؟	انضم للشركات الرائدة في قطاعك التي تستخدم Arabiq بالفعل.	احصل على عرض مخصص لصناعتك	2026-01-30 18:18:43.159	2026-01-30 18:18:43.159	\N	\N	\N	ar
4	ifdaxgwgkmwhyqnymx4jr7cj	حلول افتراضية لكل صناعة	ساعدنا الشركات عبر جميع القطاعات في تحويل تجارب عملائها بتقنية ثلاثية الأبعاد الغامرة	التأثير على الصناعة	جاهز لتحويل صناعتك؟	انضم للشركات الرائدة في قطاعك التي تستخدم Arabiq بالفعل.	احصل على عرض مخصص لصناعتك	2026-01-30 18:18:43.159	2026-01-30 18:18:43.159	2026-01-30 18:18:43.162	\N	\N	ar
\.


--
-- Data for Name: nav_items; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.nav_items (id, document_id, label, href, location, "order", is_external, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	raegc8yaa8dmtsawsoel2fgo	Home	/	header	1	f	2026-01-30 18:18:43.294	2026-01-30 18:18:43.294	\N	\N	\N	en
2	raegc8yaa8dmtsawsoel2fgo	Home	/	header	1	f	2026-01-30 18:18:43.294	2026-01-30 18:18:43.294	2026-01-30 18:18:43.298	\N	\N	en
3	raegc8yaa8dmtsawsoel2fgo	الرئيسية	/	header	1	f	2026-01-30 18:18:43.319	2026-01-30 18:18:43.319	\N	\N	\N	ar
4	raegc8yaa8dmtsawsoel2fgo	الرئيسية	/	header	1	f	2026-01-30 18:18:43.319	2026-01-30 18:18:43.319	2026-01-30 18:18:43.322	\N	\N	ar
5	l4sgcr496pyn8zq43r8i4n37	Solutions	/solutions	header	2	f	2026-01-30 18:18:43.343	2026-01-30 18:18:43.343	\N	\N	\N	en
6	l4sgcr496pyn8zq43r8i4n37	Solutions	/solutions	header	2	f	2026-01-30 18:18:43.343	2026-01-30 18:18:43.343	2026-01-30 18:18:43.346	\N	\N	en
7	l4sgcr496pyn8zq43r8i4n37	الحلول	/solutions	header	2	f	2026-01-30 18:18:43.364	2026-01-30 18:18:43.364	\N	\N	\N	ar
8	l4sgcr496pyn8zq43r8i4n37	الحلول	/solutions	header	2	f	2026-01-30 18:18:43.364	2026-01-30 18:18:43.364	2026-01-30 18:18:43.366	\N	\N	ar
9	hrzgt72ub8jm4e3ftrms0uyp	Industries	/industries	header	3	f	2026-01-30 18:18:43.385	2026-01-30 18:18:43.385	\N	\N	\N	en
10	hrzgt72ub8jm4e3ftrms0uyp	Industries	/industries	header	3	f	2026-01-30 18:18:43.385	2026-01-30 18:18:43.385	2026-01-30 18:18:43.387	\N	\N	en
11	hrzgt72ub8jm4e3ftrms0uyp	الصناعات	/industries	header	3	f	2026-01-30 18:18:43.404	2026-01-30 18:18:43.404	\N	\N	\N	ar
12	hrzgt72ub8jm4e3ftrms0uyp	الصناعات	/industries	header	3	f	2026-01-30 18:18:43.404	2026-01-30 18:18:43.404	2026-01-30 18:18:43.407	\N	\N	ar
13	yvfzbkoejrivevwyonbsmlmt	Case Studies	/case-studies	header	4	f	2026-01-30 18:18:43.431	2026-01-30 18:18:43.431	\N	\N	\N	en
14	yvfzbkoejrivevwyonbsmlmt	Case Studies	/case-studies	header	4	f	2026-01-30 18:18:43.431	2026-01-30 18:18:43.431	2026-01-30 18:18:43.433	\N	\N	en
15	yvfzbkoejrivevwyonbsmlmt	دراسات الحالة	/case-studies	header	4	f	2026-01-30 18:18:43.451	2026-01-30 18:18:43.451	\N	\N	\N	ar
16	yvfzbkoejrivevwyonbsmlmt	دراسات الحالة	/case-studies	header	4	f	2026-01-30 18:18:43.451	2026-01-30 18:18:43.451	2026-01-30 18:18:43.453	\N	\N	ar
17	xgakndqsc0ehefkx5cizlnw7	Pricing	/pricing	header	5	f	2026-01-30 18:18:43.477	2026-01-30 18:18:43.477	\N	\N	\N	en
18	xgakndqsc0ehefkx5cizlnw7	Pricing	/pricing	header	5	f	2026-01-30 18:18:43.477	2026-01-30 18:18:43.477	2026-01-30 18:18:43.48	\N	\N	en
19	xgakndqsc0ehefkx5cizlnw7	الأسعار	/pricing	header	5	f	2026-01-30 18:18:43.497	2026-01-30 18:18:43.497	\N	\N	\N	ar
20	xgakndqsc0ehefkx5cizlnw7	الأسعار	/pricing	header	5	f	2026-01-30 18:18:43.497	2026-01-30 18:18:43.497	2026-01-30 18:18:43.499	\N	\N	ar
21	a0k9mfymdectpn282l1vajck	Demos	/demos	header	6	f	2026-01-30 18:18:43.522	2026-01-30 18:18:43.522	\N	\N	\N	en
22	a0k9mfymdectpn282l1vajck	Demos	/demos	header	6	f	2026-01-30 18:18:43.522	2026-01-30 18:18:43.522	2026-01-30 18:18:43.525	\N	\N	en
23	a0k9mfymdectpn282l1vajck	العروض	/demos	header	6	f	2026-01-30 18:18:43.541	2026-01-30 18:18:43.541	\N	\N	\N	ar
24	a0k9mfymdectpn282l1vajck	العروض	/demos	header	6	f	2026-01-30 18:18:43.541	2026-01-30 18:18:43.541	2026-01-30 18:18:43.543	\N	\N	ar
25	w40u32x8qr65s1s4dcslqcfx	About	/about	header	7	f	2026-01-30 18:18:43.561	2026-01-30 18:18:43.561	\N	\N	\N	en
26	w40u32x8qr65s1s4dcslqcfx	About	/about	header	7	f	2026-01-30 18:18:43.561	2026-01-30 18:18:43.561	2026-01-30 18:18:43.564	\N	\N	en
27	w40u32x8qr65s1s4dcslqcfx	من نحن	/about	header	7	f	2026-01-30 18:18:43.58	2026-01-30 18:18:43.58	\N	\N	\N	ar
28	w40u32x8qr65s1s4dcslqcfx	من نحن	/about	header	7	f	2026-01-30 18:18:43.58	2026-01-30 18:18:43.58	2026-01-30 18:18:43.583	\N	\N	ar
29	g83zezotrpr8rpjjufogmmqy	Contact	/contact	header	8	f	2026-01-30 18:18:43.604	2026-01-30 18:18:43.604	\N	\N	\N	en
30	g83zezotrpr8rpjjufogmmqy	Contact	/contact	header	8	f	2026-01-30 18:18:43.604	2026-01-30 18:18:43.604	2026-01-30 18:18:43.606	\N	\N	en
31	g83zezotrpr8rpjjufogmmqy	اتصل بنا	/contact	header	8	f	2026-01-30 18:18:43.623	2026-01-30 18:18:43.623	\N	\N	\N	ar
32	g83zezotrpr8rpjjufogmmqy	اتصل بنا	/contact	header	8	f	2026-01-30 18:18:43.623	2026-01-30 18:18:43.623	2026-01-30 18:18:43.628	\N	\N	ar
33	wv05oxybtxaiy2sp7rzb6sps	About Us	/about	footer-company	10	f	2026-01-30 18:18:43.648	2026-01-30 18:18:43.648	\N	\N	\N	en
34	wv05oxybtxaiy2sp7rzb6sps	About Us	/about	footer-company	10	f	2026-01-30 18:18:43.648	2026-01-30 18:18:43.648	2026-01-30 18:18:43.65	\N	\N	en
35	wv05oxybtxaiy2sp7rzb6sps	من نحن	/about	footer-company	10	f	2026-01-30 18:18:43.668	2026-01-30 18:18:43.668	\N	\N	\N	ar
36	wv05oxybtxaiy2sp7rzb6sps	من نحن	/about	footer-company	10	f	2026-01-30 18:18:43.668	2026-01-30 18:18:43.668	2026-01-30 18:18:43.672	\N	\N	ar
37	zz5f6w6q4a75ia6ma7658m5u	Careers	/careers	footer-company	11	f	2026-01-30 18:18:43.692	2026-01-30 18:18:43.692	\N	\N	\N	en
38	zz5f6w6q4a75ia6ma7658m5u	Careers	/careers	footer-company	11	f	2026-01-30 18:18:43.692	2026-01-30 18:18:43.692	2026-01-30 18:18:43.695	\N	\N	en
39	zz5f6w6q4a75ia6ma7658m5u	الوظائف	/careers	footer-company	11	f	2026-01-30 18:18:43.714	2026-01-30 18:18:43.714	\N	\N	\N	ar
40	zz5f6w6q4a75ia6ma7658m5u	الوظائف	/careers	footer-company	11	f	2026-01-30 18:18:43.714	2026-01-30 18:18:43.714	2026-01-30 18:18:43.717	\N	\N	ar
41	qmpjrhlrk6olmghoqkhi6wh2	Contact	/contact	footer-company	12	f	2026-01-30 18:18:43.74	2026-01-30 18:18:43.74	\N	\N	\N	en
42	qmpjrhlrk6olmghoqkhi6wh2	Contact	/contact	footer-company	12	f	2026-01-30 18:18:43.74	2026-01-30 18:18:43.74	2026-01-30 18:18:43.743	\N	\N	en
43	qmpjrhlrk6olmghoqkhi6wh2	اتصل بنا	/contact	footer-company	12	f	2026-01-30 18:18:43.759	2026-01-30 18:18:43.759	\N	\N	\N	ar
44	qmpjrhlrk6olmghoqkhi6wh2	اتصل بنا	/contact	footer-company	12	f	2026-01-30 18:18:43.759	2026-01-30 18:18:43.759	2026-01-30 18:18:43.762	\N	\N	ar
45	qjmbvsnny6jggsbxmpj2kwi3	Press	/press	footer-company	13	f	2026-01-30 18:18:43.787	2026-01-30 18:18:43.787	\N	\N	\N	en
46	qjmbvsnny6jggsbxmpj2kwi3	Press	/press	footer-company	13	f	2026-01-30 18:18:43.787	2026-01-30 18:18:43.787	2026-01-30 18:18:43.79	\N	\N	en
47	qjmbvsnny6jggsbxmpj2kwi3	الصحافة	/press	footer-company	13	f	2026-01-30 18:18:43.806	2026-01-30 18:18:43.806	\N	\N	\N	ar
48	qjmbvsnny6jggsbxmpj2kwi3	الصحافة	/press	footer-company	13	f	2026-01-30 18:18:43.806	2026-01-30 18:18:43.806	2026-01-30 18:18:43.808	\N	\N	ar
49	agq8sw7l8pzvw7s4bw4y30xk	Vmall Platform	/solutions/vmall-platform	footer-products	20	f	2026-01-30 18:18:43.826	2026-01-30 18:18:43.826	\N	\N	\N	en
50	agq8sw7l8pzvw7s4bw4y30xk	Vmall Platform	/solutions/vmall-platform	footer-products	20	f	2026-01-30 18:18:43.826	2026-01-30 18:18:43.826	2026-01-30 18:18:43.828	\N	\N	en
51	agq8sw7l8pzvw7s4bw4y30xk	منصة Vmall	/solutions/vmall-platform	footer-products	20	f	2026-01-30 18:18:43.845	2026-01-30 18:18:43.845	\N	\N	\N	ar
52	agq8sw7l8pzvw7s4bw4y30xk	منصة Vmall	/solutions/vmall-platform	footer-products	20	f	2026-01-30 18:18:43.845	2026-01-30 18:18:43.845	2026-01-30 18:18:43.847	\N	\N	ar
53	jfry982b0mf2csdm875iozrp	AI Suite	/solutions/arabiq-ai-suite	footer-products	21	f	2026-01-30 18:18:43.866	2026-01-30 18:18:43.866	\N	\N	\N	en
54	jfry982b0mf2csdm875iozrp	AI Suite	/solutions/arabiq-ai-suite	footer-products	21	f	2026-01-30 18:18:43.866	2026-01-30 18:18:43.866	2026-01-30 18:18:43.869	\N	\N	en
55	jfry982b0mf2csdm875iozrp	مجموعة الذكاء الاصطناعي	/solutions/arabiq-ai-suite	footer-products	21	f	2026-01-30 18:18:43.885	2026-01-30 18:18:43.885	\N	\N	\N	ar
56	jfry982b0mf2csdm875iozrp	مجموعة الذكاء الاصطناعي	/solutions/arabiq-ai-suite	footer-products	21	f	2026-01-30 18:18:43.885	2026-01-30 18:18:43.885	2026-01-30 18:18:43.889	\N	\N	ar
57	rq2u1jraro076onekzxjlgwv	Commerce	/solutions/arabiq-commerce	footer-products	22	f	2026-01-30 18:18:43.913	2026-01-30 18:18:43.913	\N	\N	\N	en
58	rq2u1jraro076onekzxjlgwv	Commerce	/solutions/arabiq-commerce	footer-products	22	f	2026-01-30 18:18:43.913	2026-01-30 18:18:43.913	2026-01-30 18:18:43.916	\N	\N	en
59	rq2u1jraro076onekzxjlgwv	التجارة	/solutions/arabiq-commerce	footer-products	22	f	2026-01-30 18:18:43.932	2026-01-30 18:18:43.932	\N	\N	\N	ar
60	rq2u1jraro076onekzxjlgwv	التجارة	/solutions/arabiq-commerce	footer-products	22	f	2026-01-30 18:18:43.932	2026-01-30 18:18:43.932	2026-01-30 18:18:43.936	\N	\N	ar
67	xkqdrzkqgipbpvrqrsqk5x2f	دراسات الحالة	/case-studies	footer-resources	30	f	2026-01-30 18:18:44.018	2026-01-30 18:18:44.018	\N	\N	\N	ar
68	xkqdrzkqgipbpvrqrsqk5x2f	دراسات الحالة	/case-studies	footer-resources	30	f	2026-01-30 18:18:44.018	2026-01-30 18:18:44.018	2026-01-30 18:18:44.023	\N	\N	ar
83	jmodresyl36fod3cuwmb8q1e	مركز المساعدة	/support	footer-support	40	f	2026-01-30 18:18:44.192	2026-01-30 18:18:44.192	\N	\N	\N	ar
84	jmodresyl36fod3cuwmb8q1e	مركز المساعدة	/support	footer-support	40	f	2026-01-30 18:18:44.192	2026-01-30 18:18:44.192	2026-01-30 18:18:44.194	\N	\N	ar
91	o8vvlj8ve51wppzgqriu958d	شروط الخدمة	/terms	footer-support	42	f	2026-01-30 18:18:44.271	2026-01-30 18:18:44.271	\N	\N	\N	ar
92	o8vvlj8ve51wppzgqriu958d	شروط الخدمة	/terms	footer-support	42	f	2026-01-30 18:18:44.271	2026-01-30 18:18:44.271	2026-01-30 18:18:44.274	\N	\N	ar
99	f8kjfmykuic87n4oq5smwq6i	لينكد إن	https://linkedin.com/company/arabiq	footer-social	51	t	2026-01-30 18:18:44.354	2026-01-30 18:18:44.354	\N	\N	\N	ar
100	f8kjfmykuic87n4oq5smwq6i	لينكد إن	https://linkedin.com/company/arabiq	footer-social	51	t	2026-01-30 18:18:44.354	2026-01-30 18:18:44.354	2026-01-30 18:18:44.358	\N	\N	ar
107	wnuvumue3x4lbte8ytbmr83q	يوتيوب	https://youtube.com/@arabiqtech	footer-social	53	t	2026-01-30 18:18:44.451	2026-01-30 18:18:44.451	\N	\N	\N	ar
108	wnuvumue3x4lbte8ytbmr83q	يوتيوب	https://youtube.com/@arabiqtech	footer-social	53	t	2026-01-30 18:18:44.451	2026-01-30 18:18:44.451	2026-01-30 18:18:44.453	\N	\N	ar
61	f6t0zamugip5yjdqzbq5e5iz	VFair Events	/solutions/vfair-edition	footer-products	23	f	2026-01-30 18:18:43.956	2026-01-30 18:18:43.956	\N	\N	\N	en
62	f6t0zamugip5yjdqzbq5e5iz	VFair Events	/solutions/vfair-edition	footer-products	23	f	2026-01-30 18:18:43.956	2026-01-30 18:18:43.956	2026-01-30 18:18:43.959	\N	\N	en
65	xkqdrzkqgipbpvrqrsqk5x2f	Case Studies	/case-studies	footer-resources	30	f	2026-01-30 18:18:43.999	2026-01-30 18:18:43.999	\N	\N	\N	en
66	xkqdrzkqgipbpvrqrsqk5x2f	Case Studies	/case-studies	footer-resources	30	f	2026-01-30 18:18:43.999	2026-01-30 18:18:43.999	2026-01-30 18:18:44.001	\N	\N	en
69	ovkqi3j5gb2lgnlr4ouswb74	Demos	/demos	footer-resources	31	f	2026-01-30 18:18:44.048	2026-01-30 18:18:44.048	\N	\N	\N	en
70	ovkqi3j5gb2lgnlr4ouswb74	Demos	/demos	footer-resources	31	f	2026-01-30 18:18:44.048	2026-01-30 18:18:44.048	2026-01-30 18:18:44.051	\N	\N	en
73	va433bevugruzxp9qwnl2ofp	FAQ	/faq	footer-resources	32	f	2026-01-30 18:18:44.091	2026-01-30 18:18:44.091	\N	\N	\N	en
74	va433bevugruzxp9qwnl2ofp	FAQ	/faq	footer-resources	32	f	2026-01-30 18:18:44.091	2026-01-30 18:18:44.091	2026-01-30 18:18:44.093	\N	\N	en
75	va433bevugruzxp9qwnl2ofp	الأسئلة الشائعة	/faq	footer-resources	32	f	2026-01-30 18:18:44.112	2026-01-30 18:18:44.112	\N	\N	\N	ar
76	va433bevugruzxp9qwnl2ofp	الأسئلة الشائعة	/faq	footer-resources	32	f	2026-01-30 18:18:44.112	2026-01-30 18:18:44.112	2026-01-30 18:18:44.114	\N	\N	ar
81	jmodresyl36fod3cuwmb8q1e	Help Center	/support	footer-support	40	f	2026-01-30 18:18:44.175	2026-01-30 18:18:44.175	\N	\N	\N	en
82	jmodresyl36fod3cuwmb8q1e	Help Center	/support	footer-support	40	f	2026-01-30 18:18:44.175	2026-01-30 18:18:44.175	2026-01-30 18:18:44.178	\N	\N	en
85	si37xkyrmogx8f8gw074j4z8	Privacy Policy	/privacy	footer-support	41	f	2026-01-30 18:18:44.213	2026-01-30 18:18:44.213	\N	\N	\N	en
86	si37xkyrmogx8f8gw074j4z8	Privacy Policy	/privacy	footer-support	41	f	2026-01-30 18:18:44.213	2026-01-30 18:18:44.213	2026-01-30 18:18:44.216	\N	\N	en
87	si37xkyrmogx8f8gw074j4z8	سياسة الخصوصية	/privacy	footer-support	41	f	2026-01-30 18:18:44.23	2026-01-30 18:18:44.23	\N	\N	\N	ar
88	si37xkyrmogx8f8gw074j4z8	سياسة الخصوصية	/privacy	footer-support	41	f	2026-01-30 18:18:44.23	2026-01-30 18:18:44.23	2026-01-30 18:18:44.232	\N	\N	ar
95	rmvrvicx420gwsmttsupir3u	تويتر	https://twitter.com/arabiqtech	footer-social	50	t	2026-01-30 18:18:44.313	2026-01-30 18:18:44.313	\N	\N	\N	ar
96	rmvrvicx420gwsmttsupir3u	تويتر	https://twitter.com/arabiqtech	footer-social	50	t	2026-01-30 18:18:44.313	2026-01-30 18:18:44.313	2026-01-30 18:18:44.316	\N	\N	ar
103	ibe5o4f91o2zug9phkntdsh6	انستغرام	https://instagram.com/arabiqtech	footer-social	52	t	2026-01-30 18:18:44.402	2026-01-30 18:18:44.402	\N	\N	\N	ar
104	ibe5o4f91o2zug9phkntdsh6	انستغرام	https://instagram.com/arabiqtech	footer-social	52	t	2026-01-30 18:18:44.402	2026-01-30 18:18:44.402	2026-01-30 18:18:44.405	\N	\N	ar
63	f6t0zamugip5yjdqzbq5e5iz	فعاليات VFair	/solutions/vfair-edition	footer-products	23	f	2026-01-30 18:18:43.975	2026-01-30 18:18:43.975	\N	\N	\N	ar
64	f6t0zamugip5yjdqzbq5e5iz	فعاليات VFair	/solutions/vfair-edition	footer-products	23	f	2026-01-30 18:18:43.975	2026-01-30 18:18:43.975	2026-01-30 18:18:43.977	\N	\N	ar
71	ovkqi3j5gb2lgnlr4ouswb74	العروض	/demos	footer-resources	31	f	2026-01-30 18:18:44.066	2026-01-30 18:18:44.066	\N	\N	\N	ar
72	ovkqi3j5gb2lgnlr4ouswb74	العروض	/demos	footer-resources	31	f	2026-01-30 18:18:44.066	2026-01-30 18:18:44.066	2026-01-30 18:18:44.069	\N	\N	ar
79	whoow9wi4jbdzjxsuj8v6dx5	المدونة	/blog	footer-resources	33	f	2026-01-30 18:18:44.153	2026-01-30 18:18:44.153	\N	\N	\N	ar
80	whoow9wi4jbdzjxsuj8v6dx5	المدونة	/blog	footer-resources	33	f	2026-01-30 18:18:44.153	2026-01-30 18:18:44.153	2026-01-30 18:18:44.155	\N	\N	ar
89	o8vvlj8ve51wppzgqriu958d	Terms of Service	/terms	footer-support	42	f	2026-01-30 18:18:44.255	2026-01-30 18:18:44.255	\N	\N	\N	en
90	o8vvlj8ve51wppzgqriu958d	Terms of Service	/terms	footer-support	42	f	2026-01-30 18:18:44.255	2026-01-30 18:18:44.255	2026-01-30 18:18:44.257	\N	\N	en
93	rmvrvicx420gwsmttsupir3u	Twitter	https://twitter.com/arabiqtech	footer-social	50	t	2026-01-30 18:18:44.295	2026-01-30 18:18:44.295	\N	\N	\N	en
94	rmvrvicx420gwsmttsupir3u	Twitter	https://twitter.com/arabiqtech	footer-social	50	t	2026-01-30 18:18:44.295	2026-01-30 18:18:44.295	2026-01-30 18:18:44.297	\N	\N	en
97	f8kjfmykuic87n4oq5smwq6i	LinkedIn	https://linkedin.com/company/arabiq	footer-social	51	t	2026-01-30 18:18:44.333	2026-01-30 18:18:44.333	\N	\N	\N	en
98	f8kjfmykuic87n4oq5smwq6i	LinkedIn	https://linkedin.com/company/arabiq	footer-social	51	t	2026-01-30 18:18:44.333	2026-01-30 18:18:44.333	2026-01-30 18:18:44.336	\N	\N	en
101	ibe5o4f91o2zug9phkntdsh6	Instagram	https://instagram.com/arabiqtech	footer-social	52	t	2026-01-30 18:18:44.382	2026-01-30 18:18:44.382	\N	\N	\N	en
102	ibe5o4f91o2zug9phkntdsh6	Instagram	https://instagram.com/arabiqtech	footer-social	52	t	2026-01-30 18:18:44.382	2026-01-30 18:18:44.382	2026-01-30 18:18:44.385	\N	\N	en
105	wnuvumue3x4lbte8ytbmr83q	YouTube	https://youtube.com/@arabiqtech	footer-social	53	t	2026-01-30 18:18:44.434	2026-01-30 18:18:44.434	\N	\N	\N	en
106	wnuvumue3x4lbte8ytbmr83q	YouTube	https://youtube.com/@arabiqtech	footer-social	53	t	2026-01-30 18:18:44.434	2026-01-30 18:18:44.434	2026-01-30 18:18:44.436	\N	\N	en
77	whoow9wi4jbdzjxsuj8v6dx5	Blog	/blog	footer-resources	33	f	2026-01-30 18:18:44.133	2026-01-30 18:18:44.133	\N	\N	\N	en
78	whoow9wi4jbdzjxsuj8v6dx5	Blog	/blog	footer-resources	33	f	2026-01-30 18:18:44.133	2026-01-30 18:18:44.133	2026-01-30 18:18:44.136	\N	\N	en
\.


--
-- Data for Name: partners; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.partners (id, document_id, slug, "order", partner_type, logo_url, website_url, name, description, partnership, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	bsvd4p89j0yb94c16fzeeiff	matterport	1	technology	\N	https://matterport.com	Matterport	World leader in 3D capture technology. Arabiq is a certified Matterport partner using Pro3 cameras for all scanning projects.	Certified Partner	2026-01-30 18:18:46.636	2026-01-30 18:18:46.636	\N	\N	\N	en
2	bsvd4p89j0yb94c16fzeeiff	matterport	1	technology	\N	https://matterport.com	Matterport	World leader in 3D capture technology. Arabiq is a certified Matterport partner using Pro3 cameras for all scanning projects.	Certified Partner	2026-01-30 18:18:46.636	2026-01-30 18:18:46.636	2026-01-30 18:18:46.639	\N	\N	en
3	bsvd4p89j0yb94c16fzeeiff	matterport	1	technology	\N	https://matterport.com	Matterport	الرائد العالمي في تقنية الالتقاط ثلاثي الأبعاد. Arabiq شريك Matterport معتمد يستخدم كاميرات Pro3 لجميع مشاريع المسح.	شريك معتمد	2026-01-30 18:18:46.653	2026-01-30 18:18:46.653	\N	\N	\N	ar
4	bsvd4p89j0yb94c16fzeeiff	matterport	1	technology	\N	https://matterport.com	Matterport	الرائد العالمي في تقنية الالتقاط ثلاثي الأبعاد. Arabiq شريك Matterport معتمد يستخدم كاميرات Pro3 لجميع مشاريع المسح.	شريك معتمد	2026-01-30 18:18:46.653	2026-01-30 18:18:46.653	2026-01-30 18:18:46.656	\N	\N	ar
5	zqj4agqr31qcfosztd68uqq5	aws	2	technology	\N	https://aws.amazon.com	Amazon Web Services	Our cloud infrastructure partner providing enterprise-grade hosting with regional data centers in Bahrain and UAE.	Advanced Partner	2026-01-30 18:18:46.674	2026-01-30 18:18:46.674	\N	\N	\N	en
6	zqj4agqr31qcfosztd68uqq5	aws	2	technology	\N	https://aws.amazon.com	Amazon Web Services	Our cloud infrastructure partner providing enterprise-grade hosting with regional data centers in Bahrain and UAE.	Advanced Partner	2026-01-30 18:18:46.674	2026-01-30 18:18:46.674	2026-01-30 18:18:46.677	\N	\N	en
7	zqj4agqr31qcfosztd68uqq5	aws	2	technology	\N	https://aws.amazon.com	Amazon Web Services	شريك البنية التحتية السحابية لدينا يوفر استضافة على مستوى المؤسسات مع مراكز بيانات إقليمية في البحرين والإمارات.	شريك متقدم	2026-01-30 18:18:46.692	2026-01-30 18:18:46.692	\N	\N	\N	ar
8	zqj4agqr31qcfosztd68uqq5	aws	2	technology	\N	https://aws.amazon.com	Amazon Web Services	شريك البنية التحتية السحابية لدينا يوفر استضافة على مستوى المؤسسات مع مراكز بيانات إقليمية في البحرين والإمارات.	شريك متقدم	2026-01-30 18:18:46.692	2026-01-30 18:18:46.692	2026-01-30 18:18:46.694	\N	\N	ar
9	q6vkq0ff1cvnky8z9vvs5itv	paytabs	3	payment	\N	https://paytabs.com	PayTabs	Leading MENA payment gateway integrated into our e-commerce solutions for seamless regional transactions.	Integration Partner	2026-01-30 18:18:46.722	2026-01-30 18:18:46.722	\N	\N	\N	en
10	q6vkq0ff1cvnky8z9vvs5itv	paytabs	3	payment	\N	https://paytabs.com	PayTabs	Leading MENA payment gateway integrated into our e-commerce solutions for seamless regional transactions.	Integration Partner	2026-01-30 18:18:46.722	2026-01-30 18:18:46.722	2026-01-30 18:18:46.725	\N	\N	en
11	q6vkq0ff1cvnky8z9vvs5itv	paytabs	3	payment	\N	https://paytabs.com	PayTabs	بوابة الدفع الرائدة في الشرق الأوسط المدمجة في حلول التجارة الإلكترونية لدينا للمعاملات الإقليمية السلسة.	شريك تكامل	2026-01-30 18:18:46.74	2026-01-30 18:18:46.74	\N	\N	\N	ar
12	q6vkq0ff1cvnky8z9vvs5itv	paytabs	3	payment	\N	https://paytabs.com	PayTabs	بوابة الدفع الرائدة في الشرق الأوسط المدمجة في حلول التجارة الإلكترونية لدينا للمعاملات الإقليمية السلسة.	شريك تكامل	2026-01-30 18:18:46.74	2026-01-30 18:18:46.74	2026-01-30 18:18:46.743	\N	\N	ar
13	al9qg47mf902yrf1lw56y6au	shopify	4	ecommerce	\N	https://shopify.com	Shopify	Native integration with Shopify and Shopify Plus for seamless product synchronization and checkout.	App Partner	2026-01-30 18:18:46.759	2026-01-30 18:18:46.759	\N	\N	\N	en
14	al9qg47mf902yrf1lw56y6au	shopify	4	ecommerce	\N	https://shopify.com	Shopify	Native integration with Shopify and Shopify Plus for seamless product synchronization and checkout.	App Partner	2026-01-30 18:18:46.759	2026-01-30 18:18:46.759	2026-01-30 18:18:46.761	\N	\N	en
15	al9qg47mf902yrf1lw56y6au	shopify	4	ecommerce	\N	https://shopify.com	Shopify	تكامل أصلي مع Shopify و Shopify Plus لمزامنة المنتجات والدفع السلس.	شريك تطبيقات	2026-01-30 18:18:46.774	2026-01-30 18:18:46.774	\N	\N	\N	ar
16	al9qg47mf902yrf1lw56y6au	shopify	4	ecommerce	\N	https://shopify.com	Shopify	تكامل أصلي مع Shopify و Shopify Plus لمزامنة المنتجات والدفع السلس.	شريك تطبيقات	2026-01-30 18:18:46.774	2026-01-30 18:18:46.774	2026-01-30 18:18:46.777	\N	\N	ar
17	z4nuwywgrr9ht59qutmgtwc2	aramex	5	logistics	\N	https://aramex.com	Aramex	Regional logistics partner for e-commerce fulfillment with integrated tracking in our commerce solutions.	Logistics Partner	2026-01-30 18:18:46.796	2026-01-30 18:18:46.796	\N	\N	\N	en
18	z4nuwywgrr9ht59qutmgtwc2	aramex	5	logistics	\N	https://aramex.com	Aramex	Regional logistics partner for e-commerce fulfillment with integrated tracking in our commerce solutions.	Logistics Partner	2026-01-30 18:18:46.796	2026-01-30 18:18:46.796	2026-01-30 18:18:46.798	\N	\N	en
19	z4nuwywgrr9ht59qutmgtwc2	aramex	5	logistics	\N	https://aramex.com	أرامكس	شريك اللوجستيات الإقليمي لتنفيذ التجارة الإلكترونية مع تتبع متكامل في حلول التجارة لدينا.	شريك لوجستي	2026-01-30 18:18:46.811	2026-01-30 18:18:46.811	\N	\N	\N	ar
20	z4nuwywgrr9ht59qutmgtwc2	aramex	5	logistics	\N	https://aramex.com	أرامكس	شريك اللوجستيات الإقليمي لتنفيذ التجارة الإلكترونية مع تتبع متكامل في حلول التجارة لدينا.	شريك لوجستي	2026-01-30 18:18:46.811	2026-01-30 18:18:46.811	2026-01-30 18:18:46.813	\N	\N	ar
21	crqrxytx9c5t3zl5m4c41zvq	salla	6	ecommerce	\N	https://salla.sa	Salla	Direct integration with Saudi Arabia's leading Arabic e-commerce platform for local merchants.	App Partner	2026-01-30 18:18:46.833	2026-01-30 18:18:46.833	\N	\N	\N	en
22	crqrxytx9c5t3zl5m4c41zvq	salla	6	ecommerce	\N	https://salla.sa	Salla	Direct integration with Saudi Arabia's leading Arabic e-commerce platform for local merchants.	App Partner	2026-01-30 18:18:46.833	2026-01-30 18:18:46.833	2026-01-30 18:18:46.835	\N	\N	en
23	crqrxytx9c5t3zl5m4c41zvq	salla	6	ecommerce	\N	https://salla.sa	سلة	تكامل مباشر مع منصة التجارة الإلكترونية العربية الرائدة في السعودية للتجار المحليين.	شريك تطبيقات	2026-01-30 18:18:46.848	2026-01-30 18:18:46.848	\N	\N	\N	ar
24	crqrxytx9c5t3zl5m4c41zvq	salla	6	ecommerce	\N	https://salla.sa	سلة	تكامل مباشر مع منصة التجارة الإلكترونية العربية الرائدة في السعودية للتجار المحليين.	شريك تطبيقات	2026-01-30 18:18:46.848	2026-01-30 18:18:46.848	2026-01-30 18:18:46.85	\N	\N	ar
\.


--
-- Data for Name: pricing_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.pricing_pages (id, document_id, hero_title, hero_subtitle, monthly_label, annual_label, annual_discount, popular_badge, features_title, feature_1, feature_2, feature_3, feature_4, feature_5, comparison_title, enterprise_title, enterprise_subtitle, enterprise_cta, faq_title, guarantee_title, guarantee_text, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	lkx5moczi3oe2jztwvsvzqh7	Simple, Transparent Pricing	Choose the plan that fits your business. No hidden fees, no surprises.	Monthly	Annual	Save 20%	Most Popular	All Plans Include	Matterport 3D scanning	Cloud hosting with CDN	Mobile responsive	Basic analytics	Email support	Detailed Plan Comparison	Need a Custom Solution?	For large organizations with complex requirements, we offer tailored packages with dedicated support.	Contact Enterprise Sales	Pricing FAQs	30-Day Money-Back Guarantee	Try any plan risk-free. If you're not completely satisfied within the first 30 days, we'll refund your payment in full.	2026-01-30 18:18:43.022	2026-01-30 18:18:43.022	\N	\N	\N	en
2	lkx5moczi3oe2jztwvsvzqh7	Simple, Transparent Pricing	Choose the plan that fits your business. No hidden fees, no surprises.	Monthly	Annual	Save 20%	Most Popular	All Plans Include	Matterport 3D scanning	Cloud hosting with CDN	Mobile responsive	Basic analytics	Email support	Detailed Plan Comparison	Need a Custom Solution?	For large organizations with complex requirements, we offer tailored packages with dedicated support.	Contact Enterprise Sales	Pricing FAQs	30-Day Money-Back Guarantee	Try any plan risk-free. If you're not completely satisfied within the first 30 days, we'll refund your payment in full.	2026-01-30 18:18:43.022	2026-01-30 18:18:43.022	2026-01-30 18:18:43.029	\N	\N	en
3	lkx5moczi3oe2jztwvsvzqh7	تسعير بسيط وشفاف	اختر الخطة المناسبة لعملك. بدون رسوم خفية، بدون مفاجآت.	شهري	سنوي	وفر 20%	الأكثر شيوعاً	جميع الخطط تشمل	مسح Matterport ثلاثي الأبعاد	استضافة سحابية مع CDN	متجاوب مع الجوال	تحليلات أساسية	دعم بالبريد الإلكتروني	مقارنة الخطط التفصيلية	تحتاج حلاً مخصصاً؟	للمؤسسات الكبيرة ذات المتطلبات المعقدة، نقدم باقات مخصصة مع دعم مخصص.	تواصل مع مبيعات المؤسسات	الأسئلة الشائعة عن التسعير	ضمان استرداد الأموال خلال 30 يوماً	جرب أي خطة بدون مخاطرة. إذا لم تكن راضياً تماماً خلال الـ 30 يوماً الأولى، سنسترد دفعتك بالكامل.	2026-01-30 18:18:43.06	2026-01-30 18:18:43.06	\N	\N	\N	ar
4	lkx5moczi3oe2jztwvsvzqh7	تسعير بسيط وشفاف	اختر الخطة المناسبة لعملك. بدون رسوم خفية، بدون مفاجآت.	شهري	سنوي	وفر 20%	الأكثر شيوعاً	جميع الخطط تشمل	مسح Matterport ثلاثي الأبعاد	استضافة سحابية مع CDN	متجاوب مع الجوال	تحليلات أساسية	دعم بالبريد الإلكتروني	مقارنة الخطط التفصيلية	تحتاج حلاً مخصصاً؟	للمؤسسات الكبيرة ذات المتطلبات المعقدة، نقدم باقات مخصصة مع دعم مخصص.	تواصل مع مبيعات المؤسسات	الأسئلة الشائعة عن التسعير	ضمان استرداد الأموال خلال 30 يوماً	جرب أي خطة بدون مخاطرة. إذا لم تكن راضياً تماماً خلال الـ 30 يوماً الأولى، سنسترد دفعتك بالكامل.	2026-01-30 18:18:43.06	2026-01-30 18:18:43.06	2026-01-30 18:18:43.064	\N	\N	ar
\.


--
-- Data for Name: pricing_plans; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.pricing_plans (id, document_id, slug, "order", popular, name, price, currency, period, description, features, limitations, cta, ideal_for, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ft3fhikbzqzqaokaf5mrr1kx	starter	1	f	Starter	5,000	SAR	one-time	Perfect for small spaces and one-time projects	Up to 200 sqm scanning|Basic 3D virtual tour|5 interactive hotspots|1 year hosting included|Dollhouse and floor plan views|Mobile responsive|Email support|Basic analytics	No e-commerce integration|No AI features|No custom branding	Get Started	Small retail stores, real estate listings, restaurant previews	2026-01-30 18:18:46.477	2026-01-30 18:18:46.477	\N	\N	\N	en
2	ft3fhikbzqzqaokaf5mrr1kx	starter	1	f	Starter	5,000	SAR	one-time	Perfect for small spaces and one-time projects	Up to 200 sqm scanning|Basic 3D virtual tour|5 interactive hotspots|1 year hosting included|Dollhouse and floor plan views|Mobile responsive|Email support|Basic analytics	No e-commerce integration|No AI features|No custom branding	Get Started	Small retail stores, real estate listings, restaurant previews	2026-01-30 18:18:46.477	2026-01-30 18:18:46.477	2026-01-30 18:18:46.48	\N	\N	en
3	ft3fhikbzqzqaokaf5mrr1kx	starter	1	f	البداية	5,000	ريال	مرة واحدة	مثالي للمساحات الصغيرة والمشاريع لمرة واحدة	مسح حتى 200 متر مربع|جولة افتراضية ثلاثية الأبعاد أساسية|5 نقاط تفاعلية|سنة استضافة مضمنة|عرض الدمية ومخطط الطابق|متجاوب مع الجوال|دعم بالبريد الإلكتروني|تحليلات أساسية	بدون تكامل تجارة إلكترونية|بدون ميزات ذكاء اصطناعي|بدون علامة تجارية مخصصة	ابدأ الآن	متاجر التجزئة الصغيرة، قوائم العقارات، معاينات المطاعم	2026-01-30 18:18:46.497	2026-01-30 18:18:46.497	\N	\N	\N	ar
4	ft3fhikbzqzqaokaf5mrr1kx	starter	1	f	البداية	5,000	ريال	مرة واحدة	مثالي للمساحات الصغيرة والمشاريع لمرة واحدة	مسح حتى 200 متر مربع|جولة افتراضية ثلاثية الأبعاد أساسية|5 نقاط تفاعلية|سنة استضافة مضمنة|عرض الدمية ومخطط الطابق|متجاوب مع الجوال|دعم بالبريد الإلكتروني|تحليلات أساسية	بدون تكامل تجارة إلكترونية|بدون ميزات ذكاء اصطناعي|بدون علامة تجارية مخصصة	ابدأ الآن	متاجر التجزئة الصغيرة، قوائم العقارات، معاينات المطاعم	2026-01-30 18:18:46.497	2026-01-30 18:18:46.497	2026-01-30 18:18:46.499	\N	\N	ar
5	ao40ftksyfzfjnwz1fuap352	professional	2	t	Professional	2,500	SAR	month	For growing businesses needing ongoing virtual presence	Up to 500 sqm scanning|Advanced 3D tour with all views|Unlimited hotspots|E-commerce integration|Arabic AI chatbot|Full analytics dashboard|Custom branding|Priority support|Quarterly re-scan included|Lead capture forms	Single location|Standard AI voices	Start Free Trial	Medium retail, showrooms, hotels, multi-room properties	2026-01-30 18:18:46.516	2026-01-30 18:18:46.516	\N	\N	\N	en
6	ao40ftksyfzfjnwz1fuap352	professional	2	t	Professional	2,500	SAR	month	For growing businesses needing ongoing virtual presence	Up to 500 sqm scanning|Advanced 3D tour with all views|Unlimited hotspots|E-commerce integration|Arabic AI chatbot|Full analytics dashboard|Custom branding|Priority support|Quarterly re-scan included|Lead capture forms	Single location|Standard AI voices	Start Free Trial	Medium retail, showrooms, hotels, multi-room properties	2026-01-30 18:18:46.516	2026-01-30 18:18:46.516	2026-01-30 18:18:46.518	\N	\N	en
7	ao40ftksyfzfjnwz1fuap352	professional	2	t	الاحترافي	2,500	ريال	شهرياً	للشركات النامية التي تحتاج حضوراً افتراضياً مستمراً	مسح حتى 500 متر مربع|جولة ثلاثية الأبعاد متقدمة بجميع العروض|نقاط تفاعلية غير محدودة|تكامل التجارة الإلكترونية|روبوت محادثة عربي بالذكاء الاصطناعي|لوحة تحليلات كاملة|علامة تجارية مخصصة|دعم أولوية|إعادة مسح ربعية مضمنة|نماذج التقاط العملاء	موقع واحد|أصوات ذكاء اصطناعي قياسية	ابدأ تجربة مجانية	التجزئة المتوسطة، صالات العرض، الفنادق، العقارات متعددة الغرف	2026-01-30 18:18:46.533	2026-01-30 18:18:46.533	\N	\N	\N	ar
8	ao40ftksyfzfjnwz1fuap352	professional	2	t	الاحترافي	2,500	ريال	شهرياً	للشركات النامية التي تحتاج حضوراً افتراضياً مستمراً	مسح حتى 500 متر مربع|جولة ثلاثية الأبعاد متقدمة بجميع العروض|نقاط تفاعلية غير محدودة|تكامل التجارة الإلكترونية|روبوت محادثة عربي بالذكاء الاصطناعي|لوحة تحليلات كاملة|علامة تجارية مخصصة|دعم أولوية|إعادة مسح ربعية مضمنة|نماذج التقاط العملاء	موقع واحد|أصوات ذكاء اصطناعي قياسية	ابدأ تجربة مجانية	التجزئة المتوسطة، صالات العرض، الفنادق، العقارات متعددة الغرف	2026-01-30 18:18:46.533	2026-01-30 18:18:46.533	2026-01-30 18:18:46.537	\N	\N	ar
9	kr3oiddgej4uxv2qnvhw0ips	business	3	f	Business	7,500	SAR	month	For established businesses with multiple locations	Up to 2,000 sqm scanning|Up to 3 locations|All Professional features|Custom AI voice cloning|Advanced e-commerce features|API access|Monthly re-scans|Dedicated account manager|Phone support|Custom integrations	Up to 3 locations	Contact Sales	Multi-location retail, real estate agencies, hotel chains	2026-01-30 18:18:46.558	2026-01-30 18:18:46.558	\N	\N	\N	en
10	kr3oiddgej4uxv2qnvhw0ips	business	3	f	Business	7,500	SAR	month	For established businesses with multiple locations	Up to 2,000 sqm scanning|Up to 3 locations|All Professional features|Custom AI voice cloning|Advanced e-commerce features|API access|Monthly re-scans|Dedicated account manager|Phone support|Custom integrations	Up to 3 locations	Contact Sales	Multi-location retail, real estate agencies, hotel chains	2026-01-30 18:18:46.558	2026-01-30 18:18:46.558	2026-01-30 18:18:46.56	\N	\N	en
11	kr3oiddgej4uxv2qnvhw0ips	business	3	f	الأعمال	7,500	ريال	شهرياً	للشركات الراسخة ذات المواقع المتعددة	مسح حتى 2,000 متر مربع|حتى 3 مواقع|جميع ميزات الاحترافي|استنساخ صوت ذكاء اصطناعي مخصص|ميزات تجارة إلكترونية متقدمة|وصول API|إعادة مسح شهرية|مدير حساب مخصص|دعم هاتفي|تكاملات مخصصة	حتى 3 مواقع	تواصل مع المبيعات	التجزئة متعددة المواقع، الوكالات العقارية، سلاسل الفنادق	2026-01-30 18:18:46.574	2026-01-30 18:18:46.574	\N	\N	\N	ar
12	kr3oiddgej4uxv2qnvhw0ips	business	3	f	الأعمال	7,500	ريال	شهرياً	للشركات الراسخة ذات المواقع المتعددة	مسح حتى 2,000 متر مربع|حتى 3 مواقع|جميع ميزات الاحترافي|استنساخ صوت ذكاء اصطناعي مخصص|ميزات تجارة إلكترونية متقدمة|وصول API|إعادة مسح شهرية|مدير حساب مخصص|دعم هاتفي|تكاملات مخصصة	حتى 3 مواقع	تواصل مع المبيعات	التجزئة متعددة المواقع، الوكالات العقارية، سلاسل الفنادق	2026-01-30 18:18:46.574	2026-01-30 18:18:46.574	2026-01-30 18:18:46.576	\N	\N	ar
13	q36bxbo8jscv8kfgk2zoiicl	enterprise	4	f	Enterprise	Custom			For large organizations with complex requirements	Unlimited scanning|Unlimited locations|All Business features|White-label solution|SSO integration|Custom SLA (99.9% uptime)|Dedicated infrastructure|On-site training|24/7 phone support|Custom development|Data residency options|Compliance documentation		Contact Enterprise Sales	Large retailers, government, museums, enterprise real estate	2026-01-30 18:18:46.597	2026-01-30 18:18:46.597	\N	\N	\N	en
14	q36bxbo8jscv8kfgk2zoiicl	enterprise	4	f	Enterprise	Custom			For large organizations with complex requirements	Unlimited scanning|Unlimited locations|All Business features|White-label solution|SSO integration|Custom SLA (99.9% uptime)|Dedicated infrastructure|On-site training|24/7 phone support|Custom development|Data residency options|Compliance documentation		Contact Enterprise Sales	Large retailers, government, museums, enterprise real estate	2026-01-30 18:18:46.597	2026-01-30 18:18:46.597	2026-01-30 18:18:46.599	\N	\N	en
15	q36bxbo8jscv8kfgk2zoiicl	enterprise	4	f	المؤسسات	مخصص			للمؤسسات الكبيرة ذات المتطلبات المعقدة	مسح غير محدود|مواقع غير محدودة|جميع ميزات الأعمال|حل العلامة البيضاء|تكامل SSO|اتفاقية SLA مخصصة (وقت تشغيل 99.9%)|بنية تحتية مخصصة|تدريب في الموقع|دعم هاتفي 24/7|تطوير مخصص|خيارات إقامة البيانات|وثائق الامتثال		تواصل مع مبيعات المؤسسات	تجار التجزئة الكبار، الحكومة، المتاحف، العقارات المؤسسية	2026-01-30 18:18:46.613	2026-01-30 18:18:46.613	\N	\N	\N	ar
16	q36bxbo8jscv8kfgk2zoiicl	enterprise	4	f	المؤسسات	مخصص			للمؤسسات الكبيرة ذات المتطلبات المعقدة	مسح غير محدود|مواقع غير محدودة|جميع ميزات الأعمال|حل العلامة البيضاء|تكامل SSO|اتفاقية SLA مخصصة (وقت تشغيل 99.9%)|بنية تحتية مخصصة|تدريب في الموقع|دعم هاتفي 24/7|تطوير مخصص|خيارات إقامة البيانات|وثائق الامتثال		تواصل مع مبيعات المؤسسات	تجار التجزئة الكبار، الحكومة، المتاحف، العقارات المؤسسية	2026-01-30 18:18:46.613	2026-01-30 18:18:46.613	2026-01-30 18:18:46.615	\N	\N	ar
\.


--
-- Data for Name: process_steps; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.process_steps (id, document_id, step, title, description, icon, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	qqyjxtl2n63w1lcupjhr2pyx	1	Discovery & Planning	We start with a detailed consultation to understand your business goals and requirements.	💬	2026-01-30 18:18:45.161	2026-01-30 18:18:45.161	\N	\N	\N	en
2	qqyjxtl2n63w1lcupjhr2pyx	1	Discovery & Planning	We start with a detailed consultation to understand your business goals and requirements.	💬	2026-01-30 18:18:45.161	2026-01-30 18:18:45.161	2026-01-30 18:18:45.166	\N	\N	en
3	qqyjxtl2n63w1lcupjhr2pyx	1	الاكتشاف والتخطيط	نبدأ باستشارة مفصلة لفهم أهداف عملك ومتطلباتك.	💬	2026-01-30 18:18:45.188	2026-01-30 18:18:45.188	\N	\N	\N	ar
4	qqyjxtl2n63w1lcupjhr2pyx	1	الاكتشاف والتخطيط	نبدأ باستشارة مفصلة لفهم أهداف عملك ومتطلباتك.	💬	2026-01-30 18:18:45.188	2026-01-30 18:18:45.188	2026-01-30 18:18:45.191	\N	\N	ar
5	y5cfo2qcvfrjyt4i2e1hsp2b	2	Professional 3D Capture	Our certified technicians capture your space with Matterport Pro3 equipment.	📸	2026-01-30 18:18:45.208	2026-01-30 18:18:45.208	\N	\N	\N	en
6	y5cfo2qcvfrjyt4i2e1hsp2b	2	Professional 3D Capture	Our certified technicians capture your space with Matterport Pro3 equipment.	📸	2026-01-30 18:18:45.208	2026-01-30 18:18:45.208	2026-01-30 18:18:45.211	\N	\N	en
7	y5cfo2qcvfrjyt4i2e1hsp2b	2	الالتقاط ثلاثي الأبعاد الاحترافي	يلتقط فنيونا المعتمدون مساحتك بمعدات Matterport Pro3.	📸	2026-01-30 18:18:45.226	2026-01-30 18:18:45.226	\N	\N	\N	ar
8	y5cfo2qcvfrjyt4i2e1hsp2b	2	الالتقاط ثلاثي الأبعاد الاحترافي	يلتقط فنيونا المعتمدون مساحتك بمعدات Matterport Pro3.	📸	2026-01-30 18:18:45.226	2026-01-30 18:18:45.226	2026-01-30 18:18:45.228	\N	\N	ar
9	xdbuck3q9zdbdi5bkbi7cgpi	3	Enhancement & Integration	We enhance your scan and add interactive hotspots and integrations.	✨	2026-01-30 18:18:45.252	2026-01-30 18:18:45.252	\N	\N	\N	en
10	xdbuck3q9zdbdi5bkbi7cgpi	3	Enhancement & Integration	We enhance your scan and add interactive hotspots and integrations.	✨	2026-01-30 18:18:45.252	2026-01-30 18:18:45.252	2026-01-30 18:18:45.254	\N	\N	en
11	xdbuck3q9zdbdi5bkbi7cgpi	3	التحسين والتكامل	نحسّن المسح ونضيف نقاطاً تفاعلية وتكاملات.	✨	2026-01-30 18:18:45.268	2026-01-30 18:18:45.268	\N	\N	\N	ar
12	xdbuck3q9zdbdi5bkbi7cgpi	3	التحسين والتكامل	نحسّن المسح ونضيف نقاطاً تفاعلية وتكاملات.	✨	2026-01-30 18:18:45.268	2026-01-30 18:18:45.268	2026-01-30 18:18:45.27	\N	\N	ar
13	va2tqarc1dhg7q91rbdfqotz	4	Launch & Optimize	Your virtual experience goes live with full analytics tracking.	🚀	2026-01-30 18:18:45.296	2026-01-30 18:18:45.296	\N	\N	\N	en
14	va2tqarc1dhg7q91rbdfqotz	4	Launch & Optimize	Your virtual experience goes live with full analytics tracking.	🚀	2026-01-30 18:18:45.296	2026-01-30 18:18:45.296	2026-01-30 18:18:45.298	\N	\N	en
15	va2tqarc1dhg7q91rbdfqotz	4	الإطلاق والتحسين	تنطلق تجربتك الافتراضية مع تتبع تحليلات كامل.	🚀	2026-01-30 18:18:45.311	2026-01-30 18:18:45.311	\N	\N	\N	ar
16	va2tqarc1dhg7q91rbdfqotz	4	الإطلاق والتحسين	تنطلق تجربتك الافتراضية مع تتبع تحليلات كامل.	🚀	2026-01-30 18:18:45.311	2026-01-30 18:18:45.311	2026-01-30 18:18:45.314	\N	\N	ar
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.site_settings (id, document_id, title, description, contact_email, contact_phone, footer_company_title, footer_products_title, footer_resources_title, footer_connect_title, copyright_text, login_button_text, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	x78ut3tqgg2ysm9sdloy9h4n	Arabiq - Virtual Reality Experiences for MENA	Transform your business with immersive 3D virtual spaces. Create virtual malls, showrooms, events, and tours using Matterport technology and Arabic-first AI.	hello@arabiq.tech	+966 11 234 5678	Company	Products	Resources	Connect	© 2026 Arabiq Technologies. All rights reserved.	Login	2026-01-30 18:18:42.969	2026-01-30 18:18:42.969	2026-01-30 18:18:42.968	\N	\N	en
2	x78ut3tqgg2ysm9sdloy9h4n	Arabiq - تجارب الواقع الافتراضي للشرق الأوسط	حوّل أعمالك بمساحات افتراضية ثلاثية الأبعاد غامرة. أنشئ مراكز تسوق ومعارض وفعاليات وجولات افتراضية.	hello@arabiq.tech	+966 11 234 5678	الشركة	المنتجات	الموارد	تواصل معنا	© 2026 Arabiq Technologies. جميع الحقوق محفوظة.	تسجيل الدخول	2026-01-30 18:18:42.998	2026-01-30 18:18:42.998	2026-01-30 18:18:42.99	\N	\N	ar
\.


--
-- Data for Name: solutions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.solutions (id, document_id, slug, title, summary, description, body, icon, allowed_roles, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	y2oa3frissstsgakqseygyaa	vmall-platform	Vmall Platform	Create immersive 3D virtual malls and shops using Matterport technology with full e-commerce integration.	## Transform Physical Retail Into Digital Experiences\n\nThe Vmall Platform is our flagship solution for retailers looking to create stunning virtual shopping experiences.	\N	🏬	[]	2026-01-30 18:18:47.255	2026-01-30 18:18:47.255	\N	\N	\N	en
2	y2oa3frissstsgakqseygyaa	vmall-platform	Vmall Platform	Create immersive 3D virtual malls and shops using Matterport technology with full e-commerce integration.	## Transform Physical Retail Into Digital Experiences\n\nThe Vmall Platform is our flagship solution for retailers looking to create stunning virtual shopping experiences.	\N	🏬	[]	2026-01-30 18:18:47.255	2026-01-30 18:18:47.255	2026-01-30 18:18:47.259	\N	\N	en
4	jttjl27jparr5i4e0b1x7qri	arabiq-ai-suite	Arabiq AI Suite	Arabic-first AI tools including voice narration, intelligent chatbots, and personalized recommendations.	## AI Built for Arabic Markets\n\nThe Arabiq AI Suite is a comprehensive collection of AI tools designed specifically for Arabic-speaking markets.	\N	🤖	[]	2026-01-30 18:18:47.289	2026-01-30 18:18:47.289	\N	\N	\N	en
5	jttjl27jparr5i4e0b1x7qri	arabiq-ai-suite	Arabiq AI Suite	Arabic-first AI tools including voice narration, intelligent chatbots, and personalized recommendations.	## AI Built for Arabic Markets\n\nThe Arabiq AI Suite is a comprehensive collection of AI tools designed specifically for Arabic-speaking markets.	\N	🤖	[]	2026-01-30 18:18:47.289	2026-01-30 18:18:47.289	2026-01-30 18:18:47.292	\N	\N	en
7	oitp7u9upvj6zq665q0isv9a	arabiq-commerce	Arabiq Commerce	Complete e-commerce backend with MENA payment gateways and regional shipping integrations.	## E-commerce Infrastructure for MENA\n\nArabiq Commerce provides everything you need to sell online in the Middle East.	\N	🛒	[]	2026-01-30 18:18:47.322	2026-01-30 18:18:47.322	\N	\N	\N	en
8	oitp7u9upvj6zq665q0isv9a	arabiq-commerce	Arabiq Commerce	Complete e-commerce backend with MENA payment gateways and regional shipping integrations.	## E-commerce Infrastructure for MENA\n\nArabiq Commerce provides everything you need to sell online in the Middle East.	\N	🛒	[]	2026-01-30 18:18:47.322	2026-01-30 18:18:47.322	2026-01-30 18:18:47.324	\N	\N	en
10	tp1v0g9mwwc85l8cr06uph1k	digital-twin-production	Digital Twin Production	End-to-end 3D scanning, modeling, and hosting services with professional Matterport capture.	## Full-Service 3D Production\n\nOur Digital Twin Production service handles everything from initial consultation to final delivery.	\N	📸	[]	2026-01-30 18:18:47.354	2026-01-30 18:18:47.354	\N	\N	\N	en
11	tp1v0g9mwwc85l8cr06uph1k	digital-twin-production	Digital Twin Production	End-to-end 3D scanning, modeling, and hosting services with professional Matterport capture.	## Full-Service 3D Production\n\nOur Digital Twin Production service handles everything from initial consultation to final delivery.	\N	📸	[]	2026-01-30 18:18:47.354	2026-01-30 18:18:47.354	2026-01-30 18:18:47.356	\N	\N	en
13	p6oj1wlsr0uj7nw7jld866h4	vfair-edition	VFair Edition	Complete virtual events platform for conferences, trade shows, and corporate events.	## Next-Generation Virtual Events\n\nVFair Edition transforms how organizations host events.	\N	🎪	[]	2026-01-30 18:18:47.385	2026-01-30 18:18:47.385	\N	\N	\N	en
14	p6oj1wlsr0uj7nw7jld866h4	vfair-edition	VFair Edition	Complete virtual events platform for conferences, trade shows, and corporate events.	## Next-Generation Virtual Events\n\nVFair Edition transforms how organizations host events.	\N	🎪	[]	2026-01-30 18:18:47.385	2026-01-30 18:18:47.385	2026-01-30 18:18:47.387	\N	\N	en
16	com7pqvstu1ar0n4mdqpawgm	system-integration	System Integration	Connect Arabiq with your existing CRM, ERP, POS, and e-commerce systems.	## Unified Business Systems\n\nArabiq doesn't replace your existing systems—it enhances them.	\N	🔗	[]	2026-01-30 18:18:47.416	2026-01-30 18:18:47.416	\N	\N	\N	en
17	com7pqvstu1ar0n4mdqpawgm	system-integration	System Integration	Connect Arabiq with your existing CRM, ERP, POS, and e-commerce systems.	## Unified Business Systems\n\nArabiq doesn't replace your existing systems—it enhances them.	\N	🔗	[]	2026-01-30 18:18:47.416	2026-01-30 18:18:47.416	2026-01-30 18:18:47.418	\N	\N	en
\.


--
-- Data for Name: solutions_pages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.solutions_pages (id, document_id, hero_title, hero_subtitle, filter_all, filter_platforms, filter_services, filter_ai, cta_title, cta_subtitle, cta_button, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	m7ti5vgrjw2bs05w39f2ahtt	Solutions for Every Business	Comprehensive virtual experience solutions tailored to your industry and goals	All Solutions	Platforms	Services	AI Tools	Not Sure Which Solution Is Right for You?	Our team will help you find the perfect combination of solutions for your business needs.	Schedule a Consultation	2026-01-30 18:18:43.084	2026-01-30 18:18:43.084	\N	\N	\N	en
2	m7ti5vgrjw2bs05w39f2ahtt	Solutions for Every Business	Comprehensive virtual experience solutions tailored to your industry and goals	All Solutions	Platforms	Services	AI Tools	Not Sure Which Solution Is Right for You?	Our team will help you find the perfect combination of solutions for your business needs.	Schedule a Consultation	2026-01-30 18:18:43.084	2026-01-30 18:18:43.084	2026-01-30 18:18:43.087	\N	\N	en
3	m7ti5vgrjw2bs05w39f2ahtt	حلول لكل الأعمال	حلول تجارب افتراضية شاملة مصممة لصناعتك وأهدافك	جميع الحلول	المنصات	الخدمات	أدوات الذكاء الاصطناعي	غير متأكد من الحل المناسب لك؟	سيساعدك فريقنا في إيجاد المجموعة المثالية من الحلول لاحتياجات عملك.	احجز استشارة	2026-01-30 18:18:43.111	2026-01-30 18:18:43.111	\N	\N	\N	ar
4	m7ti5vgrjw2bs05w39f2ahtt	حلول لكل الأعمال	حلول تجارب افتراضية شاملة مصممة لصناعتك وأهدافك	جميع الحلول	المنصات	الخدمات	أدوات الذكاء الاصطناعي	غير متأكد من الحل المناسب لك؟	سيساعدك فريقنا في إيجاد المجموعة المثالية من الحلول لاحتياجات عملك.	احجز استشارة	2026-01-30 18:18:43.111	2026-01-30 18:18:43.111	2026-01-30 18:18:43.114	\N	\N	ar
\.


--
-- Data for Name: stats; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.stats (id, document_id, value, label, "order", created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	typ511z4s15pwanppld4djbw	100+	Businesses Transformed	1	2026-01-30 18:18:44.917	2026-01-30 18:18:44.917	\N	\N	\N	en
2	typ511z4s15pwanppld4djbw	100+	Businesses Transformed	1	2026-01-30 18:18:44.917	2026-01-30 18:18:44.917	2026-01-30 18:18:44.92	\N	\N	en
3	typ511z4s15pwanppld4djbw	+100	شركة تم تحويلها	1	2026-01-30 18:18:44.936	2026-01-30 18:18:44.936	\N	\N	\N	ar
4	typ511z4s15pwanppld4djbw	+100	شركة تم تحويلها	1	2026-01-30 18:18:44.936	2026-01-30 18:18:44.936	2026-01-30 18:18:44.939	\N	\N	ar
5	o1xivj864s582431slikv69g	12	Countries Served	2	2026-01-30 18:18:44.957	2026-01-30 18:18:44.957	\N	\N	\N	en
6	o1xivj864s582431slikv69g	12	Countries Served	2	2026-01-30 18:18:44.957	2026-01-30 18:18:44.957	2026-01-30 18:18:44.959	\N	\N	en
7	o1xivj864s582431slikv69g	12	دولة نخدمها	2	2026-01-30 18:18:44.973	2026-01-30 18:18:44.973	\N	\N	\N	ar
8	o1xivj864s582431slikv69g	12	دولة نخدمها	2	2026-01-30 18:18:44.973	2026-01-30 18:18:44.973	2026-01-30 18:18:44.974	\N	\N	ar
9	z99huyjw6zrse61d54nrvln2	2M+	Virtual Visitors	3	2026-01-30 18:18:44.995	2026-01-30 18:18:44.995	\N	\N	\N	en
10	z99huyjw6zrse61d54nrvln2	2M+	Virtual Visitors	3	2026-01-30 18:18:44.995	2026-01-30 18:18:44.995	2026-01-30 18:18:44.998	\N	\N	en
11	z99huyjw6zrse61d54nrvln2	+2 مليون	زائر افتراضي	3	2026-01-30 18:18:45.011	2026-01-30 18:18:45.011	\N	\N	\N	ar
12	z99huyjw6zrse61d54nrvln2	+2 مليون	زائر افتراضي	3	2026-01-30 18:18:45.011	2026-01-30 18:18:45.011	2026-01-30 18:18:45.013	\N	\N	ar
13	bmj7p348829pw5f8bcxykezf	48hr	Average Delivery	4	2026-01-30 18:18:45.037	2026-01-30 18:18:45.037	\N	\N	\N	en
14	bmj7p348829pw5f8bcxykezf	48hr	Average Delivery	4	2026-01-30 18:18:45.037	2026-01-30 18:18:45.037	2026-01-30 18:18:45.039	\N	\N	en
15	bmj7p348829pw5f8bcxykezf	48 ساعة	متوسط التسليم	4	2026-01-30 18:18:45.056	2026-01-30 18:18:45.056	\N	\N	\N	ar
16	bmj7p348829pw5f8bcxykezf	48 ساعة	متوسط التسليم	4	2026-01-30 18:18:45.056	2026-01-30 18:18:45.056	2026-01-30 18:18:45.058	\N	\N	ar
17	ggacr0iflsppqqp77ggyfu1s	340%	Average Sales Lift	5	2026-01-30 18:18:45.078	2026-01-30 18:18:45.078	\N	\N	\N	en
18	ggacr0iflsppqqp77ggyfu1s	340%	Average Sales Lift	5	2026-01-30 18:18:45.078	2026-01-30 18:18:45.078	2026-01-30 18:18:45.08	\N	\N	en
19	ggacr0iflsppqqp77ggyfu1s	340%	متوسط زيادة المبيعات	5	2026-01-30 18:18:45.093	2026-01-30 18:18:45.093	\N	\N	\N	ar
20	ggacr0iflsppqqp77ggyfu1s	340%	متوسط زيادة المبيعات	5	2026-01-30 18:18:45.093	2026-01-30 18:18:45.093	2026-01-30 18:18:45.096	\N	\N	ar
21	pymy6iacdargxg3dw1do183q	4.9/5	Client Satisfaction	6	2026-01-30 18:18:45.121	2026-01-30 18:18:45.121	\N	\N	\N	en
22	pymy6iacdargxg3dw1do183q	4.9/5	Client Satisfaction	6	2026-01-30 18:18:45.121	2026-01-30 18:18:45.121	2026-01-30 18:18:45.123	\N	\N	en
23	pymy6iacdargxg3dw1do183q	4.9/5	رضا العملاء	6	2026-01-30 18:18:45.135	2026-01-30 18:18:45.135	\N	\N	\N	ar
24	pymy6iacdargxg3dw1do183q	4.9/5	رضا العملاء	6	2026-01-30 18:18:45.135	2026-01-30 18:18:45.135	2026-01-30 18:18:45.137	\N	\N	ar
\.


--
-- Data for Name: strapi_ai_localization_jobs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_ai_localization_jobs (id, content_type, related_document_id, source_locale, target_locales, status, created_at, updated_at) FROM stdin;
1	api::nav-item.nav-item	pbhswucxcw73a6wrexgb73qx	en	["ar"]	failed	2026-01-30 13:28:33.988	2026-01-30 13:29:52.722
2	api::nav-item.nav-item	y0hrjua4k44xko9nl1x4dbjf	en	["ar"]	failed	2026-01-30 13:28:34.066	2026-01-30 13:29:52.821
3	api::nav-item.nav-item	z4em4dj8w19lhunc4cu80cw8	en	["ar"]	failed	2026-01-30 13:28:34.137	2026-01-30 13:29:52.899
4	api::nav-item.nav-item	rdwgrxcapmvx0lako7jjx7ff	en	["ar"]	failed	2026-01-30 13:28:34.201	2026-01-30 13:29:52.972
5	api::nav-item.nav-item	hlfvcuck4sxo5g81xk6krfrx	en	["ar"]	failed	2026-01-30 13:28:34.257	2026-01-30 13:29:53.038
6	api::nav-item.nav-item	ryv8lnx7fober5yglsafdi1t	en	["ar"]	failed	2026-01-30 13:28:34.317	2026-01-30 13:29:53.107
7	api::nav-item.nav-item	r2ozsms43zxmuj5nr1snrgkg	en	["ar"]	failed	2026-01-30 13:28:34.375	2026-01-30 13:29:53.167
8	api::nav-item.nav-item	jydmfzzbbcfpgec0w49dyewu	en	["ar"]	failed	2026-01-30 13:28:34.432	2026-01-30 13:29:53.224
9	api::nav-item.nav-item	anpvuicjfnc7jfapmlf09iak	en	["ar"]	failed	2026-01-30 13:28:34.484	2026-01-30 13:29:53.282
10	api::nav-item.nav-item	k0vo6catt99duz7ljqm3josx	en	["ar"]	failed	2026-01-30 13:28:34.543	2026-01-30 13:29:53.338
11	api::nav-item.nav-item	qbs09odlivjoss99uqr2sbc9	en	["ar"]	failed	2026-01-30 13:28:34.6	2026-01-30 13:29:53.394
12	api::nav-item.nav-item	qdkemfmvqpn5bgygtyx7x1bt	en	["ar"]	failed	2026-01-30 13:28:34.649	2026-01-30 13:29:53.451
13	api::nav-item.nav-item	i1turdfe9h1ll6e8gfw46gct	en	["ar"]	failed	2026-01-30 13:28:34.697	2026-01-30 13:29:53.503
14	api::nav-item.nav-item	vz1j59v83ye7nlx1u2g5nnsx	en	["ar"]	failed	2026-01-30 13:28:34.755	2026-01-30 13:29:53.568
15	api::nav-item.nav-item	bs5ghndmi57r5immsbwxmx6s	en	["ar"]	failed	2026-01-30 13:28:34.812	2026-01-30 13:29:53.63
16	api::nav-item.nav-item	wpt37owti2jpg9zkf2ijlow1	en	["ar"]	failed	2026-01-30 13:28:34.864	2026-01-30 13:29:53.683
17	api::nav-item.nav-item	nqakvu7a637v3u693qeii7r7	en	["ar"]	failed	2026-01-30 13:28:34.915	2026-01-30 13:29:53.737
18	api::nav-item.nav-item	s9crjq6hbw3lo440kzuknphb	en	["ar"]	failed	2026-01-30 13:28:34.965	2026-01-30 13:29:53.786
19	api::nav-item.nav-item	o9amdzth44ab88us7dbgbokv	en	["ar"]	failed	2026-01-30 13:28:35.014	2026-01-30 13:29:53.837
20	api::nav-item.nav-item	innibom0y6msnvjy3xsqdqyc	en	["ar"]	failed	2026-01-30 13:28:35.059	2026-01-30 13:29:53.888
21	api::nav-item.nav-item	ftu5ffalyrvjwkn8yp98as8u	en	["ar"]	failed	2026-01-30 13:28:35.16	2026-01-30 13:29:53.995
22	api::nav-item.nav-item	k0hvy01ev9e8duicvyvdijft	en	["ar"]	failed	2026-01-30 13:28:35.207	2026-01-30 13:29:54.048
23	api::nav-item.nav-item	mw3w6o1r2a6kd2gubgfmhyfa	en	["ar"]	failed	2026-01-30 13:28:35.257	2026-01-30 13:29:54.099
24	api::nav-item.nav-item	sow2fywql2g0wa2hfnngvtr0	en	["ar"]	failed	2026-01-30 13:28:35.302	2026-01-30 13:29:54.149
25	api::feature.feature	k1jra03i9lkeztu8x8d22is2	en	["ar"]	failed	2026-01-30 13:28:35.674	2026-01-30 13:29:54.526
26	api::feature.feature	ok3kc66a7i2y6cz9q8i4wmse	en	["ar"]	failed	2026-01-30 13:28:35.738	2026-01-30 13:29:54.607
27	api::feature.feature	y6o04idbwfzsdaay6kofka05	en	["ar"]	failed	2026-01-30 13:28:35.806	2026-01-30 13:29:54.674
28	api::feature.feature	i4dkzjlvl1lu9p235cj2ub7b	en	["ar"]	failed	2026-01-30 13:28:35.87	2026-01-30 13:29:54.742
29	api::feature.feature	x0m30dpz1rxe0k198zsv6ezm	en	["ar"]	failed	2026-01-30 13:28:35.936	2026-01-30 13:29:54.803
30	api::feature.feature	ivnxuc8pbaf7gany3wcruwyn	en	["ar"]	failed	2026-01-30 13:28:36.006	2026-01-30 13:29:54.874
31	api::feature.feature	qsi791uprrxhi6sa796n04rj	en	["ar"]	failed	2026-01-30 13:28:36.075	2026-01-30 13:29:54.936
32	api::feature.feature	iwmchlh2l7dlvd6xymxcx47v	en	["ar"]	failed	2026-01-30 13:28:36.135	2026-01-30 13:29:54.999
33	api::value.value	b7qcdj10g5cxh1mhrhtanwkb	en	["ar"]	failed	2026-01-30 13:28:36.202	2026-01-30 13:29:55.076
34	api::value.value	y03iemvahxiw2nefjrei49uy	en	["ar"]	failed	2026-01-30 13:28:36.263	2026-01-30 13:29:55.145
35	api::value.value	ul9kvvxapz9l9xv1c161bary	en	["ar"]	failed	2026-01-30 13:28:36.324	2026-01-30 13:29:55.21
36	api::value.value	ilhmif7djgk9cqcgay1o36yc	en	["ar"]	failed	2026-01-30 13:28:36.39	2026-01-30 13:29:55.278
37	api::value.value	swit4duvl957rrh12n8pcubn	en	["ar"]	failed	2026-01-30 13:28:36.458	2026-01-30 13:29:55.347
38	api::value.value	w7lo6myxfcpdw967yme1hho6	en	["ar"]	failed	2026-01-30 13:28:36.518	2026-01-30 13:29:55.422
39	api::testimonial.testimonial	hb6z3co41twdz85uasd1t06e	en	["ar"]	failed	2026-01-30 13:28:36.586	2026-01-30 13:29:55.485
40	api::testimonial.testimonial	qbjqccwia98t3aqkfco75zvy	en	["ar"]	failed	2026-01-30 13:28:36.634	2026-01-30 13:29:55.535
41	api::testimonial.testimonial	hcoaoxpwl6v7kmqudxug2zjr	en	["ar"]	failed	2026-01-30 13:28:36.681	2026-01-30 13:29:55.589
42	api::testimonial.testimonial	zu45kb8b0cmz7g0fln9qp268	en	["ar"]	failed	2026-01-30 13:28:36.728	2026-01-30 13:29:55.634
43	api::testimonial.testimonial	dgfwle2xkrrvca30031nubvq	en	["ar"]	failed	2026-01-30 13:28:36.775	2026-01-30 13:29:55.68
44	api::testimonial.testimonial	ae0xtubg69qt3cp70cu87dii	en	["ar"]	failed	2026-01-30 13:28:36.822	2026-01-30 13:29:55.729
45	api::faq.faq	uz319w0xnmgjju7q8xhqmylk	en	["ar"]	failed	2026-01-30 13:28:36.879	2026-01-30 13:29:55.782
46	api::faq.faq	rcf5ficwoibv84orqiwku5h5	en	["ar"]	failed	2026-01-30 13:28:36.931	2026-01-30 13:29:55.833
47	api::faq.faq	b3rvitbxugv00l7569aqx7po	en	["ar"]	failed	2026-01-30 13:28:36.983	2026-01-30 13:29:55.885
48	api::faq.faq	jhbm7a60ps7105hiqye1bdmu	en	["ar"]	failed	2026-01-30 13:28:37.037	2026-01-30 13:29:55.937
49	api::faq.faq	gsv5ahlo7j0wdijcguqffe56	en	["ar"]	failed	2026-01-30 13:28:37.09	2026-01-30 13:29:55.987
50	api::faq.faq	jn8j9qdaxgm6bcmze21fyhp6	en	["ar"]	failed	2026-01-30 13:28:37.145	2026-01-30 13:29:56.037
51	api::faq.faq	ceirb08m3qx33izsut5b09m0	en	["ar"]	failed	2026-01-30 13:28:37.201	2026-01-30 13:29:56.09
52	api::faq.faq	iz3f5f3mlcrhq3b4aaahqd1r	en	["ar"]	failed	2026-01-30 13:28:37.258	2026-01-30 13:29:56.15
53	api::faq.faq	jjwclft4c0za7c5mrz7onmej	en	["ar"]	failed	2026-01-30 13:28:37.309	2026-01-30 13:29:56.211
54	api::faq.faq	qjuq6ouy05zuklrb09bgbjpu	en	["ar"]	failed	2026-01-30 13:28:37.364	2026-01-30 13:29:56.275
55	api::pricing-plan.pricing-plan	zl53fe61n4p94fxngibkuzv5	en	["ar"]	failed	2026-01-30 13:28:37.425	2026-01-30 13:29:56.342
56	api::pricing-plan.pricing-plan	ccyvmzkhpktzmvzzr7qb37fa	en	["ar"]	failed	2026-01-30 13:28:39.271	2026-01-30 13:29:56.397
57	api::pricing-plan.pricing-plan	sjhm9lmc1lgtq2oxl4wkozvs	en	["ar"]	failed	2026-01-30 13:28:39.327	2026-01-30 13:29:56.457
58	api::pricing-plan.pricing-plan	eh6xavp4jxgeh63z0xmanb19	en	["ar"]	failed	2026-01-30 13:28:39.385	2026-01-30 13:29:56.506
59	api::partner.partner	hyok9jxi6onuqhattk1p4c45	en	["ar"]	failed	2026-01-30 13:28:39.448	2026-01-30 13:29:03.919
60	api::partner.partner	fksra64c2epa532kogb0dtme	en	["ar"]	failed	2026-01-30 13:28:39.501	2026-01-30 13:29:03.98
61	api::partner.partner	n2c0d05gwlyls2k7dlmf4zcs	en	["ar"]	failed	2026-01-30 13:28:39.552	2026-01-30 13:29:04.037
62	api::partner.partner	aooct80zbh6cvaz8tlbt9ldt	en	["ar"]	failed	2026-01-30 13:28:39.604	2026-01-30 13:29:04.092
63	api::partner.partner	aryhb53fl806e18un55tdytl	en	["ar"]	failed	2026-01-30 13:28:39.654	2026-01-30 13:29:04.147
64	api::partner.partner	wk5amblec1ez4b6iamzrrj34	en	["ar"]	failed	2026-01-30 13:28:39.705	2026-01-30 13:29:04.203
65	api::nav-item.nav-item	buevkrllfgf0mp998h1r65e9	en	["ar"]	failed	2026-01-30 13:33:00.101	2026-01-30 13:34:31.707
75	api::nav-item.nav-item	cu273jrstb312isfs6w4346j	en	["ar"]	failed	2026-01-30 13:33:00.703	2026-01-30 13:34:32.299
486	api::homepage.homepage	fd3ws4k73m7nfjicvtb0jr6l	en	["ar"]	failed	2026-01-30 18:18:42.835	2026-01-30 18:18:42.851
76	api::nav-item.nav-item	b9iu50vqihxbj75ouj0b5yh3	en	["ar"]	failed	2026-01-30 13:33:00.755	2026-01-30 13:34:32.366
103	api::testimonial.testimonial	wpxb5c1wbkey8ze3auavm3te	en	["ar"]	failed	2026-01-30 13:33:02.7	2026-01-30 13:34:34.334
77	api::nav-item.nav-item	sg1k3nloiggrs1hecfunygn4	en	["ar"]	failed	2026-01-30 13:33:00.808	2026-01-30 13:34:32.461
88	api::nav-item.nav-item	rd9wkqqfecba9drsq001gh38	en	["ar"]	failed	2026-01-30 13:33:01.421	2026-01-30 13:34:33.075
104	api::testimonial.testimonial	n2dpxr050x38ec4fdx6didh5	en	["ar"]	failed	2026-01-30 13:33:02.749	2026-01-30 13:34:34.383
89	api::feature.feature	rahi1n7iba6y8j7eyshd0lzp	en	["ar"]	failed	2026-01-30 13:33:01.743	2026-01-30 13:34:33.397
490	api::pricing-page.pricing-page	lkx5moczi3oe2jztwvsvzqh7	en	["ar"]	failed	2026-01-30 18:18:43.053	2026-01-30 18:18:43.063
105	api::testimonial.testimonial	qxfwemlc2fmgignp32tr754a	en	["ar"]	failed	2026-01-30 13:33:02.796	2026-01-30 13:34:34.433
106	api::testimonial.testimonial	go2r8rajvjy5xpotz57le3rg	en	["ar"]	failed	2026-01-30 13:33:02.84	2026-01-30 13:34:34.482
491	api::solutions-page.solutions-page	m7ti5vgrjw2bs05w39f2ahtt	en	["ar"]	failed	2026-01-30 18:18:43.102	2026-01-30 18:18:43.109
107	api::testimonial.testimonial	epwzk3z6v889cx4r7j4bf5wo	en	["ar"]	failed	2026-01-30 13:33:02.89	2026-01-30 13:34:34.54
492	api::industries-page.industries-page	ifdaxgwgkmwhyqnymx4jr7cj	en	["ar"]	failed	2026-01-30 18:18:43.154	2026-01-30 18:18:43.16
523	api::team-member.team-member	zkj9afum7rkox7d98i8bgzr0	en	["ar"]	failed	2026-01-30 18:18:44.707	2026-01-30 18:18:44.713
524	api::team-member.team-member	ruf8gglwetvtk0wupucbwmm6	en	["ar"]	failed	2026-01-30 18:18:44.753	2026-01-30 18:18:44.76
526	api::team-member.team-member	n8wdzrj8lnse55886m2yq1ds	en	["ar"]	failed	2026-01-30 18:18:44.844	2026-01-30 18:18:44.849
550	api::value.value	tvjktjdvlsnwwu4t5u78xeyh	en	["ar"]	failed	2026-01-30 18:18:45.788	2026-01-30 18:18:45.793
108	api::testimonial.testimonial	g1j7kc4ec9juhdfaj1wc350i	en	["ar"]	failed	2026-01-30 13:33:02.935	2026-01-30 13:33:02.942
109	api::faq.faq	oyamwagh3s8b3kaydhhclaum	en	["ar"]	failed	2026-01-30 13:33:02.982	2026-01-30 13:33:02.992
110	api::faq.faq	plqdxdlsb5nw07r9kdafpodo	en	["ar"]	failed	2026-01-30 13:33:03.051	2026-01-30 13:33:03.06
111	api::faq.faq	xqnu1ugt0812bpgtf9k5sdl9	en	["ar"]	failed	2026-01-30 13:33:03.118	2026-01-30 13:33:03.126
112	api::faq.faq	edq57gassjzvgbvu1dydnh9o	en	["ar"]	failed	2026-01-30 13:33:03.19	2026-01-30 13:33:03.199
115	api::faq.faq	oyiyja58i0ynuulp1ipiu94n	en	["ar"]	failed	2026-01-30 13:33:03.39	2026-01-30 13:33:03.396
116	api::faq.faq	b4qh3uomyrs6papnbggnbg1o	en	["ar"]	failed	2026-01-30 13:33:03.462	2026-01-30 13:33:03.469
119	api::pricing-plan.pricing-plan	su78ippq7l3wamfsu9j5jw5u	en	["ar"]	failed	2026-01-30 13:33:03.67	2026-01-30 13:33:03.679
122	api::pricing-plan.pricing-plan	pbhbzuasdmbqyhtargfxoooq	en	["ar"]	failed	2026-01-30 13:33:03.87	2026-01-30 13:33:03.877
551	api::value.value	i6kg6udk3hiccgl1f2ckgtx1	en	["ar"]	failed	2026-01-30 18:18:45.825	2026-01-30 18:18:45.832
66	api::nav-item.nav-item	gy14b4o8kkd32ct0bcr2mrl0	en	["ar"]	failed	2026-01-30 13:33:00.162	2026-01-30 13:34:31.764
90	api::feature.feature	iuptkjtxcpf4wl0kcke8071h	en	["ar"]	failed	2026-01-30 13:33:01.808	2026-01-30 13:34:33.468
67	api::nav-item.nav-item	xqdibsifqxjvb7gt7bvkbrrd	en	["ar"]	failed	2026-01-30 13:33:00.226	2026-01-30 13:34:31.82
68	api::nav-item.nav-item	fymwss7im1s9h43za1h8y6jl	en	["ar"]	failed	2026-01-30 13:33:00.291	2026-01-30 13:34:31.875
91	api::feature.feature	y6sa1yfm17rjbhh80vlesrix	en	["ar"]	failed	2026-01-30 13:33:01.878	2026-01-30 13:34:33.551
69	api::nav-item.nav-item	cogrf7vgapmayq4cfgoxdqvl	en	["ar"]	failed	2026-01-30 13:33:00.347	2026-01-30 13:34:31.934
552	api::testimonial.testimonial	opq1fmv3lnckbzxhmwwk62ds	en	["ar"]	failed	2026-01-30 18:18:45.868	2026-01-30 18:18:45.875
70	api::nav-item.nav-item	ow5fgb6adr3sfeinhwumgn1l	en	["ar"]	failed	2026-01-30 13:33:00.415	2026-01-30 13:34:31.996
94	api::feature.feature	nw0ft91czxs6fsgz8rwdh5n2	en	["ar"]	failed	2026-01-30 13:33:02.075	2026-01-30 13:34:33.779
71	api::nav-item.nav-item	po5ulk42u9aixbjmdam4pijq	en	["ar"]	failed	2026-01-30 13:33:00.484	2026-01-30 13:34:32.056
72	api::nav-item.nav-item	i33pn3v14bjld466t49dxn6w	en	["ar"]	failed	2026-01-30 13:33:00.542	2026-01-30 13:34:32.113
95	api::feature.feature	bosmjjeton2ga5jhuo0p60cv	en	["ar"]	failed	2026-01-30 13:33:02.154	2026-01-30 13:34:33.836
73	api::nav-item.nav-item	mjsik0uc78nyty73egl21q24	en	["ar"]	failed	2026-01-30 13:33:00.595	2026-01-30 13:34:32.171
554	api::testimonial.testimonial	qb2es65ey3qka86jksib45ki	en	["ar"]	failed	2026-01-30 18:18:45.951	2026-01-30 18:18:45.958
74	api::nav-item.nav-item	nhugwwkiy6hr8a2e6ou51ujz	en	["ar"]	failed	2026-01-30 13:33:00.651	2026-01-30 13:34:32.234
98	api::value.value	j47vlgzbv9c2918xgoejutt7	en	["ar"]	failed	2026-01-30 13:33:02.365	2026-01-30 13:34:34.012
555	api::testimonial.testimonial	xmyhaokucnw2dalfdoavcqxk	en	["ar"]	failed	2026-01-30 18:18:45.988	2026-01-30 18:18:45.994
99	api::value.value	e8u3e6a00flsvpkam17y0ifv	en	["ar"]	failed	2026-01-30 13:33:02.423	2026-01-30 13:34:34.083
100	api::value.value	o3y1gguvx188xjc5gp2heplz	en	["ar"]	failed	2026-01-30 13:33:02.49	2026-01-30 13:34:34.147
573	api::partner.partner	zqj4agqr31qcfosztd68uqq5	en	["ar"]	failed	2026-01-30 18:18:46.688	2026-01-30 18:18:46.697
101	api::value.value	ag1jewvwv8d9f5ktawipry94	en	["ar"]	failed	2026-01-30 13:33:02.55	2026-01-30 13:34:34.209
581	api::demo.demo	zeeuzedqjrhzp8gmkkki41de	en	["ar"]	failed	2026-01-30 18:18:46.99	2026-01-30 18:18:46.997
584	api::case-study.case-study	skq1yjxd7770pz5in55zfgg7	en	["ar"]	failed	2026-01-30 18:18:47.097	2026-01-30 18:18:47.104
586	api::case-study.case-study	qj6gtnln0t7cdf0691h03fkf	en	["ar"]	failed	2026-01-30 18:18:47.162	2026-01-30 18:18:47.167
593	api::solution.solution	p6oj1wlsr0uj7nw7jld866h4	en	["ar"]	failed	2026-01-30 18:18:47.397	2026-01-30 18:18:47.404
597	api::industry.industry	fjz0xzgvdm0hkx4tv4knpeev	en	["ar"]	failed	2026-01-30 18:18:47.53	2026-01-30 18:18:47.536
600	api::industry.industry	y6jskmvdb2f7ac83uglzuqxn	en	["ar"]	failed	2026-01-30 18:18:47.656	2026-01-30 18:18:47.662
82	api::nav-item.nav-item	hnr85wic2p8q0laqwdx8t0mf	en	["ar"]	failed	2026-01-30 13:33:01.083	2026-01-30 13:34:32.736
134	api::nav-item.nav-item	jd6cph2w1mngvqrj8tsxgxzq	en	["ar"]	failed	2026-01-30 14:07:20.619	2026-01-30 14:07:20.63
135	api::nav-item.nav-item	c9pezgv8otu1ywp151t0zeao	en	["ar"]	failed	2026-01-30 14:07:20.679	2026-01-30 14:07:20.689
136	api::nav-item.nav-item	elkyea8978bagttnlsn4badx	en	["ar"]	failed	2026-01-30 14:07:20.738	2026-01-30 14:07:20.746
137	api::nav-item.nav-item	mybe4y3geqohoxfydqm0vcfx	en	["ar"]	failed	2026-01-30 14:07:20.789	2026-01-30 14:07:20.798
138	api::nav-item.nav-item	yotgk1870id0x6ahorwdpn2r	en	["ar"]	failed	2026-01-30 14:07:20.844	2026-01-30 14:07:20.852
139	api::nav-item.nav-item	e8ylef87taqz4pb3s5bev1q9	en	["ar"]	failed	2026-01-30 14:07:20.902	2026-01-30 14:07:20.908
113	api::faq.faq	w43b4ioqanl9qhen9rwm77y8	en	["ar"]	failed	2026-01-30 13:33:03.256	2026-01-30 13:33:03.263
114	api::faq.faq	mhowux1nkqmngycuh6maj16u	en	["ar"]	failed	2026-01-30 13:33:03.321	2026-01-30 13:33:03.327
117	api::faq.faq	pzbbeueudoei9tfj0damo3b4	en	["ar"]	failed	2026-01-30 13:33:03.525	2026-01-30 13:33:03.535
118	api::faq.faq	yoc2m0xg8bb9esgfy1tyqcmr	en	["ar"]	failed	2026-01-30 13:33:03.605	2026-01-30 13:33:03.614
120	api::pricing-plan.pricing-plan	j04yna0vl3hofjsbu3477osk	en	["ar"]	failed	2026-01-30 13:33:03.74	2026-01-30 13:33:03.749
121	api::pricing-plan.pricing-plan	b3pzgzre97fpnrn9vbmsfx4u	en	["ar"]	failed	2026-01-30 13:33:03.807	2026-01-30 13:33:03.813
123	api::partner.partner	dqce8hkr4wynqtf7k8lgatf6	en	["ar"]	failed	2026-01-30 13:33:03.944	2026-01-30 13:33:03.952
124	api::partner.partner	s4rm8vj9jcmv89z1xq9lekhn	en	["ar"]	failed	2026-01-30 13:33:04.01	2026-01-30 13:33:04.018
125	api::partner.partner	qmhkzs7e1sdjci1g9r2yvh8n	en	["ar"]	failed	2026-01-30 13:33:04.073	2026-01-30 13:33:04.08
126	api::partner.partner	fawy4fl4it2usb5y5ysjw7f8	en	["ar"]	failed	2026-01-30 13:33:04.147	2026-01-30 13:33:04.153
127	api::partner.partner	t5x7smcioig1epbvk512yt14	en	["ar"]	failed	2026-01-30 13:33:04.212	2026-01-30 13:33:04.217
128	api::partner.partner	vkdyvisiwm1mfm1rsi9dqti6	en	["ar"]	failed	2026-01-30 13:33:04.275	2026-01-30 13:33:04.288
83	api::nav-item.nav-item	n5hpxay2ibfs1p5zzr2dmnwt	en	["ar"]	failed	2026-01-30 13:33:01.137	2026-01-30 13:34:32.783
78	api::nav-item.nav-item	x4ieapygihntdpzxf90smhgq	en	["ar"]	failed	2026-01-30 13:33:00.859	2026-01-30 13:34:32.531
140	api::nav-item.nav-item	og49n1evpg14tddd1vvesgvl	en	["ar"]	failed	2026-01-30 14:07:20.959	2026-01-30 14:07:20.966
79	api::nav-item.nav-item	nevp1qwdkassgou2zi34c676	en	["ar"]	failed	2026-01-30 13:33:00.919	2026-01-30 13:34:32.584
84	api::nav-item.nav-item	r7wgihju496rdmpmncu354il	en	["ar"]	failed	2026-01-30 13:33:01.188	2026-01-30 13:34:32.833
80	api::nav-item.nav-item	cbhceshch20w5fhitsiv4opd	en	["ar"]	failed	2026-01-30 13:33:00.973	2026-01-30 13:34:32.638
81	api::nav-item.nav-item	e2ptx42xl8iya8v14fk1iqvz	en	["ar"]	failed	2026-01-30 13:33:01.023	2026-01-30 13:34:32.689
141	api::nav-item.nav-item	klk1v693zu6uargpqya7ik3b	en	["ar"]	failed	2026-01-30 14:07:21.009	2026-01-30 14:07:21.016
85	api::nav-item.nav-item	aktki5ym3i8du57uc7lpbqnc	en	["ar"]	failed	2026-01-30 13:33:01.269	2026-01-30 13:34:32.923
86	api::nav-item.nav-item	vym406frbswht94nl7xcwqns	en	["ar"]	failed	2026-01-30 13:33:01.319	2026-01-30 13:34:32.978
142	api::nav-item.nav-item	dhbmrbni3cmbavrlk553m4lr	en	["ar"]	failed	2026-01-30 14:07:21.064	2026-01-30 14:07:21.073
87	api::nav-item.nav-item	bmfx8usx97aiq2ytvt9bw807	en	["ar"]	failed	2026-01-30 13:33:01.369	2026-01-30 13:34:33.031
92	api::feature.feature	d2vggrtechjs7mnoo4qbyt10	en	["ar"]	failed	2026-01-30 13:33:01.947	2026-01-30 13:34:33.62
143	api::nav-item.nav-item	vuod9ihbmz3dkag8xcsc2vuv	en	["ar"]	failed	2026-01-30 14:07:21.12	2026-01-30 14:07:21.133
93	api::feature.feature	r5he12tjtnhcbygghy8uk6wc	en	["ar"]	failed	2026-01-30 13:33:02.007	2026-01-30 13:34:33.721
96	api::feature.feature	gyukp6kvqjofvjs7nwfdeap5	en	["ar"]	failed	2026-01-30 13:33:02.224	2026-01-30 13:34:33.892
144	api::nav-item.nav-item	r02rd2hrkln35gc641pa8erk	en	["ar"]	failed	2026-01-30 14:07:21.18	2026-01-30 14:07:21.188
97	api::value.value	colwi82db5423qllfogcnqdk	en	["ar"]	failed	2026-01-30 13:33:02.297	2026-01-30 13:34:33.951
102	api::value.value	osvo6jh7ldmn61dxvtkexbk6	en	["ar"]	failed	2026-01-30 13:33:02.616	2026-01-30 13:34:34.268
129	api::nav-item.nav-item	gvy6c9y1icuafxio76f4mvj6	en	["ar"]	failed	2026-01-30 14:07:20.255	2026-01-30 14:07:20.264
130	api::nav-item.nav-item	vu50e31yks8q9usqghpcbvoz	en	["ar"]	failed	2026-01-30 14:07:20.339	2026-01-30 14:07:20.346
131	api::nav-item.nav-item	b12jxebooq63n8w95ic2vg9d	en	["ar"]	failed	2026-01-30 14:07:20.417	2026-01-30 14:07:20.424
132	api::nav-item.nav-item	yi17re197hepw1csm6td2d6v	en	["ar"]	failed	2026-01-30 14:07:20.492	2026-01-30 14:07:20.5
133	api::nav-item.nav-item	gp3dw116zoicklx0152pl6u9	en	["ar"]	failed	2026-01-30 14:07:20.552	2026-01-30 14:07:20.56
145	api::nav-item.nav-item	ojuuqzet84br5frysin8apmm	en	["ar"]	failed	2026-01-30 14:07:21.238	2026-01-30 14:07:21.245
146	api::nav-item.nav-item	l8cu1zwfaexgzx77d5wwp4u4	en	["ar"]	failed	2026-01-30 14:07:21.295	2026-01-30 14:07:21.303
147	api::nav-item.nav-item	qjkaxsqeoo8hg3ia6lcszbbr	en	["ar"]	failed	2026-01-30 14:07:21.348	2026-01-30 14:07:21.355
148	api::nav-item.nav-item	teb4xh94ge9gwq17xhz4jl0j	en	["ar"]	failed	2026-01-30 14:07:21.405	2026-01-30 14:07:21.412
149	api::nav-item.nav-item	c7eyvugqt4yocz9y78irqn9p	en	["ar"]	failed	2026-01-30 14:07:21.505	2026-01-30 14:07:21.512
150	api::nav-item.nav-item	voyoho926sg4vjma12ymmtxn	en	["ar"]	failed	2026-01-30 14:07:21.561	2026-01-30 14:07:21.568
151	api::nav-item.nav-item	x4xc5yqjgvtjrpxemmsss5gj	en	["ar"]	failed	2026-01-30 14:07:21.613	2026-01-30 14:07:21.62
152	api::nav-item.nav-item	k9yv5i47slbr0v6b8fuan2f5	en	["ar"]	failed	2026-01-30 14:07:21.663	2026-01-30 14:07:21.672
153	api::nav-item.nav-item	w6pwm6pfbq8f3n2le5ubpn0y	en	["ar"]	failed	2026-01-30 14:17:22.887	2026-01-30 14:17:22.897
154	api::nav-item.nav-item	znf982pqxr3gkej6lbrzgmg8	en	["ar"]	failed	2026-01-30 14:17:22.953	2026-01-30 14:17:22.96
155	api::nav-item.nav-item	b7dq7vtkaj2t043qyb00fs5n	en	["ar"]	failed	2026-01-30 14:17:23.014	2026-01-30 14:17:23.022
156	api::nav-item.nav-item	hza2sjkxy0pp1nrlv7ibllso	en	["ar"]	failed	2026-01-30 14:17:23.074	2026-01-30 14:17:23.089
157	api::nav-item.nav-item	w9wgqrfmucs4v0442gl8e6hr	en	["ar"]	failed	2026-01-30 14:17:23.141	2026-01-30 14:17:23.148
158	api::nav-item.nav-item	v7n5h2knet4y0sc3vyr7u3za	en	["ar"]	failed	2026-01-30 14:17:23.198	2026-01-30 14:17:23.206
159	api::nav-item.nav-item	dovsyk4d657q5ckev97mmffw	en	["ar"]	failed	2026-01-30 14:17:23.259	2026-01-30 14:17:23.267
160	api::nav-item.nav-item	uqu1mmkrvbusxzevg962oz92	en	["ar"]	failed	2026-01-30 14:17:23.319	2026-01-30 14:17:23.328
161	api::nav-item.nav-item	jwt75ioq51hy9gx73qnnr7dv	en	["ar"]	failed	2026-01-30 14:17:23.379	2026-01-30 14:17:23.391
162	api::nav-item.nav-item	ybhv9g272pjhceftuvknby6t	en	["ar"]	failed	2026-01-30 14:17:23.445	2026-01-30 14:17:23.452
163	api::nav-item.nav-item	bgylxkcm3e7uf5yldyw5lm74	en	["ar"]	failed	2026-01-30 14:17:23.502	2026-01-30 14:17:23.51
164	api::nav-item.nav-item	flxdcuuerwa5djha58vb0suv	en	["ar"]	failed	2026-01-30 14:17:23.556	2026-01-30 14:17:23.564
165	api::nav-item.nav-item	ttkwgzhrfeofsdp3rg6tw7yz	en	["ar"]	failed	2026-01-30 14:17:23.612	2026-01-30 14:17:23.619
166	api::nav-item.nav-item	qvbv12c5gnq3xxcyy8ke7xw8	en	["ar"]	failed	2026-01-30 14:17:23.666	2026-01-30 14:17:23.672
167	api::nav-item.nav-item	vlol84ff0qa2lix656m4a0dp	en	["ar"]	failed	2026-01-30 14:17:23.719	2026-01-30 14:17:23.728
168	api::nav-item.nav-item	fy1egboqs38sfr6dha9v3pc8	en	["ar"]	failed	2026-01-30 14:17:23.772	2026-01-30 14:17:23.788
169	api::nav-item.nav-item	aibaz4x215l4pkb024w93b0e	en	["ar"]	failed	2026-01-30 14:17:23.841	2026-01-30 14:17:23.849
170	api::nav-item.nav-item	lo5w8ygdz0sfxr60b5zhi9ej	en	["ar"]	failed	2026-01-30 14:17:23.889	2026-01-30 14:17:23.897
171	api::nav-item.nav-item	vnommucx1bott3h99wgp2pbw	en	["ar"]	failed	2026-01-30 14:17:23.941	2026-01-30 14:17:23.949
172	api::nav-item.nav-item	e398nv701gbw3z3rhg9dwvd9	en	["ar"]	failed	2026-01-30 14:17:23.996	2026-01-30 14:17:24.006
173	api::nav-item.nav-item	kou5ithukzq1dmghspxeejge	en	["ar"]	failed	2026-01-30 14:17:24.108	2026-01-30 14:17:24.116
174	api::nav-item.nav-item	ejti2khdnehwpi0wvqqitm4a	en	["ar"]	failed	2026-01-30 14:17:24.168	2026-01-30 14:17:24.175
185	api::value.value	jzjr3etn4axripl6xijy2lvb	en	["ar"]	failed	2026-01-30 14:17:25.218	2026-01-30 14:17:25.224
188	api::value.value	t4ke80stt43afyzttli5m16n	en	["ar"]	failed	2026-01-30 14:17:25.422	2026-01-30 14:17:25.428
191	api::testimonial.testimonial	gxagtai07lxq861ulm2vh60s	en	["ar"]	failed	2026-01-30 14:17:25.636	2026-01-30 14:17:25.645
192	api::testimonial.testimonial	uskudlq40ycxx5b5mkbqjs4w	en	["ar"]	failed	2026-01-30 14:17:25.724	2026-01-30 14:17:25.732
193	api::testimonial.testimonial	qs4h0qld9s24zm08yq2abk48	en	["ar"]	failed	2026-01-30 14:17:25.784	2026-01-30 14:17:25.795
194	api::testimonial.testimonial	mjespu8flu14l1tavomcrfcg	en	["ar"]	failed	2026-01-30 14:17:25.836	2026-01-30 14:17:25.844
195	api::testimonial.testimonial	k120st7rswzpbmfkgy0zd4s1	en	["ar"]	failed	2026-01-30 14:17:25.894	2026-01-30 14:17:25.9
196	api::testimonial.testimonial	pg60nvunvxodadnya10vtnpd	en	["ar"]	failed	2026-01-30 14:17:25.945	2026-01-30 14:17:25.952
197	api::faq.faq	fu6t8od3ca193wtkzx2fxnfr	en	["ar"]	failed	2026-01-30 14:17:25.991	2026-01-30 14:17:25.996
198	api::faq.faq	dy6zf932mosoc5tneusf1jj9	en	["ar"]	failed	2026-01-30 14:17:26.05	2026-01-30 14:17:26.057
199	api::faq.faq	x75mu9wbj869gu81f6ca6p55	en	["ar"]	failed	2026-01-30 14:17:26.111	2026-01-30 14:17:26.117
200	api::faq.faq	guo7x3cmr5gs0256mivyq3x9	en	["ar"]	failed	2026-01-30 14:17:26.169	2026-01-30 14:17:26.178
201	api::faq.faq	ahb2k3fe5ey6mrwc8vh4ifz1	en	["ar"]	failed	2026-01-30 14:17:26.228	2026-01-30 14:17:26.236
202	api::faq.faq	n16etyfeah3wwshg2bebwx8z	en	["ar"]	failed	2026-01-30 14:17:26.292	2026-01-30 14:17:26.298
203	api::faq.faq	jbycliu4tvd5miow140g94kd	en	["ar"]	failed	2026-01-30 14:17:26.352	2026-01-30 14:17:26.362
204	api::faq.faq	b7cx0qoqj4xvr2gntexry771	en	["ar"]	failed	2026-01-30 14:17:26.407	2026-01-30 14:17:26.416
205	api::faq.faq	sopnvcr3qq62ki8jppsku3we	en	["ar"]	failed	2026-01-30 14:17:26.464	2026-01-30 14:17:26.47
206	api::faq.faq	csotctz2hxb32fuw09r1ma26	en	["ar"]	failed	2026-01-30 14:17:26.523	2026-01-30 14:17:26.53
207	api::pricing-plan.pricing-plan	inrajg7juckvg55v4ifd39oi	en	["ar"]	failed	2026-01-30 14:17:26.579	2026-01-30 14:17:26.591
208	api::pricing-plan.pricing-plan	kxb4vheko2v5pome0dszjo7a	en	["ar"]	failed	2026-01-30 14:17:26.644	2026-01-30 14:17:26.656
209	api::pricing-plan.pricing-plan	ssv1353ms0p5b0aqhyxnks6u	en	["ar"]	failed	2026-01-30 14:17:26.706	2026-01-30 14:17:26.713
210	api::pricing-plan.pricing-plan	hvnjs4xosc9z36bmf8290ear	en	["ar"]	failed	2026-01-30 14:17:26.767	2026-01-30 14:17:26.775
211	api::partner.partner	nkx4e48wg1k85vcz3v2ouuv3	en	["ar"]	failed	2026-01-30 14:17:26.825	2026-01-30 14:17:26.832
212	api::partner.partner	exk4zbo6uxtjx4xfc8fqqlcc	en	["ar"]	failed	2026-01-30 14:17:26.879	2026-01-30 14:17:26.887
213	api::partner.partner	t8dw46e81hx0misinxqlerzr	en	["ar"]	failed	2026-01-30 14:17:26.942	2026-01-30 14:17:26.948
214	api::partner.partner	e4pm75o5l4cowbucgraxyp44	en	["ar"]	failed	2026-01-30 14:17:27	2026-01-30 14:17:27.007
487	api::about-page.about-page	vbf6jma6n21ku5zgcr6ee324	en	["ar"]	failed	2026-01-30 18:18:42.9	2026-01-30 18:18:42.909
489	api::site-setting.site-setting	x78ut3tqgg2ysm9sdloy9h4n	en	["ar"]	failed	2026-01-30 18:18:42.983	2026-01-30 18:18:42.994
495	api::nav-item.nav-item	raegc8yaa8dmtsawsoel2fgo	en	["ar"]	failed	2026-01-30 18:18:43.31	2026-01-30 18:18:43.319
509	api::nav-item.nav-item	rq2u1jraro076onekzxjlgwv	en	["ar"]	failed	2026-01-30 18:18:43.927	2026-01-30 18:18:43.933
510	api::nav-item.nav-item	f6t0zamugip5yjdqzbq5e5iz	en	["ar"]	failed	2026-01-30 18:18:43.97	2026-01-30 18:18:43.977
511	api::nav-item.nav-item	xkqdrzkqgipbpvrqrsqk5x2f	en	["ar"]	failed	2026-01-30 18:18:44.013	2026-01-30 18:18:44.02
512	api::nav-item.nav-item	ovkqi3j5gb2lgnlr4ouswb74	en	["ar"]	failed	2026-01-30 18:18:44.061	2026-01-30 18:18:44.068
515	api::nav-item.nav-item	jmodresyl36fod3cuwmb8q1e	en	["ar"]	failed	2026-01-30 18:18:44.187	2026-01-30 18:18:44.194
516	api::nav-item.nav-item	si37xkyrmogx8f8gw074j4z8	en	["ar"]	failed	2026-01-30 18:18:44.225	2026-01-30 18:18:44.232
517	api::nav-item.nav-item	o8vvlj8ve51wppzgqriu958d	en	["ar"]	failed	2026-01-30 18:18:44.267	2026-01-30 18:18:44.275
518	api::nav-item.nav-item	rmvrvicx420gwsmttsupir3u	en	["ar"]	failed	2026-01-30 18:18:44.307	2026-01-30 18:18:44.313
519	api::nav-item.nav-item	f8kjfmykuic87n4oq5smwq6i	en	["ar"]	failed	2026-01-30 18:18:44.349	2026-01-30 18:18:44.356
520	api::nav-item.nav-item	ibe5o4f91o2zug9phkntdsh6	en	["ar"]	failed	2026-01-30 18:18:44.397	2026-01-30 18:18:44.405
521	api::nav-item.nav-item	wnuvumue3x4lbte8ytbmr83q	en	["ar"]	failed	2026-01-30 18:18:44.446	2026-01-30 18:18:44.454
522	api::team-member.team-member	wfxkypmk0rpvaivtlbz5drau	en	["ar"]	failed	2026-01-30 18:18:44.661	2026-01-30 18:18:44.669
527	api::team-member.team-member	v9bi4z813g4he5edn4tzgs6v	en	["ar"]	failed	2026-01-30 18:18:44.889	2026-01-30 18:18:44.896
530	api::stat.stat	z99huyjw6zrse61d54nrvln2	en	["ar"]	failed	2026-01-30 18:18:45.007	2026-01-30 18:18:45.014
547	api::value.value	d680w77v6vhw7jk786pi58qc	en	["ar"]	failed	2026-01-30 18:18:45.683	2026-01-30 18:18:45.689
548	api::value.value	p3v9zqx13t56qmsq07eib6pc	en	["ar"]	failed	2026-01-30 18:18:45.719	2026-01-30 18:18:45.725
549	api::value.value	darw2vj9gh9fbzzi6gb3og0h	en	["ar"]	failed	2026-01-30 18:18:45.754	2026-01-30 18:18:45.761
559	api::faq.faq	e5va2j1ibgljs74b05z81k82	en	["ar"]	failed	2026-01-30 18:18:46.148	2026-01-30 18:18:46.155
560	api::faq.faq	v7ywhj37cvl764cezauz0f5b	en	["ar"]	failed	2026-01-30 18:18:46.185	2026-01-30 18:18:46.191
561	api::faq.faq	qf5pq80t9a507yj8aj21zhn2	en	["ar"]	failed	2026-01-30 18:18:46.219	2026-01-30 18:18:46.224
562	api::faq.faq	ipjdyql10frdiatc57uf0y3p	en	["ar"]	failed	2026-01-30 18:18:46.259	2026-01-30 18:18:46.265
563	api::faq.faq	ol7pspiirafqq04g4ary8rkp	en	["ar"]	failed	2026-01-30 18:18:46.294	2026-01-30 18:18:46.3
564	api::faq.faq	jb4wfle7qm7svvk4sbhqy0hq	en	["ar"]	failed	2026-01-30 18:18:46.329	2026-01-30 18:18:46.338
565	api::faq.faq	gpr95kfdlvaugfr2br39ro41	en	["ar"]	failed	2026-01-30 18:18:46.367	2026-01-30 18:18:46.373
566	api::faq.faq	eg3xmm6xkmgwsikgq0x6whr1	en	["ar"]	failed	2026-01-30 18:18:46.409	2026-01-30 18:18:46.417
567	api::faq.faq	q6hnl9m0dha5oj4z85bea7ib	en	["ar"]	failed	2026-01-30 18:18:46.447	2026-01-30 18:18:46.453
175	api::nav-item.nav-item	kh4m2h0znkffd84m59cmpkxb	en	["ar"]	failed	2026-01-30 14:17:24.219	2026-01-30 14:17:24.228
176	api::nav-item.nav-item	nyql2tja2yocq740mg9mf4a6	en	["ar"]	failed	2026-01-30 14:17:24.273	2026-01-30 14:17:24.287
177	api::feature.feature	xmcxff5edk472705mbqb71bl	en	["ar"]	failed	2026-01-30 14:17:24.643	2026-01-30 14:17:24.651
178	api::feature.feature	okon92nasoeif9oychpf026h	en	["ar"]	failed	2026-01-30 14:17:24.715	2026-01-30 14:17:24.722
179	api::feature.feature	mukat5cb666vp5d81toli0rg	en	["ar"]	failed	2026-01-30 14:17:24.785	2026-01-30 14:17:24.796
180	api::feature.feature	xdopmje4njvvqrzrf6ufyp3b	en	["ar"]	failed	2026-01-30 14:17:24.859	2026-01-30 14:17:24.867
181	api::feature.feature	akxamcikpepgsz2i6ypr56xg	en	["ar"]	failed	2026-01-30 14:17:24.928	2026-01-30 14:17:24.94
186	api::value.value	fh5kn0swwxb3ni1k3ddlxaoa	en	["ar"]	failed	2026-01-30 14:17:25.287	2026-01-30 14:17:25.297
187	api::value.value	f9f9lr81alrbdkgdbfs27s2c	en	["ar"]	failed	2026-01-30 14:17:25.36	2026-01-30 14:17:25.366
190	api::value.value	hrersmog4yigihu1wd9kpell	en	["ar"]	failed	2026-01-30 14:17:25.565	2026-01-30 14:17:25.573
488	api::contact-page.contact-page	zdj851gva7noajn8sr0udmkv	en	["ar"]	failed	2026-01-30 18:18:42.942	2026-01-30 18:18:42.952
494	api::case-studies-page.case-studies-page	k1g4t5kgflzg3fxy6mtz4yqu	en	["ar"]	failed	2026-01-30 18:18:43.256	2026-01-30 18:18:43.265
496	api::nav-item.nav-item	l4sgcr496pyn8zq43r8i4n37	en	["ar"]	failed	2026-01-30 18:18:43.356	2026-01-30 18:18:43.363
498	api::nav-item.nav-item	yvfzbkoejrivevwyonbsmlmt	en	["ar"]	failed	2026-01-30 18:18:43.446	2026-01-30 18:18:43.455
499	api::nav-item.nav-item	xgakndqsc0ehefkx5cizlnw7	en	["ar"]	failed	2026-01-30 18:18:43.491	2026-01-30 18:18:43.499
500	api::nav-item.nav-item	a0k9mfymdectpn282l1vajck	en	["ar"]	failed	2026-01-30 18:18:43.535	2026-01-30 18:18:43.542
501	api::nav-item.nav-item	w40u32x8qr65s1s4dcslqcfx	en	["ar"]	failed	2026-01-30 18:18:43.574	2026-01-30 18:18:43.581
502	api::nav-item.nav-item	g83zezotrpr8rpjjufogmmqy	en	["ar"]	failed	2026-01-30 18:18:43.619	2026-01-30 18:18:43.626
503	api::nav-item.nav-item	wv05oxybtxaiy2sp7rzb6sps	en	["ar"]	failed	2026-01-30 18:18:43.663	2026-01-30 18:18:43.669
504	api::nav-item.nav-item	zz5f6w6q4a75ia6ma7658m5u	en	["ar"]	failed	2026-01-30 18:18:43.707	2026-01-30 18:18:43.715
505	api::nav-item.nav-item	qmpjrhlrk6olmghoqkhi6wh2	en	["ar"]	failed	2026-01-30 18:18:43.753	2026-01-30 18:18:43.761
506	api::nav-item.nav-item	qjmbvsnny6jggsbxmpj2kwi3	en	["ar"]	failed	2026-01-30 18:18:43.799	2026-01-30 18:18:43.806
507	api::nav-item.nav-item	agq8sw7l8pzvw7s4bw4y30xk	en	["ar"]	failed	2026-01-30 18:18:43.838	2026-01-30 18:18:43.846
508	api::nav-item.nav-item	jfry982b0mf2csdm875iozrp	en	["ar"]	failed	2026-01-30 18:18:43.879	2026-01-30 18:18:43.887
513	api::nav-item.nav-item	va433bevugruzxp9qwnl2ofp	en	["ar"]	failed	2026-01-30 18:18:44.104	2026-01-30 18:18:44.112
514	api::nav-item.nav-item	whoow9wi4jbdzjxsuj8v6dx5	en	["ar"]	failed	2026-01-30 18:18:44.146	2026-01-30 18:18:44.155
182	api::feature.feature	xxopspqhwd5wa36uklzj09il	en	["ar"]	failed	2026-01-30 14:17:25.001	2026-01-30 14:17:25.007
183	api::feature.feature	apq34e9g85zgu1vzoft5cfwf	en	["ar"]	failed	2026-01-30 14:17:25.071	2026-01-30 14:17:25.077
184	api::feature.feature	gshyklm5wf8whfvfjzy0rs6u	en	["ar"]	failed	2026-01-30 14:17:25.143	2026-01-30 14:17:25.15
189	api::value.value	z9oqtf8yarxhlpfs48nk1anu	en	["ar"]	failed	2026-01-30 14:17:25.495	2026-01-30 14:17:25.504
215	api::partner.partner	g4nubzrjv3a83sbhvr89ncg9	en	["ar"]	failed	2026-01-30 14:17:27.056	2026-01-30 14:17:27.061
216	api::partner.partner	qbw92czgjvqd28c8xtb56s9c	en	["ar"]	failed	2026-01-30 14:17:27.118	2026-01-30 14:17:27.125
217	api::nav-item.nav-item	qml569g7l96ps6g7y6b03rrg	en	["ar"]	failed	2026-01-30 15:39:04.299	2026-01-30 15:39:04.309
218	api::nav-item.nav-item	z17u0ipiy7igighlooomk9jq	en	["ar"]	failed	2026-01-30 15:39:04.361	2026-01-30 15:39:04.371
219	api::nav-item.nav-item	ja37yxbj6s2elnzjiozfoo53	en	["ar"]	failed	2026-01-30 15:39:04.446	2026-01-30 15:39:04.455
220	api::nav-item.nav-item	z7lx9phzz6x75i9sxiyxpsde	en	["ar"]	failed	2026-01-30 15:39:04.508	2026-01-30 15:39:04.515
221	api::nav-item.nav-item	z0qomm9fye27l2xfycp2qzx6	en	["ar"]	failed	2026-01-30 15:39:04.56	2026-01-30 15:39:04.568
222	api::nav-item.nav-item	e1xft54oktx53gvnrhz5r4jk	en	["ar"]	failed	2026-01-30 15:39:04.611	2026-01-30 15:39:04.618
223	api::nav-item.nav-item	ca27i7h5s4dvsdwg7ew6v58a	en	["ar"]	failed	2026-01-30 15:39:04.664	2026-01-30 15:39:04.671
224	api::nav-item.nav-item	c7hhj3roki8ndt97ccm92w7w	en	["ar"]	failed	2026-01-30 15:39:04.719	2026-01-30 15:39:04.733
225	api::nav-item.nav-item	p0mctt5dc1l4umtv2q7ydsdp	en	["ar"]	failed	2026-01-30 15:39:04.771	2026-01-30 15:39:04.782
226	api::nav-item.nav-item	xxggy5zyy8n30fvgq8tpe2a5	en	["ar"]	failed	2026-01-30 15:39:04.831	2026-01-30 15:39:04.839
227	api::nav-item.nav-item	gsprs3d3umli1r29rxx04h0o	en	["ar"]	failed	2026-01-30 15:39:04.882	2026-01-30 15:39:04.889
228	api::nav-item.nav-item	lo9cl8t0ner6tsiaaey3me6l	en	["ar"]	failed	2026-01-30 15:39:04.931	2026-01-30 15:39:04.937
229	api::nav-item.nav-item	ygc4iq5emmv2x3aw1vcgcytg	en	["ar"]	failed	2026-01-30 15:39:04.974	2026-01-30 15:39:04.985
230	api::nav-item.nav-item	pus6nlh4d003j41got08q4ir	en	["ar"]	failed	2026-01-30 15:39:05.023	2026-01-30 15:39:05.033
231	api::nav-item.nav-item	jtfb59hswh6r1dxt5kv0qani	en	["ar"]	failed	2026-01-30 15:39:05.07	2026-01-30 15:39:05.084
232	api::nav-item.nav-item	oxlqgpiscqn33jaoy2s2cnf0	en	["ar"]	failed	2026-01-30 15:39:05.119	2026-01-30 15:39:05.132
233	api::nav-item.nav-item	m7pplg5a08665rpjutax3bl7	en	["ar"]	failed	2026-01-30 15:39:05.167	2026-01-30 15:39:05.173
234	api::nav-item.nav-item	xouri4r4ucagisz5zb5nodl4	en	["ar"]	failed	2026-01-30 15:39:05.21	2026-01-30 15:39:05.217
235	api::nav-item.nav-item	he2t38pnrjvkm899pqn4n0b2	en	["ar"]	failed	2026-01-30 15:39:05.257	2026-01-30 15:39:05.267
236	api::nav-item.nav-item	snf4dt2bc337wrdr7erfejbm	en	["ar"]	failed	2026-01-30 15:39:05.305	2026-01-30 15:39:05.312
237	api::nav-item.nav-item	dhgz8g37i6d3m26rrnjbb35q	en	["ar"]	failed	2026-01-30 15:39:05.402	2026-01-30 15:39:05.41
238	api::nav-item.nav-item	qjy0yb0c1okv3i81070qq6b2	en	["ar"]	failed	2026-01-30 15:39:05.451	2026-01-30 15:39:05.46
239	api::nav-item.nav-item	gdt5f3hi9f4xbob1j3p95r6v	en	["ar"]	failed	2026-01-30 15:39:05.501	2026-01-30 15:39:05.509
240	api::nav-item.nav-item	g9hat6hk31vlwwnnp54mrvw9	en	["ar"]	failed	2026-01-30 15:39:05.546	2026-01-30 15:39:05.552
241	api::feature.feature	y77s571ctmu3li0dt606vv2u	en	["ar"]	failed	2026-01-30 15:39:05.922	2026-01-30 15:39:05.936
242	api::feature.feature	is2137cd7lniwt29mmd28sqz	en	["ar"]	failed	2026-01-30 15:39:05.993	2026-01-30 15:39:05.999
243	api::feature.feature	vjozukabzs1et1d5g0x7sq3v	en	["ar"]	failed	2026-01-30 15:39:06.057	2026-01-30 15:39:06.063
244	api::feature.feature	nuivmcra6032uvfdm40mg1jr	en	["ar"]	failed	2026-01-30 15:39:06.122	2026-01-30 15:39:06.138
245	api::feature.feature	i4l6v2tixeqhkjpvm80m892b	en	["ar"]	failed	2026-01-30 15:39:06.199	2026-01-30 15:39:06.205
246	api::feature.feature	gto31emz30rra4s8b7i9u9py	en	["ar"]	failed	2026-01-30 15:39:06.264	2026-01-30 15:39:06.27
247	api::feature.feature	lqunuw5tc89ikxay1f0xsex2	en	["ar"]	failed	2026-01-30 15:39:06.348	2026-01-30 15:39:06.356
248	api::feature.feature	hlu535ir0p570b2ofdcologe	en	["ar"]	failed	2026-01-30 15:39:06.413	2026-01-30 15:39:06.421
249	api::value.value	fpwomjz7i6zptw1vim490y7f	en	["ar"]	failed	2026-01-30 15:39:06.49	2026-01-30 15:39:06.496
250	api::value.value	hlhvfk49679xo61h7dcuqhnl	en	["ar"]	failed	2026-01-30 15:39:06.554	2026-01-30 15:39:06.56
251	api::value.value	xjua5k5many9sbx6qambqn1i	en	["ar"]	failed	2026-01-30 15:39:06.612	2026-01-30 15:39:06.618
252	api::value.value	ea7f5paszs7eory2fkgnaxv0	en	["ar"]	failed	2026-01-30 15:39:06.673	2026-01-30 15:39:06.687
253	api::value.value	ma75shc2ym033245jgatz8f3	en	["ar"]	failed	2026-01-30 15:39:06.738	2026-01-30 15:39:06.745
254	api::value.value	hgjcpkiinviyi1qk6f1281ix	en	["ar"]	failed	2026-01-30 15:39:06.797	2026-01-30 15:39:06.802
255	api::testimonial.testimonial	xmhsy6ruhv7thgqk8t7xwnro	en	["ar"]	failed	2026-01-30 15:39:06.862	2026-01-30 15:39:06.869
256	api::testimonial.testimonial	d6ss97xsimqipmc2xm8hgo0s	en	["ar"]	failed	2026-01-30 15:39:06.911	2026-01-30 15:39:06.92
257	api::testimonial.testimonial	xebb2lg3o0edxbwhtnu67gve	en	["ar"]	failed	2026-01-30 15:39:06.953	2026-01-30 15:39:06.959
258	api::testimonial.testimonial	o4or4c8hjmewx1roh3fja1b2	en	["ar"]	failed	2026-01-30 15:39:06.997	2026-01-30 15:39:07.003
259	api::testimonial.testimonial	wl3yac9al1s177vcrfg43y50	en	["ar"]	failed	2026-01-30 15:39:07.04	2026-01-30 15:39:07.047
260	api::testimonial.testimonial	b4haoku42786nr6c59xf1az4	en	["ar"]	failed	2026-01-30 15:39:07.086	2026-01-30 15:39:07.092
261	api::faq.faq	vs0rmezicbkl0waxg6g6q3i6	en	["ar"]	failed	2026-01-30 15:39:07.127	2026-01-30 15:39:07.138
262	api::faq.faq	guulfw151451h6f6fzm458xd	en	["ar"]	failed	2026-01-30 15:39:07.177	2026-01-30 15:39:07.187
263	api::faq.faq	hfq9haj80tilvs6u4it8n04z	en	["ar"]	failed	2026-01-30 15:39:07.225	2026-01-30 15:39:07.239
264	api::faq.faq	pnptskjyl3c0u7jrayizkpfi	en	["ar"]	failed	2026-01-30 15:39:07.275	2026-01-30 15:39:07.287
265	api::faq.faq	zt3gagfuydbxsb2czspxwn9a	en	["ar"]	failed	2026-01-30 15:39:07.321	2026-01-30 15:39:07.329
266	api::faq.faq	xmp33zlfyvh4psf7s4546ko9	en	["ar"]	failed	2026-01-30 15:39:07.369	2026-01-30 15:39:07.376
267	api::faq.faq	hsg4mbe35xww4gqs4cmv9qgg	en	["ar"]	failed	2026-01-30 15:39:07.414	2026-01-30 15:39:07.422
268	api::faq.faq	w7zb2m9bs5gys197lg28kzfh	en	["ar"]	failed	2026-01-30 15:39:07.469	2026-01-30 15:39:07.477
269	api::faq.faq	nqirj2c2peeq3dqlho6h2pir	en	["ar"]	failed	2026-01-30 15:39:07.516	2026-01-30 15:39:07.52
270	api::faq.faq	o7urpq87s00uhbw32zg61zek	en	["ar"]	failed	2026-01-30 15:39:07.567	2026-01-30 15:39:07.573
271	api::pricing-plan.pricing-plan	adqdwuavcn5hprfxmp9e1s44	en	["ar"]	failed	2026-01-30 15:39:07.623	2026-01-30 15:39:07.636
272	api::pricing-plan.pricing-plan	ryl7f1q0pn3jf4z4a5kxmesw	en	["ar"]	failed	2026-01-30 15:39:07.676	2026-01-30 15:39:07.69
273	api::pricing-plan.pricing-plan	uk4r69821v4ckadn2ard7eco	en	["ar"]	failed	2026-01-30 15:39:07.727	2026-01-30 15:39:07.74
274	api::pricing-plan.pricing-plan	nj9mtkdeuktyvhqsa19lemx4	en	["ar"]	failed	2026-01-30 15:39:07.782	2026-01-30 15:39:07.799
275	api::partner.partner	m61n9wrzo0dwoqd8dqmzi37d	en	["ar"]	failed	2026-01-30 15:39:07.854	2026-01-30 15:39:07.862
276	api::partner.partner	cr5v6c6ghcufb4xizsgkdrhw	en	["ar"]	failed	2026-01-30 15:39:07.91	2026-01-30 15:39:07.917
493	api::demos-page.demos-page	ykxxlf848bgvbfirle8citsp	en	["ar"]	failed	2026-01-30 18:18:43.203	2026-01-30 18:18:43.211
497	api::nav-item.nav-item	hrzgt72ub8jm4e3ftrms0uyp	en	["ar"]	failed	2026-01-30 18:18:43.396	2026-01-30 18:18:43.404
532	api::stat.stat	ggacr0iflsppqqp77ggyfu1s	en	["ar"]	failed	2026-01-30 18:18:45.089	2026-01-30 18:18:45.094
533	api::stat.stat	pymy6iacdargxg3dw1do183q	en	["ar"]	failed	2026-01-30 18:18:45.132	2026-01-30 18:18:45.139
534	api::process-step.process-step	qqyjxtl2n63w1lcupjhr2pyx	en	["ar"]	failed	2026-01-30 18:18:45.184	2026-01-30 18:18:45.19
535	api::process-step.process-step	y5cfo2qcvfrjyt4i2e1hsp2b	en	["ar"]	failed	2026-01-30 18:18:45.222	2026-01-30 18:18:45.231
536	api::process-step.process-step	xdbuck3q9zdbdi5bkbi7cgpi	en	["ar"]	failed	2026-01-30 18:18:45.264	2026-01-30 18:18:45.27
537	api::process-step.process-step	va2tqarc1dhg7q91rbdfqotz	en	["ar"]	failed	2026-01-30 18:18:45.306	2026-01-30 18:18:45.312
538	api::feature.feature	midl6kjouzvf0w346s7eehce	en	["ar"]	failed	2026-01-30 18:18:45.349	2026-01-30 18:18:45.356
539	api::feature.feature	jnbpf3xbfwd8s6mkrrv4qojl	en	["ar"]	failed	2026-01-30 18:18:45.386	2026-01-30 18:18:45.394
540	api::feature.feature	t6u90g9zii4cf007q64e5ao9	en	["ar"]	failed	2026-01-30 18:18:45.42	2026-01-30 18:18:45.427
541	api::feature.feature	q6sz4zmgh5g7vwrzivuqxy6t	en	["ar"]	failed	2026-01-30 18:18:45.459	2026-01-30 18:18:45.465
542	api::feature.feature	lzx4x43kzzh1ty3qy5yo3hry	en	["ar"]	failed	2026-01-30 18:18:45.496	2026-01-30 18:18:45.503
543	api::feature.feature	gn0lthbliz56shcl2yjnlgw2	en	["ar"]	failed	2026-01-30 18:18:45.533	2026-01-30 18:18:45.539
553	api::testimonial.testimonial	n5savc0wwmy19jtftka6buc6	en	["ar"]	failed	2026-01-30 18:18:45.906	2026-01-30 18:18:45.912
556	api::testimonial.testimonial	xdsfqj4itwrnw086uzh4giwc	en	["ar"]	failed	2026-01-30 18:18:46.023	2026-01-30 18:18:46.029
557	api::testimonial.testimonial	z0ovc7vux0d784b6uw7j9jhk	en	["ar"]	failed	2026-01-30 18:18:46.063	2026-01-30 18:18:46.069
558	api::faq.faq	tu18q591jjftd3d8raojpd16	en	["ar"]	failed	2026-01-30 18:18:46.11	2026-01-30 18:18:46.116
277	api::partner.partner	oes2yvpfn7znpx0jp3x3604p	en	["ar"]	failed	2026-01-30 15:39:07.956	2026-01-30 15:39:07.962
278	api::partner.partner	h4vealnnkkmm1yojfr7z9g5i	en	["ar"]	failed	2026-01-30 15:39:08.006	2026-01-30 15:39:08.012
279	api::partner.partner	mfrub78sruw9oidymwqpfb8g	en	["ar"]	failed	2026-01-30 15:39:08.054	2026-01-30 15:39:08.061
525	api::team-member.team-member	p92k1mn0eki62w9n7m9eyuef	en	["ar"]	failed	2026-01-30 18:18:44.799	2026-01-30 18:18:44.805
528	api::stat.stat	typ511z4s15pwanppld4djbw	en	["ar"]	failed	2026-01-30 18:18:44.93	2026-01-30 18:18:44.939
529	api::stat.stat	o1xivj864s582431slikv69g	en	["ar"]	failed	2026-01-30 18:18:44.969	2026-01-30 18:18:44.976
531	api::stat.stat	bmj7p348829pw5f8bcxykezf	en	["ar"]	failed	2026-01-30 18:18:45.05	2026-01-30 18:18:45.057
544	api::feature.feature	qaagrpp7iu495nq6rhigp911	en	["ar"]	failed	2026-01-30 18:18:45.571	2026-01-30 18:18:45.578
545	api::feature.feature	vxcazdvukyt62ad8ozwmvntk	en	["ar"]	failed	2026-01-30 18:18:45.608	2026-01-30 18:18:45.614
546	api::value.value	cyus3i632uky9wpccoaefv84	en	["ar"]	failed	2026-01-30 18:18:45.648	2026-01-30 18:18:45.654
568	api::pricing-plan.pricing-plan	ft3fhikbzqzqaokaf5mrr1kx	en	["ar"]	failed	2026-01-30 18:18:46.491	2026-01-30 18:18:46.498
579	api::demo.demo	l7pvfpt36e6lpyzs1h2ams5e	en	["ar"]	failed	2026-01-30 18:18:46.925	2026-01-30 18:18:46.931
582	api::demo.demo	a66vegjhpjstd93rnenqgv2x	en	["ar"]	failed	2026-01-30 18:18:47.028	2026-01-30 18:18:47.035
585	api::case-study.case-study	gatf4vjguywsjam79sw73bsn	en	["ar"]	failed	2026-01-30 18:18:47.131	2026-01-30 18:18:47.137
588	api::case-study.case-study	u7b7vlfvpfl6eyam7oxml33d	en	["ar"]	failed	2026-01-30 18:18:47.231	2026-01-30 18:18:47.238
590	api::solution.solution	jttjl27jparr5i4e0b1x7qri	en	["ar"]	failed	2026-01-30 18:18:47.302	2026-01-30 18:18:47.307
592	api::solution.solution	tp1v0g9mwwc85l8cr06uph1k	en	["ar"]	failed	2026-01-30 18:18:47.368	2026-01-30 18:18:47.374
595	api::industry.industry	bn3pijiba064cpswricg4tyj	en	["ar"]	failed	2026-01-30 18:18:47.466	2026-01-30 18:18:47.471
598	api::industry.industry	ahi4chuql6uq3voxc68rybjd	en	["ar"]	failed	2026-01-30 18:18:47.592	2026-01-30 18:18:47.599
280	api::partner.partner	dxxum777dql70wiq2ulz3jwt	en	["ar"]	failed	2026-01-30 15:39:08.102	2026-01-30 15:39:08.109
281	api::nav-item.nav-item	ps4i21nbk18w51pykh08zylk	en	["ar"]	failed	2026-01-30 15:44:48.436	2026-01-30 15:44:48.449
282	api::nav-item.nav-item	epne1m36npf10mv8ogti885z	en	["ar"]	failed	2026-01-30 15:44:48.489	2026-01-30 15:44:48.502
283	api::nav-item.nav-item	c7a3ubob0errty4zkrf1354i	en	["ar"]	failed	2026-01-30 15:44:48.548	2026-01-30 15:44:48.559
284	api::nav-item.nav-item	fupjkrw5k4t8uyl8glkrvq75	en	["ar"]	failed	2026-01-30 15:44:48.601	2026-01-30 15:44:48.609
285	api::nav-item.nav-item	c3goqgiwll6g0vx0fd7lsq90	en	["ar"]	failed	2026-01-30 15:44:48.648	2026-01-30 15:44:48.657
286	api::nav-item.nav-item	mmeykzwkx2uhaqj6q4x0iqdn	en	["ar"]	failed	2026-01-30 15:44:48.693	2026-01-30 15:44:48.701
287	api::nav-item.nav-item	tyvocjzhqxu53g82ghe9jg4g	en	["ar"]	failed	2026-01-30 15:44:48.737	2026-01-30 15:44:48.747
288	api::nav-item.nav-item	mdnlsd8zts0jkin79o6zln5y	en	["ar"]	failed	2026-01-30 15:44:48.785	2026-01-30 15:44:48.791
289	api::nav-item.nav-item	rtdyfqgbbjtedtk3yh63rjc7	en	["ar"]	failed	2026-01-30 15:44:48.835	2026-01-30 15:44:48.845
290	api::nav-item.nav-item	bhcvol97mjs390xnh4s4agxp	en	["ar"]	failed	2026-01-30 15:44:48.886	2026-01-30 15:44:48.892
291	api::nav-item.nav-item	chhq2a72tntqfdks0kycmhxr	en	["ar"]	failed	2026-01-30 15:44:48.936	2026-01-30 15:44:48.942
292	api::nav-item.nav-item	v5nezviti4gnl75fq05pdt8g	en	["ar"]	failed	2026-01-30 15:44:48.985	2026-01-30 15:44:48.991
293	api::nav-item.nav-item	o1upa6a7wca5vldvlrtp0r5y	en	["ar"]	failed	2026-01-30 15:44:49.046	2026-01-30 15:44:49.055
294	api::nav-item.nav-item	n5l1y6dih1jdjbjv2v6ch0cp	en	["ar"]	failed	2026-01-30 15:44:49.112	2026-01-30 15:44:49.121
295	api::nav-item.nav-item	pqc4qya1cp80qkgrpkckvan2	en	["ar"]	failed	2026-01-30 15:44:49.173	2026-01-30 15:44:49.181
296	api::nav-item.nav-item	ihxdzzg3rcllc571xxyphnj7	en	["ar"]	failed	2026-01-30 15:44:49.22	2026-01-30 15:44:49.227
297	api::nav-item.nav-item	qu9gkhln381km7k4eo44eab2	en	["ar"]	failed	2026-01-30 15:44:49.267	2026-01-30 15:44:49.275
298	api::nav-item.nav-item	n7t6k8d3rvnl83fyjineqin9	en	["ar"]	failed	2026-01-30 15:44:49.317	2026-01-30 15:44:49.341
299	api::nav-item.nav-item	wimbuo7acu8q18mw0omr2pov	en	["ar"]	failed	2026-01-30 15:44:49.38	2026-01-30 15:44:49.387
300	api::nav-item.nav-item	a8fqop5rid567hot7lvcqvmk	en	["ar"]	failed	2026-01-30 15:44:49.423	2026-01-30 15:44:49.431
301	api::nav-item.nav-item	vtsrp7zdnscp5i2fakg34dtd	en	["ar"]	failed	2026-01-30 15:44:49.47	2026-01-30 15:44:49.478
302	api::nav-item.nav-item	p42t1hvwpgzlwmx76fev4r6i	en	["ar"]	failed	2026-01-30 15:44:49.517	2026-01-30 15:44:49.525
303	api::nav-item.nav-item	efsweabyp2y18kpvt294r39m	en	["ar"]	failed	2026-01-30 15:44:49.563	2026-01-30 15:44:49.57
304	api::nav-item.nav-item	xbezgrrpcv3lgqxm5h1ozxwp	en	["ar"]	failed	2026-01-30 15:44:49.606	2026-01-30 15:44:49.615
305	api::nav-item.nav-item	dq4kspt4unjzh1pup2yw6183	en	["ar"]	failed	2026-01-30 15:44:49.652	2026-01-30 15:44:49.659
306	api::nav-item.nav-item	x3p18c70rpgl61hf7wglkpjg	en	["ar"]	failed	2026-01-30 15:44:49.704	2026-01-30 15:44:49.712
307	api::nav-item.nav-item	lmevf5vvfn2cpf93pxldsjs4	en	["ar"]	failed	2026-01-30 15:44:49.748	2026-01-30 15:44:49.755
308	api::feature.feature	hec0f37j7o9cfpznte5fb1c3	en	["ar"]	failed	2026-01-30 15:44:50.192	2026-01-30 15:44:50.204
309	api::feature.feature	v9w8w3jjvmgfdqp53belefb8	en	["ar"]	failed	2026-01-30 15:44:50.263	2026-01-30 15:44:50.269
310	api::feature.feature	s3wmah977wh3ltipkhtckd5c	en	["ar"]	failed	2026-01-30 15:44:50.329	2026-01-30 15:44:50.337
311	api::feature.feature	e4awgqqf6l4mhs126qx09n7t	en	["ar"]	failed	2026-01-30 15:44:50.392	2026-01-30 15:44:50.399
312	api::feature.feature	xyhe8dvj5dbaga9m092psvij	en	["ar"]	failed	2026-01-30 15:44:50.453	2026-01-30 15:44:50.46
313	api::feature.feature	ucpfvjxlpx11bkuek63vonq4	en	["ar"]	failed	2026-01-30 15:44:50.512	2026-01-30 15:44:50.518
314	api::feature.feature	ncafeqdsm0nvdancfpis8w1a	en	["ar"]	failed	2026-01-30 15:44:50.568	2026-01-30 15:44:50.574
315	api::feature.feature	alui35tqffv4867y9n0hi2hz	en	["ar"]	failed	2026-01-30 15:44:50.623	2026-01-30 15:44:50.63
316	api::value.value	nzgiqobb646jnnrjhqz5dljx	en	["ar"]	failed	2026-01-30 15:44:50.689	2026-01-30 15:44:50.696
317	api::value.value	lbgf9c8sai5mosiuehk4kqng	en	["ar"]	failed	2026-01-30 15:44:50.745	2026-01-30 15:44:50.751
318	api::value.value	r8eo4ra2x7k7atzqvas0r94e	en	["ar"]	failed	2026-01-30 15:44:50.802	2026-01-30 15:44:50.808
319	api::value.value	h72d0htxexq9h2q7aiu9t56l	en	["ar"]	failed	2026-01-30 15:44:50.856	2026-01-30 15:44:50.863
320	api::value.value	pf8zm81srdyvnzf2qylljqu7	en	["ar"]	failed	2026-01-30 15:44:50.909	2026-01-30 15:44:50.914
321	api::value.value	a55n7kc28to30rpjxs3e03wt	en	["ar"]	failed	2026-01-30 15:44:50.965	2026-01-30 15:44:50.972
322	api::testimonial.testimonial	zk71jumbk8hcmawb0z16h0mr	en	["ar"]	failed	2026-01-30 15:44:51.024	2026-01-30 15:44:51.03
323	api::testimonial.testimonial	amxum6ei6q2c6zv1lp1s6s3s	en	["ar"]	failed	2026-01-30 15:44:51.062	2026-01-30 15:44:51.069
324	api::testimonial.testimonial	unpi8ti73w7hqi00vh01ahsm	en	["ar"]	failed	2026-01-30 15:44:51.098	2026-01-30 15:44:51.105
325	api::testimonial.testimonial	dfcaiaqg6y2je705i9rvfs5y	en	["ar"]	failed	2026-01-30 15:44:51.142	2026-01-30 15:44:51.151
326	api::testimonial.testimonial	uu6o6oo0jptd5g6ghtr5tjxv	en	["ar"]	failed	2026-01-30 15:44:51.18	2026-01-30 15:44:51.185
327	api::testimonial.testimonial	tsgr7vsklp8are0kmfhrv0h9	en	["ar"]	failed	2026-01-30 15:44:51.217	2026-01-30 15:44:51.223
328	api::faq.faq	ep80lpoxicrnms9tktx69nnd	en	["ar"]	failed	2026-01-30 15:44:51.261	2026-01-30 15:44:51.269
329	api::faq.faq	vtr88u1ox8n7lku6c4i9etfk	en	["ar"]	failed	2026-01-30 15:44:51.319	2026-01-30 15:44:51.325
330	api::faq.faq	d7o7sqyxo5pfglkb594sqqya	en	["ar"]	failed	2026-01-30 15:44:51.372	2026-01-30 15:44:51.381
331	api::faq.faq	qturimm7isxacjm2eeqpax2g	en	["ar"]	failed	2026-01-30 15:44:51.424	2026-01-30 15:44:51.43
332	api::faq.faq	axtkqhkyo32enzg5tfwf0z21	en	["ar"]	failed	2026-01-30 15:44:51.479	2026-01-30 15:44:51.484
333	api::faq.faq	ndtt39q91lpt3dukoabgvui9	en	["ar"]	failed	2026-01-30 15:44:51.531	2026-01-30 15:44:51.537
334	api::faq.faq	jao6wu3o6222i9qw7uli14mw	en	["ar"]	failed	2026-01-30 15:44:51.584	2026-01-30 15:44:51.589
335	api::faq.faq	yowclj3uye9a553sid0jnozr	en	["ar"]	failed	2026-01-30 15:44:51.647	2026-01-30 15:44:51.655
336	api::faq.faq	uky0vuki15q786s08ym5psox	en	["ar"]	failed	2026-01-30 15:44:51.7	2026-01-30 15:44:51.707
337	api::faq.faq	vfkr91p9hszn90yb5351h5r8	en	["ar"]	failed	2026-01-30 15:44:51.781	2026-01-30 15:44:51.788
338	api::pricing-plan.pricing-plan	qy1k5jwsy9h6mafi7a73y9y5	en	["ar"]	failed	2026-01-30 15:44:51.843	2026-01-30 15:44:51.85
339	api::pricing-plan.pricing-plan	yknmpj3jz0fmon5penqglh6f	en	["ar"]	failed	2026-01-30 15:44:51.893	2026-01-30 15:44:51.9
340	api::pricing-plan.pricing-plan	mlev1x549s7l3o0r2ptsxqks	en	["ar"]	failed	2026-01-30 15:44:51.944	2026-01-30 15:44:51.95
341	api::pricing-plan.pricing-plan	en09b9suhjzupzpzgzgxvk5e	en	["ar"]	failed	2026-01-30 15:44:51.996	2026-01-30 15:44:52.001
342	api::partner.partner	btbq10ee3z3ns2inqtmdez3y	en	["ar"]	failed	2026-01-30 15:44:52.055	2026-01-30 15:44:52.063
343	api::partner.partner	bz7jpl9vy6frcj4d957pkyak	en	["ar"]	failed	2026-01-30 15:44:52.113	2026-01-30 15:44:52.12
344	api::partner.partner	knbllycimdvzhnjkjb6axk48	en	["ar"]	failed	2026-01-30 15:44:52.168	2026-01-30 15:44:52.175
345	api::partner.partner	pewvvx7vwe4a8de0smsa3pz0	en	["ar"]	failed	2026-01-30 15:44:52.219	2026-01-30 15:44:52.227
569	api::pricing-plan.pricing-plan	ao40ftksyfzfjnwz1fuap352	en	["ar"]	failed	2026-01-30 18:18:46.529	2026-01-30 18:18:46.538
570	api::pricing-plan.pricing-plan	kr3oiddgej4uxv2qnvhw0ips	en	["ar"]	failed	2026-01-30 18:18:46.57	2026-01-30 18:18:46.577
571	api::pricing-plan.pricing-plan	q36bxbo8jscv8kfgk2zoiicl	en	["ar"]	failed	2026-01-30 18:18:46.609	2026-01-30 18:18:46.615
572	api::partner.partner	bsvd4p89j0yb94c16fzeeiff	en	["ar"]	failed	2026-01-30 18:18:46.648	2026-01-30 18:18:46.655
574	api::partner.partner	q6vkq0ff1cvnky8z9vvs5itv	en	["ar"]	failed	2026-01-30 18:18:46.736	2026-01-30 18:18:46.741
575	api::partner.partner	al9qg47mf902yrf1lw56y6au	en	["ar"]	failed	2026-01-30 18:18:46.77	2026-01-30 18:18:46.777
576	api::partner.partner	z4nuwywgrr9ht59qutmgtwc2	en	["ar"]	failed	2026-01-30 18:18:46.806	2026-01-30 18:18:46.813
577	api::partner.partner	crqrxytx9c5t3zl5m4c41zvq	en	["ar"]	failed	2026-01-30 18:18:46.843	2026-01-30 18:18:46.85
578	api::demo.demo	j112ribw4k841vuisw962l9s	en	["ar"]	failed	2026-01-30 18:18:46.89	2026-01-30 18:18:46.896
580	api::demo.demo	vrpeuc4o1es5bixrakcojgbw	en	["ar"]	failed	2026-01-30 18:18:46.957	2026-01-30 18:18:46.963
583	api::demo.demo	i6mc8bb1lpjpgg2nxe3f9ptc	en	["ar"]	failed	2026-01-30 18:18:47.062	2026-01-30 18:18:47.07
587	api::case-study.case-study	ipj2ah2vev2rppewt3d0fycn	en	["ar"]	failed	2026-01-30 18:18:47.196	2026-01-30 18:18:47.202
589	api::solution.solution	y2oa3frissstsgakqseygyaa	en	["ar"]	failed	2026-01-30 18:18:47.27	2026-01-30 18:18:47.276
591	api::solution.solution	oitp7u9upvj6zq665q0isv9a	en	["ar"]	failed	2026-01-30 18:18:47.334	2026-01-30 18:18:47.341
594	api::solution.solution	com7pqvstu1ar0n4mdqpawgm	en	["ar"]	failed	2026-01-30 18:18:47.431	2026-01-30 18:18:47.438
596	api::industry.industry	mxl9hxj99r2zpiiqb4kmu1mv	en	["ar"]	failed	2026-01-30 18:18:47.498	2026-01-30 18:18:47.504
599	api::industry.industry	q25s86r5acs1poy2jjp1glw7	en	["ar"]	failed	2026-01-30 18:18:47.625	2026-01-30 18:18:47.631
346	api::partner.partner	iesx0qmwzg75gq8c2wuxki7u	en	["ar"]	failed	2026-01-30 15:44:52.27	2026-01-30 15:44:52.275
354	api::case-study.case-study	x7m58n60s5ma4gn20yp5lkku	en	["ar"]	failed	2026-01-30 15:44:52.66	2026-01-30 15:44:52.666
355	api::case-study.case-study	nieg3dvr2ylgqk3yujmj8df8	en	["ar"]	failed	2026-01-30 15:44:52.703	2026-01-30 15:44:52.713
356	api::case-study.case-study	o6xljb5lajwdoj64909po338	en	["ar"]	failed	2026-01-30 15:44:52.747	2026-01-30 15:44:52.753
357	api::case-study.case-study	ty92z32dt3egbn7cbfim9fty	en	["ar"]	failed	2026-01-30 15:44:52.788	2026-01-30 15:44:52.794
358	api::case-study.case-study	c812i67rbqz5mu5q92cpa5qc	en	["ar"]	failed	2026-01-30 15:44:52.831	2026-01-30 15:44:52.837
359	api::solution.solution	ffjxszg5b4wgqsyu169eurq8	en	["ar"]	failed	2026-01-30 15:44:52.873	2026-01-30 15:44:52.88
360	api::solution.solution	zbkotqqwspimugbx6wyvb1az	en	["ar"]	failed	2026-01-30 15:44:52.92	2026-01-30 15:44:52.925
364	api::solution.solution	savbmcncma7j4jumkqxj0tbp	en	["ar"]	failed	2026-01-30 15:44:53.102	2026-01-30 15:44:53.109
365	api::industry.industry	xksrm492b7vlqyx4hnsuktvs	en	["ar"]	failed	2026-01-30 15:44:53.151	2026-01-30 15:44:53.159
366	api::industry.industry	uyvknsx7gf2v1s1dmnmt2d2n	en	["ar"]	failed	2026-01-30 15:44:53.194	2026-01-30 15:44:53.203
367	api::industry.industry	lrhhjtzl8gu3zbq8mdy0p2x1	en	["ar"]	failed	2026-01-30 15:44:53.238	2026-01-30 15:44:53.245
368	api::industry.industry	g4ig23xrc0od21alqqrbsqpc	en	["ar"]	failed	2026-01-30 15:44:53.283	2026-01-30 15:44:53.29
369	api::industry.industry	auc8l4bhcxg8c7v3395nu6tt	en	["ar"]	failed	2026-01-30 15:44:53.33	2026-01-30 15:44:53.336
370	api::industry.industry	n2pxy0u2c6ativ1gckrtbe6u	en	["ar"]	failed	2026-01-30 15:44:53.379	2026-01-30 15:44:53.384
347	api::partner.partner	dvm22n865twlw1o9z6qnc7uz	en	["ar"]	failed	2026-01-30 15:44:52.32	2026-01-30 15:44:52.326
349	api::demo.demo	tzobm52hdsy44yai1f8rpv72	en	["ar"]	failed	2026-01-30 15:44:52.433	2026-01-30 15:44:52.441
350	api::demo.demo	w5unflyo5hud7k9jj75o2bxv	en	["ar"]	failed	2026-01-30 15:44:52.476	2026-01-30 15:44:52.483
351	api::demo.demo	c7p81shsi9dow7xmllopgdjq	en	["ar"]	failed	2026-01-30 15:44:52.517	2026-01-30 15:44:52.524
352	api::demo.demo	elbxmz415z1dhol7qlskjyw9	en	["ar"]	failed	2026-01-30 15:44:52.56	2026-01-30 15:44:52.567
353	api::demo.demo	vhkfyhxhkvl4rgrz5ks9l98d	en	["ar"]	failed	2026-01-30 15:44:52.608	2026-01-30 15:44:52.617
348	api::demo.demo	ev9dtut7hr5xptoqsqjbfkzf	en	["ar"]	failed	2026-01-30 15:44:52.388	2026-01-30 15:44:52.396
361	api::solution.solution	vp6tq8t7flxt0kjhea4lm1qu	en	["ar"]	failed	2026-01-30 15:44:52.966	2026-01-30 15:44:52.973
362	api::solution.solution	t4bsj5swho2txvbgzgk3untx	en	["ar"]	failed	2026-01-30 15:44:53.012	2026-01-30 15:44:53.019
363	api::solution.solution	j7yuyzcg3ov34l3ljvjrozj7	en	["ar"]	failed	2026-01-30 15:44:53.057	2026-01-30 15:44:53.064
371	api::nav-item.nav-item	li8eii5oth0vcbu01ekxfouw	en	["ar"]	failed	2026-01-30 15:52:03.296	2026-01-30 15:57:23.084
372	api::nav-item.nav-item	ycwb2yfo76r959rc238gd634	en	["ar"]	failed	2026-01-30 15:52:03.376	2026-01-30 15:57:23.127
373	api::nav-item.nav-item	ek5yile60yudupxqodme4oyy	en	["ar"]	failed	2026-01-30 15:52:03.466	2026-01-30 15:57:23.17
374	api::nav-item.nav-item	i098u1xhemlaj12aue4fcei9	en	["ar"]	failed	2026-01-30 15:52:03.531	2026-01-30 15:57:23.213
375	api::nav-item.nav-item	xc1x4uwkvf2wvqvdx152mc5y	en	["ar"]	failed	2026-01-30 15:52:03.608	2026-01-30 15:57:23.256
376	api::nav-item.nav-item	unoxybhcvtvvk5ahg8cpv15s	en	["ar"]	failed	2026-01-30 15:52:03.669	2026-01-30 15:57:23.295
377	api::nav-item.nav-item	n067etr6bna7ofyu7fd4irqr	en	["ar"]	failed	2026-01-30 15:52:03.733	2026-01-30 15:57:23.334
378	api::nav-item.nav-item	yq2prflfirksbtplbsnzzmqp	en	["ar"]	failed	2026-01-30 15:52:03.798	2026-01-30 15:57:23.385
379	api::nav-item.nav-item	jan411b1cotvupc44ayhljca	en	["ar"]	failed	2026-01-30 15:52:03.85	2026-01-30 15:57:23.419
380	api::nav-item.nav-item	tdipyzsi5fpr51thkgus5bvh	en	["ar"]	failed	2026-01-30 15:52:03.902	2026-01-30 15:57:23.455
381	api::nav-item.nav-item	vooxc5att8ztp25ewbd8lsc9	en	["ar"]	failed	2026-01-30 15:52:03.954	2026-01-30 15:57:23.491
382	api::nav-item.nav-item	n3xavg35dt50ikwjjw6n6ptv	en	["ar"]	failed	2026-01-30 15:52:04.007	2026-01-30 15:57:23.529
383	api::nav-item.nav-item	twnpzwse8z9cjee67fj74iox	en	["ar"]	failed	2026-01-30 15:52:04.064	2026-01-30 15:57:23.566
384	api::nav-item.nav-item	a89qsi2bzsbuc0375lxeglbx	en	["ar"]	failed	2026-01-30 15:52:04.12	2026-01-30 15:57:23.616
385	api::nav-item.nav-item	yffgdkplocanwsvst9u1e703	en	["ar"]	failed	2026-01-30 15:52:04.173	2026-01-30 15:57:23.651
386	api::nav-item.nav-item	jc87gt0ax82q41m662h8uxkn	en	["ar"]	failed	2026-01-30 15:52:04.234	2026-01-30 15:57:23.684
387	api::nav-item.nav-item	bz82gbr3thr9oo6nakcb9xog	en	["ar"]	failed	2026-01-30 15:52:04.286	2026-01-30 15:57:23.719
388	api::nav-item.nav-item	augs6gaq21hqcel11piqgygi	en	["ar"]	failed	2026-01-30 15:52:04.34	2026-01-30 15:57:23.769
389	api::nav-item.nav-item	oyrhzxylwrcwep6y3i8xrlso	en	["ar"]	failed	2026-01-30 15:52:04.395	2026-01-30 15:57:23.805
390	api::nav-item.nav-item	gxx1xt5rnaysesnw9yvp6mn9	en	["ar"]	failed	2026-01-30 15:52:04.452	2026-01-30 15:57:23.84
391	api::nav-item.nav-item	lzrwz0dmfcyvuozpuufuglo4	en	["ar"]	failed	2026-01-30 15:52:04.504	2026-01-30 15:57:23.878
392	api::nav-item.nav-item	jke79aukr4e9fb5fygm0ucdp	en	["ar"]	failed	2026-01-30 15:52:04.558	2026-01-30 15:57:23.914
393	api::nav-item.nav-item	o5jk56xh2j9oag98ylwwnzy3	en	["ar"]	failed	2026-01-30 15:52:04.619	2026-01-30 15:57:23.95
394	api::nav-item.nav-item	cjvxdz3zv3th6tyknw5e8mej	en	["ar"]	failed	2026-01-30 15:52:04.67	2026-01-30 15:57:23.992
395	api::nav-item.nav-item	ymrtmt5zzot4nrhy9otcof58	en	["ar"]	failed	2026-01-30 15:52:04.722	2026-01-30 15:57:24.029
396	api::nav-item.nav-item	zwxsf16impopd9ix70ujvwm3	en	["ar"]	failed	2026-01-30 15:52:04.772	2026-01-30 15:57:24.064
397	api::nav-item.nav-item	wva6loz9r8b0b31k6ud6y5so	en	["ar"]	failed	2026-01-30 15:52:04.823	2026-01-30 15:57:24.099
398	api::team-member.team-member	ratfggrnxrgjlufh9gdyv5ex	en	["ar"]	failed	2026-01-30 15:52:05.088	2026-01-30 15:57:24.33
399	api::team-member.team-member	vg80t18dlu027c5x9oofkvf0	en	["ar"]	failed	2026-01-30 15:52:05.147	2026-01-30 15:57:24.372
400	api::team-member.team-member	um949s21ds3yzom7i1hve2zi	en	["ar"]	failed	2026-01-30 15:52:05.204	2026-01-30 15:57:24.412
401	api::team-member.team-member	ji9kdq7u51s14m37iylr4sdp	en	["ar"]	failed	2026-01-30 15:52:05.256	2026-01-30 15:57:24.453
402	api::team-member.team-member	hci3bxv8czxgboeehckcephs	en	["ar"]	failed	2026-01-30 15:52:05.311	2026-01-30 15:57:24.492
403	api::team-member.team-member	sjcueiw7p3aach0age0yegm5	en	["ar"]	failed	2026-01-30 15:52:05.361	2026-01-30 15:57:24.539
404	api::stat.stat	syq87zvb012qmnbsx7w3qa00	en	["ar"]	failed	2026-01-30 15:52:05.417	2026-01-30 15:57:24.583
405	api::stat.stat	vtiumfkxbdpjbxgc4iypuyky	en	["ar"]	failed	2026-01-30 15:52:05.475	2026-01-30 15:57:24.614
406	api::stat.stat	cl03vmsbu9jqt18tegvp41qq	en	["ar"]	failed	2026-01-30 15:52:05.523	2026-01-30 15:57:24.649
407	api::stat.stat	thu6c3os0rzvobiz1xmr2da2	en	["ar"]	failed	2026-01-30 15:52:05.581	2026-01-30 15:57:24.688
408	api::stat.stat	v5je0e1s40m5dp0pxoa2941k	en	["ar"]	failed	2026-01-30 15:52:05.635	2026-01-30 15:57:24.727
409	api::stat.stat	a7nf9gvn2v2nzr3cfpse7myz	en	["ar"]	failed	2026-01-30 15:52:05.688	2026-01-30 15:57:24.762
410	api::process-step.process-step	t93kots3xg2l9gj87dflsahy	en	["ar"]	failed	2026-01-30 15:52:05.74	2026-01-30 15:57:24.802
411	api::process-step.process-step	x5jwgop82ooju0qlp19xicj8	en	["ar"]	failed	2026-01-30 15:52:07.292	2026-01-30 15:57:24.841
412	api::process-step.process-step	zqoy0o0j31vh3yjfjr7wc1t3	en	["ar"]	failed	2026-01-30 15:52:07.37	2026-01-30 15:57:24.878
413	api::process-step.process-step	m2k6mvyxum9uub3zg81p2wx3	en	["ar"]	failed	2026-01-30 15:52:07.445	2026-01-30 15:57:24.917
414	api::feature.feature	tiw1teg61x2lk0mz0zepy1v8	en	["ar"]	failed	2026-01-30 15:52:07.522	2026-01-30 15:57:24.957
415	api::feature.feature	m4ca28no4yuspkzzzgekaaze	en	["ar"]	failed	2026-01-30 15:52:07.597	2026-01-30 15:57:24.994
416	api::feature.feature	huvvf5qpvwe48y5ywysuo83d	en	["ar"]	failed	2026-01-30 15:52:07.674	2026-01-30 15:57:25.026
417	api::feature.feature	v61slytfxdd6uvxc9xrui9jg	en	["ar"]	failed	2026-01-30 15:52:07.746	2026-01-30 15:57:25.063
418	api::feature.feature	smbb1p2qsx6exbeq6htbvy76	en	["ar"]	failed	2026-01-30 15:52:07.818	2026-01-30 15:57:25.098
419	api::feature.feature	uwp2n6e6c330hoc0z2kf8crm	en	["ar"]	failed	2026-01-30 15:52:07.891	2026-01-30 15:57:25.137
420	api::feature.feature	o35orwx2qlu6agosr70b98e0	en	["ar"]	failed	2026-01-30 15:52:07.96	2026-01-30 15:57:25.172
421	api::feature.feature	jcse0opj0vmu04j18k6ij57r	en	["ar"]	failed	2026-01-30 15:52:08.036	2026-01-30 15:57:25.206
422	api::value.value	hhmw3o2gvzeaqq9cvd7exchd	en	["ar"]	failed	2026-01-30 15:52:08.109	2026-01-30 15:57:25.243
423	api::value.value	iwrgyhke0r8krpqtvnip1578	en	["ar"]	failed	2026-01-30 15:52:08.18	2026-01-30 15:57:25.283
424	api::value.value	dajbb1ffsrtwchww9k6ljtqv	en	["ar"]	failed	2026-01-30 15:52:08.248	2026-01-30 15:57:25.316
425	api::value.value	cxlonubo05h1mlbi17bulxuh	en	["ar"]	failed	2026-01-30 15:52:08.319	2026-01-30 15:57:25.357
426	api::value.value	zhon2rf98wudk7mad2bddb8i	en	["ar"]	failed	2026-01-30 15:52:08.396	2026-01-30 15:57:25.398
427	api::value.value	v5h7n3vem0puf5502faq0ct2	en	["ar"]	failed	2026-01-30 15:52:08.466	2026-01-30 15:57:25.432
428	api::testimonial.testimonial	qblduchtbmhn4uftwydkbyjn	en	["ar"]	failed	2026-01-30 15:52:08.546	2026-01-30 15:57:25.475
429	api::testimonial.testimonial	b2gn6hv9bsnbdfhiqsfpiduu	en	["ar"]	failed	2026-01-30 15:52:08.594	2026-01-30 15:57:25.51
441	api::faq.faq	yr47d44qynjkxzeqc0rl1aj0	en	["ar"]	failed	2026-01-30 15:52:09.232	2026-01-30 15:57:25.972
463	api::case-study.case-study	ljyr0huxhcub87emb9c6azy4	en	["ar"]	failed	2026-01-30 15:52:10.457	2026-01-30 15:57:26.897
442	api::faq.faq	welleff0673pmtq15udxhug4	en	["ar"]	failed	2026-01-30 15:52:09.291	2026-01-30 15:57:26.015
443	api::faq.faq	gbopv2y8rx7n3lrw1i64cmv8	en	["ar"]	failed	2026-01-30 15:52:09.352	2026-01-30 15:57:26.06
467	api::solution.solution	whs2ps1yxocmtgw3sznx5xfp	en	["ar"]	failed	2026-01-30 15:52:10.653	2026-01-30 15:57:27.048
444	api::pricing-plan.pricing-plan	o9bt9u7clz7v3tr78tyt0rzm	en	["ar"]	failed	2026-01-30 15:52:09.421	2026-01-30 15:57:26.103
445	api::pricing-plan.pricing-plan	b8p9jj009stq4pnwcyu6ucay	en	["ar"]	failed	2026-01-30 15:52:09.479	2026-01-30 15:57:26.146
468	api::solution.solution	eib72gfjeua5lrlbqp6vud0u	en	["ar"]	failed	2026-01-30 15:52:10.698	2026-01-30 15:57:27.089
446	api::pricing-plan.pricing-plan	vnjp157p7fz4krghbihsxdiu	en	["ar"]	failed	2026-01-30 15:52:09.536	2026-01-30 15:57:26.186
447	api::pricing-plan.pricing-plan	jv6728bgrvs485v0lf5u0v2n	en	["ar"]	failed	2026-01-30 15:52:09.604	2026-01-30 15:57:26.225
469	api::solution.solution	u1e3ht4dhd8i71iuro0mir1p	en	["ar"]	failed	2026-01-30 15:52:10.744	2026-01-30 15:57:27.127
448	api::partner.partner	xkdbpq8wruclvpygni92uw4q	en	["ar"]	failed	2026-01-30 15:52:09.664	2026-01-30 15:57:26.27
449	api::partner.partner	opx1h1y4gy0truat2r2i7nf4	en	["ar"]	failed	2026-01-30 15:52:09.722	2026-01-30 15:57:26.315
470	api::solution.solution	bup4lkho82zekaxbd42xbrdy	en	["ar"]	failed	2026-01-30 15:52:10.794	2026-01-30 15:57:27.175
450	api::partner.partner	xaq0zo4k2uq8j8u2ykxmidv4	en	["ar"]	failed	2026-01-30 15:52:09.771	2026-01-30 15:57:26.36
451	api::partner.partner	mr86fp1f2fwqn40z8uwsid6v	en	["ar"]	failed	2026-01-30 15:52:09.819	2026-01-30 15:57:26.396
471	api::industry.industry	kaomv6jfmax5mqpa329al313	en	["ar"]	failed	2026-01-30 15:52:10.844	2026-01-30 15:57:27.22
457	api::demo.demo	n3002idwlm51m1k5hv1hgkwf	en	["ar"]	failed	2026-01-30 15:52:10.136	2026-01-30 15:57:26.65
472	api::industry.industry	ud72w3h4nt812vdkqxfn3lrx	en	["ar"]	failed	2026-01-30 15:52:10.901	2026-01-30 15:57:27.266
458	api::demo.demo	ljny8wcyia47u3m0280xxeyb	en	["ar"]	failed	2026-01-30 15:52:10.185	2026-01-30 15:57:26.7
473	api::industry.industry	hnmtp1jcdzg9uczkl8elwf52	en	["ar"]	failed	2026-01-30 15:52:10.945	2026-01-30 15:57:27.304
474	api::industry.industry	oocndczvifwcjfpm6td0jlim	en	["ar"]	failed	2026-01-30 15:52:10.992	2026-01-30 15:57:27.347
459	api::demo.demo	gbtiw59s69bi8qkhn8jcf7xz	en	["ar"]	failed	2026-01-30 15:52:10.237	2026-01-30 15:57:26.735
475	api::industry.industry	dmi4jw9ord0aylbbbr0tk1d7	en	["ar"]	failed	2026-01-30 15:52:11.043	2026-01-30 15:57:27.377
476	api::industry.industry	wzgd2y1crn99y4am92u39suk	en	["ar"]	failed	2026-01-30 15:52:11.093	2026-01-30 15:57:27.414
430	api::testimonial.testimonial	j9ukked0i5pt1fo2zc47d7y9	en	["ar"]	failed	2026-01-30 15:52:08.64	2026-01-30 15:57:25.543
460	api::case-study.case-study	fu41u40s44xjskgln4pcim98	en	["ar"]	failed	2026-01-30 15:52:10.293	2026-01-30 15:57:26.78
432	api::testimonial.testimonial	vs4oelsqpdytlcj9fzm8vb53	en	["ar"]	failed	2026-01-30 15:52:08.739	2026-01-30 15:57:25.617
462	api::case-study.case-study	k5l6xd0c1kw3wwbyxgzphk5g	en	["ar"]	failed	2026-01-30 15:52:10.407	2026-01-30 15:57:26.857
431	api::testimonial.testimonial	cnnfhkqwres2jtlxg2rup67p	en	["ar"]	failed	2026-01-30 15:52:08.687	2026-01-30 15:57:25.578
435	api::faq.faq	etvwt69s4vc89qw02k6kdm4l	en	["ar"]	failed	2026-01-30 15:52:08.908	2026-01-30 15:57:25.743
436	api::faq.faq	rddyinfrxv2dc11nvbt5542k	en	["ar"]	failed	2026-01-30 15:52:08.963	2026-01-30 15:57:25.78
437	api::faq.faq	pslh3j1q2le4ogy8j2e4jl8i	en	["ar"]	failed	2026-01-30 15:52:09.019	2026-01-30 15:57:25.817
438	api::faq.faq	z0x3ekls4wvpwpioq52se95z	en	["ar"]	failed	2026-01-30 15:52:09.073	2026-01-30 15:57:25.853
439	api::faq.faq	kot3dc461ui374jjtbsl65ts	en	["ar"]	failed	2026-01-30 15:52:09.125	2026-01-30 15:57:25.892
440	api::faq.faq	hwgzncpa2ofpq0q4keihpznc	en	["ar"]	failed	2026-01-30 15:52:09.18	2026-01-30 15:57:25.928
461	api::case-study.case-study	lac1c8pgovgea4jiqn2tco4t	en	["ar"]	failed	2026-01-30 15:52:10.352	2026-01-30 15:57:26.818
466	api::solution.solution	hghyc8ff7t66ppsuzcq6iojj	en	["ar"]	failed	2026-01-30 15:52:10.608	2026-01-30 15:57:27.01
433	api::testimonial.testimonial	ldd10igmczfl4jqf118cyqgd	en	["ar"]	failed	2026-01-30 15:52:08.791	2026-01-30 15:57:25.657
434	api::faq.faq	cowvs2t800dl3e68phhvr5va	en	["ar"]	failed	2026-01-30 15:52:08.849	2026-01-30 15:57:25.707
456	api::demo.demo	cegq9uar2a7wg3u4sekzjvez	en	["ar"]	failed	2026-01-30 15:52:10.082	2026-01-30 15:57:26.606
464	api::case-study.case-study	r7felbje3u95hcujnc7geoc5	en	["ar"]	failed	2026-01-30 15:52:10.502	2026-01-30 15:57:26.931
465	api::solution.solution	ak6fr4wtqn6va3phwr0aw8n3	en	["ar"]	failed	2026-01-30 15:52:10.555	2026-01-30 15:57:26.971
477	api::homepage.homepage	seosxqr4oho1hh4c3jb2tv38	en	["ar"]	failed	2026-01-30 15:55:15.181	2026-01-30 15:57:22.705
483	api::about-page.about-page	rwmt90uu03ab6769dlwf9mmz	en	["ar"]	failed	2026-01-30 15:57:22.737	2026-01-30 15:57:22.745
484	api::contact-page.contact-page	ixev5sy4qg1obchjlirmkshy	en	["ar"]	failed	2026-01-30 15:57:22.773	2026-01-30 15:57:22.783
485	api::site-setting.site-setting	d3g3nzs62511l94o8nmv6uqw	en	["ar"]	failed	2026-01-30 15:57:22.814	2026-01-30 15:57:22.822
478	api::pricing-page.pricing-page	qzusqgqk8gfiuzkuz49d1562	en	["ar"]	failed	2026-01-30 15:55:15.262	2026-01-30 15:57:22.862
479	api::solutions-page.solutions-page	wkzeoejahwkrkjxsmns02w2r	en	["ar"]	failed	2026-01-30 15:55:15.305	2026-01-30 15:57:22.899
480	api::industries-page.industries-page	pmyktga6m2p6lhv3jx6nhvaf	en	["ar"]	failed	2026-01-30 15:55:15.352	2026-01-30 15:57:22.942
481	api::demos-page.demos-page	epbl5l6urmqownlxg3hm4b3v	en	["ar"]	failed	2026-01-30 15:55:15.406	2026-01-30 15:57:22.991
482	api::case-studies-page.case-studies-page	u8gd9wweu2t98qfyz6d9b0r6	en	["ar"]	failed	2026-01-30 15:55:15.49	2026-01-30 15:57:23.033
452	api::partner.partner	xzddab1fcmq8v0esao73h7ta	en	["ar"]	failed	2026-01-30 15:52:09.874	2026-01-30 15:57:26.435
453	api::partner.partner	c1q5hr4y4ozydichnc4g4obf	en	["ar"]	failed	2026-01-30 15:52:09.927	2026-01-30 15:57:26.474
454	api::demo.demo	u8hpfg3lh3rtffp23hvjvocu	en	["ar"]	failed	2026-01-30 15:52:09.981	2026-01-30 15:57:26.523
455	api::demo.demo	kojy0zkjj5r0bklv3pk045cr	en	["ar"]	failed	2026-01-30 15:52:10.031	2026-01-30 15:57:26.564
\.


--
-- Data for Name: strapi_api_token_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_api_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_token_permissions_token_lnk (id, api_token_permission_id, api_token_id, api_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_api_tokens; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_tokens (id, document_id, name, description, type, access_key, encrypted_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	bok0bny67zh3h38rh2ql7bel	Read Only	A default API token with read-only permissions, only used for accessing resources	read-only	ad1492d339ee1d9e918cced776f5fa5cc65634ffc561ae6b7c9176fcf0e2347ec435062610e69d8614d3174bccfe927cc144cfad3345dd9e5a3ac0fbd42074f3	v1:70a226796c26a8cd71c196f80a80d70b:0861467c19738266a9f87447b4ebf779ec9bef9e3e91d6233711221b99ec8346be35cceb098cee01398759eb881002575227d8db3970e2cf3464192e8d26c0aaaf37386ed1baed1d757a39d2816de4ab65c4cf1b5875a0afb4792c05a631cc9157e6081ba6f775d1d5bce1d32d2aaa3ba3e60bddec5894ca4bee0220ce690c99147df9e067ce39db22268c45407cfd70a7456d7337de05e48122adae1929d1ec523fd06fbcfe8976f1cbd406cd6304f27b9afb5fd38e130ad6739f7d4100eb635c9b4414dc1efbfc94c6111f59f9be0eebd094a978b69aa9299ff192032289b55e10e6239f3a1a6e20a681c00a86cb2badce0ea3692bc9862070b15299d75bcc:64f8d89a6527f7db48bec7219b8644bf	\N	\N	\N	2026-01-29 17:06:08.665	2026-01-29 17:06:08.665	2026-01-29 17:06:08.665	\N	\N	\N
3	afmoyccfxa2hxk49zc40uvbe	Seeding Token	Token for seeding and web API access	full-access	b59a3b87b9eda08f4ef79af1a122c3d3baee42c39660d38f073e38f3f26b9341988b69ada549d79292f139611ff0248da525dee86cb60496a93cc87e74f5195f	v1:e116866152ffa1ad4b930d20dcb2b1d1:5068e7fd652c04a61a320471ee79a9531c155677981c85bcdd5d8c7477552206fb95da67f2ab18f4881b3c2776646810147556cf5ddb1052bec77f0bcde3d1b21de002fb6794c69099de5f77d402995d1157d7b989e5ffbaabc9a32b763eecee986e2a28fe4e62808ec6105fec5af23e564554e726c8c9969ff5bc9424b11fd960d53f91163471d0e33c03d8752d7bc46edf358a84402b27c009881200fa3e8c495f331a7060d9565dd70205052a99ecb2d484d41dd393d9157b2a7857401b108634b7274d526592dabafda08ee41ef00d3f1fb89523518b030b6c90bb993132ab28d5c17d921f40e695c2440b544244c356880c1dde8c9d75482e28077bcfd2:51aeb0f9136a45c4f39e255f95014d3e	\N	\N	\N	2026-01-29 17:10:40.96	2026-01-29 17:10:40.96	2026-01-29 17:10:40.96	\N	\N	\N
2	a4tn5pc4dd03bop1yadjk05f	Full Access	A default API token with full access permissions, used for accessing or modifying resources	full-access	55926713de9c1c5f05c1679f791da1a35b317b00c03a1ad08873ad821640153849dadab66ebc770a81d51b4b40d055e97b20b88682a6ac9708b2eeca7251c91d	v1:4301f3633b67f026b90074c30340f689:aff6265e00fa97e77dc1561d702c7ed7c77acd272e260e857207d5134d742868e6d2b45ddc1c53652b3c46e4fd416a6e8f27067ac1767b6c78eb4aa6bfe74210d0574d55c901cb28def0aa5d18b519254bf769f2d27fb1a129f31a329fc22e1f7f16b0a00428bc94ffc8d71c2469033d1ac13f00326aba03cef2bc8a3b9b912c52890ced1d56a0003b297437e63a382b16e1eb478b302b7bcb3e9ce59993a0b22946aa2e6343fa6cd30f513461988a117d79b4773d5adf41bd3258758c94f1f92803b66d626c333b8fef28feb4c846dca67766c0c09280bc89e80dd881a4f6948818b0a53f5030595035798a566958f20a844588cee37fc34c81d2cd6bf02357:97a17886c8efbe7d10f8fc9d5d9e56e3	2026-01-30 13:28:33.828	\N	\N	2026-01-29 17:06:08.674	2026-01-30 13:28:33.829	2026-01-29 17:06:08.674	\N	\N	\N
4	dk1cvekbcvj4wj6o2jtrr3oz	web		full-access	11dc49c0219f54d96e9007df1eb9e11172b6c650851a2f9b7b1bdd3cdc3b3e314352e6e817a0f4201bea12cd8c8f83d31e3858b112fe801e1b65c265f6a9a72f	v1:e520cec169856fcb814655ee46754fa6:a87685c231a4c019566af619f939d0683799be4a68c8c2ce248ac41887b9c8013a360db6425e0a45c848460297b8a9dcd523a064c84525b44a2a186731382dc5896a4a45f65b7d09e1359f7c973692d2fb0b697eff7663c2f34d61fbe1c3de8cfe185690220aa1705c5573dc488c63bd0ff5d9173938b6fc85c1939573606900c2250e80bfbd55914c1cb323ae839a201bfe8fe9ebf52613a3e7ebb9f06f61012101447c246311b58fd41ca2c2795e4d530ac014d04eff6748d79facdbf7695d296d44b0a789c66626575117479781a51c8c059a71d3021043f9b09bb91fd87924d30fe262b014a9831049cb3408118fafe48c6c1d3a0520174e9208298db252:e4a6054c4a72b8e92e783c34e404adf5	2026-01-31 00:47:52.494	\N	\N	2026-01-29 19:06:30.079	2026-01-31 00:47:52.494	2026-01-29 19:06:30.079	\N	\N	\N
\.


--
-- Data for Name: strapi_audit_logs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_audit_logs (id, document_id, action, date, payload, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_audit_logs_user_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_audit_logs_user_lnk (id, audit_log_id, user_id) FROM stdin;
\.


--
-- Data for Name: strapi_core_store_settings; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_core_store_settings (id, key, value, type, environment, tag) FROM stdin;
1	strapi_unidirectional-join-table-repair-ran	true	boolean	\N	\N
3	strapi_content_types_schema	{"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"files"}}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"plugin":"upload","globalId":"UploadFile","uid":"plugin::upload.file","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"file"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"upload_folders"}}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"plugin":"upload","globalId":"UploadFolder","uid":"plugin::upload.folder","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true}},"kind":"collectionType"},"modelName":"folder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::i18n.locale","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"i18n_locale"}}},"plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale","uid":"plugin::i18n.locale","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"i18n_locale","info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelName":"locale"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_releases"}}},"plugin":"content-releases","globalId":"ContentReleasesRelease","uid":"plugin::content-releases.release","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelName":"release"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_release_actions"}}},"plugin":"content-releases","globalId":"ContentReleasesReleaseAction","uid":"plugin::content-releases.release-action","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelName":"release-action"},"plugin::review-workflows.workflow":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflow","uid":"plugin::review-workflows.workflow","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"}},"kind":"collectionType"},"modelName":"workflow"},"plugin::review-workflows.workflow-stage":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0","draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow-stage","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows_stages"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflowStage","uid":"plugin::review-workflows.workflow-stage","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false}},"kind":"collectionType"},"modelName":"workflow-stage"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_permissions"}}},"plugin":"users-permissions","globalId":"UsersPermissionsPermission","uid":"plugin::users-permissions.permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelName":"permission","options":{"draftAndPublish":false}},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_roles"}}},"plugin":"users-permissions","globalId":"UsersPermissionsRole","uid":"plugin::users-permissions.role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelName":"role","options":{"draftAndPublish":false}},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true,"draftAndPublish":false},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"plugin":"users-permissions","globalId":"UsersPermissionsUser","uid":"plugin::users-permissions.user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false}},"kind":"collectionType"},"modelName":"user"},"api::about-page.about-page":{"kind":"singleType","collectionName":"about_pages","info":{"singularName":"about-page","pluralName":"about-pages","displayName":"About Page"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"missionTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"missionText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"visionTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"visionText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"valuesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value1Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value1Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"value2Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value2Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"value3Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value3Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"teamTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"teamSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::about-page.about-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"about_pages"}}},"apiName":"about-page","globalId":"AboutPage","uid":"api::about-page.about-page","modelType":"contentType","__schema__":{"collectionName":"about_pages","info":{"singularName":"about-page","pluralName":"about-pages","displayName":"About Page"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"missionTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"missionText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"visionTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"visionText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"valuesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value1Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value1Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"value2Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value2Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"value3Title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"value3Text":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"teamTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"teamSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"about-page","actions":{},"lifecycles":{}},"api::case-studies-page.case-studies-page":{"kind":"singleType","collectionName":"case_studies_pages","info":{"singularName":"case-studies-page","pluralName":"case-studies-pages","displayName":"Case Studies Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterRetail":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterRealEstate":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterTourism":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterEvents":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterEducation":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"resultsLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"readMoreButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::case-studies-page.case-studies-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"case_studies_pages"}}},"apiName":"case-studies-page","globalId":"CaseStudiesPage","uid":"api::case-studies-page.case-studies-page","modelType":"contentType","__schema__":{"collectionName":"case_studies_pages","info":{"singularName":"case-studies-page","pluralName":"case-studies-pages","displayName":"Case Studies Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterRetail":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterRealEstate":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterTourism":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterEvents":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterEducation":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"resultsLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"readMoreButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"case-studies-page","actions":{},"lifecycles":{}},"api::case-study.case-study":{"kind":"collectionType","collectionName":"case_studies","info":{"singularName":"case-study","pluralName":"case-studies","displayName":"Case Study"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"client":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"industry":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"allowedRoles":{"type":"json","default":[]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::case-study.case-study","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"case_studies"}}},"apiName":"case-study","globalId":"CaseStudy","uid":"api::case-study.case-study","modelType":"contentType","__schema__":{"collectionName":"case_studies","info":{"singularName":"case-study","pluralName":"case-studies","displayName":"Case Study"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"client":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"industry":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"allowedRoles":{"type":"json","default":[]}},"kind":"collectionType"},"modelName":"case-study","actions":{},"lifecycles":{}},"api::contact-page.contact-page":{"kind":"singleType","collectionName":"contact_pages","info":{"singularName":"contact-page","pluralName":"contact-pages","displayName":"Contact Page"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"formTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"nameLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"emailLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"phoneLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"messageLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"submitButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"infoTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"address":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"email":{"type":"email"},"phone":{"type":"string"},"hoursTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"hoursText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::contact-page.contact-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"contact_pages"}}},"apiName":"contact-page","globalId":"ContactPage","uid":"api::contact-page.contact-page","modelType":"contentType","__schema__":{"collectionName":"contact_pages","info":{"singularName":"contact-page","pluralName":"contact-pages","displayName":"Contact Page"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"formTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"nameLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"emailLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"phoneLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"messageLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"submitButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"infoTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"address":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"email":{"type":"email"},"phone":{"type":"string"},"hoursTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"hoursText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"contact-page","actions":{},"lifecycles":{}},"api::demo.demo":{"kind":"collectionType","collectionName":"demos","info":{"singularName":"demo","pluralName":"demos","displayName":"Demo"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"demoType":{"type":"string"},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"},"allowedRoles":{"type":"json","default":[]},"accessLevel":{"type":"enumeration","enum":["public","authenticated","client","premium"],"default":"authenticated"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::demo.demo","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"demos"}}},"apiName":"demo","globalId":"Demo","uid":"api::demo.demo","modelType":"contentType","__schema__":{"collectionName":"demos","info":{"singularName":"demo","pluralName":"demos","displayName":"Demo"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"demoType":{"type":"string"},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"},"allowedRoles":{"type":"json","default":[]},"accessLevel":{"type":"enumeration","enum":["public","authenticated","client","premium"],"default":"authenticated"}},"kind":"collectionType"},"modelName":"demo","actions":{},"lifecycles":{}},"api::demos-page.demos-page":{"kind":"singleType","collectionName":"demos_pages","info":{"singularName":"demos-page","pluralName":"demos-pages","displayName":"Demos Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterMatterport":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterAi":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterVfair":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessPublic":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessAuth":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessEnterprise":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"tryNowButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"requestAccessButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::demos-page.demos-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"demos_pages"}}},"apiName":"demos-page","globalId":"DemosPage","uid":"api::demos-page.demos-page","modelType":"contentType","__schema__":{"collectionName":"demos_pages","info":{"singularName":"demos-page","pluralName":"demos-pages","displayName":"Demos Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterMatterport":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterAi":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterVfair":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessPublic":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessAuth":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"accessEnterprise":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"tryNowButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"requestAccessButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"demos-page","actions":{},"lifecycles":{}},"api::faq.faq":{"kind":"collectionType","collectionName":"faqs","info":{"singularName":"faq","pluralName":"faqs","displayName":"FAQ"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"category":{"type":"string"},"order":{"type":"integer"},"question":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"answer":{"type":"richtext","required":true,"pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::faq.faq","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"faqs"}}},"apiName":"faq","globalId":"Faq","uid":"api::faq.faq","modelType":"contentType","__schema__":{"collectionName":"faqs","info":{"singularName":"faq","pluralName":"faqs","displayName":"FAQ"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"category":{"type":"string"},"order":{"type":"integer"},"question":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"answer":{"type":"richtext","required":true,"pluginOptions":{"i18n":{"localized":true}}}},"kind":"collectionType"},"modelName":"faq","actions":{},"lifecycles":{}},"api::feature.feature":{"kind":"collectionType","collectionName":"features","info":{"singularName":"feature","pluralName":"features","displayName":"Feature"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"star"},"order":{"type":"integer","default":0},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::feature.feature","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"features"}}},"apiName":"feature","globalId":"Feature","uid":"api::feature.feature","modelType":"contentType","__schema__":{"collectionName":"features","info":{"singularName":"feature","pluralName":"features","displayName":"Feature"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"star"},"order":{"type":"integer","default":0}},"kind":"collectionType"},"modelName":"feature","actions":{},"lifecycles":{}},"api::homepage.homepage":{"kind":"singleType","collectionName":"homepages","info":{"singularName":"homepage","pluralName":"homepages","displayName":"Homepage"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"heroPrimaryCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSecondaryCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroBadge":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustAward":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustGlobal":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustFast":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"showStatsSection":{"type":"boolean","default":true},"showTrustedBySection":{"type":"boolean","default":true},"trustedByTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"showHowItWorksSection":{"type":"boolean","default":true},"howItWorksTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"howItWorksSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showFeaturesSection":{"type":"boolean","default":true},"featuresTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"featuresSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showSolutionsSection":{"type":"boolean","default":true},"solutionsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"solutionsSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showIndustriesSection":{"type":"boolean","default":true},"industriesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"industriesSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showCaseStudiesSection":{"type":"boolean","default":true},"caseStudiesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"caseStudiesSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showDemosSection":{"type":"boolean","default":true},"demosTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"demosSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showCtaSection":{"type":"boolean","default":true},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaPrimaryButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSecondaryButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::homepage.homepage","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"homepages"}}},"apiName":"homepage","globalId":"Homepage","uid":"api::homepage.homepage","modelType":"contentType","__schema__":{"collectionName":"homepages","info":{"singularName":"homepage","pluralName":"homepages","displayName":"Homepage"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"heroPrimaryCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSecondaryCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroBadge":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustAward":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustGlobal":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"trustFast":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"showStatsSection":{"type":"boolean","default":true},"showTrustedBySection":{"type":"boolean","default":true},"trustedByTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"showHowItWorksSection":{"type":"boolean","default":true},"howItWorksTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"howItWorksSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showFeaturesSection":{"type":"boolean","default":true},"featuresTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"featuresSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showSolutionsSection":{"type":"boolean","default":true},"solutionsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"solutionsSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showIndustriesSection":{"type":"boolean","default":true},"industriesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"industriesSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showCaseStudiesSection":{"type":"boolean","default":true},"caseStudiesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"caseStudiesSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showDemosSection":{"type":"boolean","default":true},"demosTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"demosSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"showCtaSection":{"type":"boolean","default":true},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaPrimaryButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSecondaryButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"homepage","actions":{},"lifecycles":{}},"api::industries-page.industries-page":{"kind":"singleType","collectionName":"industries_pages","info":{"singularName":"industries-page","pluralName":"industries-pages","displayName":"Industries Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"statsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::industries-page.industries-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"industries_pages"}}},"apiName":"industries-page","globalId":"IndustriesPage","uid":"api::industries-page.industries-page","modelType":"contentType","__schema__":{"collectionName":"industries_pages","info":{"singularName":"industries-page","pluralName":"industries-pages","displayName":"Industries Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"statsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"industries-page","actions":{},"lifecycles":{}},"api::industry.industry":{"kind":"collectionType","collectionName":"industries","info":{"singularName":"industry","pluralName":"industries","displayName":"Industry"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::industry.industry","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"industries"}}},"apiName":"industry","globalId":"Industry","uid":"api::industry.industry","modelType":"contentType","__schema__":{"collectionName":"industries","info":{"singularName":"industry","pluralName":"industries","displayName":"Industry"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"}},"kind":"collectionType"},"modelName":"industry","actions":{},"lifecycles":{}},"api::nav-item.nav-item":{"kind":"collectionType","collectionName":"nav_items","info":{"singularName":"nav-item","pluralName":"nav-items","displayName":"Nav Item"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"label":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"href":{"type":"string","required":true},"location":{"type":"enumeration","enum":["header","footer","footer-company","footer-products","footer-resources","footer-support","footer-social"],"default":"header","required":true},"order":{"type":"integer","default":0},"isExternal":{"type":"boolean","default":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::nav-item.nav-item","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"nav_items"}}},"apiName":"nav-item","globalId":"NavItem","uid":"api::nav-item.nav-item","modelType":"contentType","__schema__":{"collectionName":"nav_items","info":{"singularName":"nav-item","pluralName":"nav-items","displayName":"Nav Item"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"label":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"href":{"type":"string","required":true},"location":{"type":"enumeration","enum":["header","footer","footer-company","footer-products","footer-resources","footer-support","footer-social"],"default":"header","required":true},"order":{"type":"integer","default":0},"isExternal":{"type":"boolean","default":false}},"kind":"collectionType"},"modelName":"nav-item","actions":{},"lifecycles":{}},"api::partner.partner":{"kind":"collectionType","collectionName":"partners","info":{"singularName":"partner","pluralName":"partners","displayName":"Partner"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"order":{"type":"integer"},"partnerType":{"type":"string"},"logoUrl":{"type":"string"},"websiteUrl":{"type":"string"},"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"partnership":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::partner.partner","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"partners"}}},"apiName":"partner","globalId":"Partner","uid":"api::partner.partner","modelType":"contentType","__schema__":{"collectionName":"partners","info":{"singularName":"partner","pluralName":"partners","displayName":"Partner"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"order":{"type":"integer"},"partnerType":{"type":"string"},"logoUrl":{"type":"string"},"websiteUrl":{"type":"string"},"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"partnership":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"collectionType"},"modelName":"partner","actions":{},"lifecycles":{}},"api::pricing-page.pricing-page":{"kind":"singleType","collectionName":"pricing_pages","info":{"singularName":"pricing-page","pluralName":"pricing-pages","displayName":"Pricing Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"monthlyLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"annualLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"annualDiscount":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"popularBadge":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"featuresTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature1":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature2":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature3":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature4":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature5":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"comparisonTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"enterpriseTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"enterpriseSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"enterpriseCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"faqTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"guaranteeTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"guaranteeText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::pricing-page.pricing-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"pricing_pages"}}},"apiName":"pricing-page","globalId":"PricingPage","uid":"api::pricing-page.pricing-page","modelType":"contentType","__schema__":{"collectionName":"pricing_pages","info":{"singularName":"pricing-page","pluralName":"pricing-pages","displayName":"Pricing Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"monthlyLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"annualLabel":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"annualDiscount":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"popularBadge":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"featuresTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature1":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature2":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature3":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature4":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"feature5":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"comparisonTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"enterpriseTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"enterpriseSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"enterpriseCta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"faqTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"guaranteeTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"guaranteeText":{"type":"text","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"pricing-page","actions":{},"lifecycles":{}},"api::pricing-plan.pricing-plan":{"kind":"collectionType","collectionName":"pricing_plans","info":{"singularName":"pricing-plan","pluralName":"pricing-plans","displayName":"Pricing Plan"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"order":{"type":"integer"},"popular":{"type":"boolean","default":false},"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"price":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"currency":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"period":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"features":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"limitations":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"cta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"idealFor":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::pricing-plan.pricing-plan","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"pricing_plans"}}},"apiName":"pricing-plan","globalId":"PricingPlan","uid":"api::pricing-plan.pricing-plan","modelType":"contentType","__schema__":{"collectionName":"pricing_plans","info":{"singularName":"pricing-plan","pluralName":"pricing-plans","displayName":"Pricing Plan"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"string","required":true,"unique":true},"order":{"type":"integer"},"popular":{"type":"boolean","default":false},"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"price":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"currency":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"period":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"features":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"limitations":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"cta":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"idealFor":{"type":"text","pluginOptions":{"i18n":{"localized":true}}}},"kind":"collectionType"},"modelName":"pricing-plan","actions":{},"lifecycles":{}},"api::process-step.process-step":{"kind":"collectionType","collectionName":"process_steps","info":{"singularName":"process-step","pluralName":"process-steps","displayName":"Process Step"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"step":{"type":"integer","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"circle"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::process-step.process-step","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"process_steps"}}},"apiName":"process-step","globalId":"ProcessStep","uid":"api::process-step.process-step","modelType":"contentType","__schema__":{"collectionName":"process_steps","info":{"singularName":"process-step","pluralName":"process-steps","displayName":"Process Step"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"step":{"type":"integer","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"circle"}},"kind":"collectionType"},"modelName":"process-step","actions":{},"lifecycles":{}},"api::site-setting.site-setting":{"kind":"singleType","collectionName":"site_settings","info":{"singularName":"site-setting","pluralName":"site-settings","displayName":"Site Settings"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"contactEmail":{"type":"email"},"contactPhone":{"type":"string"},"footerCompanyTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerProductsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerResourcesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerConnectTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"copyrightText":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"loginButtonText":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::site-setting.site-setting","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"site_settings"}}},"apiName":"site-setting","globalId":"SiteSetting","uid":"api::site-setting.site-setting","modelType":"contentType","__schema__":{"collectionName":"site_settings","info":{"singularName":"site-setting","pluralName":"site-settings","displayName":"Site Settings"},"options":{"draftAndPublish":false},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"contactEmail":{"type":"email"},"contactPhone":{"type":"string"},"footerCompanyTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerProductsTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerResourcesTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"footerConnectTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"copyrightText":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"loginButtonText":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"site-setting","actions":{},"lifecycles":{}},"api::solution.solution":{"kind":"collectionType","collectionName":"solutions","info":{"singularName":"solution","pluralName":"solutions","displayName":"Solution"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"},"allowedRoles":{"type":"json","default":[]},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::solution.solution","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"solutions"}}},"apiName":"solution","globalId":"Solution","uid":"api::solution.solution","modelType":"contentType","__schema__":{"collectionName":"solutions","info":{"singularName":"solution","pluralName":"solutions","displayName":"Solution"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"slug":{"type":"uid","targetField":"title","required":true},"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"summary":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"body":{"type":"richtext","pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string"},"allowedRoles":{"type":"json","default":[]}},"kind":"collectionType"},"modelName":"solution","actions":{},"lifecycles":{}},"api::solutions-page.solutions-page":{"kind":"singleType","collectionName":"solutions_pages","info":{"singularName":"solutions-page","pluralName":"solutions-pages","displayName":"Solutions Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterPlatforms":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterServices":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterAi":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::solutions-page.solutions-page","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"solutions_pages"}}},"apiName":"solutions-page","globalId":"SolutionsPage","uid":"api::solutions-page.solutions-page","modelType":"contentType","__schema__":{"collectionName":"solutions_pages","info":{"singularName":"solutions-page","pluralName":"solutions-pages","displayName":"Solutions Page"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"heroTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"heroSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"filterAll":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterPlatforms":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterServices":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"filterAi":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaTitle":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"ctaSubtitle":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"ctaButton":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"singleType"},"modelName":"solutions-page","actions":{},"lifecycles":{}},"api::stat.stat":{"kind":"collectionType","collectionName":"stats","info":{"singularName":"stat","pluralName":"stats","displayName":"Stat"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"value":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"label":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"order":{"type":"integer","default":0},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::stat.stat","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"stats"}}},"apiName":"stat","globalId":"Stat","uid":"api::stat.stat","modelType":"contentType","__schema__":{"collectionName":"stats","info":{"singularName":"stat","pluralName":"stats","displayName":"Stat"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"value":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"label":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"order":{"type":"integer","default":0}},"kind":"collectionType"},"modelName":"stat","actions":{},"lifecycles":{}},"api::team-member.team-member":{"kind":"collectionType","collectionName":"team_members","info":{"singularName":"team-member","pluralName":"team-members","displayName":"Team Member"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"position":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"bio":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"photo":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"order":{"type":"integer","default":0},"linkedinUrl":{"type":"string"},"twitterUrl":{"type":"string"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::team-member.team-member","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"team_members"}}},"apiName":"team-member","globalId":"TeamMember","uid":"api::team-member.team-member","modelType":"contentType","__schema__":{"collectionName":"team_members","info":{"singularName":"team-member","pluralName":"team-members","displayName":"Team Member"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"name":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"position":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"bio":{"type":"text","pluginOptions":{"i18n":{"localized":true}}},"photo":{"type":"media","multiple":false,"required":false,"allowedTypes":["images"]},"order":{"type":"integer","default":0},"linkedinUrl":{"type":"string"},"twitterUrl":{"type":"string"}},"kind":"collectionType"},"modelName":"team-member","actions":{},"lifecycles":{}},"api::testimonial.testimonial":{"kind":"collectionType","collectionName":"testimonials","info":{"singularName":"testimonial","pluralName":"testimonials","displayName":"Testimonial"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"order":{"type":"integer","required":true},"rating":{"type":"integer"},"featured":{"type":"boolean","default":false},"quote":{"type":"text","required":true,"pluginOptions":{"i18n":{"localized":true}}},"author":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"role":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"company":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::testimonial.testimonial","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"testimonials"}}},"apiName":"testimonial","globalId":"Testimonial","uid":"api::testimonial.testimonial","modelType":"contentType","__schema__":{"collectionName":"testimonials","info":{"singularName":"testimonial","pluralName":"testimonials","displayName":"Testimonial"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"order":{"type":"integer","required":true},"rating":{"type":"integer"},"featured":{"type":"boolean","default":false},"quote":{"type":"text","required":true,"pluginOptions":{"i18n":{"localized":true}}},"author":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"role":{"type":"string","pluginOptions":{"i18n":{"localized":true}}},"company":{"type":"string","pluginOptions":{"i18n":{"localized":true}}}},"kind":"collectionType"},"modelName":"testimonial","actions":{},"lifecycles":{}},"api::trusted-company.trusted-company":{"kind":"collectionType","collectionName":"trusted_companies","info":{"singularName":"trusted-company","pluralName":"trusted-companies","displayName":"Trusted Company"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"name":{"type":"string","required":true},"logo":{"type":"string"},"website":{"type":"string"},"order":{"type":"integer","default":0},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::trusted-company.trusted-company","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"trusted_companies"}}},"apiName":"trusted-company","globalId":"TrustedCompany","uid":"api::trusted-company.trusted-company","modelType":"contentType","__schema__":{"collectionName":"trusted_companies","info":{"singularName":"trusted-company","pluralName":"trusted-companies","displayName":"Trusted Company"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"name":{"type":"string","required":true},"logo":{"type":"string"},"website":{"type":"string"},"order":{"type":"integer","default":0}},"kind":"collectionType"},"modelName":"trusted-company","actions":{},"lifecycles":{}},"api::user-audit-log.user-audit-log":{"kind":"collectionType","collectionName":"user_audit_logs","info":{"singularName":"user-audit-log","pluralName":"user-audit-logs","displayName":"User Audit Log","description":"Track all user actions and events"},"options":{"draftAndPublish":false},"pluginOptions":{},"attributes":{"user":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.user"},"action":{"type":"enumeration","enum":["login","logout","register","password_reset","password_reset_request","demo_access","demo_access_denied","role_change","profile_update","failed_login","account_suspended","account_activated","email_confirmed"],"required":true},"ipAddress":{"type":"string"},"userAgent":{"type":"text"},"targetDemo":{"type":"relation","relation":"manyToOne","target":"api::demo.demo"},"metadata":{"type":"json"},"success":{"type":"boolean","default":true},"errorMessage":{"type":"text"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::user-audit-log.user-audit-log","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"user_audit_logs"}}},"apiName":"user-audit-log","globalId":"UserAuditLog","uid":"api::user-audit-log.user-audit-log","modelType":"contentType","__schema__":{"collectionName":"user_audit_logs","info":{"singularName":"user-audit-log","pluralName":"user-audit-logs","displayName":"User Audit Log","description":"Track all user actions and events"},"options":{"draftAndPublish":false},"pluginOptions":{},"attributes":{"user":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.user"},"action":{"type":"enumeration","enum":["login","logout","register","password_reset","password_reset_request","demo_access","demo_access_denied","role_change","profile_update","failed_login","account_suspended","account_activated","email_confirmed"],"required":true},"ipAddress":{"type":"string"},"userAgent":{"type":"text"},"targetDemo":{"type":"relation","relation":"manyToOne","target":"api::demo.demo"},"metadata":{"type":"json"},"success":{"type":"boolean","default":true},"errorMessage":{"type":"text"}},"kind":"collectionType"},"modelName":"user-audit-log","actions":{},"lifecycles":{}},"api::value.value":{"kind":"collectionType","collectionName":"values","info":{"singularName":"value","pluralName":"values","displayName":"Value"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","required":true,"pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"heart"},"order":{"type":"integer","default":0},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":false,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"api::value.value","writable":false,"private":false,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"values"}}},"apiName":"value","globalId":"Value","uid":"api::value.value","modelType":"contentType","__schema__":{"collectionName":"values","info":{"singularName":"value","pluralName":"values","displayName":"Value"},"options":{"draftAndPublish":true},"pluginOptions":{"i18n":{"localized":true}},"attributes":{"title":{"type":"string","required":true,"pluginOptions":{"i18n":{"localized":true}}},"description":{"type":"text","required":true,"pluginOptions":{"i18n":{"localized":true}}},"icon":{"type":"string","default":"heart"},"order":{"type":"integer","default":0}},"kind":"collectionType"},"modelName":"value","actions":{},"lifecycles":{}},"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_permissions"}}},"plugin":"admin","globalId":"AdminPermission","uid":"admin::permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelName":"permission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"plugin":"admin","globalId":"AdminUser","uid":"admin::user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelName":"user","options":{"draftAndPublish":false}},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_roles"}}},"plugin":"admin","globalId":"AdminRole","uid":"admin::role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelName":"role"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_tokens"}}},"plugin":"admin","globalId":"AdminApiToken","uid":"admin::api-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"api-token"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_token_permissions"}}},"plugin":"admin","globalId":"AdminApiTokenPermission","uid":"admin::api-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelName":"api-token-permission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_tokens"}}},"plugin":"admin","globalId":"AdminTransferToken","uid":"admin::transfer-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"transfer-token"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_token_permissions"}}},"plugin":"admin","globalId":"AdminTransferTokenPermission","uid":"admin::transfer-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelName":"transfer-token-permission"},"admin::session":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::session","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_sessions"}}},"plugin":"admin","globalId":"AdminSession","uid":"admin::session","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"session"},"admin::audit-log":{"kind":"collectionType","collectionName":"strapi_audit_logs","info":{"singularName":"audit-log","pluralName":"audit-logs","displayName":"Audit Log"},"options":{"timestamps":false,"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true},"date":{"type":"datetime","required":true},"user":{"type":"relation","relation":"oneToOne","target":"admin::user"},"payload":{"type":"json"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::audit-log","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_audit_logs"}}},"plugin":"admin","globalId":"AdminAuditLog","uid":"admin::audit-log","modelType":"contentType","__schema__":{"collectionName":"strapi_audit_logs","info":{"singularName":"audit-log","pluralName":"audit-logs","displayName":"Audit Log"},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true},"date":{"type":"datetime","required":true},"user":{"type":"relation","relation":"oneToOne","target":"admin::user"},"payload":{"type":"json"}},"kind":"collectionType"},"modelName":"audit-log"}}	object	\N	\N
4	plugin_content_manager_configuration_content_types::plugin::i18n.locale	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}	object	\N	\N
6	plugin_content_manager_configuration_content_types::plugin::upload.folder	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}	object	\N	\N
5	plugin_content_manager_configuration_content_types::plugin::upload.file	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}	object	\N	\N
7	plugin_content_manager_configuration_content_types::plugin::content-releases.release	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}	object	\N	\N
8	plugin_content_manager_configuration_content_types::plugin::content-releases.release-action	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"entryDocumentId":{"edit":{"label":"entryDocumentId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entryDocumentId","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","entryDocumentId"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"entryDocumentId","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}	object	\N	\N
9	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"stages":{"edit":{"label":"stages","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stages","searchable":false,"sortable":false}},"stageRequiredToPublish":{"edit":{"label":"stageRequiredToPublish","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stageRequiredToPublish","searchable":true,"sortable":true}},"contentTypes":{"edit":{"label":"contentTypes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentTypes","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","stages","stageRequiredToPublish"],"edit":[[{"name":"name","size":6},{"name":"stages","size":6}],[{"name":"stageRequiredToPublish","size":6}],[{"name":"contentTypes","size":12}]]},"uid":"plugin::review-workflows.workflow"}	object	\N	\N
10	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow-stage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"workflow":{"edit":{"label":"workflow","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"workflow","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","color","workflow"],"edit":[[{"name":"name","size":6},{"name":"color","size":6}],[{"name":"workflow","size":6},{"name":"permissions","size":6}]]},"uid":"plugin::review-workflows.workflow-stage"}	object	\N	\N
65	plugin_content_manager_configuration_content_types::api::about-page.about-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"missionTitle":{"edit":{"label":"missionTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"missionTitle","searchable":true,"sortable":true}},"missionText":{"edit":{"label":"missionText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"missionText","searchable":true,"sortable":true}},"visionTitle":{"edit":{"label":"visionTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"visionTitle","searchable":true,"sortable":true}},"visionText":{"edit":{"label":"visionText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"visionText","searchable":true,"sortable":true}},"valuesTitle":{"edit":{"label":"valuesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"valuesTitle","searchable":true,"sortable":true}},"value1Title":{"edit":{"label":"value1Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value1Title","searchable":true,"sortable":true}},"value1Text":{"edit":{"label":"value1Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value1Text","searchable":true,"sortable":true}},"value2Title":{"edit":{"label":"value2Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value2Title","searchable":true,"sortable":true}},"value2Text":{"edit":{"label":"value2Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value2Text","searchable":true,"sortable":true}},"value3Title":{"edit":{"label":"value3Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value3Title","searchable":true,"sortable":true}},"value3Text":{"edit":{"label":"value3Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value3Text","searchable":true,"sortable":true}},"teamTitle":{"edit":{"label":"teamTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"teamTitle","searchable":true,"sortable":true}},"teamSubtitle":{"edit":{"label":"teamSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"teamSubtitle","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","missionTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"missionTitle","size":6},{"name":"missionText","size":6}],[{"name":"visionTitle","size":6},{"name":"visionText","size":6}],[{"name":"valuesTitle","size":6},{"name":"value1Title","size":6}],[{"name":"value1Text","size":6},{"name":"value2Title","size":6}],[{"name":"value2Text","size":6},{"name":"value3Title","size":6}],[{"name":"value3Text","size":6},{"name":"teamTitle","size":6}],[{"name":"teamSubtitle","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::about-page.about-page"}	object	\N	\N
75	plugin_content_manager_configuration_content_types::api::contact-page.contact-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"formTitle":{"edit":{"label":"formTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formTitle","searchable":true,"sortable":true}},"nameLabel":{"edit":{"label":"nameLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"nameLabel","searchable":true,"sortable":true}},"emailLabel":{"edit":{"label":"emailLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"emailLabel","searchable":true,"sortable":true}},"phoneLabel":{"edit":{"label":"phoneLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"phoneLabel","searchable":true,"sortable":true}},"messageLabel":{"edit":{"label":"messageLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"messageLabel","searchable":true,"sortable":true}},"submitButton":{"edit":{"label":"submitButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"submitButton","searchable":true,"sortable":true}},"infoTitle":{"edit":{"label":"infoTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"infoTitle","searchable":true,"sortable":true}},"address":{"edit":{"label":"address","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"address","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"phone":{"edit":{"label":"phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"phone","searchable":true,"sortable":true}},"hoursTitle":{"edit":{"label":"hoursTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hoursTitle","searchable":true,"sortable":true}},"hoursText":{"edit":{"label":"hoursText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hoursText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","formTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"formTitle","size":6},{"name":"nameLabel","size":6}],[{"name":"emailLabel","size":6},{"name":"phoneLabel","size":6}],[{"name":"messageLabel","size":6},{"name":"submitButton","size":6}],[{"name":"infoTitle","size":6},{"name":"address","size":6}],[{"name":"email","size":6},{"name":"phone","size":6}],[{"name":"hoursTitle","size":6},{"name":"hoursText","size":6}]]},"uid":"api::contact-page.contact-page"}	object	\N	\N
11	plugin_content_manager_configuration_content_types::plugin::users-permissions.permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}	object	\N	\N
17	plugin_content_manager_configuration_content_types::admin::api-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}	object	\N	\N
66	plugin_content_manager_configuration_content_types::api::case-study.case-study	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"client":{"edit":{"label":"client","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"client","searchable":true,"sortable":true}},"industry":{"edit":{"label":"industry","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industry","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","client"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"client","size":6},{"name":"industry","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"allowedRoles","size":12}]]},"uid":"api::case-study.case-study"}	object	\N	\N
85	plugin_content_manager_configuration_content_types::api::demos-page.demos-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterMatterport":{"edit":{"label":"filterMatterport","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterMatterport","searchable":true,"sortable":true}},"filterAi":{"edit":{"label":"filterAi","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAi","searchable":true,"sortable":true}},"filterVfair":{"edit":{"label":"filterVfair","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterVfair","searchable":true,"sortable":true}},"accessPublic":{"edit":{"label":"accessPublic","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessPublic","searchable":true,"sortable":true}},"accessAuth":{"edit":{"label":"accessAuth","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessAuth","searchable":true,"sortable":true}},"accessEnterprise":{"edit":{"label":"accessEnterprise","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessEnterprise","searchable":true,"sortable":true}},"tryNowButton":{"edit":{"label":"tryNowButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"tryNowButton","searchable":true,"sortable":true}},"requestAccessButton":{"edit":{"label":"requestAccessButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"requestAccessButton","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterMatterport","size":6}],[{"name":"filterAi","size":6},{"name":"filterVfair","size":6}],[{"name":"accessPublic","size":6},{"name":"accessAuth","size":6}],[{"name":"accessEnterprise","size":6},{"name":"tryNowButton","size":6}],[{"name":"requestAccessButton","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaSubtitle","size":6},{"name":"ctaButton","size":6}]]},"uid":"api::demos-page.demos-page"}	object	\N	\N
14	plugin_content_manager_configuration_content_types::admin::permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}	object	\N	\N
16	plugin_content_manager_configuration_content_types::admin::role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}	object	\N	\N
19	plugin_content_manager_configuration_content_types::admin::transfer-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}	object	\N	\N
23	core_persisted_tables	[{"name":"strapi_history_versions"}]	object	\N	\N
28	plugin_users-permissions_grant	{"email":{"icon":"envelope","enabled":true},"discord":{"icon":"discord","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/discord/callback","scope":["identify","email"]},"facebook":{"icon":"facebook-square","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/facebook/callback","scope":["email"]},"google":{"icon":"google","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/google/callback","scope":["email"]},"github":{"icon":"github","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"icon":"windows","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"icon":"twitter","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitter/callback"},"instagram":{"icon":"instagram","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/instagram/callback","scope":["user_profile"]},"vk":{"icon":"vk","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/vk/callback","scope":["email"]},"twitch":{"icon":"twitch","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"icon":"linkedin","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"icon":"aws","enabled":false,"key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"icon":"reddit","enabled":false,"key":"","secret":"","callback":"api/auth/reddit/callback","scope":["identity"]},"auth0":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"icon":"book","enabled":false,"key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"icon":"","enabled":false,"key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"api/auth/keycloak/callback","scope":["openid","email","profile"]}}	object	\N	\N
29	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object	\N	\N
30	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}	object	\N	\N
67	plugin_content_manager_configuration_content_types::api::demo.demo	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"demoType":{"edit":{"label":"demoType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demoType","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"accessLevel":{"edit":{"label":"accessLevel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessLevel","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","demoType"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"demoType","size":6},{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}],[{"name":"allowedRoles","size":12}],[{"name":"accessLevel","size":6}]]},"uid":"api::demo.demo"}	object	\N	\N
79	plugin_content_manager_configuration_content_types::api::site-setting.site-setting	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"contactEmail":{"edit":{"label":"contactEmail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contactEmail","searchable":true,"sortable":true}},"contactPhone":{"edit":{"label":"contactPhone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contactPhone","searchable":true,"sortable":true}},"footerCompanyTitle":{"edit":{"label":"footerCompanyTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerCompanyTitle","searchable":true,"sortable":true}},"footerProductsTitle":{"edit":{"label":"footerProductsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerProductsTitle","searchable":true,"sortable":true}},"footerResourcesTitle":{"edit":{"label":"footerResourcesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerResourcesTitle","searchable":true,"sortable":true}},"footerConnectTitle":{"edit":{"label":"footerConnectTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerConnectTitle","searchable":true,"sortable":true}},"copyrightText":{"edit":{"label":"copyrightText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"copyrightText","searchable":true,"sortable":true}},"loginButtonText":{"edit":{"label":"loginButtonText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"loginButtonText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","contactEmail"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"contactEmail","size":6},{"name":"contactPhone","size":6}],[{"name":"footerCompanyTitle","size":6},{"name":"footerProductsTitle","size":6}],[{"name":"footerResourcesTitle","size":6},{"name":"footerConnectTitle","size":6}],[{"name":"copyrightText","size":6},{"name":"loginButtonText","size":6}]]},"uid":"api::site-setting.site-setting"}	object	\N	\N
31	ee_disabled_users	[]	object	\N	\N
32	core_admin_auth	{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}	object	\N	\N
12	plugin_content_manager_configuration_content_types::plugin::users-permissions.role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}	object	\N	\N
20	plugin_content_manager_configuration_content_types::admin::session	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"userId","defaultSortBy":"userId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"userId":{"edit":{"label":"userId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userId","searchable":true,"sortable":true}},"sessionId":{"edit":{"label":"sessionId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sessionId","searchable":true,"sortable":true}},"childId":{"edit":{"label":"childId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"childId","searchable":true,"sortable":true}},"deviceId":{"edit":{"label":"deviceId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"deviceId","searchable":true,"sortable":true}},"origin":{"edit":{"label":"origin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"origin","searchable":true,"sortable":true}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"absoluteExpiresAt":{"edit":{"label":"absoluteExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"absoluteExpiresAt","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","userId","sessionId","childId"],"edit":[[{"name":"userId","size":6},{"name":"sessionId","size":6}],[{"name":"childId","size":6},{"name":"deviceId","size":6}],[{"name":"origin","size":6},{"name":"expiresAt","size":6}],[{"name":"absoluteExpiresAt","size":6},{"name":"status","size":6}],[{"name":"type","size":6}]]},"uid":"admin::session"}	object	\N	\N
68	plugin_content_manager_configuration_content_types::api::homepage.homepage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"heroPrimaryCta":{"edit":{"label":"heroPrimaryCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroPrimaryCta","searchable":true,"sortable":true}},"heroSecondaryCta":{"edit":{"label":"heroSecondaryCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSecondaryCta","searchable":true,"sortable":true}},"heroBadge":{"edit":{"label":"heroBadge","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroBadge","searchable":true,"sortable":true}},"trustAward":{"edit":{"label":"trustAward","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustAward","searchable":true,"sortable":true}},"trustGlobal":{"edit":{"label":"trustGlobal","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustGlobal","searchable":true,"sortable":true}},"trustFast":{"edit":{"label":"trustFast","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustFast","searchable":true,"sortable":true}},"showStatsSection":{"edit":{"label":"showStatsSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showStatsSection","searchable":true,"sortable":true}},"showTrustedBySection":{"edit":{"label":"showTrustedBySection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showTrustedBySection","searchable":true,"sortable":true}},"trustedByTitle":{"edit":{"label":"trustedByTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustedByTitle","searchable":true,"sortable":true}},"showHowItWorksSection":{"edit":{"label":"showHowItWorksSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showHowItWorksSection","searchable":true,"sortable":true}},"howItWorksTitle":{"edit":{"label":"howItWorksTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"howItWorksTitle","searchable":true,"sortable":true}},"howItWorksSubtitle":{"edit":{"label":"howItWorksSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"howItWorksSubtitle","searchable":true,"sortable":true}},"showFeaturesSection":{"edit":{"label":"showFeaturesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showFeaturesSection","searchable":true,"sortable":true}},"featuresTitle":{"edit":{"label":"featuresTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresTitle","searchable":true,"sortable":true}},"featuresSubtitle":{"edit":{"label":"featuresSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresSubtitle","searchable":true,"sortable":true}},"showSolutionsSection":{"edit":{"label":"showSolutionsSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showSolutionsSection","searchable":true,"sortable":true}},"solutionsTitle":{"edit":{"label":"solutionsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"solutionsTitle","searchable":true,"sortable":true}},"solutionsSubtitle":{"edit":{"label":"solutionsSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"solutionsSubtitle","searchable":true,"sortable":true}},"showIndustriesSection":{"edit":{"label":"showIndustriesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showIndustriesSection","searchable":true,"sortable":true}},"industriesTitle":{"edit":{"label":"industriesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industriesTitle","searchable":true,"sortable":true}},"industriesSubtitle":{"edit":{"label":"industriesSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industriesSubtitle","searchable":true,"sortable":true}},"showCaseStudiesSection":{"edit":{"label":"showCaseStudiesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showCaseStudiesSection","searchable":true,"sortable":true}},"caseStudiesTitle":{"edit":{"label":"caseStudiesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caseStudiesTitle","searchable":true,"sortable":true}},"caseStudiesSubtitle":{"edit":{"label":"caseStudiesSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caseStudiesSubtitle","searchable":true,"sortable":true}},"showDemosSection":{"edit":{"label":"showDemosSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showDemosSection","searchable":true,"sortable":true}},"demosTitle":{"edit":{"label":"demosTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demosTitle","searchable":true,"sortable":true}},"demosSubtitle":{"edit":{"label":"demosSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demosSubtitle","searchable":true,"sortable":true}},"showCtaSection":{"edit":{"label":"showCtaSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showCtaSection","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaPrimaryButton":{"edit":{"label":"ctaPrimaryButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaPrimaryButton","searchable":true,"sortable":true}},"ctaSecondaryButton":{"edit":{"label":"ctaSecondaryButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSecondaryButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","heroPrimaryCta"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"heroPrimaryCta","size":6},{"name":"heroSecondaryCta","size":6}],[{"name":"heroBadge","size":6},{"name":"trustAward","size":6}],[{"name":"trustGlobal","size":6},{"name":"trustFast","size":6}],[{"name":"showStatsSection","size":4},{"name":"showTrustedBySection","size":4}],[{"name":"trustedByTitle","size":6},{"name":"showHowItWorksSection","size":4}],[{"name":"howItWorksTitle","size":6},{"name":"howItWorksSubtitle","size":6}],[{"name":"showFeaturesSection","size":4},{"name":"featuresTitle","size":6}],[{"name":"featuresSubtitle","size":6},{"name":"showSolutionsSection","size":4}],[{"name":"solutionsTitle","size":6},{"name":"solutionsSubtitle","size":6}],[{"name":"showIndustriesSection","size":4},{"name":"industriesTitle","size":6}],[{"name":"industriesSubtitle","size":6},{"name":"showCaseStudiesSection","size":4}],[{"name":"caseStudiesTitle","size":6},{"name":"caseStudiesSubtitle","size":6}],[{"name":"showDemosSection","size":4},{"name":"demosTitle","size":6}],[{"name":"demosSubtitle","size":6},{"name":"showCtaSection","size":4}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaPrimaryButton","size":6},{"name":"ctaSecondaryButton","size":6}]]},"uid":"api::homepage.homepage"}	object	\N	\N
86	plugin_content_manager_configuration_content_types::api::pricing-page.pricing-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"monthlyLabel":{"edit":{"label":"monthlyLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"monthlyLabel","searchable":true,"sortable":true}},"annualLabel":{"edit":{"label":"annualLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"annualLabel","searchable":true,"sortable":true}},"annualDiscount":{"edit":{"label":"annualDiscount","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"annualDiscount","searchable":true,"sortable":true}},"popularBadge":{"edit":{"label":"popularBadge","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"popularBadge","searchable":true,"sortable":true}},"featuresTitle":{"edit":{"label":"featuresTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresTitle","searchable":true,"sortable":true}},"feature1":{"edit":{"label":"feature1","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature1","searchable":true,"sortable":true}},"feature2":{"edit":{"label":"feature2","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature2","searchable":true,"sortable":true}},"feature3":{"edit":{"label":"feature3","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature3","searchable":true,"sortable":true}},"feature4":{"edit":{"label":"feature4","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature4","searchable":true,"sortable":true}},"feature5":{"edit":{"label":"feature5","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature5","searchable":true,"sortable":true}},"comparisonTitle":{"edit":{"label":"comparisonTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"comparisonTitle","searchable":true,"sortable":true}},"enterpriseTitle":{"edit":{"label":"enterpriseTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseTitle","searchable":true,"sortable":true}},"enterpriseSubtitle":{"edit":{"label":"enterpriseSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseSubtitle","searchable":true,"sortable":true}},"enterpriseCta":{"edit":{"label":"enterpriseCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseCta","searchable":true,"sortable":true}},"faqTitle":{"edit":{"label":"faqTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"faqTitle","searchable":true,"sortable":true}},"guaranteeTitle":{"edit":{"label":"guaranteeTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"guaranteeTitle","searchable":true,"sortable":true}},"guaranteeText":{"edit":{"label":"guaranteeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"guaranteeText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","monthlyLabel"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"monthlyLabel","size":6},{"name":"annualLabel","size":6}],[{"name":"annualDiscount","size":6},{"name":"popularBadge","size":6}],[{"name":"featuresTitle","size":6},{"name":"feature1","size":6}],[{"name":"feature2","size":6},{"name":"feature3","size":6}],[{"name":"feature4","size":6},{"name":"feature5","size":6}],[{"name":"comparisonTitle","size":6},{"name":"enterpriseTitle","size":6}],[{"name":"enterpriseSubtitle","size":6},{"name":"enterpriseCta","size":6}],[{"name":"faqTitle","size":6},{"name":"guaranteeTitle","size":6}],[{"name":"guaranteeText","size":6}]]},"uid":"api::pricing-page.pricing-page"}	object	\N	\N
13	plugin_content_manager_configuration_content_types::plugin::users-permissions.user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.user"}	object	\N	\N
15	plugin_content_manager_configuration_content_types::admin::user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}	object	\N	\N
18	plugin_content_manager_configuration_content_types::admin::transfer-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}	object	\N	\N
21	plugin_content_manager_configuration_content_types::admin::audit-log	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"date":{"edit":{"label":"date","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date","searchable":true,"sortable":true}},"user":{"edit":{"label":"user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"user","searchable":true,"sortable":true}},"payload":{"edit":{"label":"payload","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"payload","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","date","user"],"edit":[[{"name":"action","size":6},{"name":"date","size":6}],[{"name":"user","size":6}],[{"name":"payload","size":12}]]},"uid":"admin::audit-log"}	object	\N	\N
22	plugin_content_manager_configuration_content_types::admin::api-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"encryptedKey":{"edit":{"label":"encryptedKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"encryptedKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"encryptedKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}	object	\N	\N
24	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false,"aiMetadata":true}	object	\N	\N
25	plugin_upload_view_configuration	{"pageSize":10,"sort":"createdAt:DESC"}	object	\N	\N
27	plugin_i18n_default_locale	"en"	string	\N	\N
69	plugin_content_manager_configuration_content_types::api::industry.industry	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","summary"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}]]},"uid":"api::industry.industry"}	object	\N	\N
77	plugin_content_manager_configuration_content_types::api::user-audit-log.user-audit-log	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"ipAddress","defaultSortBy":"ipAddress","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"user":{"edit":{"label":"user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"user","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"ipAddress":{"edit":{"label":"ipAddress","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ipAddress","searchable":true,"sortable":true}},"userAgent":{"edit":{"label":"userAgent","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userAgent","searchable":true,"sortable":true}},"targetDemo":{"edit":{"label":"targetDemo","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"targetDemo","searchable":true,"sortable":true}},"metadata":{"edit":{"label":"metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"metadata","searchable":false,"sortable":false}},"success":{"edit":{"label":"success","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"success","searchable":true,"sortable":true}},"errorMessage":{"edit":{"label":"errorMessage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"errorMessage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","user","action","ipAddress"],"edit":[[{"name":"user","size":6},{"name":"action","size":6}],[{"name":"ipAddress","size":6},{"name":"userAgent","size":6}],[{"name":"targetDemo","size":6}],[{"name":"metadata","size":12}],[{"name":"success","size":4},{"name":"errorMessage","size":6}]]},"uid":"api::user-audit-log.user-audit-log"}	object	\N	\N
26	plugin_upload_metrics	{"weeklySchedule":"49 6 17 * * 4","lastWeeklyUpdate":1769699209402}	object	\N	\N
87	plugin_content_manager_configuration_content_types::api::solutions-page.solutions-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterPlatforms":{"edit":{"label":"filterPlatforms","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterPlatforms","searchable":true,"sortable":true}},"filterServices":{"edit":{"label":"filterServices","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterServices","searchable":true,"sortable":true}},"filterAi":{"edit":{"label":"filterAi","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAi","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterPlatforms","size":6}],[{"name":"filterServices","size":6},{"name":"filterAi","size":6}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::solutions-page.solutions-page"}	object	\N	\N
70	plugin_content_manager_configuration_content_types::api::process-step.process-step	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"step":{"edit":{"label":"step","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"step","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","step","title","description"],"edit":[[{"name":"step","size":4},{"name":"title","size":6}],[{"name":"description","size":6},{"name":"icon","size":6}]]},"uid":"api::process-step.process-step"}	object	\N	\N
88	plugin_content_manager_configuration_content_types::api::pricing-plan.pricing-plan	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"popular":{"edit":{"label":"popular","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"popular","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"price":{"edit":{"label":"price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"price","searchable":true,"sortable":true}},"currency":{"edit":{"label":"currency","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"currency","searchable":true,"sortable":true}},"period":{"edit":{"label":"period","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"period","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"features":{"edit":{"label":"features","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"features","searchable":true,"sortable":true}},"limitations":{"edit":{"label":"limitations","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"limitations","searchable":true,"sortable":true}},"cta":{"edit":{"label":"cta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"cta","searchable":true,"sortable":true}},"idealFor":{"edit":{"label":"idealFor","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"idealFor","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","order","popular"],"edit":[[{"name":"slug","size":6},{"name":"order","size":4}],[{"name":"popular","size":4},{"name":"name","size":6}],[{"name":"price","size":6},{"name":"currency","size":6}],[{"name":"period","size":6},{"name":"description","size":6}],[{"name":"features","size":6},{"name":"limitations","size":6}],[{"name":"cta","size":6},{"name":"idealFor","size":6}]]},"uid":"api::pricing-plan.pricing-plan"}	object	\N	\N
71	plugin_content_manager_configuration_content_types::api::feature.feature	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","icon"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"icon","size":6},{"name":"order","size":4}]]},"uid":"api::feature.feature"}	object	\N	\N
81	plugin_i18n_settings	{"aiLocalizations":true}	object	\N	\N
89	plugin_content_manager_configuration_content_types::api::partner.partner	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"partnerType":{"edit":{"label":"partnerType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"partnerType","searchable":true,"sortable":true}},"logoUrl":{"edit":{"label":"logoUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"logoUrl","searchable":true,"sortable":true}},"websiteUrl":{"edit":{"label":"websiteUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"websiteUrl","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"partnership":{"edit":{"label":"partnership","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"partnership","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","order","partnerType"],"edit":[[{"name":"slug","size":6},{"name":"order","size":4}],[{"name":"partnerType","size":6},{"name":"logoUrl","size":6}],[{"name":"websiteUrl","size":6},{"name":"name","size":6}],[{"name":"description","size":6},{"name":"partnership","size":6}]]},"uid":"api::partner.partner"}	object	\N	\N
72	plugin_content_manager_configuration_content_types::api::nav-item.nav-item	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"label","defaultSortBy":"label","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"label":{"edit":{"label":"label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"label","searchable":true,"sortable":true}},"href":{"edit":{"label":"href","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"href","searchable":true,"sortable":true}},"location":{"edit":{"label":"location","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"location","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"isExternal":{"edit":{"label":"isExternal","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isExternal","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","label","href","location"],"edit":[[{"name":"label","size":6},{"name":"href","size":6}],[{"name":"location","size":6},{"name":"order","size":4}],[{"name":"isExternal","size":4}]]},"uid":"api::nav-item.nav-item"}	object	\N	\N
80	plugin_content_manager_configuration_content_types::api::team-member.team-member	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"position":{"edit":{"label":"position","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"position","searchable":true,"sortable":true}},"bio":{"edit":{"label":"bio","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"bio","searchable":true,"sortable":true}},"photo":{"edit":{"label":"photo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"photo","searchable":false,"sortable":false}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"linkedinUrl":{"edit":{"label":"linkedinUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"linkedinUrl","searchable":true,"sortable":true}},"twitterUrl":{"edit":{"label":"twitterUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"twitterUrl","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","position","bio"],"edit":[[{"name":"name","size":6},{"name":"position","size":6}],[{"name":"bio","size":6},{"name":"photo","size":6}],[{"name":"order","size":4},{"name":"linkedinUrl","size":6}],[{"name":"twitterUrl","size":6}]]},"uid":"api::team-member.team-member"}	object	\N	\N
82	plugin_content_manager_configuration_content_types::api::faq.faq	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"category":{"edit":{"label":"category","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"category","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"question":{"edit":{"label":"question","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"question","searchable":true,"sortable":true}},"answer":{"edit":{"label":"answer","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"answer","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","category","order"],"edit":[[{"name":"slug","size":6},{"name":"category","size":6}],[{"name":"order","size":4},{"name":"question","size":6}],[{"name":"answer","size":12}]]},"uid":"api::faq.faq"}	object	\N	\N
90	plugin_content_manager_configuration_content_types::api::testimonial.testimonial	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"author","defaultSortBy":"author","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"rating":{"edit":{"label":"rating","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"rating","searchable":true,"sortable":true}},"featured":{"edit":{"label":"featured","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featured","searchable":true,"sortable":true}},"quote":{"edit":{"label":"quote","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"quote","searchable":true,"sortable":true}},"author":{"edit":{"label":"author","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"author","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"role","searchable":true,"sortable":true}},"company":{"edit":{"label":"company","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"company","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","order","rating","featured"],"edit":[[{"name":"order","size":4},{"name":"rating","size":4},{"name":"featured","size":4}],[{"name":"quote","size":6},{"name":"author","size":6}],[{"name":"role","size":6},{"name":"company","size":6}]]},"uid":"api::testimonial.testimonial"}	object	\N	\N
73	plugin_content_manager_configuration_content_types::api::solution.solution	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","summary"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}],[{"name":"allowedRoles","size":12}]]},"uid":"api::solution.solution"}	object	\N	\N
78	plugin_content_manager_configuration_content_types::api::value.value	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","icon"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"icon","size":6},{"name":"order","size":4}]]},"uid":"api::value.value"}	object	\N	\N
83	plugin_content_manager_configuration_content_types::api::case-studies-page.case-studies-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterRetail":{"edit":{"label":"filterRetail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterRetail","searchable":true,"sortable":true}},"filterRealEstate":{"edit":{"label":"filterRealEstate","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterRealEstate","searchable":true,"sortable":true}},"filterTourism":{"edit":{"label":"filterTourism","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterTourism","searchable":true,"sortable":true}},"filterEvents":{"edit":{"label":"filterEvents","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterEvents","searchable":true,"sortable":true}},"filterEducation":{"edit":{"label":"filterEducation","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterEducation","searchable":true,"sortable":true}},"resultsLabel":{"edit":{"label":"resultsLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"resultsLabel","searchable":true,"sortable":true}},"readMoreButton":{"edit":{"label":"readMoreButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"readMoreButton","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterRetail","size":6}],[{"name":"filterRealEstate","size":6},{"name":"filterTourism","size":6}],[{"name":"filterEvents","size":6},{"name":"filterEducation","size":6}],[{"name":"resultsLabel","size":6},{"name":"readMoreButton","size":6}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::case-studies-page.case-studies-page"}	object	\N	\N
2	ee_information	{"lastCheckAt":1769813147965,"license":"UXcvV0IxZ0VjdmtwSHhzbGEyQ3pTbGRIMjgybHRKclkwVFFTY0lUSUxoY3lIYklLWFpad08rWlFiYU1EUDRqWFlOTnZWQi9LQ0tNTlVQekpzU2k4enEycXlOUjZLRnJZcVQxZUJWL21GN0V0djBQTmF6N1FGTVR2bFFMZmhUVUc1ZzJZQ0MxUlRhQTN3bndEbUxQVUJXUTVNTkdObWhLRWhhTFFEZFBGRUlHSWF0RXd4NnlQc2pUdE9ndW1JZDlKVXJiOTBjRkR5SDFiNFFEZ1dDZlRKampLdlRBWnRJeEdpMVhmSzVhSFdaemFCUndTUS81WW82WitqUG1sZHYwa2FGcGFrN2lyYW9MekZkRUplbTA4YzNSbnU1MXRVb2xUYlNVcElJWjZ5Z2YxbHBiRnNZaGxYcGF4REh4Q3VSOUZHcm14RFVtWTV1UXhObGx6WTZzeWlRPT0KZXlKc2FXTmxibk5sUzJWNUlqb2lNelUyT0Rkak5qRXRNVEU0T1MwME9XTTFMVGc0T1RjdFlqSm1Oemt6TXpsbU9URmxJaXdpZEhsd1pTSTZJbk5wYkhabGNpSXNJbWx6VkhKcFlXd2lPblJ5ZFdVc0ltVjRjR2x5WlVGMElqb3hOelk1T1RnMU9UVXdNek00TENKelpXRjBjeUk2TVRBd01Dd2labVZoZEhWeVpYTWlPbHQ3SW01aGJXVWlPaUp6YzI4aWZTeDdJbTVoYldVaU9pSmpiWE10WVdraUxDSnZjSFJwYjI1eklqcDdJbU55WldScGRITkNZWE5sSWpveE1Dd2lZM0psWkdsMGMwMWhlRlZ6WVdkbElqb3hNSDE5TEhzaWJtRnRaU0k2SW1OdGN5MWpiMjUwWlc1MExXaHBjM1J2Y25raUxDSnZjSFJwYjI1eklqcDdJbkpsZEdWdWRHbHZia1JoZVhNaU9qTXdmWDBzZXlKdVlXMWxJam9pWTIxekxXRmtkbUZ1WTJWa0xYQnlaWFpwWlhjaWZTeDdJbTVoYldVaU9pSmpiWE10WTI5dWRHVnVkQzF5Wld4bFlYTmxjeUlzSW05d2RHbHZibk1pT25zaWJXRjRhVzExYlZKbGJHVmhjMlZ6SWpvNU9UazVPVGw5ZlYwc0ltTjFjM1J2YldWeVNXUWlPaUpCZWxwYVMycFdPVE52ZG1Kb01uRjJkeUlzSW5OMVluTmpjbWx3ZEdsdmJrbGtJam9pUVhweFYzVmxWamt6YjNweFF6SnhNREFpTENKd2JHRnVVSEpwWTJWSlpDSTZJbWR5YjNkMGFDMXpjMjh0WTJ4cExYWXlMVlZUUkMxTmIyNTBhR3g1SW4wPQ=="}	\N	\N	\N
84	plugin_content_manager_configuration_content_types::api::industries-page.industries-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"statsTitle":{"edit":{"label":"statsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"statsTitle","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","statsTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"statsTitle","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaSubtitle","size":6},{"name":"ctaButton","size":6}]]},"uid":"api::industries-page.industries-page"}	object	\N	\N
74	plugin_content_manager_configuration_content_types::api::stat.stat	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"value","defaultSortBy":"value","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"value":{"edit":{"label":"value","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value","searchable":true,"sortable":true}},"label":{"edit":{"label":"label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"label","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","value","label","order"],"edit":[[{"name":"value","size":6},{"name":"label","size":6}],[{"name":"order","size":4}]]},"uid":"api::stat.stat"}	object	\N	\N
76	plugin_content_manager_configuration_content_types::api::trusted-company.trusted-company	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"logo":{"edit":{"label":"logo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"logo","searchable":true,"sortable":true}},"website":{"edit":{"label":"website","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"website","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","logo","website"],"edit":[[{"name":"name","size":6},{"name":"logo","size":6}],[{"name":"website","size":6},{"name":"order","size":4}]]},"uid":"api::trusted-company.trusted-company"}	object	\N	\N
\.


--
-- Data for Name: strapi_database_schema; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_database_schema (id, schema, "time", hash) FROM stdin;
39	{"tables":[{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_documents_idx","columns":["document_id","locale","published_at"]},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_documents_idx","columns":["document_id","locale","published_at"]},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_documents_idx","columns":["document_id","locale","published_at"]},{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows","indexes":[{"name":"strapi_workflows_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_types","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_workflows_stages","indexes":[{"name":"strapi_workflows_stages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_roles","indexes":[{"name":"up_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_users","indexes":[{"name":"up_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"about_pages","indexes":[{"name":"about_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"about_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"about_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"about_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"about_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mission_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mission_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"vision_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"vision_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"values_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_1_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_1_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_2_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_2_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_3_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value_3_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"team_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"team_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"case_studies_pages","indexes":[{"name":"case_studies_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"case_studies_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"case_studies_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"case_studies_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"case_studies_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_all","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_retail","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_real_estate","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_tourism","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_events","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_education","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"results_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"read_more_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"case_studies","indexes":[{"name":"case_studies_documents_idx","columns":["document_id","locale","published_at"]},{"name":"case_studies_created_by_id_fk","columns":["created_by_id"]},{"name":"case_studies_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"case_studies_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"case_studies_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"client","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"industry","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"summary","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"body","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"allowed_roles","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"contact_pages","indexes":[{"name":"contact_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"contact_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"contact_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"contact_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"contact_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"form_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"phone_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"message_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"submit_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"info_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"address","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"phone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hours_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hours_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"demos","indexes":[{"name":"demos_documents_idx","columns":["document_id","locale","published_at"]},{"name":"demos_created_by_id_fk","columns":["created_by_id"]},{"name":"demos_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"demos_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"demos_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"demo_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"summary","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"body","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"allowed_roles","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_level","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"demos_pages","indexes":[{"name":"demos_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"demos_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"demos_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"demos_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"demos_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_all","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_matterport","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_ai","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_vfair","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_public","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_auth","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_enterprise","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"try_now_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"request_access_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"faqs","indexes":[{"name":"faqs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"faqs_created_by_id_fk","columns":["created_by_id"]},{"name":"faqs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"faqs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"faqs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"category","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"question","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"answer","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"features","indexes":[{"name":"features_documents_idx","columns":["document_id","locale","published_at"]},{"name":"features_created_by_id_fk","columns":["created_by_id"]},{"name":"features_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"features_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"features_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"homepages","indexes":[{"name":"homepages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"homepages_created_by_id_fk","columns":["created_by_id"]},{"name":"homepages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"homepages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"homepages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_primary_cta","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_secondary_cta","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_badge","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"trust_award","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"trust_global","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"trust_fast","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_stats_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_trusted_by_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"trusted_by_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_how_it_works_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"how_it_works_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"how_it_works_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_features_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"features_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"features_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_solutions_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"solutions_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"solutions_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_industries_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"industries_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"industries_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_case_studies_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"case_studies_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"case_studies_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_demos_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"demos_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"demos_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"show_cta_section","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_primary_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_secondary_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"industries_pages","indexes":[{"name":"industries_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"industries_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"industries_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"industries_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"industries_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"stats_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"industries","indexes":[{"name":"industries_documents_idx","columns":["document_id","locale","published_at"]},{"name":"industries_created_by_id_fk","columns":["created_by_id"]},{"name":"industries_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"industries_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"industries_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"summary","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"body","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"nav_items","indexes":[{"name":"nav_items_documents_idx","columns":["document_id","locale","published_at"]},{"name":"nav_items_created_by_id_fk","columns":["created_by_id"]},{"name":"nav_items_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"nav_items_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"nav_items_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"href","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"location","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_external","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"partners","indexes":[{"name":"partners_documents_idx","columns":["document_id","locale","published_at"]},{"name":"partners_created_by_id_fk","columns":["created_by_id"]},{"name":"partners_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"partners_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"partners_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"partner_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"logo_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"website_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"partnership","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"pricing_pages","indexes":[{"name":"pricing_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"pricing_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"pricing_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"pricing_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"pricing_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"monthly_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"annual_label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"annual_discount","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"popular_badge","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"features_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"feature_1","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"feature_2","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"feature_3","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"feature_4","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"feature_5","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"comparison_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enterprise_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enterprise_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enterprise_cta","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"faq_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"guarantee_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"guarantee_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"pricing_plans","indexes":[{"name":"pricing_plans_documents_idx","columns":["document_id","locale","published_at"]},{"name":"pricing_plans_created_by_id_fk","columns":["created_by_id"]},{"name":"pricing_plans_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"pricing_plans_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"pricing_plans_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"popular","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"price","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"currency","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"period","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"features","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"limitations","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ideal_for","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"process_steps","indexes":[{"name":"process_steps_documents_idx","columns":["document_id","locale","published_at"]},{"name":"process_steps_created_by_id_fk","columns":["created_by_id"]},{"name":"process_steps_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"process_steps_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"process_steps_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"step","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"site_settings","indexes":[{"name":"site_settings_documents_idx","columns":["document_id","locale","published_at"]},{"name":"site_settings_created_by_id_fk","columns":["created_by_id"]},{"name":"site_settings_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"site_settings_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"site_settings_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"contact_email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"contact_phone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"footer_company_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"footer_products_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"footer_resources_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"footer_connect_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"copyright_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"login_button_text","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"solutions","indexes":[{"name":"solutions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"solutions_created_by_id_fk","columns":["created_by_id"]},{"name":"solutions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"solutions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"solutions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"slug","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"summary","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"body","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"allowed_roles","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"solutions_pages","indexes":[{"name":"solutions_pages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"solutions_pages_created_by_id_fk","columns":["created_by_id"]},{"name":"solutions_pages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"solutions_pages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"solutions_pages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hero_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_all","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_platforms","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_services","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"filter_ai","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_subtitle","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"cta_button","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"stats","indexes":[{"name":"stats_documents_idx","columns":["document_id","locale","published_at"]},{"name":"stats_created_by_id_fk","columns":["created_by_id"]},{"name":"stats_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"stats_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"stats_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"label","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"team_members","indexes":[{"name":"team_members_documents_idx","columns":["document_id","locale","published_at"]},{"name":"team_members_created_by_id_fk","columns":["created_by_id"]},{"name":"team_members_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"team_members_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"team_members_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"position","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"bio","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"linkedin_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"twitter_url","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"testimonials","indexes":[{"name":"testimonials_documents_idx","columns":["document_id","locale","published_at"]},{"name":"testimonials_created_by_id_fk","columns":["created_by_id"]},{"name":"testimonials_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"testimonials_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"testimonials_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"rating","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"featured","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"quote","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"author","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"role","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"company","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"trusted_companies","indexes":[{"name":"trusted_companies_documents_idx","columns":["document_id","locale","published_at"]},{"name":"trusted_companies_created_by_id_fk","columns":["created_by_id"]},{"name":"trusted_companies_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"trusted_companies_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"trusted_companies_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"logo","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"website","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"user_audit_logs","indexes":[{"name":"user_audit_logs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"user_audit_logs_created_by_id_fk","columns":["created_by_id"]},{"name":"user_audit_logs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"user_audit_logs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"user_audit_logs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ip_address","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_agent","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"success","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"error_message","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"values","indexes":[{"name":"values_documents_idx","columns":["document_id","locale","published_at"]},{"name":"values_created_by_id_fk","columns":["created_by_id"]},{"name":"values_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"values_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"values_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"title","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"icon","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_users","indexes":[{"name":"admin_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"encrypted_key","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_sessions","indexes":[{"name":"strapi_sessions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"session_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"child_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"device_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"origin","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"absolute_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_audit_logs","indexes":[{"name":"strapi_audit_logs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_audit_logs_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_audit_logs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_audit_logs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_audit_logs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"payload","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_history_versions","indexes":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"]}],"foreignKeys":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"data","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schema","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_ai_localization_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"source_locale","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"target_locales","type":"jsonb","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"files_related_mph","indexes":[{"name":"files_related_mph_fk","columns":["file_id"]},{"name":"files_related_mph_oidx","columns":["order"]},{"name":"files_related_mph_idix","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_mph_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_lnk","indexes":[{"name":"files_folder_lnk_fk","columns":["file_id"]},{"name":"files_folder_lnk_ifk","columns":["folder_id"]},{"name":"files_folder_lnk_uq","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_lnk_oifk","columns":["file_ord"]}],"foreignKeys":[{"name":"files_folder_lnk_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_lnk_ifk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_lnk","indexes":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"]},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_lnk_uq","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_lnk_oifk","columns":["folder_ord"]}],"foreignKeys":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_lnk","indexes":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"]},{"name":"strapi_release_actions_release_lnk_uq","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_lnk_oifk","columns":["release_action_ord"]}],"foreignKeys":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stage_required_to_publish_lnk","indexes":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_uq","columns":["workflow_id","workflow_stage_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_workflow_lnk","indexes":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"]},{"name":"strapi_workflows_stages_workflow_lnk_uq","columns":["workflow_stage_id","workflow_id"],"type":"unique"},{"name":"strapi_workflows_stages_workflow_lnk_oifk","columns":["workflow_stage_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_permissions_lnk","indexes":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"]},{"name":"strapi_workflows_stages_permissions_lnk_uq","columns":["workflow_stage_id","permission_id"],"type":"unique"},{"name":"strapi_workflows_stages_permissions_lnk_ofk","columns":["permission_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_lnk","indexes":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"up_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_lnk","indexes":[{"name":"up_users_role_lnk_fk","columns":["user_id"]},{"name":"up_users_role_lnk_ifk","columns":["role_id"]},{"name":"up_users_role_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"up_users_role_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"user_audit_logs_user_lnk","indexes":[{"name":"user_audit_logs_user_lnk_fk","columns":["user_audit_log_id"]},{"name":"user_audit_logs_user_lnk_ifk","columns":["user_id"]},{"name":"user_audit_logs_user_lnk_uq","columns":["user_audit_log_id","user_id"],"type":"unique"}],"foreignKeys":[{"name":"user_audit_logs_user_lnk_fk","columns":["user_audit_log_id"],"referencedColumns":["id"],"referencedTable":"user_audit_logs","onDelete":"CASCADE"},{"name":"user_audit_logs_user_lnk_ifk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_audit_log_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"user_audit_logs_target_demo_lnk","indexes":[{"name":"user_audit_logs_target_demo_lnk_fk","columns":["user_audit_log_id"]},{"name":"user_audit_logs_target_demo_lnk_ifk","columns":["demo_id"]},{"name":"user_audit_logs_target_demo_lnk_uq","columns":["user_audit_log_id","demo_id"],"type":"unique"}],"foreignKeys":[{"name":"user_audit_logs_target_demo_lnk_fk","columns":["user_audit_log_id"],"referencedColumns":["id"],"referencedTable":"user_audit_logs","onDelete":"CASCADE"},{"name":"user_audit_logs_target_demo_lnk_ifk","columns":["demo_id"],"referencedColumns":["id"],"referencedTable":"demos","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_audit_log_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"demo_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_permissions_role_lnk","indexes":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"admin_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_lnk","indexes":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"]},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"]},{"name":"admin_users_roles_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_lnk_ofk","columns":["role_ord"]},{"name":"admin_users_roles_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_lnk","indexes":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_lnk_uq","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_lnk_oifk","columns":["api_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_lnk","indexes":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_uq","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_lnk_oifk","columns":["transfer_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_audit_logs_user_lnk","indexes":[{"name":"strapi_audit_logs_user_lnk_fk","columns":["audit_log_id"]},{"name":"strapi_audit_logs_user_lnk_ifk","columns":["user_id"]},{"name":"strapi_audit_logs_user_lnk_uq","columns":["audit_log_id","user_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_audit_logs_user_lnk_fk","columns":["audit_log_id"],"referencedColumns":["id"],"referencedTable":"strapi_audit_logs","onDelete":"CASCADE"},{"name":"strapi_audit_logs_user_lnk_ifk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"audit_log_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}	2026-01-30 17:58:08.748	94038f2cad654d8570e61c340deaee18cfda09b37f113b325b54960b8e614566
\.


--
-- Data for Name: strapi_history_versions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_history_versions (id, content_type, related_document_id, locale, status, data, schema, created_at, created_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_migrations; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_migrations (id, name, "time") FROM stdin;
\.


--
-- Data for Name: strapi_migrations_internal; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_migrations_internal (id, name, "time") FROM stdin;
1	5.0.0-rename-identifiers-longer-than-max-length	2026-01-29 17:06:04.732
2	5.0.0-02-created-document-id	2026-01-29 17:06:04.761
3	5.0.0-03-created-locale	2026-01-29 17:06:04.784
4	5.0.0-04-created-published-at	2026-01-29 17:06:04.809
5	5.0.0-05-drop-slug-fields-index	2026-01-29 17:06:04.831
6	core::5.0.0-discard-drafts	2026-01-29 17:06:04.854
7	content-releases::5.0.0-add-entry-document-id-to-release-actions	2026-01-29 17:06:04.862
\.


--
-- Data for Name: strapi_release_actions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_release_actions (id, document_id, type, content_type, entry_document_id, locale, is_entry_valid, created_at, updated_at, published_at, created_by_id, updated_by_id) FROM stdin;
\.


--
-- Data for Name: strapi_release_actions_release_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_release_actions_release_lnk (id, release_action_id, release_id, release_action_ord) FROM stdin;
\.


--
-- Data for Name: strapi_releases; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_releases (id, document_id, name, released_at, scheduled_at, timezone, status, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_sessions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_sessions (id, document_id, user_id, session_id, child_id, device_id, origin, expires_at, absolute_expires_at, status, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	onj2no8yp1by71n5x6kypz71	1	34f2d98e55538a1c6c40506a4ded1aca	\N	3f3aa7d3-da50-4035-80c1-c196542276e5	admin	2026-01-29 19:09:23.216	2026-02-28 17:09:23.216	active	session	2026-01-29 17:09:23.216	2026-01-29 17:09:23.216	2026-01-29 17:09:23.217	\N	\N	\N
2	b3j2sjs1fhmppnzzun167leq	1	a2755321270d0b38bdc6de61d79ee3d7	\N	1fe7d24d-1931-45ef-92df-5265fdb0e526	admin	2026-01-29 19:10:21.206	2026-02-28 17:10:21.206	active	session	2026-01-29 17:10:21.206	2026-01-29 17:10:21.206	2026-01-29 17:10:21.206	\N	\N	\N
3	namifktb98skfsf3xln1l5i9	1	d8d53c76552a3d0e30ad7182c9e4a229	\N	de473add-67e4-4a69-b3b4-767a361a871a	admin	2026-01-29 19:53:36.454	2026-02-28 17:53:36.454	active	session	2026-01-29 17:53:36.454	2026-01-29 17:53:36.454	2026-01-29 17:53:36.455	\N	\N	\N
4	zdjf1qfznw3nshpbqsn0yqx4	1	76d0714dff10d9a578089fbf612d1986	\N	2f0dfce9-3659-4f20-b13c-8778ec7972b6	admin	2026-01-29 19:54:09.012	2026-02-28 17:54:09.012	active	session	2026-01-29 17:54:09.012	2026-01-29 17:54:09.012	2026-01-29 17:54:09.013	\N	\N	\N
6	dj7hyqf2baafwmx641fqaxi3	1	b4acc3014741cfd866cbd5eefa8a1593	\N	f30c5aed-438c-4066-be91-c78a52617203	admin	2026-01-29 20:04:56.067	2026-02-28 18:04:56.067	active	session	2026-01-29 18:04:56.067	2026-01-29 18:04:56.067	2026-01-29 18:04:56.068	\N	\N	\N
7	c31g4nalroipqthutb775uw9	1	078194c5532355b87087a6ee9429e690	\N	308bb0e6-d585-454a-9119-d63a14fa67fe	admin	2026-01-29 20:17:54.232	2026-02-28 18:17:54.232	active	session	2026-01-29 18:17:54.232	2026-01-29 18:17:54.232	2026-01-29 18:17:54.232	\N	\N	\N
8	oie9orwa4em4jzg1nkllaugq	1	07d61444bb0cb19bb001a23fce6e60d3	\N	8e7aac5e-b1ce-4169-b804-a9669e11a94d	admin	2026-01-29 20:18:03.502	2026-02-28 18:18:03.502	active	session	2026-01-29 18:18:03.502	2026-01-29 18:18:03.502	2026-01-29 18:18:03.502	\N	\N	\N
9	c0xlstizwr1ru5xf3ve1twz7	1	5160c929477ac4d59bc3a8037a834d95	\N	77fc3888-42da-40f2-8a41-87c78c55342d	admin	2026-01-29 20:26:09.033	2026-02-28 18:26:09.033	active	session	2026-01-29 18:26:09.033	2026-01-29 18:26:09.033	2026-01-29 18:26:09.033	\N	\N	\N
10	vx3snf5c0wwshb8cbm55z79e	1	e20c412d00156c28fd8882a5012e4696	\N	1852e675-18f7-4c14-94ff-bfaaaef65272	admin	2026-01-29 20:26:30.372	2026-02-28 18:26:30.372	active	session	2026-01-29 18:26:30.372	2026-01-29 18:26:30.372	2026-01-29 18:26:30.372	\N	\N	\N
11	zwiszefrslqllzme5a6iedjr	1	3b2d9583bedf9f372901b50818af5873	\N	b36b097a-c034-4600-889b-392164ccf9b8	admin	2026-01-29 20:27:10.304	2026-02-28 18:27:10.304	active	session	2026-01-29 18:27:10.304	2026-01-29 18:27:10.304	2026-01-29 18:27:10.304	\N	\N	\N
12	jxb5s2imqvaxc1korgp62c6m	1	bad351c4edf674a33a9dfe1221056996	\N	56835123-b9fb-4114-9789-cabba2a3133a	admin	2026-01-29 20:27:28.29	2026-02-28 18:27:28.29	active	session	2026-01-29 18:27:28.29	2026-01-29 18:27:28.29	2026-01-29 18:27:28.29	\N	\N	\N
13	f5uhza342sxfg7ico7oe7ua8	1	ca04776f30c6c3c9a6529f5f7a95c421	\N	1f73756e-1b3a-41f1-a562-c280ac6d303d	admin	2026-01-29 20:33:05.536	2026-02-28 18:33:05.536	active	session	2026-01-29 18:33:05.536	2026-01-29 18:33:05.536	2026-01-29 18:33:05.536	\N	\N	\N
14	eqjh72vn7mz8uhagn5n4uxfh	1	ec594be000ce2d09facf3a46cf91f219	\N	f529b411-aca5-4406-b8a0-fb35fcd73156	admin	2026-01-29 20:37:27.807	2026-02-28 18:37:27.807	active	session	2026-01-29 18:37:27.807	2026-01-29 18:37:27.807	2026-01-29 18:37:27.807	\N	\N	\N
5	lb4hb40zckxa6v9vxa6im9ja	1	78a7878d3b28c8e61fbe1fef922378f0	1e9055334f19b6691f2e3b73df7caa79	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-12 18:01:26.784	2026-02-28 18:01:26.784	rotated	refresh	2026-01-29 18:01:26.784	2026-01-29 18:41:48.805	2026-01-29 18:01:26.784	\N	\N	\N
15	k5bwww36otrraoncqniv3lf0	1	1e9055334f19b6691f2e3b73df7caa79	501a0aef5a2bef0280966f244b294b92	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-12 18:41:48.793	2026-02-28 18:01:26.784	rotated	refresh	2026-01-29 18:41:48.793	2026-01-30 11:34:52.014	2026-01-29 18:41:48.795	\N	\N	\N
17	rq3ifjqpzni6vucde1w187hh	1	83a10bc7fc537b46346c81f08ff0ff48	\N	42aa97d0-d17e-4be9-aa40-109b75159070	admin	2026-01-30 13:54:34.693	2026-03-01 11:54:34.693	active	session	2026-01-30 11:54:34.693	2026-01-30 11:54:34.693	2026-01-30 11:54:34.694	\N	\N	\N
18	yu1hv8g27urx0uaq24e7jpjt	1	fad36c4a8f08d453773dd01371aefead	\N	8ff3a8ce-22ac-4568-99bc-7ea3706c2293	admin	2026-01-30 13:54:42.766	2026-03-01 11:54:42.766	active	session	2026-01-30 11:54:42.766	2026-01-30 11:54:42.766	2026-01-30 11:54:42.767	\N	\N	\N
19	dfft2ih34f1fhp54izi1mwpg	1	4863d0a5b3412b902971c1c699a3d50e	\N	7c8b90a5-bd98-457b-8f14-924d88fac190	admin	2026-01-30 13:56:10.732	2026-03-01 11:56:10.732	active	session	2026-01-30 11:56:10.732	2026-01-30 11:56:10.732	2026-01-30 11:56:10.733	\N	\N	\N
16	m2kxvusuh4m2s0mbsp5sovoq	1	501a0aef5a2bef0280966f244b294b92	e5bfff3826d0122e0042ac5957127797	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 11:34:52	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 11:34:52.001	2026-01-30 12:09:22.733	2026-01-30 11:34:52.002	\N	\N	\N
20	cvg4cg6hh3p9c0rc3asriwi8	1	e5bfff3826d0122e0042ac5957127797	4ec3a0061c2a678476d3900ee952033c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 12:09:22.712	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 12:09:22.712	2026-01-30 13:20:28.262	2026-01-30 12:09:22.713	\N	\N	\N
21	w709nfabu5bkd0w5t9geekbz	1	4ec3a0061c2a678476d3900ee952033c	14ca561cf7344ed7eae1dd50fdb7f97c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 13:20:28.252	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 13:20:28.253	2026-01-30 13:52:18.43	2026-01-30 13:20:28.254	\N	\N	\N
22	e05lrw3wg4qx87pf7k6fzf2e	1	14ca561cf7344ed7eae1dd50fdb7f97c	3c1f2a75865b538f87f4efafc05ca13c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 13:52:18.414	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 13:52:18.414	2026-01-30 15:18:53.28	2026-01-30 13:52:18.415	\N	\N	\N
23	zf0sgo1jba581vo47w9zfj3s	1	3c1f2a75865b538f87f4efafc05ca13c	5f57577348a073edcce1649e57828423	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 15:18:53.269	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 15:18:53.27	2026-01-30 15:52:20.072	2026-01-30 15:18:53.27	\N	\N	\N
24	jd6051c3mhdeornouq1lvply	1	5f57577348a073edcce1649e57828423	93ba33a054bae4ea10013d533e9e76bf	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 15:52:20.06	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 15:52:20.06	2026-01-30 18:08:04.721	2026-01-30 15:52:20.06	\N	\N	\N
25	ni092tn3mr6cz3u02n4yv7et	1	93ba33a054bae4ea10013d533e9e76bf	6671df8f375f9a2184452cc5bb7ea50c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 18:08:04.711	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 18:08:04.711	2026-01-30 18:58:45.702	2026-01-30 18:08:04.712	\N	\N	\N
27	e2086l8df154pzhn1aocru6k	1	42bb0969f028a6853b358e0dc6131134	\N	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 00:47:57.993	2026-02-28 18:01:26.784	active	refresh	2026-01-31 00:47:57.993	2026-01-31 00:47:57.993	2026-01-31 00:47:57.995	\N	\N	\N
26	ok9a36lkj75j2a84j7mbhbna	1	6671df8f375f9a2184452cc5bb7ea50c	42bb0969f028a6853b358e0dc6131134	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 18:58:45.689	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 18:58:45.689	2026-01-31 00:47:58.016	2026-01-30 18:58:45.69	\N	\N	\N
\.


--
-- Data for Name: strapi_transfer_token_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_token_permissions_token_lnk (id, transfer_token_permission_id, transfer_token_id, transfer_token_permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_transfer_tokens; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_tokens (id, document_id, name, description, access_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- Data for Name: strapi_workflows; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows (id, document_id, name, content_types, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stage_required_to_publish_lnk (id, workflow_id, workflow_stage_id) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages (id, document_id, name, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_permissions_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages_permissions_lnk (id, workflow_stage_id, permission_id, permission_ord) FROM stdin;
\.


--
-- Data for Name: strapi_workflows_stages_workflow_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages_workflow_lnk (id, workflow_stage_id, workflow_id, workflow_stage_ord) FROM stdin;
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.team_members (id, document_id, name, "position", bio, "order", linkedin_url, twitter_url, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	wfxkypmk0rpvaivtlbz5drau	Ahmed Al-Rashid	Chief Executive Officer & Founder	Former CTO at a leading MENA e-commerce platform. 15+ years building technology companies across the region.	1	https://linkedin.com/in/	\N	2026-01-30 18:18:44.645	2026-01-30 18:18:44.645	\N	\N	\N	en
2	wfxkypmk0rpvaivtlbz5drau	Ahmed Al-Rashid	Chief Executive Officer & Founder	Former CTO at a leading MENA e-commerce platform. 15+ years building technology companies across the region.	1	https://linkedin.com/in/	\N	2026-01-30 18:18:44.645	2026-01-30 18:18:44.645	2026-01-30 18:18:44.65	\N	\N	en
3	wfxkypmk0rpvaivtlbz5drau	أحمد الراشد	الرئيس التنفيذي والمؤسس	مدير تقني سابق في منصة تجارة إلكترونية رائدة في الشرق الأوسط. أكثر من 15 عاماً في بناء شركات التقنية.	1	https://linkedin.com/in/	\N	2026-01-30 18:18:44.671	2026-01-30 18:18:44.671	\N	\N	\N	ar
4	wfxkypmk0rpvaivtlbz5drau	أحمد الراشد	الرئيس التنفيذي والمؤسس	مدير تقني سابق في منصة تجارة إلكترونية رائدة في الشرق الأوسط. أكثر من 15 عاماً في بناء شركات التقنية.	1	https://linkedin.com/in/	\N	2026-01-30 18:18:44.671	2026-01-30 18:18:44.671	2026-01-30 18:18:44.674	\N	\N	ar
5	zkj9afum7rkox7d98i8bgzr0	Dr. Fatima Hassan	Chief Technology Officer	AI and Computer Vision expert with PhD from MIT. Previously led machine learning teams at major tech companies.	2	https://linkedin.com/in/	\N	2026-01-30 18:18:44.694	2026-01-30 18:18:44.694	\N	\N	\N	en
6	zkj9afum7rkox7d98i8bgzr0	Dr. Fatima Hassan	Chief Technology Officer	AI and Computer Vision expert with PhD from MIT. Previously led machine learning teams at major tech companies.	2	https://linkedin.com/in/	\N	2026-01-30 18:18:44.694	2026-01-30 18:18:44.694	2026-01-30 18:18:44.697	\N	\N	en
7	zkj9afum7rkox7d98i8bgzr0	د. فاطمة حسن	المديرة التنفيذية للتقنية	خبيرة ذكاء اصطناعي ورؤية حاسوبية مع دكتوراه من MIT. قادت سابقاً فرق تعلم الآلة في شركات تقنية كبرى.	2	https://linkedin.com/in/	\N	2026-01-30 18:18:44.716	2026-01-30 18:18:44.716	\N	\N	\N	ar
8	zkj9afum7rkox7d98i8bgzr0	د. فاطمة حسن	المديرة التنفيذية للتقنية	خبيرة ذكاء اصطناعي ورؤية حاسوبية مع دكتوراه من MIT. قادت سابقاً فرق تعلم الآلة في شركات تقنية كبرى.	2	https://linkedin.com/in/	\N	2026-01-30 18:18:44.716	2026-01-30 18:18:44.716	2026-01-30 18:18:44.721	\N	\N	ar
9	ruf8gglwetvtk0wupucbwmm6	Omar Khalil	Head of Design	Award-winning UX designer specializing in Arabic-first interfaces. 12 years of experience.	3	https://linkedin.com/in/	\N	2026-01-30 18:18:44.741	2026-01-30 18:18:44.741	\N	\N	\N	en
10	ruf8gglwetvtk0wupucbwmm6	Omar Khalil	Head of Design	Award-winning UX designer specializing in Arabic-first interfaces. 12 years of experience.	3	https://linkedin.com/in/	\N	2026-01-30 18:18:44.741	2026-01-30 18:18:44.741	2026-01-30 18:18:44.743	\N	\N	en
11	ruf8gglwetvtk0wupucbwmm6	عمر خليل	رئيس التصميم	مصمم UX حائز على جوائز متخصص في الواجهات العربية أولاً. 12 عاماً من الخبرة.	3	https://linkedin.com/in/	\N	2026-01-30 18:18:44.762	2026-01-30 18:18:44.762	\N	\N	\N	ar
12	ruf8gglwetvtk0wupucbwmm6	عمر خليل	رئيس التصميم	مصمم UX حائز على جوائز متخصص في الواجهات العربية أولاً. 12 عاماً من الخبرة.	3	https://linkedin.com/in/	\N	2026-01-30 18:18:44.762	2026-01-30 18:18:44.762	2026-01-30 18:18:44.765	\N	\N	ar
13	p92k1mn0eki62w9n7m9eyuef	Layla Mansour	Vice President of Sales	10+ years in enterprise technology sales across MENA. Built teams that closed $50M+ in annual revenue.	4	https://linkedin.com/in/	\N	2026-01-30 18:18:44.786	2026-01-30 18:18:44.786	\N	\N	\N	en
14	p92k1mn0eki62w9n7m9eyuef	Layla Mansour	Vice President of Sales	10+ years in enterprise technology sales across MENA. Built teams that closed $50M+ in annual revenue.	4	https://linkedin.com/in/	\N	2026-01-30 18:18:44.786	2026-01-30 18:18:44.786	2026-01-30 18:18:44.789	\N	\N	en
15	p92k1mn0eki62w9n7m9eyuef	ليلى منصور	نائبة رئيس المبيعات	أكثر من 10 سنوات في مبيعات تقنية المؤسسات عبر الشرق الأوسط.	4	https://linkedin.com/in/	\N	2026-01-30 18:18:44.807	2026-01-30 18:18:44.807	\N	\N	\N	ar
16	p92k1mn0eki62w9n7m9eyuef	ليلى منصور	نائبة رئيس المبيعات	أكثر من 10 سنوات في مبيعات تقنية المؤسسات عبر الشرق الأوسط.	4	https://linkedin.com/in/	\N	2026-01-30 18:18:44.807	2026-01-30 18:18:44.807	2026-01-30 18:18:44.809	\N	\N	ar
17	n8wdzrj8lnse55886m2yq1ds	Youssef Ibrahim	Head of Operations	Operations excellence leader with background in logistics and service delivery.	5	https://linkedin.com/in/	\N	2026-01-30 18:18:44.831	2026-01-30 18:18:44.831	\N	\N	\N	en
18	n8wdzrj8lnse55886m2yq1ds	Youssef Ibrahim	Head of Operations	Operations excellence leader with background in logistics and service delivery.	5	https://linkedin.com/in/	\N	2026-01-30 18:18:44.831	2026-01-30 18:18:44.831	2026-01-30 18:18:44.834	\N	\N	en
19	n8wdzrj8lnse55886m2yq1ds	يوسف إبراهيم	رئيس العمليات	قائد تميز العمليات بخلفية في اللوجستيات وتقديم الخدمات.	5	https://linkedin.com/in/	\N	2026-01-30 18:18:44.852	2026-01-30 18:18:44.852	\N	\N	\N	ar
20	n8wdzrj8lnse55886m2yq1ds	يوسف إبراهيم	رئيس العمليات	قائد تميز العمليات بخلفية في اللوجستيات وتقديم الخدمات.	5	https://linkedin.com/in/	\N	2026-01-30 18:18:44.852	2026-01-30 18:18:44.852	2026-01-30 18:18:44.855	\N	\N	ar
21	v9bi4z813g4he5edn4tzgs6v	Nour Al-Sayed	Head of Customer Success	Customer experience champion with 8 years in SaaS customer success.	6	https://linkedin.com/in/	\N	2026-01-30 18:18:44.876	2026-01-30 18:18:44.876	\N	\N	\N	en
22	v9bi4z813g4he5edn4tzgs6v	Nour Al-Sayed	Head of Customer Success	Customer experience champion with 8 years in SaaS customer success.	6	https://linkedin.com/in/	\N	2026-01-30 18:18:44.876	2026-01-30 18:18:44.876	2026-01-30 18:18:44.879	\N	\N	en
23	v9bi4z813g4he5edn4tzgs6v	نور السيد	رئيسة نجاح العملاء	بطلة تجربة العملاء مع 8 سنوات في نجاح عملاء SaaS.	6	https://linkedin.com/in/	\N	2026-01-30 18:18:44.898	2026-01-30 18:18:44.898	\N	\N	\N	ar
24	v9bi4z813g4he5edn4tzgs6v	نور السيد	رئيسة نجاح العملاء	بطلة تجربة العملاء مع 8 سنوات في نجاح عملاء SaaS.	6	https://linkedin.com/in/	\N	2026-01-30 18:18:44.898	2026-01-30 18:18:44.898	2026-01-30 18:18:44.9	\N	\N	ar
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.testimonials (id, document_id, "order", rating, featured, quote, author, role, company, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	opq1fmv3lnckbzxhmwwk62ds	1	5	t	Arabiq transformed how we sell furniture. Our customers can now walk through our showroom from anywhere in the world. Sales increased 340% in the first quarter after launching.	Mohamed El-Sayed	CEO	Suites Egypt	2026-01-30 18:18:45.853	2026-01-30 18:18:45.853	\N	\N	\N	en
2	opq1fmv3lnckbzxhmwwk62ds	1	5	t	Arabiq transformed how we sell furniture. Our customers can now walk through our showroom from anywhere in the world. Sales increased 340% in the first quarter after launching.	Mohamed El-Sayed	CEO	Suites Egypt	2026-01-30 18:18:45.853	2026-01-30 18:18:45.853	2026-01-30 18:18:45.857	\N	\N	en
3	opq1fmv3lnckbzxhmwwk62ds	1	5	t	حوّلت Arabiq طريقة بيعنا للأثاث. يمكن لعملائنا الآن التجول في صالة العرض من أي مكان في العالم. زادت المبيعات 340% في الربع الأول بعد الإطلاق.	محمد السيد	الرئيس التنفيذي	Suites Egypt	2026-01-30 18:18:45.873	2026-01-30 18:18:45.873	\N	\N	\N	ar
4	opq1fmv3lnckbzxhmwwk62ds	1	5	t	حوّلت Arabiq طريقة بيعنا للأثاث. يمكن لعملائنا الآن التجول في صالة العرض من أي مكان في العالم. زادت المبيعات 340% في الربع الأول بعد الإطلاق.	محمد السيد	الرئيس التنفيذي	Suites Egypt	2026-01-30 18:18:45.873	2026-01-30 18:18:45.873	2026-01-30 18:18:45.875	\N	\N	ar
5	n5savc0wwmy19jtftka6buc6	2	5	t	The Arabic AI assistant understands our customers perfectly. It handles Gulf, Egyptian, and Levantine dialects seamlessly. Customer satisfaction improved 45% since implementation.	Fatima Al-Rashid	Digital Transformation Director	Majid Al Futtaim	2026-01-30 18:18:45.894	2026-01-30 18:18:45.894	\N	\N	\N	en
6	n5savc0wwmy19jtftka6buc6	2	5	t	The Arabic AI assistant understands our customers perfectly. It handles Gulf, Egyptian, and Levantine dialects seamlessly. Customer satisfaction improved 45% since implementation.	Fatima Al-Rashid	Digital Transformation Director	Majid Al Futtaim	2026-01-30 18:18:45.894	2026-01-30 18:18:45.894	2026-01-30 18:18:45.896	\N	\N	en
7	n5savc0wwmy19jtftka6buc6	2	5	t	مساعد الذكاء الاصطناعي العربي يفهم عملاءنا تماماً. يتعامل مع اللهجات الخليجية والمصرية والشامية بسلاسة. تحسن رضا العملاء بنسبة 45% منذ التطبيق.	فاطمة الراشد	مديرة التحول الرقمي	ماجد الفطيم	2026-01-30 18:18:45.91	2026-01-30 18:18:45.91	\N	\N	\N	ar
8	n5savc0wwmy19jtftka6buc6	2	5	t	مساعد الذكاء الاصطناعي العربي يفهم عملاءنا تماماً. يتعامل مع اللهجات الخليجية والمصرية والشامية بسلاسة. تحسن رضا العملاء بنسبة 45% منذ التطبيق.	فاطمة الراشد	مديرة التحول الرقمي	ماجد الفطيم	2026-01-30 18:18:45.91	2026-01-30 18:18:45.91	2026-01-30 18:18:45.913	\N	\N	ar
9	qb2es65ey3qka86jksib45ki	3	5	t	We digitized our entire museum collection in just 3 days. Now visitors from 89 countries can explore our heritage. The UNESCO recognition was the ultimate validation of this approach.	Dr. Amira Hassan	Director	Alexandria National Museum	2026-01-30 18:18:45.936	2026-01-30 18:18:45.936	\N	\N	\N	en
10	qb2es65ey3qka86jksib45ki	3	5	t	We digitized our entire museum collection in just 3 days. Now visitors from 89 countries can explore our heritage. The UNESCO recognition was the ultimate validation of this approach.	Dr. Amira Hassan	Director	Alexandria National Museum	2026-01-30 18:18:45.936	2026-01-30 18:18:45.936	2026-01-30 18:18:45.939	\N	\N	en
11	qb2es65ey3qka86jksib45ki	3	5	t	رقمنا مجموعة متحفنا بالكامل في 3 أيام فقط. الآن يمكن للزوار من 89 دولة استكشاف تراثنا. اعتراف اليونسكو كان التأكيد النهائي لهذا النهج.	د. أميرة حسن	المديرة	متحف الإسكندرية القومي	2026-01-30 18:18:45.955	2026-01-30 18:18:45.955	\N	\N	\N	ar
12	qb2es65ey3qka86jksib45ki	3	5	t	رقمنا مجموعة متحفنا بالكامل في 3 أيام فقط. الآن يمكن للزوار من 89 دولة استكشاف تراثنا. اعتراف اليونسكو كان التأكيد النهائي لهذا النهج.	د. أميرة حسن	المديرة	متحف الإسكندرية القومي	2026-01-30 18:18:45.955	2026-01-30 18:18:45.955	2026-01-30 18:18:45.958	\N	\N	ar
13	xmyhaokucnw2dalfdoavcqxk	4	5	f	Going hybrid with Arabiq was the best decision for our conference. We reached 5x more attendees while spending less than previous years. The networking features were exceptional.	Sara Al-Dosari	Event Director	Gulf Tech Summit	2026-01-30 18:18:45.977	2026-01-30 18:18:45.977	\N	\N	\N	en
14	xmyhaokucnw2dalfdoavcqxk	4	5	f	Going hybrid with Arabiq was the best decision for our conference. We reached 5x more attendees while spending less than previous years. The networking features were exceptional.	Sara Al-Dosari	Event Director	Gulf Tech Summit	2026-01-30 18:18:45.977	2026-01-30 18:18:45.977	2026-01-30 18:18:45.979	\N	\N	en
15	xmyhaokucnw2dalfdoavcqxk	4	5	f	التحول للهجين مع Arabiq كان أفضل قرار لمؤتمرنا. وصلنا لـ 5 أضعاف الحاضرين بينما أنفقنا أقل من السنوات السابقة. ميزات التواصل كانت استثنائية.	سارة الدوسري	مديرة الفعاليات	Gulf Tech Summit	2026-01-30 18:18:45.993	2026-01-30 18:18:45.993	\N	\N	\N	ar
16	xmyhaokucnw2dalfdoavcqxk	4	5	f	التحول للهجين مع Arabiq كان أفضل قرار لمؤتمرنا. وصلنا لـ 5 أضعاف الحاضرين بينما أنفقنا أقل من السنوات السابقة. ميزات التواصل كانت استثنائية.	سارة الدوسري	مديرة الفعاليات	Gulf Tech Summit	2026-01-30 18:18:45.993	2026-01-30 18:18:45.993	2026-01-30 18:18:45.995	\N	\N	ar
17	xdsfqj4itwrnw086uzh4giwc	5	5	f	Our customers can now explore a Mercedes interior at midnight from their home. By the time they visit our showroom, they know exactly what they want. Sales cycle shortened by 65%.	Khalid Al-Mutairi	General Manager	Riyadh Motors	2026-01-30 18:18:46.011	2026-01-30 18:18:46.011	\N	\N	\N	en
18	xdsfqj4itwrnw086uzh4giwc	5	5	f	Our customers can now explore a Mercedes interior at midnight from their home. By the time they visit our showroom, they know exactly what they want. Sales cycle shortened by 65%.	Khalid Al-Mutairi	General Manager	Riyadh Motors	2026-01-30 18:18:46.011	2026-01-30 18:18:46.011	2026-01-30 18:18:46.013	\N	\N	en
19	xdsfqj4itwrnw086uzh4giwc	5	5	f	يمكن لعملائنا الآن استكشاف داخل مرسيدس في منتصف الليل من منازلهم. بحلول وقت زيارتهم لصالة العرض، يعرفون بالضبط ما يريدون. قصرت دورة المبيعات بنسبة 65%.	خالد المطيري	المدير العام	Riyadh Motors	2026-01-30 18:18:46.027	2026-01-30 18:18:46.027	\N	\N	\N	ar
20	xdsfqj4itwrnw086uzh4giwc	5	5	f	يمكن لعملائنا الآن استكشاف داخل مرسيدس في منتصف الليل من منازلهم. بحلول وقت زيارتهم لصالة العرض، يعرفون بالضبط ما يريدون. قصرت دورة المبيعات بنسبة 65%.	خالد المطيري	المدير العام	Riyadh Motors	2026-01-30 18:18:46.027	2026-01-30 18:18:46.027	2026-01-30 18:18:46.03	\N	\N	ar
21	z0ovc7vux0d784b6uw7j9jhk	6	5	f	The virtual mall concept was revolutionary for our vendors. Small boutiques that could never afford their own e-commerce presence now have beautiful virtual stores that compete with big brands.	Yasmine Fouad	Founder	Cairo Fashion Hub	2026-01-30 18:18:46.052	2026-01-30 18:18:46.052	\N	\N	\N	en
22	z0ovc7vux0d784b6uw7j9jhk	6	5	f	The virtual mall concept was revolutionary for our vendors. Small boutiques that could never afford their own e-commerce presence now have beautiful virtual stores that compete with big brands.	Yasmine Fouad	Founder	Cairo Fashion Hub	2026-01-30 18:18:46.052	2026-01-30 18:18:46.052	2026-01-30 18:18:46.054	\N	\N	en
23	z0ovc7vux0d784b6uw7j9jhk	6	5	f	مفهوم المول الافتراضي كان ثورياً لبائعينا. المتاجر الصغيرة التي لم تكن قادرة على تحمل تكاليف حضور إلكتروني خاص بها الآن لديها متاجر افتراضية جميلة تنافس العلامات الكبيرة.	ياسمين فؤاد	المؤسسة	Cairo Fashion Hub	2026-01-30 18:18:46.068	2026-01-30 18:18:46.068	\N	\N	\N	ar
24	z0ovc7vux0d784b6uw7j9jhk	6	5	f	مفهوم المول الافتراضي كان ثورياً لبائعينا. المتاجر الصغيرة التي لم تكن قادرة على تحمل تكاليف حضور إلكتروني خاص بها الآن لديها متاجر افتراضية جميلة تنافس العلامات الكبيرة.	ياسمين فؤاد	المؤسسة	Cairo Fashion Hub	2026-01-30 18:18:46.068	2026-01-30 18:18:46.068	2026-01-30 18:18:46.071	\N	\N	ar
\.


--
-- Data for Name: trusted_companies; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.trusted_companies (id, document_id, name, logo, website, "order", created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	cfzqydxal739laj0pagv53q6	Saudi Telecom Company	\N	\N	1	2026-01-30 18:18:44.476	2026-01-30 18:18:44.476	\N	\N	\N	en
2	cfzqydxal739laj0pagv53q6	Saudi Telecom Company	\N	\N	1	2026-01-30 18:18:44.476	2026-01-30 18:18:44.476	2026-01-30 18:18:44.48	\N	\N	en
3	dbyvn85adm2qvsezxnhp359y	Emaar Properties	\N	\N	2	2026-01-30 18:18:44.501	2026-01-30 18:18:44.501	\N	\N	\N	en
4	dbyvn85adm2qvsezxnhp359y	Emaar Properties	\N	\N	2	2026-01-30 18:18:44.501	2026-01-30 18:18:44.501	2026-01-30 18:18:44.503	\N	\N	en
5	sat6241t323uogqb0ky187dx	Majid Al Futtaim	\N	\N	3	2026-01-30 18:18:44.521	2026-01-30 18:18:44.521	\N	\N	\N	en
6	sat6241t323uogqb0ky187dx	Majid Al Futtaim	\N	\N	3	2026-01-30 18:18:44.521	2026-01-30 18:18:44.521	2026-01-30 18:18:44.524	\N	\N	en
7	f3px1hi3t936filz7v9m0igk	Almarai	\N	\N	4	2026-01-30 18:18:44.542	2026-01-30 18:18:44.542	\N	\N	\N	en
8	f3px1hi3t936filz7v9m0igk	Almarai	\N	\N	4	2026-01-30 18:18:44.542	2026-01-30 18:18:44.542	2026-01-30 18:18:44.544	\N	\N	en
9	us7bvc98jo14k8bd2azw4trn	Saudi Aramco	\N	\N	5	2026-01-30 18:18:44.564	2026-01-30 18:18:44.564	\N	\N	\N	en
10	us7bvc98jo14k8bd2azw4trn	Saudi Aramco	\N	\N	5	2026-01-30 18:18:44.564	2026-01-30 18:18:44.564	2026-01-30 18:18:44.567	\N	\N	en
11	gln0v8ax8zscyofaqv0ava0p	Dubai Tourism	\N	\N	6	2026-01-30 18:18:44.584	2026-01-30 18:18:44.584	\N	\N	\N	en
12	gln0v8ax8zscyofaqv0ava0p	Dubai Tourism	\N	\N	6	2026-01-30 18:18:44.584	2026-01-30 18:18:44.584	2026-01-30 18:18:44.586	\N	\N	en
13	pzvuiudozmd9v3xdbj1fqx8k	Jarir Bookstore	\N	\N	7	2026-01-30 18:18:44.604	2026-01-30 18:18:44.604	\N	\N	\N	en
14	pzvuiudozmd9v3xdbj1fqx8k	Jarir Bookstore	\N	\N	7	2026-01-30 18:18:44.604	2026-01-30 18:18:44.604	2026-01-30 18:18:44.608	\N	\N	en
15	e7je5xqzcev18hvo8c8ryxmy	ROSHN	\N	\N	8	2026-01-30 18:18:44.625	2026-01-30 18:18:44.625	\N	\N	\N	en
16	e7je5xqzcev18hvo8c8ryxmy	ROSHN	\N	\N	8	2026-01-30 18:18:44.625	2026-01-30 18:18:44.625	2026-01-30 18:18:44.627	\N	\N	en
\.


--
-- Data for Name: up_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ghysqdwedlr6utz9jq3v003q	plugin::users-permissions.auth.logout	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
2	ogmyoaahvw9y1vk392n9cyje	plugin::users-permissions.user.me	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
3	pvgqddrlka4wvvdriorn7ry2	plugin::users-permissions.auth.changePassword	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
4	gpp396rtmiogbywcrsey6919	plugin::users-permissions.auth.callback	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
5	kc3p4nb898hqr60mojg0se5g	plugin::users-permissions.auth.connect	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
6	bjwy4y9j5hgcocjj3zwuk4vu	plugin::users-permissions.auth.forgotPassword	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
7	hdy7pbqddmrg3ev0w8xgb0eb	plugin::users-permissions.auth.register	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
8	eriy2nc5mwj79o96oo80f4po	plugin::users-permissions.auth.resetPassword	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
9	vwxo66oep47ym1tl48n5n8dr	plugin::users-permissions.auth.sendEmailConfirmation	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
11	ke6ky8fmeasu2878bki1wf4t	plugin::users-permissions.auth.refresh	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
10	x3c57n62aboqgkw7h1855vpg	plugin::users-permissions.auth.emailConfirmation	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
16	\N	api::custom-auth.custom-auth.me	2026-01-30 18:52:07.755782	2026-01-30 18:52:07.755782	\N	\N	\N	\N
15	0c4a4009b1018e503a9d8b4882e12a38	api::site-setting.site-setting.find	2026-01-29 18:22:23.304281	2026-01-31 00:45:50.747	\N	\N	\N	\N
14	a313abcf5771954c6b1926023eb86744	api::nav-item.nav-item.find	2026-01-29 18:22:23.304281	2026-01-31 00:45:50.759	\N	\N	\N	\N
12	6f264cc116e845cd196b2d56a47d0519	api::nav-item.nav-item.findOne	2026-01-29 18:22:23.304281	2026-01-31 00:45:50.767	\N	\N	\N	\N
\.


--
-- Data for Name: up_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	1	1
2	3	1	1
3	2	1	1
4	4	2	1
5	5	2	1
6	10	2	1
7	6	2	1
8	11	2	1
9	8	2	2
10	9	2	2
11	7	2	2
12	12	2	\N
14	14	2	\N
15	15	2	\N
16	2	3	1
17	16	3	1
\.


--
-- Data for Name: up_roles; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_roles (id, document_id, name, description, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	sfhvqo48zt7cytfh10bgye82	Authenticated	Default role given to authenticated user.	authenticated	2026-01-29 17:06:07.674	2026-01-29 17:06:07.674	2026-01-29 17:06:07.674	\N	\N	\N
2	e03sz2xsq6v3p4rernfq818x	Public	Default role given to unauthenticated user.	public	2026-01-29 17:06:07.681	2026-01-29 17:06:07.681	2026-01-29 17:06:07.681	\N	\N	\N
3	b3zab4fbk17fc7h48b291rim	Potential Customer	New users awaiting approval, limited access to public content	potential-customer	2026-01-29 17:06:08.708	2026-01-29 17:06:08.708	2026-01-29 17:06:08.708	\N	\N	\N
4	oe2snc6ib3wi33d2zumi84ny	Client	Approved clients with access to premium demos and content	client	2026-01-29 17:06:08.715	2026-01-29 17:06:08.715	2026-01-29 17:06:08.715	\N	\N	\N
5	yyakiogp1s54z4ep27me2kav	Premium	Premium tier clients with full access to all demos	premium	2026-01-29 17:06:08.72	2026-01-29 17:06:08.72	2026-01-29 17:06:08.72	\N	\N	\N
\.


--
-- Data for Name: up_users; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_users (id, document_id, username, email, provider, password, reset_password_token, confirmation_token, confirmed, blocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, phone, country, company, sales_contact_allowed, display_name, account_status) FROM stdin;
1	oufwhzowb8b131uhieo40htg	test999	test999@example.com	local	$2a$10$NOcTyuOKaD68dGwIDDw2rODET4DYzRU1zBDkUCVlrw0iKgXYbrRNW	\N	\N	t	f	2026-01-30 17:30:19.152	2026-01-30 17:30:19.152	2026-01-30 17:30:19.152	\N	\N	\N	\N	\N	\N	t	\N	pending
2	vbbtnq637bjf9v1bq8ibev3e	newuser123	newuser123@example.com	local	$2a$10$bFdwB.s.90MXQDn4RtD/C.dFLDPkCa3kayRZXwkMMfYTZcrSqD5ZG	\N	\N	t	f	2026-01-30 17:33:01.964	2026-01-30 17:33:01.964	2026-01-30 17:33:01.965	\N	\N	\N	\N	\N	\N	t	\N	pending
3	k7oihcgku3xpxvhd37rkz2qp	anotheruser	another@example.com	local	$2a$10$zDg3H60dNxN1Lhjdmdhpd.wBkwU.SNCHtmi4E0PMKyIWu.2F.hLu2	\N	\N	t	f	2026-01-30 17:33:27.673	2026-01-30 17:33:27.673	2026-01-30 17:33:27.673	\N	\N	\N	\N	\N	\N	t	\N	pending
4	arkyzihwtdmv3uri10dq2eds	fulluser	fulluser@example.com	local	$2a$10$3YXGbdXeHZMyUWchfqddL.wVBWESeRPeImP2sEVyRIQkL6Jv3zZtu	\N	\N	t	f	2026-01-30 17:33:48.076	2026-01-30 17:33:48.076	2026-01-30 17:33:48.076	\N	\N	\N	\N	\N	\N	t	\N	pending
5	qynjxi8eh9u7qml7cgolvncv	phoneuser	phoneuser@example.com	local	$2a$10$wrWitXLSgCsDMzhIhyy78ewkH526EPoQhxsTXqwm.zbHAJCh84YnW	\N	\N	t	f	2026-01-30 17:37:41.136	2026-01-30 17:37:41.149	2026-01-30 17:37:41.137	\N	\N	\N	\N	\N	\N	t	\N	pending
6	bswy8gikl06vfdqo6joq9qz8	finaltest	finaltest@example.com	local	$2a$10$dLMohC67.qVTIDMlb.oQ6et7r4sD79.FeXw7pTsGLmhKZf0Lp0tK6	\N	\N	t	f	2026-01-30 17:39:46.461	2026-01-30 17:39:46.473	2026-01-30 17:39:46.462	\N	\N	\N	\N	\N	\N	t	\N	pending
7	sq2t3u8n0qtnovms7jjz0y7u	testfinal	testfinal@example.com	local	$2a$10$pMlBmtEdXozWHWEOs7PJPunAaTb.U9yTtJ4WfveFNdELkTUCHWyDa	\N	\N	t	f	2026-01-30 17:54:47.151	2026-01-30 17:54:47.165	2026-01-30 17:54:47.151	\N	\N	\N	\N	\N	\N	t	\N	pending
8	dsq21abmwj6iq4k1clz465km	knextest	knextest@example.com	local	$2a$10$guWuFARD1YzMKrlRxm0eiOVPzaNaH0MZRBDuQ.JX5PoAX7NDvpmQS	\N	\N	t	f	2026-01-30 17:58:17.119	2026-01-30 17:58:17.119	2026-01-30 17:58:17.12	\N	\N	\N	+1444444444	Egypt	Knex Co	t	Knex Test	pending
9	kf51r5dzgff6v7yfk04t816r	webtest	webtest@test.com	local	$2a$10$Mj3exdfFdIHKtoa4XsBEt.Z/eMaO9/bfMutXqL4hZEmfKl5/TYKBi	\N	\N	t	f	2026-01-30 18:10:40.183	2026-01-30 18:10:40.183	2026-01-30 18:10:40.184	\N	\N	\N	+20123456789	\N	\N	t	webtest	pending
11	hjhjqv1jnsaubbjqx0b8bi9k	diagtest	diag@example.com	local	$2a$10$LN1fOg7rxigFtQlYxu1YKu3xPhfLYtYJk9kfJiy5otpq4SqfgTSFK	\N	\N	t	f	2026-01-30 18:32:44.931	2026-01-30 18:32:44.931	2026-01-30 18:32:44.931	\N	\N	\N	+201234567890	EG	TestCo	t	Diag User	pending
10	n1e69nynwtunz21bvrnsawyb	ali	ahmed.se@gmail.com	local	$2a$10$U..NFuUUlAxCbhd9U1K/XeEXekysrXznmkysUNCBP8j4PKuvTvcxS	\N	\N	t	f	2026-01-30 18:19:17.809	2026-01-30 19:00:17.544	2026-01-30 19:00:17.537	\N	1	\N	+201069937577	Egypt	ClearTurn Techs	t	ali	pending
\.


--
-- Data for Name: up_users_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_users_role_lnk (id, user_id, role_id, user_ord) FROM stdin;
1	1	3	1
2	2	3	2
3	3	3	3
4	4	3	4
5	5	3	5
6	6	3	6
7	7	3	7
8	8	3	8
9	9	3	9
10	10	3	10
11	11	3	11
\.


--
-- Data for Name: upload_folders; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.upload_folders (id, document_id, name, path_id, path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: upload_folders_parent_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.upload_folders_parent_lnk (id, folder_id, inv_folder_id, folder_ord) FROM stdin;
\.


--
-- Data for Name: user_audit_logs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.user_audit_logs (id, document_id, action, ip_address, user_agent, metadata, success, error_message, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- Data for Name: user_audit_logs_target_demo_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.user_audit_logs_target_demo_lnk (id, user_audit_log_id, demo_id) FROM stdin;
\.


--
-- Data for Name: user_audit_logs_user_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.user_audit_logs_user_lnk (id, user_audit_log_id, user_id) FROM stdin;
\.


--
-- Data for Name: values; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public."values" (id, document_id, title, description, icon, "order", created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	cyus3i632uky9wpccoaefv84	Arabic-First	Built from the ground up for Arabic language and RTL design. We don't translate—we create native Arabic experiences that resonate with regional audiences.	🌍	1	2026-01-30 18:18:45.635	2026-01-30 18:18:45.635	\N	\N	\N	en
2	cyus3i632uky9wpccoaefv84	Arabic-First	Built from the ground up for Arabic language and RTL design. We don't translate—we create native Arabic experiences that resonate with regional audiences.	🌍	1	2026-01-30 18:18:45.635	2026-01-30 18:18:45.635	2026-01-30 18:18:45.637	\N	\N	en
3	cyus3i632uky9wpccoaefv84	العربية أولاً	مبني من الأساس للغة العربية وتصميم RTL. لا نترجم — ننشئ تجارب عربية أصلية تتجاوب مع الجماهير الإقليمية.	🌍	1	2026-01-30 18:18:45.654	2026-01-30 18:18:45.654	\N	\N	\N	ar
4	cyus3i632uky9wpccoaefv84	العربية أولاً	مبني من الأساس للغة العربية وتصميم RTL. لا نترجم — ننشئ تجارب عربية أصلية تتجاوب مع الجماهير الإقليمية.	🌍	1	2026-01-30 18:18:45.654	2026-01-30 18:18:45.654	2026-01-30 18:18:45.656	\N	\N	ar
5	d680w77v6vhw7jk786pi58qc	Innovation	We push the boundaries of what's possible with 3D, AI, and immersive technology. Our R&D team constantly explores new ways to enhance virtual experiences.	💡	2	2026-01-30 18:18:45.673	2026-01-30 18:18:45.673	\N	\N	\N	en
6	d680w77v6vhw7jk786pi58qc	Innovation	We push the boundaries of what's possible with 3D, AI, and immersive technology. Our R&D team constantly explores new ways to enhance virtual experiences.	💡	2	2026-01-30 18:18:45.673	2026-01-30 18:18:45.673	2026-01-30 18:18:45.675	\N	\N	en
7	d680w77v6vhw7jk786pi58qc	الابتكار	ندفع حدود الممكن مع تقنية 3D والذكاء الاصطناعي والتقنية الغامرة. يستكشف فريق البحث والتطوير لدينا باستمرار طرقاً جديدة لتعزيز التجارب الافتراضية.	💡	2	2026-01-30 18:18:45.687	2026-01-30 18:18:45.687	\N	\N	\N	ar
8	d680w77v6vhw7jk786pi58qc	الابتكار	ندفع حدود الممكن مع تقنية 3D والذكاء الاصطناعي والتقنية الغامرة. يستكشف فريق البحث والتطوير لدينا باستمرار طرقاً جديدة لتعزيز التجارب الافتراضية.	💡	2	2026-01-30 18:18:45.687	2026-01-30 18:18:45.687	2026-01-30 18:18:45.689	\N	\N	ar
9	p3v9zqx13t56qmsq07eib6pc	Excellence	We deliver photorealistic quality, enterprise-grade security, and 99.9% uptime. Every project receives our full attention and highest standards.	⭐	3	2026-01-30 18:18:45.708	2026-01-30 18:18:45.708	\N	\N	\N	en
10	p3v9zqx13t56qmsq07eib6pc	Excellence	We deliver photorealistic quality, enterprise-grade security, and 99.9% uptime. Every project receives our full attention and highest standards.	⭐	3	2026-01-30 18:18:45.708	2026-01-30 18:18:45.708	2026-01-30 18:18:45.71	\N	\N	en
11	p3v9zqx13t56qmsq07eib6pc	التميز	نقدم جودة فوتوغرافية وأمان على مستوى المؤسسات ووقت تشغيل 99.9%. كل مشروع يحصل على اهتمامنا الكامل وأعلى معاييرنا.	⭐	3	2026-01-30 18:18:45.724	2026-01-30 18:18:45.724	\N	\N	\N	ar
12	p3v9zqx13t56qmsq07eib6pc	التميز	نقدم جودة فوتوغرافية وأمان على مستوى المؤسسات ووقت تشغيل 99.9%. كل مشروع يحصل على اهتمامنا الكامل وأعلى معاييرنا.	⭐	3	2026-01-30 18:18:45.724	2026-01-30 18:18:45.724	2026-01-30 18:18:45.726	\N	\N	ar
13	darw2vj9gh9fbzzi6gb3og0h	Partnership	Your success is our success. We measure ourselves by your results and provide dedicated support every step of the way.	🤝	4	2026-01-30 18:18:45.744	2026-01-30 18:18:45.744	\N	\N	\N	en
14	darw2vj9gh9fbzzi6gb3og0h	Partnership	Your success is our success. We measure ourselves by your results and provide dedicated support every step of the way.	🤝	4	2026-01-30 18:18:45.744	2026-01-30 18:18:45.744	2026-01-30 18:18:45.746	\N	\N	en
15	darw2vj9gh9fbzzi6gb3og0h	الشراكة	نجاحك هو نجاحنا. نقيس أنفسنا بنتائجك ونوفر دعماً مخصصاً في كل خطوة على الطريق.	🤝	4	2026-01-30 18:18:45.758	2026-01-30 18:18:45.758	\N	\N	\N	ar
16	darw2vj9gh9fbzzi6gb3og0h	الشراكة	نجاحك هو نجاحنا. نقيس أنفسنا بنتائجك ونوفر دعماً مخصصاً في كل خطوة على الطريق.	🤝	4	2026-01-30 18:18:45.758	2026-01-30 18:18:45.758	2026-01-30 18:18:45.759	\N	\N	ar
17	tvjktjdvlsnwwu4t5u78xeyh	Trust	We handle your data with the highest security standards and full transparency. SOC 2 compliant with regional data residency options.	🔒	5	2026-01-30 18:18:45.777	2026-01-30 18:18:45.777	\N	\N	\N	en
18	tvjktjdvlsnwwu4t5u78xeyh	Trust	We handle your data with the highest security standards and full transparency. SOC 2 compliant with regional data residency options.	🔒	5	2026-01-30 18:18:45.777	2026-01-30 18:18:45.777	2026-01-30 18:18:45.779	\N	\N	en
19	tvjktjdvlsnwwu4t5u78xeyh	الثقة	نتعامل مع بياناتك بأعلى معايير الأمان والشفافية الكاملة. متوافقون مع SOC 2 مع خيارات إقامة البيانات الإقليمية.	🔒	5	2026-01-30 18:18:45.793	2026-01-30 18:18:45.793	\N	\N	\N	ar
20	tvjktjdvlsnwwu4t5u78xeyh	الثقة	نتعامل مع بياناتك بأعلى معايير الأمان والشفافية الكاملة. متوافقون مع SOC 2 مع خيارات إقامة البيانات الإقليمية.	🔒	5	2026-01-30 18:18:45.793	2026-01-30 18:18:45.793	2026-01-30 18:18:45.795	\N	\N	ar
21	i6kg6udk3hiccgl1f2ckgtx1	Speed	Time is valuable. Our 48-hour delivery commitment and efficient processes ensure you go live faster than any competitor.	🚀	6	2026-01-30 18:18:45.814	2026-01-30 18:18:45.814	\N	\N	\N	en
22	i6kg6udk3hiccgl1f2ckgtx1	Speed	Time is valuable. Our 48-hour delivery commitment and efficient processes ensure you go live faster than any competitor.	🚀	6	2026-01-30 18:18:45.814	2026-01-30 18:18:45.814	2026-01-30 18:18:45.816	\N	\N	en
23	i6kg6udk3hiccgl1f2ckgtx1	السرعة	الوقت ثمين. التزامنا بالتسليم خلال 48 ساعة وعملياتنا الفعالة تضمن انطلاقك أسرع من أي منافس.	🚀	6	2026-01-30 18:18:45.829	2026-01-30 18:18:45.829	\N	\N	\N	ar
24	i6kg6udk3hiccgl1f2ckgtx1	السرعة	الوقت ثمين. التزامنا بالتسليم خلال 48 ساعة وعملياتنا الفعالة تضمن انطلاقك أسرع من أي منافس.	🚀	6	2026-01-30 18:18:45.829	2026-01-30 18:18:45.829	2026-01-30 18:18:45.831	\N	\N	ar
\.


--
-- Name: about_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.about_pages_id_seq', 2, true);


--
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 366, true);


--
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_permissions_role_lnk_id_seq', 366, true);


--
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_users_roles_lnk_id_seq', 1, true);


--
-- Name: case_studies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.case_studies_id_seq', 15, true);


--
-- Name: case_studies_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.case_studies_pages_id_seq', 4, true);


--
-- Name: contact_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.contact_pages_id_seq', 2, true);


--
-- Name: demos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.demos_id_seq', 18, true);


--
-- Name: demos_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.demos_pages_id_seq', 4, true);


--
-- Name: faqs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.faqs_id_seq', 40, true);


--
-- Name: features_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.features_id_seq', 32, true);


--
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_folder_lnk_id_seq', 1, false);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_id_seq', 1, false);


--
-- Name: files_related_mph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_related_mph_id_seq', 1, false);


--
-- Name: homepages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.homepages_id_seq', 4, true);


--
-- Name: i18n_locale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.i18n_locale_id_seq', 2, true);


--
-- Name: industries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.industries_id_seq', 18, true);


--
-- Name: industries_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.industries_pages_id_seq', 4, true);


--
-- Name: nav_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.nav_items_id_seq', 108, true);


--
-- Name: partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.partners_id_seq', 24, true);


--
-- Name: pricing_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.pricing_pages_id_seq', 4, true);


--
-- Name: pricing_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.pricing_plans_id_seq', 16, true);


--
-- Name: process_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.process_steps_id_seq', 16, true);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 2, true);


--
-- Name: solutions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.solutions_id_seq', 18, true);


--
-- Name: solutions_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.solutions_pages_id_seq', 4, true);


--
-- Name: stats_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.stats_id_seq', 24, true);


--
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_ai_localization_jobs_id_seq', 600, true);


--
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_id_seq', 1, false);


--
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_tokens_id_seq', 4, true);


--
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_audit_logs_id_seq', 1, false);


--
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_audit_logs_user_lnk_id_seq', 1, false);


--
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_core_store_settings_id_seq', 90, true);


--
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_database_schema_id_seq', 39, true);


--
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_history_versions_id_seq', 1, false);


--
-- Name: strapi_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_migrations_id_seq', 1, false);


--
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_migrations_internal_id_seq', 7, true);


--
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_release_actions_id_seq', 1, false);


--
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_release_actions_release_lnk_id_seq', 1, false);


--
-- Name: strapi_releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_releases_id_seq', 1, false);


--
-- Name: strapi_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_sessions_id_seq', 27, true);


--
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_id_seq', 1, false);


--
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_token_lnk_id_seq', 1, false);


--
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_tokens_id_seq', 1, false);


--
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- Name: strapi_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_id_seq', 1, false);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_permissions_lnk_id_seq', 1, false);


--
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_workflow_lnk_id_seq', 1, false);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.team_members_id_seq', 24, true);


--
-- Name: testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.testimonials_id_seq', 24, true);


--
-- Name: trusted_companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.trusted_companies_id_seq', 16, true);


--
-- Name: up_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_permissions_id_seq', 16, true);


--
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_permissions_role_lnk_id_seq', 17, true);


--
-- Name: up_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_roles_id_seq', 5, true);


--
-- Name: up_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_users_id_seq', 11, true);


--
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_users_role_lnk_id_seq', 11, true);


--
-- Name: upload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.upload_folders_id_seq', 1, false);


--
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.upload_folders_parent_lnk_id_seq', 1, false);


--
-- Name: user_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.user_audit_logs_id_seq', 1, false);


--
-- Name: user_audit_logs_target_demo_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.user_audit_logs_target_demo_lnk_id_seq', 1, false);


--
-- Name: user_audit_logs_user_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.user_audit_logs_user_lnk_id_seq', 1, false);


--
-- Name: values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.values_id_seq', 24, true);


--
-- Name: about_pages about_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.about_pages
    ADD CONSTRAINT about_pages_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: case_studies_pages case_studies_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies_pages
    ADD CONSTRAINT case_studies_pages_pkey PRIMARY KEY (id);


--
-- Name: case_studies case_studies_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies
    ADD CONSTRAINT case_studies_pkey PRIMARY KEY (id);


--
-- Name: contact_pages contact_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.contact_pages
    ADD CONSTRAINT contact_pages_pkey PRIMARY KEY (id);


--
-- Name: demos_pages demos_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos_pages
    ADD CONSTRAINT demos_pages_pkey PRIMARY KEY (id);


--
-- Name: demos demos_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos
    ADD CONSTRAINT demos_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: features features_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- Name: homepages homepages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.homepages
    ADD CONSTRAINT homepages_pkey PRIMARY KEY (id);


--
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- Name: industries_pages industries_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries_pages
    ADD CONSTRAINT industries_pages_pkey PRIMARY KEY (id);


--
-- Name: industries industries_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_pkey PRIMARY KEY (id);


--
-- Name: nav_items nav_items_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.nav_items
    ADD CONSTRAINT nav_items_pkey PRIMARY KEY (id);


--
-- Name: partners partners_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_pkey PRIMARY KEY (id);


--
-- Name: pricing_pages pricing_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_pages
    ADD CONSTRAINT pricing_pages_pkey PRIMARY KEY (id);


--
-- Name: pricing_plans pricing_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_plans
    ADD CONSTRAINT pricing_plans_pkey PRIMARY KEY (id);


--
-- Name: process_steps process_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.process_steps
    ADD CONSTRAINT process_steps_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: solutions_pages solutions_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions_pages
    ADD CONSTRAINT solutions_pages_pkey PRIMARY KEY (id);


--
-- Name: solutions solutions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_pkey PRIMARY KEY (id);


--
-- Name: stats stats_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_pkey PRIMARY KEY (id);


--
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_audit_logs strapi_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_uq UNIQUE (audit_log_id, user_id);


--
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: trusted_companies trusted_companies_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.trusted_companies
    ADD CONSTRAINT trusted_companies_pkey PRIMARY KEY (id);


--
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs user_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs
    ADD CONSTRAINT user_audit_logs_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs_target_demo_lnk user_audit_logs_target_demo_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_target_demo_lnk
    ADD CONSTRAINT user_audit_logs_target_demo_lnk_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs_target_demo_lnk user_audit_logs_target_demo_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_target_demo_lnk
    ADD CONSTRAINT user_audit_logs_target_demo_lnk_uq UNIQUE (user_audit_log_id, demo_id);


--
-- Name: user_audit_logs_user_lnk user_audit_logs_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_user_lnk
    ADD CONSTRAINT user_audit_logs_user_lnk_pkey PRIMARY KEY (id);


--
-- Name: user_audit_logs_user_lnk user_audit_logs_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_user_lnk
    ADD CONSTRAINT user_audit_logs_user_lnk_uq UNIQUE (user_audit_log_id, user_id);


--
-- Name: values values_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public."values"
    ADD CONSTRAINT values_pkey PRIMARY KEY (id);


--
-- Name: about_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX about_pages_created_by_id_fk ON public.about_pages USING btree (created_by_id);


--
-- Name: about_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX about_pages_documents_idx ON public.about_pages USING btree (document_id, locale, published_at);


--
-- Name: about_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX about_pages_updated_by_id_fk ON public.about_pages USING btree (updated_by_id);


--
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- Name: case_studies_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_created_by_id_fk ON public.case_studies USING btree (created_by_id);


--
-- Name: case_studies_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_documents_idx ON public.case_studies USING btree (document_id, locale, published_at);


--
-- Name: case_studies_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_pages_created_by_id_fk ON public.case_studies_pages USING btree (created_by_id);


--
-- Name: case_studies_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_pages_documents_idx ON public.case_studies_pages USING btree (document_id, locale, published_at);


--
-- Name: case_studies_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_pages_updated_by_id_fk ON public.case_studies_pages USING btree (updated_by_id);


--
-- Name: case_studies_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX case_studies_updated_by_id_fk ON public.case_studies USING btree (updated_by_id);


--
-- Name: contact_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX contact_pages_created_by_id_fk ON public.contact_pages USING btree (created_by_id);


--
-- Name: contact_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX contact_pages_documents_idx ON public.contact_pages USING btree (document_id, locale, published_at);


--
-- Name: contact_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX contact_pages_updated_by_id_fk ON public.contact_pages USING btree (updated_by_id);


--
-- Name: demos_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_created_by_id_fk ON public.demos USING btree (created_by_id);


--
-- Name: demos_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_documents_idx ON public.demos USING btree (document_id, locale, published_at);


--
-- Name: demos_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_pages_created_by_id_fk ON public.demos_pages USING btree (created_by_id);


--
-- Name: demos_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_pages_documents_idx ON public.demos_pages USING btree (document_id, locale, published_at);


--
-- Name: demos_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_pages_updated_by_id_fk ON public.demos_pages USING btree (updated_by_id);


--
-- Name: demos_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX demos_updated_by_id_fk ON public.demos USING btree (updated_by_id);


--
-- Name: faqs_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX faqs_created_by_id_fk ON public.faqs USING btree (created_by_id);


--
-- Name: faqs_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX faqs_documents_idx ON public.faqs USING btree (document_id, locale, published_at);


--
-- Name: faqs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX faqs_updated_by_id_fk ON public.faqs USING btree (updated_by_id);


--
-- Name: features_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX features_created_by_id_fk ON public.features USING btree (created_by_id);


--
-- Name: features_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX features_documents_idx ON public.features USING btree (document_id, locale, published_at);


--
-- Name: features_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX features_updated_by_id_fk ON public.features USING btree (updated_by_id);


--
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- Name: homepages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX homepages_created_by_id_fk ON public.homepages USING btree (created_by_id);


--
-- Name: homepages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX homepages_documents_idx ON public.homepages USING btree (document_id, locale, published_at);


--
-- Name: homepages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX homepages_updated_by_id_fk ON public.homepages USING btree (updated_by_id);


--
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- Name: industries_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_created_by_id_fk ON public.industries USING btree (created_by_id);


--
-- Name: industries_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_documents_idx ON public.industries USING btree (document_id, locale, published_at);


--
-- Name: industries_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_pages_created_by_id_fk ON public.industries_pages USING btree (created_by_id);


--
-- Name: industries_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_pages_documents_idx ON public.industries_pages USING btree (document_id, locale, published_at);


--
-- Name: industries_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_pages_updated_by_id_fk ON public.industries_pages USING btree (updated_by_id);


--
-- Name: industries_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX industries_updated_by_id_fk ON public.industries USING btree (updated_by_id);


--
-- Name: nav_items_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX nav_items_created_by_id_fk ON public.nav_items USING btree (created_by_id);


--
-- Name: nav_items_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX nav_items_documents_idx ON public.nav_items USING btree (document_id, locale, published_at);


--
-- Name: nav_items_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX nav_items_updated_by_id_fk ON public.nav_items USING btree (updated_by_id);


--
-- Name: partners_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX partners_created_by_id_fk ON public.partners USING btree (created_by_id);


--
-- Name: partners_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX partners_documents_idx ON public.partners USING btree (document_id, locale, published_at);


--
-- Name: partners_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX partners_updated_by_id_fk ON public.partners USING btree (updated_by_id);


--
-- Name: pricing_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_pages_created_by_id_fk ON public.pricing_pages USING btree (created_by_id);


--
-- Name: pricing_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_pages_documents_idx ON public.pricing_pages USING btree (document_id, locale, published_at);


--
-- Name: pricing_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_pages_updated_by_id_fk ON public.pricing_pages USING btree (updated_by_id);


--
-- Name: pricing_plans_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_plans_created_by_id_fk ON public.pricing_plans USING btree (created_by_id);


--
-- Name: pricing_plans_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_plans_documents_idx ON public.pricing_plans USING btree (document_id, locale, published_at);


--
-- Name: pricing_plans_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX pricing_plans_updated_by_id_fk ON public.pricing_plans USING btree (updated_by_id);


--
-- Name: process_steps_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX process_steps_created_by_id_fk ON public.process_steps USING btree (created_by_id);


--
-- Name: process_steps_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX process_steps_documents_idx ON public.process_steps USING btree (document_id, locale, published_at);


--
-- Name: process_steps_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX process_steps_updated_by_id_fk ON public.process_steps USING btree (updated_by_id);


--
-- Name: site_settings_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX site_settings_created_by_id_fk ON public.site_settings USING btree (created_by_id);


--
-- Name: site_settings_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX site_settings_documents_idx ON public.site_settings USING btree (document_id, locale, published_at);


--
-- Name: site_settings_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX site_settings_updated_by_id_fk ON public.site_settings USING btree (updated_by_id);


--
-- Name: solutions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_created_by_id_fk ON public.solutions USING btree (created_by_id);


--
-- Name: solutions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_documents_idx ON public.solutions USING btree (document_id, locale, published_at);


--
-- Name: solutions_pages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_pages_created_by_id_fk ON public.solutions_pages USING btree (created_by_id);


--
-- Name: solutions_pages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_pages_documents_idx ON public.solutions_pages USING btree (document_id, locale, published_at);


--
-- Name: solutions_pages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_pages_updated_by_id_fk ON public.solutions_pages USING btree (updated_by_id);


--
-- Name: solutions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX solutions_updated_by_id_fk ON public.solutions USING btree (updated_by_id);


--
-- Name: stats_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX stats_created_by_id_fk ON public.stats USING btree (created_by_id);


--
-- Name: stats_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX stats_documents_idx ON public.stats USING btree (document_id, locale, published_at);


--
-- Name: stats_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX stats_updated_by_id_fk ON public.stats USING btree (updated_by_id);


--
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- Name: strapi_audit_logs_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_created_by_id_fk ON public.strapi_audit_logs USING btree (created_by_id);


--
-- Name: strapi_audit_logs_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_documents_idx ON public.strapi_audit_logs USING btree (document_id, locale, published_at);


--
-- Name: strapi_audit_logs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_updated_by_id_fk ON public.strapi_audit_logs USING btree (updated_by_id);


--
-- Name: strapi_audit_logs_user_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_user_lnk_fk ON public.strapi_audit_logs_user_lnk USING btree (audit_log_id);


--
-- Name: strapi_audit_logs_user_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_user_lnk_ifk ON public.strapi_audit_logs_user_lnk USING btree (user_id);


--
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- Name: team_members_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX team_members_created_by_id_fk ON public.team_members USING btree (created_by_id);


--
-- Name: team_members_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX team_members_documents_idx ON public.team_members USING btree (document_id, locale, published_at);


--
-- Name: team_members_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX team_members_updated_by_id_fk ON public.team_members USING btree (updated_by_id);


--
-- Name: testimonials_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX testimonials_created_by_id_fk ON public.testimonials USING btree (created_by_id);


--
-- Name: testimonials_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX testimonials_documents_idx ON public.testimonials USING btree (document_id, locale, published_at);


--
-- Name: testimonials_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX testimonials_updated_by_id_fk ON public.testimonials USING btree (updated_by_id);


--
-- Name: trusted_companies_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX trusted_companies_created_by_id_fk ON public.trusted_companies USING btree (created_by_id);


--
-- Name: trusted_companies_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX trusted_companies_documents_idx ON public.trusted_companies USING btree (document_id, locale, published_at);


--
-- Name: trusted_companies_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX trusted_companies_updated_by_id_fk ON public.trusted_companies USING btree (updated_by_id);


--
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- Name: user_audit_logs_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_created_by_id_fk ON public.user_audit_logs USING btree (created_by_id);


--
-- Name: user_audit_logs_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_documents_idx ON public.user_audit_logs USING btree (document_id, locale, published_at);


--
-- Name: user_audit_logs_target_demo_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_target_demo_lnk_fk ON public.user_audit_logs_target_demo_lnk USING btree (user_audit_log_id);


--
-- Name: user_audit_logs_target_demo_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_target_demo_lnk_ifk ON public.user_audit_logs_target_demo_lnk USING btree (demo_id);


--
-- Name: user_audit_logs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_updated_by_id_fk ON public.user_audit_logs USING btree (updated_by_id);


--
-- Name: user_audit_logs_user_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_user_lnk_fk ON public.user_audit_logs_user_lnk USING btree (user_audit_log_id);


--
-- Name: user_audit_logs_user_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX user_audit_logs_user_lnk_ifk ON public.user_audit_logs_user_lnk USING btree (user_id);


--
-- Name: values_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX values_created_by_id_fk ON public."values" USING btree (created_by_id);


--
-- Name: values_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX values_documents_idx ON public."values" USING btree (document_id, locale, published_at);


--
-- Name: values_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX values_updated_by_id_fk ON public."values" USING btree (updated_by_id);


--
-- Name: about_pages about_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.about_pages
    ADD CONSTRAINT about_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: about_pages about_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.about_pages
    ADD CONSTRAINT about_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: case_studies case_studies_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies
    ADD CONSTRAINT case_studies_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: case_studies_pages case_studies_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies_pages
    ADD CONSTRAINT case_studies_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: case_studies_pages case_studies_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies_pages
    ADD CONSTRAINT case_studies_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: case_studies case_studies_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.case_studies
    ADD CONSTRAINT case_studies_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: contact_pages contact_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.contact_pages
    ADD CONSTRAINT contact_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: contact_pages contact_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.contact_pages
    ADD CONSTRAINT contact_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: demos demos_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos
    ADD CONSTRAINT demos_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: demos_pages demos_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos_pages
    ADD CONSTRAINT demos_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: demos_pages demos_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos_pages
    ADD CONSTRAINT demos_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: demos demos_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.demos
    ADD CONSTRAINT demos_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: faqs faqs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: faqs faqs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: features features_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: features features_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.features
    ADD CONSTRAINT features_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: homepages homepages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.homepages
    ADD CONSTRAINT homepages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: homepages homepages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.homepages
    ADD CONSTRAINT homepages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: industries industries_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: industries_pages industries_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries_pages
    ADD CONSTRAINT industries_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: industries_pages industries_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries_pages
    ADD CONSTRAINT industries_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: industries industries_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.industries
    ADD CONSTRAINT industries_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: nav_items nav_items_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.nav_items
    ADD CONSTRAINT nav_items_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: nav_items nav_items_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.nav_items
    ADD CONSTRAINT nav_items_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: partners partners_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: partners partners_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.partners
    ADD CONSTRAINT partners_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pricing_pages pricing_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_pages
    ADD CONSTRAINT pricing_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pricing_pages pricing_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_pages
    ADD CONSTRAINT pricing_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pricing_plans pricing_plans_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_plans
    ADD CONSTRAINT pricing_plans_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: pricing_plans pricing_plans_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.pricing_plans
    ADD CONSTRAINT pricing_plans_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: process_steps process_steps_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.process_steps
    ADD CONSTRAINT process_steps_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: process_steps process_steps_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.process_steps
    ADD CONSTRAINT process_steps_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: site_settings site_settings_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: site_settings site_settings_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: solutions solutions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: solutions_pages solutions_pages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions_pages
    ADD CONSTRAINT solutions_pages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: solutions_pages solutions_pages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions_pages
    ADD CONSTRAINT solutions_pages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: solutions solutions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.solutions
    ADD CONSTRAINT solutions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: stats stats_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: stats stats_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.stats
    ADD CONSTRAINT stats_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_audit_logs strapi_audit_logs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_audit_logs strapi_audit_logs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_fk FOREIGN KEY (audit_log_id) REFERENCES public.strapi_audit_logs(id) ON DELETE CASCADE;


--
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: team_members team_members_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: team_members team_members_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: testimonials testimonials_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: testimonials testimonials_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: trusted_companies trusted_companies_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.trusted_companies
    ADD CONSTRAINT trusted_companies_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: trusted_companies trusted_companies_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.trusted_companies
    ADD CONSTRAINT trusted_companies_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: user_audit_logs user_audit_logs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs
    ADD CONSTRAINT user_audit_logs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: user_audit_logs_target_demo_lnk user_audit_logs_target_demo_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_target_demo_lnk
    ADD CONSTRAINT user_audit_logs_target_demo_lnk_fk FOREIGN KEY (user_audit_log_id) REFERENCES public.user_audit_logs(id) ON DELETE CASCADE;


--
-- Name: user_audit_logs_target_demo_lnk user_audit_logs_target_demo_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_target_demo_lnk
    ADD CONSTRAINT user_audit_logs_target_demo_lnk_ifk FOREIGN KEY (demo_id) REFERENCES public.demos(id) ON DELETE CASCADE;


--
-- Name: user_audit_logs user_audit_logs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs
    ADD CONSTRAINT user_audit_logs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: user_audit_logs_user_lnk user_audit_logs_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_user_lnk
    ADD CONSTRAINT user_audit_logs_user_lnk_fk FOREIGN KEY (user_audit_log_id) REFERENCES public.user_audit_logs(id) ON DELETE CASCADE;


--
-- Name: user_audit_logs_user_lnk user_audit_logs_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.user_audit_logs_user_lnk
    ADD CONSTRAINT user_audit_logs_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- Name: values values_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public."values"
    ADD CONSTRAINT values_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: values values_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public."values"
    ADD CONSTRAINT values_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO arabiq;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO arabiq;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO arabiq;


--
-- PostgreSQL database dump complete
--

\unrestrict 6OPkjHiCzpQtr6F6JdVuF2zKcE0k2iNC81bAhbRS2HF38mNmfDGFDneGlQkqAfX

