--
-- PostgreSQL database dump
--

\restrict P655QeJ6aAWakh07DVgbU1eoNCO1JSamkq4wImUucZCGwlsNM4sgBCbJnzc36Ix

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

-- Started on 2026-01-31 22:01:07 EET

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 242 (class 1259 OID 106148)
-- Name: admin_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    action_parameters jsonb,
    subject character varying(255),
    properties jsonb,
    conditions jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_permissions OWNER TO arabiq;

--
-- TOC entry 241 (class 1259 OID 106147)
-- Name: admin_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_id_seq OWNER TO arabiq;

--
-- TOC entry 3994 (class 0 OID 0)
-- Dependencies: 241
-- Name: admin_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_permissions_id_seq OWNED BY public.admin_permissions.id;


--
-- TOC entry 286 (class 1259 OID 106400)
-- Name: admin_permissions_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.admin_permissions_role_lnk OWNER TO arabiq;

--
-- TOC entry 285 (class 1259 OID 106399)
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 3995 (class 0 OID 0)
-- Dependencies: 285
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_permissions_role_lnk_id_seq OWNED BY public.admin_permissions_role_lnk.id;


--
-- TOC entry 246 (class 1259 OID 106172)
-- Name: admin_roles; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    description character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_roles OWNER TO arabiq;

--
-- TOC entry 245 (class 1259 OID 106171)
-- Name: admin_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_roles_id_seq OWNER TO arabiq;

--
-- TOC entry 3996 (class 0 OID 0)
-- Dependencies: 245
-- Name: admin_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_roles_id_seq OWNED BY public.admin_roles.id;


--
-- TOC entry 244 (class 1259 OID 106160)
-- Name: admin_users; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_users (
    id integer NOT NULL,
    document_id character varying(255),
    firstname character varying(255),
    lastname character varying(255),
    username character varying(255),
    email character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    registration_token character varying(255),
    is_active boolean,
    blocked boolean,
    prefered_language character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.admin_users OWNER TO arabiq;

--
-- TOC entry 243 (class 1259 OID 106159)
-- Name: admin_users_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_id_seq OWNER TO arabiq;

--
-- TOC entry 3997 (class 0 OID 0)
-- Dependencies: 243
-- Name: admin_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_users_id_seq OWNED BY public.admin_users.id;


--
-- TOC entry 288 (class 1259 OID 106412)
-- Name: admin_users_roles_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.admin_users_roles_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    role_ord double precision,
    user_ord double precision
);


ALTER TABLE public.admin_users_roles_lnk OWNER TO arabiq;

--
-- TOC entry 287 (class 1259 OID 106411)
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.admin_users_roles_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 3998 (class 0 OID 0)
-- Dependencies: 287
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.admin_users_roles_lnk_id_seq OWNED BY public.admin_users_roles_lnk.id;


--
-- TOC entry 222 (class 1259 OID 106018)
-- Name: files; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    alternative_text text,
    caption text,
    width integer,
    height integer,
    formats jsonb,
    hash character varying(255),
    ext character varying(255),
    mime character varying(255),
    size numeric(10,2),
    url text,
    preview_url text,
    provider character varying(255),
    provider_metadata jsonb,
    folder_path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.files OWNER TO arabiq;

--
-- TOC entry 270 (class 1259 OID 106305)
-- Name: files_folder_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files_folder_lnk (
    id integer NOT NULL,
    file_id integer,
    folder_id integer,
    file_ord double precision
);


ALTER TABLE public.files_folder_lnk OWNER TO arabiq;

--
-- TOC entry 269 (class 1259 OID 106304)
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_folder_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_folder_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 3999 (class 0 OID 0)
-- Dependencies: 269
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_folder_lnk_id_seq OWNED BY public.files_folder_lnk.id;


--
-- TOC entry 221 (class 1259 OID 106017)
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO arabiq;

--
-- TOC entry 4000 (class 0 OID 0)
-- Dependencies: 221
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- TOC entry 268 (class 1259 OID 106293)
-- Name: files_related_mph; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.files_related_mph (
    id integer NOT NULL,
    file_id integer,
    related_id integer,
    related_type character varying(255),
    field character varying(255),
    "order" double precision
);


ALTER TABLE public.files_related_mph OWNER TO arabiq;

--
-- TOC entry 267 (class 1259 OID 106292)
-- Name: files_related_mph_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.files_related_mph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_related_mph_id_seq OWNER TO arabiq;

--
-- TOC entry 4001 (class 0 OID 0)
-- Dependencies: 267
-- Name: files_related_mph_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.files_related_mph_id_seq OWNED BY public.files_related_mph.id;


--
-- TOC entry 226 (class 1259 OID 106052)
-- Name: i18n_locale; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.i18n_locale (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    code character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.i18n_locale OWNER TO arabiq;

--
-- TOC entry 225 (class 1259 OID 106051)
-- Name: i18n_locale_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.i18n_locale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.i18n_locale_id_seq OWNER TO arabiq;

--
-- TOC entry 4002 (class 0 OID 0)
-- Dependencies: 225
-- Name: i18n_locale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.i18n_locale_id_seq OWNED BY public.i18n_locale.id;


--
-- TOC entry 266 (class 1259 OID 106284)
-- Name: strapi_ai_localization_jobs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_ai_localization_jobs (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255) NOT NULL,
    source_locale character varying(255) NOT NULL,
    target_locales jsonb NOT NULL,
    status character varying(255) NOT NULL,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone
);


ALTER TABLE public.strapi_ai_localization_jobs OWNER TO arabiq;

--
-- TOC entry 265 (class 1259 OID 106283)
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_ai_localization_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNER TO arabiq;

--
-- TOC entry 4003 (class 0 OID 0)
-- Dependencies: 265
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_ai_localization_jobs_id_seq OWNED BY public.strapi_ai_localization_jobs.id;


--
-- TOC entry 250 (class 1259 OID 106196)
-- Name: strapi_api_token_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_token_permissions OWNER TO arabiq;

--
-- TOC entry 249 (class 1259 OID 106195)
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNER TO arabiq;

--
-- TOC entry 4004 (class 0 OID 0)
-- Dependencies: 249
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_token_permissions_id_seq OWNED BY public.strapi_api_token_permissions.id;


--
-- TOC entry 290 (class 1259 OID 106425)
-- Name: strapi_api_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_token_permissions_token_lnk (
    id integer NOT NULL,
    api_token_permission_id integer,
    api_token_id integer,
    api_token_permission_ord double precision
);


ALTER TABLE public.strapi_api_token_permissions_token_lnk OWNER TO arabiq;

--
-- TOC entry 289 (class 1259 OID 106424)
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4005 (class 0 OID 0)
-- Dependencies: 289
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_token_permissions_token_lnk_id_seq OWNED BY public.strapi_api_token_permissions_token_lnk.id;


--
-- TOC entry 248 (class 1259 OID 106184)
-- Name: strapi_api_tokens; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_api_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    access_key character varying(255),
    encrypted_key text,
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_api_tokens OWNER TO arabiq;

--
-- TOC entry 247 (class 1259 OID 106183)
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_api_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNER TO arabiq;

--
-- TOC entry 4006 (class 0 OID 0)
-- Dependencies: 247
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_api_tokens_id_seq OWNED BY public.strapi_api_tokens.id;


--
-- TOC entry 258 (class 1259 OID 106244)
-- Name: strapi_audit_logs; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_audit_logs (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    date timestamp(6) without time zone,
    payload jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_audit_logs OWNER TO arabiq;

--
-- TOC entry 257 (class 1259 OID 106243)
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_audit_logs_id_seq OWNER TO arabiq;

--
-- TOC entry 4007 (class 0 OID 0)
-- Dependencies: 257
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_audit_logs_id_seq OWNED BY public.strapi_audit_logs.id;


--
-- TOC entry 294 (class 1259 OID 106449)
-- Name: strapi_audit_logs_user_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_audit_logs_user_lnk (
    id integer NOT NULL,
    audit_log_id integer,
    user_id integer
);


ALTER TABLE public.strapi_audit_logs_user_lnk OWNER TO arabiq;

--
-- TOC entry 293 (class 1259 OID 106448)
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_audit_logs_user_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_audit_logs_user_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4008 (class 0 OID 0)
-- Dependencies: 293
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_audit_logs_user_lnk_id_seq OWNED BY public.strapi_audit_logs_user_lnk.id;


--
-- TOC entry 260 (class 1259 OID 106256)
-- Name: strapi_core_store_settings; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_core_store_settings (
    id integer NOT NULL,
    key character varying(255),
    value text,
    type character varying(255),
    environment character varying(255),
    tag character varying(255)
);


ALTER TABLE public.strapi_core_store_settings OWNER TO arabiq;

--
-- TOC entry 259 (class 1259 OID 106255)
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_core_store_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNER TO arabiq;

--
-- TOC entry 4009 (class 0 OID 0)
-- Dependencies: 259
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_core_store_settings_id_seq OWNED BY public.strapi_core_store_settings.id;


--
-- TOC entry 220 (class 1259 OID 106009)
-- Name: strapi_database_schema; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_database_schema (
    id integer NOT NULL,
    schema json,
    "time" timestamp without time zone,
    hash character varying(255)
);


ALTER TABLE public.strapi_database_schema OWNER TO arabiq;

--
-- TOC entry 219 (class 1259 OID 106008)
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_database_schema_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_database_schema_id_seq OWNER TO arabiq;

--
-- TOC entry 4010 (class 0 OID 0)
-- Dependencies: 219
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_database_schema_id_seq OWNED BY public.strapi_database_schema.id;


--
-- TOC entry 264 (class 1259 OID 106274)
-- Name: strapi_history_versions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_history_versions (
    id integer NOT NULL,
    content_type character varying(255) NOT NULL,
    related_document_id character varying(255),
    locale character varying(255),
    status character varying(255),
    data jsonb,
    schema jsonb,
    created_at timestamp(6) without time zone,
    created_by_id integer
);


ALTER TABLE public.strapi_history_versions OWNER TO arabiq;

--
-- TOC entry 263 (class 1259 OID 106273)
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_history_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_history_versions_id_seq OWNER TO arabiq;

--
-- TOC entry 4011 (class 0 OID 0)
-- Dependencies: 263
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_history_versions_id_seq OWNED BY public.strapi_history_versions.id;


--
-- TOC entry 216 (class 1259 OID 105995)
-- Name: strapi_migrations; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_migrations (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations OWNER TO arabiq;

--
-- TOC entry 215 (class 1259 OID 105994)
-- Name: strapi_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_id_seq OWNER TO arabiq;

--
-- TOC entry 4012 (class 0 OID 0)
-- Dependencies: 215
-- Name: strapi_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_migrations_id_seq OWNED BY public.strapi_migrations.id;


--
-- TOC entry 218 (class 1259 OID 106002)
-- Name: strapi_migrations_internal; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_migrations_internal (
    id integer NOT NULL,
    name character varying(255),
    "time" timestamp without time zone
);


ALTER TABLE public.strapi_migrations_internal OWNER TO arabiq;

--
-- TOC entry 217 (class 1259 OID 105999)
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_migrations_internal_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNER TO arabiq;

--
-- TOC entry 4013 (class 0 OID 0)
-- Dependencies: 217
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_migrations_internal_id_seq OWNED BY public.strapi_migrations_internal.id;


--
-- TOC entry 230 (class 1259 OID 106076)
-- Name: strapi_release_actions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_release_actions (
    id integer NOT NULL,
    document_id character varying(255),
    type character varying(255),
    content_type character varying(255),
    entry_document_id character varying(255),
    locale character varying(255),
    is_entry_valid boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer
);


ALTER TABLE public.strapi_release_actions OWNER TO arabiq;

--
-- TOC entry 229 (class 1259 OID 106075)
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_release_actions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_id_seq OWNER TO arabiq;

--
-- TOC entry 4014 (class 0 OID 0)
-- Dependencies: 229
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_release_actions_id_seq OWNED BY public.strapi_release_actions.id;


--
-- TOC entry 274 (class 1259 OID 106329)
-- Name: strapi_release_actions_release_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_release_actions_release_lnk (
    id integer NOT NULL,
    release_action_id integer,
    release_id integer,
    release_action_ord double precision
);


ALTER TABLE public.strapi_release_actions_release_lnk OWNER TO arabiq;

--
-- TOC entry 273 (class 1259 OID 106328)
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_release_actions_release_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4015 (class 0 OID 0)
-- Dependencies: 273
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_release_actions_release_lnk_id_seq OWNED BY public.strapi_release_actions_release_lnk.id;


--
-- TOC entry 228 (class 1259 OID 106064)
-- Name: strapi_releases; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_releases (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    released_at timestamp(6) without time zone,
    scheduled_at timestamp(6) without time zone,
    timezone character varying(255),
    status character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_releases OWNER TO arabiq;

--
-- TOC entry 227 (class 1259 OID 106063)
-- Name: strapi_releases_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_releases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_releases_id_seq OWNER TO arabiq;

--
-- TOC entry 4016 (class 0 OID 0)
-- Dependencies: 227
-- Name: strapi_releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_releases_id_seq OWNED BY public.strapi_releases.id;


--
-- TOC entry 256 (class 1259 OID 106232)
-- Name: strapi_sessions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_sessions (
    id integer NOT NULL,
    document_id character varying(255),
    user_id character varying(255),
    session_id character varying(255),
    child_id character varying(255),
    device_id character varying(255),
    origin character varying(255),
    expires_at timestamp(6) without time zone,
    absolute_expires_at timestamp(6) without time zone,
    status character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_sessions OWNER TO arabiq;

--
-- TOC entry 255 (class 1259 OID 106231)
-- Name: strapi_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_sessions_id_seq OWNER TO arabiq;

--
-- TOC entry 4017 (class 0 OID 0)
-- Dependencies: 255
-- Name: strapi_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_sessions_id_seq OWNED BY public.strapi_sessions.id;


--
-- TOC entry 254 (class 1259 OID 106220)
-- Name: strapi_transfer_token_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_token_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_token_permissions OWNER TO arabiq;

--
-- TOC entry 253 (class 1259 OID 106219)
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNER TO arabiq;

--
-- TOC entry 4018 (class 0 OID 0)
-- Dependencies: 253
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_id_seq OWNED BY public.strapi_transfer_token_permissions.id;


--
-- TOC entry 292 (class 1259 OID 106437)
-- Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_token_permissions_token_lnk (
    id integer NOT NULL,
    transfer_token_permission_id integer,
    transfer_token_id integer,
    transfer_token_permission_ord double precision
);


ALTER TABLE public.strapi_transfer_token_permissions_token_lnk OWNER TO arabiq;

--
-- TOC entry 291 (class 1259 OID 106436)
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4019 (class 0 OID 0)
-- Dependencies: 291
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_token_permissions_token_lnk_id_seq OWNED BY public.strapi_transfer_token_permissions_token_lnk.id;


--
-- TOC entry 252 (class 1259 OID 106208)
-- Name: strapi_transfer_tokens; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_transfer_tokens (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    access_key character varying(255),
    last_used_at timestamp(6) without time zone,
    expires_at timestamp(6) without time zone,
    lifespan bigint,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_transfer_tokens OWNER TO arabiq;

--
-- TOC entry 251 (class 1259 OID 106207)
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_transfer_tokens_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNER TO arabiq;

--
-- TOC entry 4020 (class 0 OID 0)
-- Dependencies: 251
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_transfer_tokens_id_seq OWNED BY public.strapi_transfer_tokens.id;


--
-- TOC entry 262 (class 1259 OID 106265)
-- Name: strapi_webhooks; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_webhooks (
    id integer NOT NULL,
    name character varying(255),
    url text,
    headers jsonb,
    events jsonb,
    enabled boolean
);


ALTER TABLE public.strapi_webhooks OWNER TO arabiq;

--
-- TOC entry 261 (class 1259 OID 106264)
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_webhooks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_webhooks_id_seq OWNER TO arabiq;

--
-- TOC entry 4021 (class 0 OID 0)
-- Dependencies: 261
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_webhooks_id_seq OWNED BY public.strapi_webhooks.id;


--
-- TOC entry 232 (class 1259 OID 106088)
-- Name: strapi_workflows; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    content_types jsonb,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows OWNER TO arabiq;

--
-- TOC entry 231 (class 1259 OID 106087)
-- Name: strapi_workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_id_seq OWNER TO arabiq;

--
-- TOC entry 4022 (class 0 OID 0)
-- Dependencies: 231
-- Name: strapi_workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_id_seq OWNED BY public.strapi_workflows.id;


--
-- TOC entry 276 (class 1259 OID 106341)
-- Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stage_required_to_publish_lnk (
    id integer NOT NULL,
    workflow_id integer,
    workflow_stage_id integer
);


ALTER TABLE public.strapi_workflows_stage_required_to_publish_lnk OWNER TO arabiq;

--
-- TOC entry 275 (class 1259 OID 106340)
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4023 (class 0 OID 0)
-- Dependencies: 275
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stage_required_to_publish_lnk_id_seq OWNED BY public.strapi_workflows_stage_required_to_publish_lnk.id;


--
-- TOC entry 234 (class 1259 OID 106100)
-- Name: strapi_workflows_stages; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    color character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.strapi_workflows_stages OWNER TO arabiq;

--
-- TOC entry 233 (class 1259 OID 106099)
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNER TO arabiq;

--
-- TOC entry 4024 (class 0 OID 0)
-- Dependencies: 233
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_id_seq OWNED BY public.strapi_workflows_stages.id;


--
-- TOC entry 280 (class 1259 OID 106364)
-- Name: strapi_workflows_stages_permissions_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages_permissions_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    permission_id integer,
    permission_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_permissions_lnk OWNER TO arabiq;

--
-- TOC entry 279 (class 1259 OID 106363)
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4025 (class 0 OID 0)
-- Dependencies: 279
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_permissions_lnk_id_seq OWNED BY public.strapi_workflows_stages_permissions_lnk.id;


--
-- TOC entry 278 (class 1259 OID 106352)
-- Name: strapi_workflows_stages_workflow_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.strapi_workflows_stages_workflow_lnk (
    id integer NOT NULL,
    workflow_stage_id integer,
    workflow_id integer,
    workflow_stage_ord double precision
);


ALTER TABLE public.strapi_workflows_stages_workflow_lnk OWNER TO arabiq;

--
-- TOC entry 277 (class 1259 OID 106351)
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4026 (class 0 OID 0)
-- Dependencies: 277
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.strapi_workflows_stages_workflow_lnk_id_seq OWNED BY public.strapi_workflows_stages_workflow_lnk.id;


--
-- TOC entry 236 (class 1259 OID 106112)
-- Name: up_permissions; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_permissions (
    id integer NOT NULL,
    document_id character varying(255),
    action character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_permissions OWNER TO arabiq;

--
-- TOC entry 235 (class 1259 OID 106111)
-- Name: up_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_id_seq OWNER TO arabiq;

--
-- TOC entry 4027 (class 0 OID 0)
-- Dependencies: 235
-- Name: up_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_permissions_id_seq OWNED BY public.up_permissions.id;


--
-- TOC entry 282 (class 1259 OID 106376)
-- Name: up_permissions_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_permissions_role_lnk (
    id integer NOT NULL,
    permission_id integer,
    role_id integer,
    permission_ord double precision
);


ALTER TABLE public.up_permissions_role_lnk OWNER TO arabiq;

--
-- TOC entry 281 (class 1259 OID 106375)
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_permissions_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4028 (class 0 OID 0)
-- Dependencies: 281
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_permissions_role_lnk_id_seq OWNED BY public.up_permissions_role_lnk.id;


--
-- TOC entry 238 (class 1259 OID 106124)
-- Name: up_roles; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_roles (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    description character varying(255),
    type character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.up_roles OWNER TO arabiq;

--
-- TOC entry 237 (class 1259 OID 106123)
-- Name: up_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_roles_id_seq OWNER TO arabiq;

--
-- TOC entry 4029 (class 0 OID 0)
-- Dependencies: 237
-- Name: up_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_roles_id_seq OWNED BY public.up_roles.id;


--
-- TOC entry 240 (class 1259 OID 106136)
-- Name: up_users; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_users (
    id integer NOT NULL,
    document_id character varying(255),
    username character varying(255),
    email character varying(255),
    provider character varying(255),
    password character varying(255),
    reset_password_token character varying(255),
    confirmation_token character varying(255),
    confirmed boolean,
    blocked boolean,
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255),
    phone character varying(255),
    country character varying(255),
    company character varying(255),
    sales_contact_allowed boolean,
    display_name character varying(255),
    account_status character varying(255),
    last_login timestamp without time zone,
    confirmation_token_expires_at timestamp without time zone
);


ALTER TABLE public.up_users OWNER TO arabiq;

--
-- TOC entry 239 (class 1259 OID 106135)
-- Name: up_users_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_id_seq OWNER TO arabiq;

--
-- TOC entry 4030 (class 0 OID 0)
-- Dependencies: 239
-- Name: up_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_users_id_seq OWNED BY public.up_users.id;


--
-- TOC entry 284 (class 1259 OID 106388)
-- Name: up_users_role_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.up_users_role_lnk (
    id integer NOT NULL,
    user_id integer,
    role_id integer,
    user_ord double precision
);


ALTER TABLE public.up_users_role_lnk OWNER TO arabiq;

--
-- TOC entry 283 (class 1259 OID 106387)
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.up_users_role_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4031 (class 0 OID 0)
-- Dependencies: 283
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.up_users_role_lnk_id_seq OWNED BY public.up_users_role_lnk.id;


--
-- TOC entry 224 (class 1259 OID 106036)
-- Name: upload_folders; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.upload_folders (
    id integer NOT NULL,
    document_id character varying(255),
    name character varying(255),
    path_id integer,
    path character varying(255),
    created_at timestamp(6) without time zone,
    updated_at timestamp(6) without time zone,
    published_at timestamp(6) without time zone,
    created_by_id integer,
    updated_by_id integer,
    locale character varying(255)
);


ALTER TABLE public.upload_folders OWNER TO arabiq;

--
-- TOC entry 223 (class 1259 OID 106035)
-- Name: upload_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.upload_folders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_id_seq OWNER TO arabiq;

--
-- TOC entry 4032 (class 0 OID 0)
-- Dependencies: 223
-- Name: upload_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.upload_folders_id_seq OWNED BY public.upload_folders.id;


--
-- TOC entry 272 (class 1259 OID 106317)
-- Name: upload_folders_parent_lnk; Type: TABLE; Schema: public; Owner: arabiq
--

CREATE TABLE public.upload_folders_parent_lnk (
    id integer NOT NULL,
    folder_id integer,
    inv_folder_id integer,
    folder_ord double precision
);


ALTER TABLE public.upload_folders_parent_lnk OWNER TO arabiq;

--
-- TOC entry 271 (class 1259 OID 106316)
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE; Schema: public; Owner: arabiq
--

CREATE SEQUENCE public.upload_folders_parent_lnk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNER TO arabiq;

--
-- TOC entry 4033 (class 0 OID 0)
-- Dependencies: 271
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: arabiq
--

ALTER SEQUENCE public.upload_folders_parent_lnk_id_seq OWNED BY public.upload_folders_parent_lnk.id;


--
-- TOC entry 3457 (class 2604 OID 106151)
-- Name: admin_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_id_seq'::regclass);


--
-- TOC entry 3479 (class 2604 OID 106403)
-- Name: admin_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_permissions_role_lnk_id_seq'::regclass);


--
-- TOC entry 3459 (class 2604 OID 106175)
-- Name: admin_roles id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles ALTER COLUMN id SET DEFAULT nextval('public.admin_roles_id_seq'::regclass);


--
-- TOC entry 3458 (class 2604 OID 106163)
-- Name: admin_users id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users ALTER COLUMN id SET DEFAULT nextval('public.admin_users_id_seq'::regclass);


--
-- TOC entry 3480 (class 2604 OID 106415)
-- Name: admin_users_roles_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk ALTER COLUMN id SET DEFAULT nextval('public.admin_users_roles_lnk_id_seq'::regclass);


--
-- TOC entry 3447 (class 2604 OID 106021)
-- Name: files id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- TOC entry 3471 (class 2604 OID 106308)
-- Name: files_folder_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk ALTER COLUMN id SET DEFAULT nextval('public.files_folder_lnk_id_seq'::regclass);


--
-- TOC entry 3470 (class 2604 OID 106296)
-- Name: files_related_mph id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph ALTER COLUMN id SET DEFAULT nextval('public.files_related_mph_id_seq'::regclass);


--
-- TOC entry 3449 (class 2604 OID 106055)
-- Name: i18n_locale id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale ALTER COLUMN id SET DEFAULT nextval('public.i18n_locale_id_seq'::regclass);


--
-- TOC entry 3469 (class 2604 OID 106287)
-- Name: strapi_ai_localization_jobs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs ALTER COLUMN id SET DEFAULT nextval('public.strapi_ai_localization_jobs_id_seq'::regclass);


--
-- TOC entry 3461 (class 2604 OID 106199)
-- Name: strapi_api_token_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_id_seq'::regclass);


--
-- TOC entry 3481 (class 2604 OID 106428)
-- Name: strapi_api_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_token_permissions_token_lnk_id_seq'::regclass);


--
-- TOC entry 3460 (class 2604 OID 106187)
-- Name: strapi_api_tokens id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_api_tokens_id_seq'::regclass);


--
-- TOC entry 3465 (class 2604 OID 106247)
-- Name: strapi_audit_logs id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs ALTER COLUMN id SET DEFAULT nextval('public.strapi_audit_logs_id_seq'::regclass);


--
-- TOC entry 3483 (class 2604 OID 106452)
-- Name: strapi_audit_logs_user_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_audit_logs_user_lnk_id_seq'::regclass);


--
-- TOC entry 3466 (class 2604 OID 106259)
-- Name: strapi_core_store_settings id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_core_store_settings ALTER COLUMN id SET DEFAULT nextval('public.strapi_core_store_settings_id_seq'::regclass);


--
-- TOC entry 3446 (class 2604 OID 106012)
-- Name: strapi_database_schema id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_database_schema ALTER COLUMN id SET DEFAULT nextval('public.strapi_database_schema_id_seq'::regclass);


--
-- TOC entry 3468 (class 2604 OID 106277)
-- Name: strapi_history_versions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions ALTER COLUMN id SET DEFAULT nextval('public.strapi_history_versions_id_seq'::regclass);


--
-- TOC entry 3444 (class 2604 OID 105998)
-- Name: strapi_migrations id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_id_seq'::regclass);


--
-- TOC entry 3445 (class 2604 OID 106005)
-- Name: strapi_migrations_internal id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations_internal ALTER COLUMN id SET DEFAULT nextval('public.strapi_migrations_internal_id_seq'::regclass);


--
-- TOC entry 3451 (class 2604 OID 106079)
-- Name: strapi_release_actions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_id_seq'::regclass);


--
-- TOC entry 3473 (class 2604 OID 106332)
-- Name: strapi_release_actions_release_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_release_actions_release_lnk_id_seq'::regclass);


--
-- TOC entry 3450 (class 2604 OID 106067)
-- Name: strapi_releases id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases ALTER COLUMN id SET DEFAULT nextval('public.strapi_releases_id_seq'::regclass);


--
-- TOC entry 3464 (class 2604 OID 106235)
-- Name: strapi_sessions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions ALTER COLUMN id SET DEFAULT nextval('public.strapi_sessions_id_seq'::regclass);


--
-- TOC entry 3463 (class 2604 OID 106223)
-- Name: strapi_transfer_token_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_id_seq'::regclass);


--
-- TOC entry 3482 (class 2604 OID 106440)
-- Name: strapi_transfer_token_permissions_token_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_token_permissions_token_lnk_id_seq'::regclass);


--
-- TOC entry 3462 (class 2604 OID 106211)
-- Name: strapi_transfer_tokens id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens ALTER COLUMN id SET DEFAULT nextval('public.strapi_transfer_tokens_id_seq'::regclass);


--
-- TOC entry 3467 (class 2604 OID 106268)
-- Name: strapi_webhooks id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_webhooks ALTER COLUMN id SET DEFAULT nextval('public.strapi_webhooks_id_seq'::regclass);


--
-- TOC entry 3452 (class 2604 OID 106091)
-- Name: strapi_workflows id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_id_seq'::regclass);


--
-- TOC entry 3474 (class 2604 OID 106344)
-- Name: strapi_workflows_stage_required_to_publish_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq'::regclass);


--
-- TOC entry 3453 (class 2604 OID 106103)
-- Name: strapi_workflows_stages id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_id_seq'::regclass);


--
-- TOC entry 3476 (class 2604 OID 106367)
-- Name: strapi_workflows_stages_permissions_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_permissions_lnk_id_seq'::regclass);


--
-- TOC entry 3475 (class 2604 OID 106355)
-- Name: strapi_workflows_stages_workflow_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk ALTER COLUMN id SET DEFAULT nextval('public.strapi_workflows_stages_workflow_lnk_id_seq'::regclass);


--
-- TOC entry 3454 (class 2604 OID 106115)
-- Name: up_permissions id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_id_seq'::regclass);


--
-- TOC entry 3477 (class 2604 OID 106379)
-- Name: up_permissions_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_permissions_role_lnk_id_seq'::regclass);


--
-- TOC entry 3455 (class 2604 OID 106127)
-- Name: up_roles id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles ALTER COLUMN id SET DEFAULT nextval('public.up_roles_id_seq'::regclass);


--
-- TOC entry 3456 (class 2604 OID 106139)
-- Name: up_users id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users ALTER COLUMN id SET DEFAULT nextval('public.up_users_id_seq'::regclass);


--
-- TOC entry 3478 (class 2604 OID 106391)
-- Name: up_users_role_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk ALTER COLUMN id SET DEFAULT nextval('public.up_users_role_lnk_id_seq'::regclass);


--
-- TOC entry 3448 (class 2604 OID 106039)
-- Name: upload_folders id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_id_seq'::regclass);


--
-- TOC entry 3472 (class 2604 OID 106320)
-- Name: upload_folders_parent_lnk id; Type: DEFAULT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk ALTER COLUMN id SET DEFAULT nextval('public.upload_folders_parent_lnk_id_seq'::regclass);


--
-- TOC entry 3935 (class 0 OID 106148)
-- Dependencies: 242
-- Data for Name: admin_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_permissions (id, document_id, action, action_parameters, subject, properties, conditions, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	izp6tnrs2rv535f4nvk3axfp	plugin::upload.read	{}	\N	{}	[]	2026-01-29 17:06:07.779	2026-01-29 17:06:07.779	2026-01-29 17:06:07.779	\N	\N	\N
2	al6yzaq8hgd3phwo1jtg2dsa	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:07.79	2026-01-29 17:06:07.79	2026-01-29 17:06:07.79	\N	\N	\N
3	ux8jw44qtw553c3my50ehiqf	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:07.8	2026-01-29 17:06:07.8	2026-01-29 17:06:07.8	\N	\N	\N
4	gct3fh42ruj926oezgvjjay0	plugin::upload.assets.update	{}	\N	{}	[]	2026-01-29 17:06:07.809	2026-01-29 17:06:07.809	2026-01-29 17:06:07.809	\N	\N	\N
5	soalf3svooid38mludbggprw	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:07.819	2026-01-29 17:06:07.819	2026-01-29 17:06:07.819	\N	\N	\N
6	n4m7y52h5nbnh2j3yzu5u6bi	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:07.83	2026-01-29 17:06:07.83	2026-01-29 17:06:07.83	\N	\N	\N
7	oeixn75rtpes1i0t2wrs53lu	plugin::upload.read	{}	\N	{}	["admin::is-creator"]	2026-01-29 17:06:07.842	2026-01-29 17:06:07.842	2026-01-29 17:06:07.842	\N	\N	\N
8	fiwkr78j74duo7e91fsg61vm	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:07.855	2026-01-29 17:06:07.855	2026-01-29 17:06:07.855	\N	\N	\N
9	u4qpwhoo9zfjaoada447ivgg	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:07.867	2026-01-29 17:06:07.867	2026-01-29 17:06:07.867	\N	\N	\N
10	d9scw8nepl1jn34xij2rrjuo	plugin::upload.assets.update	{}	\N	{}	["admin::is-creator"]	2026-01-29 17:06:07.878	2026-01-29 17:06:07.878	2026-01-29 17:06:07.878	\N	\N	\N
11	rjcwqagkn3y8neg0fmn735v7	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:07.887	2026-01-29 17:06:07.887	2026-01-29 17:06:07.887	\N	\N	\N
12	q0fl894v0ct5l4xtv2u9c4oe	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:07.899	2026-01-29 17:06:07.899	2026-01-29 17:06:07.899	\N	\N	\N
16	od5htowq2z60lfqhsoou4ryq	plugin::content-manager.explorer.delete	{}	plugin::users-permissions.user	{}	[]	2026-01-29 17:06:07.959	2026-01-29 17:06:07.959	2026-01-29 17:06:07.959	\N	\N	\N
17	qqfqyl3higzs74et5uybi5md	plugin::content-manager.explorer.publish	{}	plugin::users-permissions.user	{}	[]	2026-01-29 17:06:07.97	2026-01-29 17:06:07.97	2026-01-29 17:06:07.97	\N	\N	\N
18	v7yj7s3fzmjs5b1vsdidiquf	plugin::content-releases.read	{}	\N	{}	[]	2026-01-29 17:06:07.98	2026-01-29 17:06:07.98	2026-01-29 17:06:07.98	\N	\N	\N
19	seddlvcb93dmimtuity26ifm	plugin::content-releases.create	{}	\N	{}	[]	2026-01-29 17:06:07.992	2026-01-29 17:06:07.992	2026-01-29 17:06:07.992	\N	\N	\N
20	ek1zw3xf2c8uszyqm53ik46i	plugin::content-releases.update	{}	\N	{}	[]	2026-01-29 17:06:08.001	2026-01-29 17:06:08.001	2026-01-29 17:06:08.001	\N	\N	\N
21	xccn46mqvby4ul2o4ig89o6t	plugin::content-releases.delete	{}	\N	{}	[]	2026-01-29 17:06:08.013	2026-01-29 17:06:08.013	2026-01-29 17:06:08.013	\N	\N	\N
22	xekcgaq3qj3cohzhvfcvagzl	plugin::content-releases.publish	{}	\N	{}	[]	2026-01-29 17:06:08.026	2026-01-29 17:06:08.026	2026-01-29 17:06:08.026	\N	\N	\N
23	v5oa6w1lotjkf5luskz0ro3o	plugin::content-releases.delete-action	{}	\N	{}	[]	2026-01-29 17:06:08.037	2026-01-29 17:06:08.037	2026-01-29 17:06:08.037	\N	\N	\N
24	ucifjxw381f5ppvdhcgt81cb	plugin::content-releases.create-action	{}	\N	{}	[]	2026-01-29 17:06:08.048	2026-01-29 17:06:08.048	2026-01-29 17:06:08.048	\N	\N	\N
25	qbs4775ue72msdvfa392xkh9	plugin::content-releases.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.059	2026-01-29 17:06:08.059	2026-01-29 17:06:08.059	\N	\N	\N
26	prq8ti151pqfz6cc6vq3js49	plugin::content-releases.settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.068	2026-01-29 17:06:08.068	2026-01-29 17:06:08.068	\N	\N	\N
27	fzlnjc1b94j59i9ntmvxd312	plugin::content-manager.single-types.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.077	2026-01-29 17:06:08.077	2026-01-29 17:06:08.077	\N	\N	\N
28	mrw35wjwak5b4bdsh0aq053i	plugin::content-manager.collection-types.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.086	2026-01-29 17:06:08.086	2026-01-29 17:06:08.086	\N	\N	\N
29	v9geh26mrv3fivo4q0rb7b5q	plugin::content-manager.components.configure-layout	{}	\N	{}	[]	2026-01-29 17:06:08.096	2026-01-29 17:06:08.096	2026-01-29 17:06:08.096	\N	\N	\N
30	p3uwbnil51rzgxic88i499fv	plugin::content-type-builder.read	{}	\N	{}	[]	2026-01-29 17:06:08.107	2026-01-29 17:06:08.107	2026-01-29 17:06:08.107	\N	\N	\N
31	fcyhus8hczpprjkn68pjjx4a	plugin::email.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.116	2026-01-29 17:06:08.116	2026-01-29 17:06:08.116	\N	\N	\N
32	h4xb4uy1ef6qjwd7ld2g93th	plugin::upload.read	{}	\N	{}	[]	2026-01-29 17:06:08.128	2026-01-29 17:06:08.128	2026-01-29 17:06:08.128	\N	\N	\N
33	jgetb6xr867ecvt79o8t319r	plugin::upload.assets.create	{}	\N	{}	[]	2026-01-29 17:06:08.137	2026-01-29 17:06:08.137	2026-01-29 17:06:08.137	\N	\N	\N
34	ocqispu40x63bspajczjcyqh	plugin::upload.assets.update	{}	\N	{}	[]	2026-01-29 17:06:08.146	2026-01-29 17:06:08.146	2026-01-29 17:06:08.146	\N	\N	\N
35	qhvfrhb5rr3aybiydicdnulo	plugin::upload.assets.download	{}	\N	{}	[]	2026-01-29 17:06:08.157	2026-01-29 17:06:08.157	2026-01-29 17:06:08.157	\N	\N	\N
36	r6xi8x1t4p1y4zn78np55pqp	plugin::upload.assets.copy-link	{}	\N	{}	[]	2026-01-29 17:06:08.166	2026-01-29 17:06:08.166	2026-01-29 17:06:08.166	\N	\N	\N
37	wsh6vsvtokoa3rzabk49decc	plugin::upload.configure-view	{}	\N	{}	[]	2026-01-29 17:06:08.176	2026-01-29 17:06:08.176	2026-01-29 17:06:08.176	\N	\N	\N
38	gff3p1ulaffug3kmbkn4778w	plugin::upload.settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.185	2026-01-29 17:06:08.185	2026-01-29 17:06:08.186	\N	\N	\N
39	amfi69epn3818wx0y3om6tqk	plugin::i18n.locale.create	{}	\N	{}	[]	2026-01-29 17:06:08.199	2026-01-29 17:06:08.199	2026-01-29 17:06:08.199	\N	\N	\N
40	ecguy48rj1zr1o7y7c22q81s	plugin::i18n.locale.read	{}	\N	{}	[]	2026-01-29 17:06:08.209	2026-01-29 17:06:08.209	2026-01-29 17:06:08.209	\N	\N	\N
41	jhfis9jccroyoxjixz18h1q9	plugin::i18n.locale.update	{}	\N	{}	[]	2026-01-29 17:06:08.217	2026-01-29 17:06:08.217	2026-01-29 17:06:08.217	\N	\N	\N
42	xgi5iya8fvvseqn6j0d167yh	plugin::i18n.locale.delete	{}	\N	{}	[]	2026-01-29 17:06:08.226	2026-01-29 17:06:08.226	2026-01-29 17:06:08.227	\N	\N	\N
43	pot730pher7lirmf80q8z4vj	plugin::users-permissions.roles.create	{}	\N	{}	[]	2026-01-29 17:06:08.236	2026-01-29 17:06:08.236	2026-01-29 17:06:08.236	\N	\N	\N
44	pu1gsmmedc64xzgxq0bnvhnb	plugin::users-permissions.roles.read	{}	\N	{}	[]	2026-01-29 17:06:08.245	2026-01-29 17:06:08.245	2026-01-29 17:06:08.245	\N	\N	\N
45	ogmpy8yx0fictkfgfe2o4qb2	plugin::users-permissions.roles.update	{}	\N	{}	[]	2026-01-29 17:06:08.26	2026-01-29 17:06:08.26	2026-01-29 17:06:08.26	\N	\N	\N
46	awwe4hb0uoppf40jyxm4id0j	plugin::users-permissions.roles.delete	{}	\N	{}	[]	2026-01-29 17:06:08.269	2026-01-29 17:06:08.269	2026-01-29 17:06:08.269	\N	\N	\N
47	gvlizriiswnxspf4086p0q5h	plugin::users-permissions.providers.read	{}	\N	{}	[]	2026-01-29 17:06:08.279	2026-01-29 17:06:08.279	2026-01-29 17:06:08.279	\N	\N	\N
48	sc3olw11pcbo2lgpu8jl0w90	plugin::users-permissions.providers.update	{}	\N	{}	[]	2026-01-29 17:06:08.291	2026-01-29 17:06:08.291	2026-01-29 17:06:08.291	\N	\N	\N
49	uioi711d682dxp8tkqxymlh5	plugin::users-permissions.email-templates.read	{}	\N	{}	[]	2026-01-29 17:06:08.301	2026-01-29 17:06:08.301	2026-01-29 17:06:08.301	\N	\N	\N
50	c83n9dhtww693bi8bgwbcdwz	plugin::users-permissions.email-templates.update	{}	\N	{}	[]	2026-01-29 17:06:08.31	2026-01-29 17:06:08.31	2026-01-29 17:06:08.31	\N	\N	\N
51	g4o7c358u08n9ei10jn00e5l	plugin::users-permissions.advanced-settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.318	2026-01-29 17:06:08.318	2026-01-29 17:06:08.318	\N	\N	\N
52	z7lblyolv1tqz0awf7aruv39	plugin::users-permissions.advanced-settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.326	2026-01-29 17:06:08.326	2026-01-29 17:06:08.326	\N	\N	\N
53	x0b45iyo0at61pypj86prekv	admin::provider-login.read	{}	\N	{}	[]	2026-01-29 17:06:08.335	2026-01-29 17:06:08.335	2026-01-29 17:06:08.335	\N	\N	\N
54	vh7zmk9e8j1alpp2csemd9yx	admin::provider-login.update	{}	\N	{}	[]	2026-01-29 17:06:08.344	2026-01-29 17:06:08.344	2026-01-29 17:06:08.345	\N	\N	\N
55	tpwq1gfop87wwdqmhevf8crq	admin::marketplace.read	{}	\N	{}	[]	2026-01-29 17:06:08.354	2026-01-29 17:06:08.354	2026-01-29 17:06:08.354	\N	\N	\N
56	jlneooynrnb9zo19pzfu880o	admin::webhooks.create	{}	\N	{}	[]	2026-01-29 17:06:08.366	2026-01-29 17:06:08.366	2026-01-29 17:06:08.366	\N	\N	\N
57	wwiphnxzvhsf7vmgu4dkwe27	admin::webhooks.read	{}	\N	{}	[]	2026-01-29 17:06:08.377	2026-01-29 17:06:08.377	2026-01-29 17:06:08.377	\N	\N	\N
58	om1jy44phkyd5tqd0n214w1l	admin::webhooks.update	{}	\N	{}	[]	2026-01-29 17:06:08.386	2026-01-29 17:06:08.386	2026-01-29 17:06:08.387	\N	\N	\N
59	g260ugrov60c6on3j1tz67yi	admin::webhooks.delete	{}	\N	{}	[]	2026-01-29 17:06:08.396	2026-01-29 17:06:08.396	2026-01-29 17:06:08.396	\N	\N	\N
60	fqdu0rn2hxkvkvpmb33cy87g	admin::users.create	{}	\N	{}	[]	2026-01-29 17:06:08.405	2026-01-29 17:06:08.405	2026-01-29 17:06:08.406	\N	\N	\N
61	j19csikzyid75mmimd0oc1oq	admin::users.read	{}	\N	{}	[]	2026-01-29 17:06:08.414	2026-01-29 17:06:08.414	2026-01-29 17:06:08.415	\N	\N	\N
62	duvpr92wus6585bkpk6uqq5l	admin::users.update	{}	\N	{}	[]	2026-01-29 17:06:08.432	2026-01-29 17:06:08.432	2026-01-29 17:06:08.432	\N	\N	\N
63	toruapj34xhp7ipr7lperu0g	admin::users.delete	{}	\N	{}	[]	2026-01-29 17:06:08.445	2026-01-29 17:06:08.445	2026-01-29 17:06:08.446	\N	\N	\N
64	sppm844antalzft9fwlut8j5	admin::roles.create	{}	\N	{}	[]	2026-01-29 17:06:08.456	2026-01-29 17:06:08.456	2026-01-29 17:06:08.456	\N	\N	\N
65	lqeyoq5okfp546jlwhl4zhh8	admin::roles.read	{}	\N	{}	[]	2026-01-29 17:06:08.468	2026-01-29 17:06:08.468	2026-01-29 17:06:08.468	\N	\N	\N
66	oxl3m9rkv1bx42xq1glrje98	admin::roles.update	{}	\N	{}	[]	2026-01-29 17:06:08.479	2026-01-29 17:06:08.479	2026-01-29 17:06:08.479	\N	\N	\N
67	docbysryzsufid1zt31xl0hs	admin::roles.delete	{}	\N	{}	[]	2026-01-29 17:06:08.491	2026-01-29 17:06:08.491	2026-01-29 17:06:08.491	\N	\N	\N
68	muosuqy1otyjpuj77yt9uha9	admin::api-tokens.access	{}	\N	{}	[]	2026-01-29 17:06:08.501	2026-01-29 17:06:08.501	2026-01-29 17:06:08.501	\N	\N	\N
69	z4mv0uzc2rdt962m5jyo6tns	admin::api-tokens.create	{}	\N	{}	[]	2026-01-29 17:06:08.512	2026-01-29 17:06:08.512	2026-01-29 17:06:08.512	\N	\N	\N
70	ahl6g1d7ocb9xzm6l6c0i4n0	admin::api-tokens.read	{}	\N	{}	[]	2026-01-29 17:06:08.522	2026-01-29 17:06:08.522	2026-01-29 17:06:08.522	\N	\N	\N
71	kzzx4105euv9s5bjhiy5l97s	admin::api-tokens.update	{}	\N	{}	[]	2026-01-29 17:06:08.531	2026-01-29 17:06:08.531	2026-01-29 17:06:08.532	\N	\N	\N
72	wyl3ox196dy1etpjme660prm	admin::api-tokens.regenerate	{}	\N	{}	[]	2026-01-29 17:06:08.54	2026-01-29 17:06:08.54	2026-01-29 17:06:08.541	\N	\N	\N
73	y0d7kd7o16jj444md3o11n5m	admin::api-tokens.delete	{}	\N	{}	[]	2026-01-29 17:06:08.551	2026-01-29 17:06:08.551	2026-01-29 17:06:08.552	\N	\N	\N
74	qq9a6v96haviqgbwdayn1ex6	admin::project-settings.update	{}	\N	{}	[]	2026-01-29 17:06:08.562	2026-01-29 17:06:08.562	2026-01-29 17:06:08.562	\N	\N	\N
75	f567xbdt933z63cz8k43c13j	admin::project-settings.read	{}	\N	{}	[]	2026-01-29 17:06:08.571	2026-01-29 17:06:08.571	2026-01-29 17:06:08.571	\N	\N	\N
76	tgaqzh4738nf85w9qy3fgih9	admin::transfer.tokens.access	{}	\N	{}	[]	2026-01-29 17:06:08.582	2026-01-29 17:06:08.582	2026-01-29 17:06:08.582	\N	\N	\N
77	ufvn1cbpgucl84uotjiwvtp4	admin::transfer.tokens.create	{}	\N	{}	[]	2026-01-29 17:06:08.591	2026-01-29 17:06:08.591	2026-01-29 17:06:08.591	\N	\N	\N
78	nfs4n9cowptjjl4z6qknpmt9	admin::transfer.tokens.read	{}	\N	{}	[]	2026-01-29 17:06:08.6	2026-01-29 17:06:08.6	2026-01-29 17:06:08.6	\N	\N	\N
79	ddnkn90akh26bzicv1tl3co1	admin::transfer.tokens.update	{}	\N	{}	[]	2026-01-29 17:06:08.61	2026-01-29 17:06:08.61	2026-01-29 17:06:08.61	\N	\N	\N
80	wtsu6uak50q49ns6jed0yzys	admin::transfer.tokens.regenerate	{}	\N	{}	[]	2026-01-29 17:06:08.62	2026-01-29 17:06:08.62	2026-01-29 17:06:08.62	\N	\N	\N
81	m9ltlbyq69rc1mbrejqdme3m	admin::transfer.tokens.delete	{}	\N	{}	[]	2026-01-29 17:06:08.628	2026-01-29 17:06:08.628	2026-01-29 17:06:08.629	\N	\N	\N
242	e95dp7eqn40n0o9fk2fbcyoi	plugin::content-manager.explorer.create	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.874	2026-01-29 18:15:40.874	2026-01-29 18:15:40.874	\N	\N	\N
243	cxnws3bso9ggd6g8xy0sqfec	plugin::content-manager.explorer.create	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.887	2026-01-29 18:15:40.887	2026-01-29 18:15:40.887	\N	\N	\N
244	f04d5soin62pqkrcctc708m5	plugin::content-manager.explorer.create	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.897	2026-01-29 18:15:40.897	2026-01-29 18:15:40.897	\N	\N	\N
245	mjmwizikd7or6ydk3qy7p9q2	plugin::content-manager.explorer.create	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.907	2026-01-29 18:15:40.907	2026-01-29 18:15:40.907	\N	\N	\N
246	t7jc7vnyetw27hx35vhia2rc	plugin::content-manager.explorer.create	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.918	2026-01-29 18:15:40.918	2026-01-29 18:15:40.918	\N	\N	\N
247	r79kdfarjm7aat8af8un6wpz	plugin::content-manager.explorer.create	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.931	2026-01-29 18:15:40.931	2026-01-29 18:15:40.931	\N	\N	\N
248	f0g4uzcq7fb1ndowokudfugx	plugin::content-manager.explorer.create	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.947	2026-01-29 18:15:40.947	2026-01-29 18:15:40.948	\N	\N	\N
249	t469372m5k1u2pm5bjmewww7	plugin::content-manager.explorer.create	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.969	2026-01-29 18:15:40.969	2026-01-29 18:15:40.969	\N	\N	\N
250	pqw32ods8eds8dposq1sy297	plugin::content-manager.explorer.create	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:40.991	2026-01-29 18:15:40.991	2026-01-29 18:15:40.991	\N	\N	\N
251	eva8cluj7dtwfhzpi01czdgf	plugin::content-manager.explorer.create	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.01	2026-01-29 18:15:41.01	2026-01-29 18:15:41.011	\N	\N	\N
252	uw9mrrqmhw34rlzne0blbcmp	plugin::content-manager.explorer.create	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.025	2026-01-29 18:15:41.025	2026-01-29 18:15:41.025	\N	\N	\N
253	ejyg1sxidfl1y8gw3ge981a4	plugin::content-manager.explorer.create	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.042	2026-01-29 18:15:41.042	2026-01-29 18:15:41.043	\N	\N	\N
254	rqkyy2tn5l8pyq3g7z89dbx6	plugin::content-manager.explorer.create	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.064	2026-01-29 18:15:41.064	2026-01-29 18:15:41.064	\N	\N	\N
255	b1zynsj2ajwd9nrcozqmfuwc	plugin::content-manager.explorer.create	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.081	2026-01-29 18:15:41.081	2026-01-29 18:15:41.081	\N	\N	\N
256	ij89zqt0ny3fwjp3okypya2n	plugin::content-manager.explorer.create	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.096	2026-01-29 18:15:41.096	2026-01-29 18:15:41.097	\N	\N	\N
257	tlmv2jxrp8o567mp2jx3flhj	plugin::content-manager.explorer.create	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.11	2026-01-29 18:15:41.11	2026-01-29 18:15:41.11	\N	\N	\N
258	j5aukz0efl9d6pyubjl5xmct	plugin::content-manager.explorer.read	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.124	2026-01-29 18:15:41.124	2026-01-29 18:15:41.124	\N	\N	\N
259	mu18momhjk31hinirv174laq	plugin::content-manager.explorer.read	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.134	2026-01-29 18:15:41.134	2026-01-29 18:15:41.134	\N	\N	\N
260	yf4jyl3lhnxdinwdlgavqlf4	plugin::content-manager.explorer.read	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.143	2026-01-29 18:15:41.143	2026-01-29 18:15:41.143	\N	\N	\N
261	zg0g20jq9uhqyaipm72x4vvy	plugin::content-manager.explorer.read	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.153	2026-01-29 18:15:41.153	2026-01-29 18:15:41.153	\N	\N	\N
262	gakhpoma79lxphm9qklabdhb	plugin::content-manager.explorer.read	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.163	2026-01-29 18:15:41.163	2026-01-29 18:15:41.163	\N	\N	\N
263	oavkw3jpylfrottn6i7ko5k0	plugin::content-manager.explorer.read	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.172	2026-01-29 18:15:41.172	2026-01-29 18:15:41.172	\N	\N	\N
264	zsjdfo2z0oyct2mzf42816he	plugin::content-manager.explorer.read	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.183	2026-01-29 18:15:41.183	2026-01-29 18:15:41.183	\N	\N	\N
265	djc7ahowjlnrzcqeevonk5h1	plugin::content-manager.explorer.read	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.197	2026-01-29 18:15:41.197	2026-01-29 18:15:41.197	\N	\N	\N
266	dn55t1bpuusohtrd4bqzz86j	plugin::content-manager.explorer.read	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.21	2026-01-29 18:15:41.21	2026-01-29 18:15:41.211	\N	\N	\N
267	kr9vua3aeoevg1hjzl004lmx	plugin::content-manager.explorer.read	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.225	2026-01-29 18:15:41.225	2026-01-29 18:15:41.225	\N	\N	\N
268	wk1jkm71xbl1nbj4tmtt7fwo	plugin::content-manager.explorer.read	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.242	2026-01-29 18:15:41.242	2026-01-29 18:15:41.242	\N	\N	\N
269	fb6h61pvr5kxjm97xkdwnwku	plugin::content-manager.explorer.read	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.255	2026-01-29 18:15:41.255	2026-01-29 18:15:41.255	\N	\N	\N
270	bjmu4loht35a205u4xlbj2q1	plugin::content-manager.explorer.read	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.27	2026-01-29 18:15:41.27	2026-01-29 18:15:41.27	\N	\N	\N
271	hmgjxnkm8s0yhnn6f871ot0a	plugin::content-manager.explorer.read	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.28	2026-01-29 18:15:41.28	2026-01-29 18:15:41.28	\N	\N	\N
272	b6z45bby1z1kumgrzp9gjdnr	plugin::content-manager.explorer.read	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.289	2026-01-29 18:15:41.289	2026-01-29 18:15:41.29	\N	\N	\N
273	lr42y4qw2f6f23dijcfkhomz	plugin::content-manager.explorer.read	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.299	2026-01-29 18:15:41.299	2026-01-29 18:15:41.299	\N	\N	\N
274	kysiabmdswkr0k8ugedz25gp	plugin::content-manager.explorer.update	{}	api::about-page.about-page	{"fields": ["heroTitle", "heroSubtitle", "missionTitle", "missionText", "visionTitle", "visionText", "valuesTitle", "value1Title", "value1Text", "value2Title", "value2Text", "value3Title", "value3Text", "teamTitle", "teamSubtitle", "ctaTitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.308	2026-01-29 18:15:41.308	2026-01-29 18:15:41.308	\N	\N	\N
275	rwxb2hiyupt10lgr6r3a1nyh	plugin::content-manager.explorer.update	{}	api::case-study.case-study	{"fields": ["slug", "title", "client", "industry", "summary", "description", "body", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.318	2026-01-29 18:15:41.318	2026-01-29 18:15:41.318	\N	\N	\N
306	vxu7zbbkmxrmej96k57c4500	plugin::content-manager.explorer.publish	{}	api::about-page.about-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.699	2026-01-29 18:15:41.699	2026-01-29 18:15:41.699	\N	\N	\N
276	etid1ba4p45n9mc4yube68hv	plugin::content-manager.explorer.update	{}	api::contact-page.contact-page	{"fields": ["heroTitle", "heroSubtitle", "formTitle", "nameLabel", "emailLabel", "phoneLabel", "messageLabel", "submitButton", "infoTitle", "address", "email", "phone", "hoursTitle", "hoursText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.328	2026-01-29 18:15:41.328	2026-01-29 18:15:41.328	\N	\N	\N
277	c24ibbqboaoxhs03wq74g28r	plugin::content-manager.explorer.update	{}	api::demo.demo	{"fields": ["slug", "title", "demoType", "summary", "description", "body", "icon", "allowedRoles", "accessLevel"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.337	2026-01-29 18:15:41.337	2026-01-29 18:15:41.337	\N	\N	\N
278	bx98t7asitex3ydybehsw9yd	plugin::content-manager.explorer.update	{}	api::feature.feature	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.346	2026-01-29 18:15:41.346	2026-01-29 18:15:41.347	\N	\N	\N
279	gp14zgu1uyi95mrnn9wupqxi	plugin::content-manager.explorer.update	{}	api::homepage.homepage	{"fields": ["heroTitle", "heroSubtitle", "heroPrimaryCta", "heroSecondaryCta", "heroBadge", "trustAward", "trustGlobal", "trustFast", "showStatsSection", "showTrustedBySection", "trustedByTitle", "showHowItWorksSection", "howItWorksTitle", "howItWorksSubtitle", "showFeaturesSection", "featuresTitle", "featuresSubtitle", "showSolutionsSection", "solutionsTitle", "solutionsSubtitle", "showIndustriesSection", "industriesTitle", "industriesSubtitle", "showCaseStudiesSection", "caseStudiesTitle", "caseStudiesSubtitle", "showDemosSection", "demosTitle", "demosSubtitle", "showCtaSection", "ctaTitle", "ctaSubtitle", "ctaPrimaryButton", "ctaSecondaryButton"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.356	2026-01-29 18:15:41.356	2026-01-29 18:15:41.356	\N	\N	\N
280	b9prpmdx7xb07xy6li8hu5go	plugin::content-manager.explorer.update	{}	api::industry.industry	{"fields": ["slug", "title", "summary", "description", "body", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.367	2026-01-29 18:15:41.367	2026-01-29 18:15:41.368	\N	\N	\N
281	c0m6854hbbhosek0nikn926l	plugin::content-manager.explorer.update	{}	api::nav-item.nav-item	{"fields": ["label", "href", "location", "order", "isExternal"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.384	2026-01-29 18:15:41.384	2026-01-29 18:15:41.384	\N	\N	\N
282	o3oq9rmxfnub33v4xjx3hfgy	plugin::content-manager.explorer.update	{}	api::process-step.process-step	{"fields": ["step", "title", "description", "icon"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.397	2026-01-29 18:15:41.397	2026-01-29 18:15:41.397	\N	\N	\N
283	r02tgtil3otjq2x7qlom6e6c	plugin::content-manager.explorer.update	{}	api::site-setting.site-setting	{"fields": ["title", "description", "contactEmail", "contactPhone", "footerCompanyTitle", "footerProductsTitle", "footerResourcesTitle", "footerConnectTitle", "copyrightText", "loginButtonText"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.413	2026-01-29 18:15:41.413	2026-01-29 18:15:41.413	\N	\N	\N
284	hflwdj8gvmzmalbn84ly7bmk	plugin::content-manager.explorer.update	{}	api::solution.solution	{"fields": ["slug", "title", "summary", "description", "body", "icon", "allowedRoles"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.425	2026-01-29 18:15:41.425	2026-01-29 18:15:41.426	\N	\N	\N
285	y99thxikw3wc2yvscthyli3h	plugin::content-manager.explorer.update	{}	api::stat.stat	{"fields": ["value", "label", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.437	2026-01-29 18:15:41.437	2026-01-29 18:15:41.437	\N	\N	\N
286	wu1kkxkyoumik4r75t50mksh	plugin::content-manager.explorer.update	{}	api::team-member.team-member	{"fields": ["name", "position", "bio", "photo", "order", "linkedinUrl", "twitterUrl"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.448	2026-01-29 18:15:41.448	2026-01-29 18:15:41.448	\N	\N	\N
287	dmi8l0u5eg6x997st977uo2q	plugin::content-manager.explorer.update	{}	api::trusted-company.trusted-company	{"fields": ["name", "logo", "website", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.457	2026-01-29 18:15:41.457	2026-01-29 18:15:41.457	\N	\N	\N
288	up0top4w6fxfa01fzqij0qfp	plugin::content-manager.explorer.update	{}	api::user-audit-log.user-audit-log	{"fields": ["user", "action", "ipAddress", "userAgent", "targetDemo", "metadata", "success", "errorMessage"]}	[]	2026-01-29 18:15:41.468	2026-01-29 18:15:41.468	2026-01-29 18:15:41.468	\N	\N	\N
289	n8ixeua0ylsp5pbanzkidnqx	plugin::content-manager.explorer.update	{}	api::value.value	{"fields": ["title", "description", "icon", "order"], "locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.479	2026-01-29 18:15:41.479	2026-01-29 18:15:41.479	\N	\N	\N
290	clg2kn29dw7y2ue5josd38oz	plugin::content-manager.explorer.delete	{}	api::about-page.about-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.489	2026-01-29 18:15:41.489	2026-01-29 18:15:41.489	\N	\N	\N
291	cuqxf1lbhurdarzz1r8qfg8f	plugin::content-manager.explorer.delete	{}	api::case-study.case-study	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.501	2026-01-29 18:15:41.501	2026-01-29 18:15:41.501	\N	\N	\N
292	o4hridkz4r30k9k74pky2gbk	plugin::content-manager.explorer.delete	{}	api::contact-page.contact-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.516	2026-01-29 18:15:41.516	2026-01-29 18:15:41.516	\N	\N	\N
293	bf9jnhn52kj632v7pudttw6k	plugin::content-manager.explorer.delete	{}	api::demo.demo	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.528	2026-01-29 18:15:41.528	2026-01-29 18:15:41.528	\N	\N	\N
294	nf1l7f0mdoaz18rbiy46g382	plugin::content-manager.explorer.delete	{}	api::feature.feature	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.539	2026-01-29 18:15:41.539	2026-01-29 18:15:41.539	\N	\N	\N
295	xrhfj699xsgudx9wvz65yal8	plugin::content-manager.explorer.delete	{}	api::homepage.homepage	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.553	2026-01-29 18:15:41.553	2026-01-29 18:15:41.554	\N	\N	\N
296	d9kaahf5m3j3iwre8il722ta	plugin::content-manager.explorer.delete	{}	api::industry.industry	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.566	2026-01-29 18:15:41.566	2026-01-29 18:15:41.566	\N	\N	\N
297	vdznpag9kkc4jxvtd5u8y7xh	plugin::content-manager.explorer.delete	{}	api::nav-item.nav-item	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.579	2026-01-29 18:15:41.579	2026-01-29 18:15:41.579	\N	\N	\N
298	slg7j9qu10ffefetiqgccj9q	plugin::content-manager.explorer.delete	{}	api::process-step.process-step	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.59	2026-01-29 18:15:41.59	2026-01-29 18:15:41.59	\N	\N	\N
299	tmx2kjqke57r2mtdg6bykrxu	plugin::content-manager.explorer.delete	{}	api::site-setting.site-setting	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.602	2026-01-29 18:15:41.602	2026-01-29 18:15:41.603	\N	\N	\N
300	eoiybxbhowlqfn8hogfi2n9z	plugin::content-manager.explorer.delete	{}	api::solution.solution	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.617	2026-01-29 18:15:41.617	2026-01-29 18:15:41.617	\N	\N	\N
301	q9s12yknfupu1ei1wr6kmdah	plugin::content-manager.explorer.delete	{}	api::stat.stat	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.629	2026-01-29 18:15:41.629	2026-01-29 18:15:41.629	\N	\N	\N
302	xk8hfdqkgpfqy6j363z431jz	plugin::content-manager.explorer.delete	{}	api::team-member.team-member	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.641	2026-01-29 18:15:41.641	2026-01-29 18:15:41.641	\N	\N	\N
303	t3d5zxjzezn0kmo3cuzh9ubh	plugin::content-manager.explorer.delete	{}	api::trusted-company.trusted-company	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.658	2026-01-29 18:15:41.658	2026-01-29 18:15:41.659	\N	\N	\N
304	jfdzivlafn3blgk6dwpvpuix	plugin::content-manager.explorer.delete	{}	api::user-audit-log.user-audit-log	{}	[]	2026-01-29 18:15:41.67	2026-01-29 18:15:41.67	2026-01-29 18:15:41.67	\N	\N	\N
305	t7jsm8d2mu950fbm04cw75w5	plugin::content-manager.explorer.delete	{}	api::value.value	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.686	2026-01-29 18:15:41.686	2026-01-29 18:15:41.687	\N	\N	\N
307	hoqd2iap0m45hsy3q5gzh41l	plugin::content-manager.explorer.publish	{}	api::case-study.case-study	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.711	2026-01-29 18:15:41.711	2026-01-29 18:15:41.712	\N	\N	\N
308	szme4dgwm1j9ialahbpklvwa	plugin::content-manager.explorer.publish	{}	api::contact-page.contact-page	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.725	2026-01-29 18:15:41.725	2026-01-29 18:15:41.725	\N	\N	\N
309	slaa1rdnhekdtxdvxqpcd8hj	plugin::content-manager.explorer.publish	{}	api::demo.demo	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.739	2026-01-29 18:15:41.739	2026-01-29 18:15:41.739	\N	\N	\N
310	vusfuzp91jfphpxafiz1inpv	plugin::content-manager.explorer.publish	{}	api::feature.feature	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.753	2026-01-29 18:15:41.753	2026-01-29 18:15:41.753	\N	\N	\N
311	ct52eq3tk7btt6jkg8fgngcu	plugin::content-manager.explorer.publish	{}	api::homepage.homepage	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.765	2026-01-29 18:15:41.765	2026-01-29 18:15:41.765	\N	\N	\N
312	m7l92naunxwmnumtawgyghl6	plugin::content-manager.explorer.publish	{}	api::industry.industry	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.777	2026-01-29 18:15:41.777	2026-01-29 18:15:41.777	\N	\N	\N
313	udknctti756kmw6e6m2lnqmf	plugin::content-manager.explorer.publish	{}	api::nav-item.nav-item	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.794	2026-01-29 18:15:41.794	2026-01-29 18:15:41.794	\N	\N	\N
314	h29olcelzhz4yodr5jem4qc7	plugin::content-manager.explorer.publish	{}	api::process-step.process-step	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.809	2026-01-29 18:15:41.809	2026-01-29 18:15:41.81	\N	\N	\N
315	y7gy5zbrol8bxoft3b45v6d8	plugin::content-manager.explorer.publish	{}	api::site-setting.site-setting	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.825	2026-01-29 18:15:41.825	2026-01-29 18:15:41.825	\N	\N	\N
316	kzi1tyq6mqidfg7u7rvlvxfj	plugin::content-manager.explorer.publish	{}	api::solution.solution	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.839	2026-01-29 18:15:41.839	2026-01-29 18:15:41.84	\N	\N	\N
317	l865sua2rqmubiz1p5k2hb5p	plugin::content-manager.explorer.publish	{}	api::stat.stat	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.854	2026-01-29 18:15:41.854	2026-01-29 18:15:41.854	\N	\N	\N
318	xxsboeh5cpjylcdijyyb047h	plugin::content-manager.explorer.publish	{}	api::team-member.team-member	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.868	2026-01-29 18:15:41.868	2026-01-29 18:15:41.868	\N	\N	\N
319	gzrvyiwzr28kz95x8q0eprmv	plugin::content-manager.explorer.publish	{}	api::trusted-company.trusted-company	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.883	2026-01-29 18:15:41.883	2026-01-29 18:15:41.883	\N	\N	\N
320	tpbyfk34hlhr1yxl7rmyd4tz	plugin::content-manager.explorer.publish	{}	api::user-audit-log.user-audit-log	{}	[]	2026-01-29 18:15:41.897	2026-01-29 18:15:41.897	2026-01-29 18:15:41.897	\N	\N	\N
321	ic5xbnbp8i0gfw36o2hg1kkh	plugin::content-manager.explorer.publish	{}	api::value.value	{"locales": ["en", "ar"]}	[]	2026-01-29 18:15:41.914	2026-01-29 18:15:41.914	2026-01-29 18:15:41.914	\N	\N	\N
322	v6kfjtqxdfr5hdztvuvbi240	plugin::content-manager.explorer.create	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.476	2026-01-30 13:26:27.476	2026-01-30 13:26:27.477	\N	\N	\N
323	nb79ns36ng8ncqx4egkaypjv	plugin::content-manager.explorer.read	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.497	2026-01-30 13:26:27.497	2026-01-30 13:26:27.497	\N	\N	\N
324	alw1hp9fc04u1lcl5xuh7wek	plugin::content-manager.explorer.update	{}	api::faq.faq	{"fields": ["slug", "category", "order", "question", "answer"], "locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.506	2026-01-30 13:26:27.506	2026-01-30 13:26:27.507	\N	\N	\N
325	m348468gslb2miyxcdd5ns1b	plugin::content-manager.explorer.delete	{}	api::faq.faq	{"locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.516	2026-01-30 13:26:27.516	2026-01-30 13:26:27.516	\N	\N	\N
326	g6f84h0evcod4f449fvdjy7v	plugin::content-manager.explorer.publish	{}	api::faq.faq	{"locales": ["en", "ar"]}	[]	2026-01-30 13:26:27.526	2026-01-30 13:26:27.526	2026-01-30 13:26:27.526	\N	\N	\N
327	ixg9lq3113p0e4w07xx5v5e5	plugin::content-manager.explorer.create	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:13.99	2026-01-30 13:28:13.99	2026-01-30 13:28:13.991	\N	\N	\N
328	pjok6wgt2nt4iw5icp2es4zo	plugin::content-manager.explorer.create	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.001	2026-01-30 13:28:14.001	2026-01-30 13:28:14.001	\N	\N	\N
329	y6nqvrb1cwk0grr9mqbzvouj	plugin::content-manager.explorer.create	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.01	2026-01-30 13:28:14.01	2026-01-30 13:28:14.011	\N	\N	\N
330	epdyehbzhwjr36g65qyyo95g	plugin::content-manager.explorer.create	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.022	2026-01-30 13:28:14.022	2026-01-30 13:28:14.022	\N	\N	\N
331	kdl6hxoh2zd3aj817ifg24wv	plugin::content-manager.explorer.create	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.03	2026-01-30 13:28:14.03	2026-01-30 13:28:14.03	\N	\N	\N
332	qszvlc3p03oclivp9ss4ml9s	plugin::content-manager.explorer.create	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.04	2026-01-30 13:28:14.04	2026-01-30 13:28:14.04	\N	\N	\N
333	w526jsfrtpd14ye87vk3ilb9	plugin::content-manager.explorer.create	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.051	2026-01-30 13:28:14.051	2026-01-30 13:28:14.051	\N	\N	\N
334	zfgwux1sai66zhz0we014ngb	plugin::content-manager.explorer.create	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.062	2026-01-30 13:28:14.062	2026-01-30 13:28:14.062	\N	\N	\N
335	q0ilwk760s9np6n6z17c1ham	plugin::content-manager.explorer.read	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.071	2026-01-30 13:28:14.071	2026-01-30 13:28:14.071	\N	\N	\N
362	p86mgk78lgi30g30ji84prgb	plugin::content-manager.explorer.publish	{}	api::partner.partner	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.38	2026-01-30 13:28:14.38	2026-01-30 13:28:14.38	\N	\N	\N
336	qfwa3ztr63lfgarbfu4wjbnl	plugin::content-manager.explorer.read	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.081	2026-01-30 13:28:14.081	2026-01-30 13:28:14.081	\N	\N	\N
337	nho6llz83t88rtjo2lm8cj63	plugin::content-manager.explorer.read	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.091	2026-01-30 13:28:14.091	2026-01-30 13:28:14.092	\N	\N	\N
338	ftbfb06l0qmqzfp1j37xeznc	plugin::content-manager.explorer.read	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.101	2026-01-30 13:28:14.101	2026-01-30 13:28:14.102	\N	\N	\N
339	s8s5zgfkjam2osi9xcrp9c75	plugin::content-manager.explorer.read	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.11	2026-01-30 13:28:14.11	2026-01-30 13:28:14.11	\N	\N	\N
340	eqn2ep8pem0738x1ef8xiqvd	plugin::content-manager.explorer.read	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.121	2026-01-30 13:28:14.121	2026-01-30 13:28:14.121	\N	\N	\N
341	kxzrcx7lvweninnbmglhjg5m	plugin::content-manager.explorer.read	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.13	2026-01-30 13:28:14.13	2026-01-30 13:28:14.13	\N	\N	\N
342	drdqn6w7ukrb5607reajq7cw	plugin::content-manager.explorer.read	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.139	2026-01-30 13:28:14.139	2026-01-30 13:28:14.139	\N	\N	\N
343	gna8sktg7uqnt0epof5nlfzi	plugin::content-manager.explorer.update	{}	api::case-studies-page.case-studies-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterRetail", "filterRealEstate", "filterTourism", "filterEvents", "filterEducation", "resultsLabel", "readMoreButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.15	2026-01-30 13:28:14.15	2026-01-30 13:28:14.15	\N	\N	\N
344	lbhbfj42ti4rte29b37u9s32	plugin::content-manager.explorer.update	{}	api::demos-page.demos-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterMatterport", "filterAi", "filterVfair", "accessPublic", "accessAuth", "accessEnterprise", "tryNowButton", "requestAccessButton", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.164	2026-01-30 13:28:14.164	2026-01-30 13:28:14.164	\N	\N	\N
345	j6a2vsotsha21bghx679r9e7	plugin::content-manager.explorer.update	{}	api::industries-page.industries-page	{"fields": ["heroTitle", "heroSubtitle", "statsTitle", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.175	2026-01-30 13:28:14.175	2026-01-30 13:28:14.175	\N	\N	\N
346	hst8h0nvr9a5juzjngy2o1e3	plugin::content-manager.explorer.update	{}	api::partner.partner	{"fields": ["slug", "order", "partnerType", "logoUrl", "websiteUrl", "name", "description", "partnership"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.189	2026-01-30 13:28:14.189	2026-01-30 13:28:14.189	\N	\N	\N
347	nrvxauwnggdoqu4qq21d6ho5	plugin::content-manager.explorer.update	{}	api::pricing-page.pricing-page	{"fields": ["heroTitle", "heroSubtitle", "monthlyLabel", "annualLabel", "annualDiscount", "popularBadge", "featuresTitle", "feature1", "feature2", "feature3", "feature4", "feature5", "comparisonTitle", "enterpriseTitle", "enterpriseSubtitle", "enterpriseCta", "faqTitle", "guaranteeTitle", "guaranteeText"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.209	2026-01-30 13:28:14.209	2026-01-30 13:28:14.209	\N	\N	\N
348	ixjflm9if5qm64gt6nz4va6y	plugin::content-manager.explorer.update	{}	api::pricing-plan.pricing-plan	{"fields": ["slug", "order", "popular", "name", "price", "currency", "period", "description", "features", "limitations", "cta", "idealFor"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.239	2026-01-30 13:28:14.239	2026-01-30 13:28:14.239	\N	\N	\N
349	gp79rjsvw6gkgm34flls531q	plugin::content-manager.explorer.update	{}	api::solutions-page.solutions-page	{"fields": ["heroTitle", "heroSubtitle", "filterAll", "filterPlatforms", "filterServices", "filterAi", "ctaTitle", "ctaSubtitle", "ctaButton"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.252	2026-01-30 13:28:14.252	2026-01-30 13:28:14.252	\N	\N	\N
350	mh266nyrd6mrydxtqozh21r1	plugin::content-manager.explorer.update	{}	api::testimonial.testimonial	{"fields": ["order", "rating", "featured", "quote", "author", "role", "company"], "locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.261	2026-01-30 13:28:14.261	2026-01-30 13:28:14.261	\N	\N	\N
351	s914xkn0h5dq79e3b5v7vhdi	plugin::content-manager.explorer.delete	{}	api::case-studies-page.case-studies-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.269	2026-01-30 13:28:14.269	2026-01-30 13:28:14.269	\N	\N	\N
352	fwryuyr3599e3eci24hrjo6n	plugin::content-manager.explorer.delete	{}	api::demos-page.demos-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.278	2026-01-30 13:28:14.278	2026-01-30 13:28:14.278	\N	\N	\N
353	xygn0bu157gz7oba6pkrk2ds	plugin::content-manager.explorer.delete	{}	api::industries-page.industries-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.288	2026-01-30 13:28:14.288	2026-01-30 13:28:14.289	\N	\N	\N
354	hvf3t7tytymifaw9pe1utwzm	plugin::content-manager.explorer.delete	{}	api::partner.partner	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.298	2026-01-30 13:28:14.298	2026-01-30 13:28:14.298	\N	\N	\N
355	u5dbo4x5yf195a0uae7j5bml	plugin::content-manager.explorer.delete	{}	api::pricing-page.pricing-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.307	2026-01-30 13:28:14.307	2026-01-30 13:28:14.307	\N	\N	\N
356	z80hje7oscezb1o49ldwy0qn	plugin::content-manager.explorer.delete	{}	api::pricing-plan.pricing-plan	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.317	2026-01-30 13:28:14.317	2026-01-30 13:28:14.317	\N	\N	\N
357	bl5sljtf1x7395kstwdz2o3q	plugin::content-manager.explorer.delete	{}	api::solutions-page.solutions-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.328	2026-01-30 13:28:14.328	2026-01-30 13:28:14.328	\N	\N	\N
358	w96qrybtnkauhayp2yqlo4ao	plugin::content-manager.explorer.delete	{}	api::testimonial.testimonial	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.337	2026-01-30 13:28:14.337	2026-01-30 13:28:14.337	\N	\N	\N
359	uql4x1ei5w52wdxlav0m7rxr	plugin::content-manager.explorer.publish	{}	api::case-studies-page.case-studies-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.347	2026-01-30 13:28:14.347	2026-01-30 13:28:14.347	\N	\N	\N
360	a929wvqvffpofosdgrqlpvnc	plugin::content-manager.explorer.publish	{}	api::demos-page.demos-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.359	2026-01-30 13:28:14.359	2026-01-30 13:28:14.359	\N	\N	\N
361	ksshxe3k7la1zzcyesk3apgq	plugin::content-manager.explorer.publish	{}	api::industries-page.industries-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.37	2026-01-30 13:28:14.37	2026-01-30 13:28:14.37	\N	\N	\N
363	yfjmkckl9f341i9icbe285cc	plugin::content-manager.explorer.publish	{}	api::pricing-page.pricing-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.394	2026-01-30 13:28:14.394	2026-01-30 13:28:14.394	\N	\N	\N
364	lscd47a09gyvbxcu0m9r5yie	plugin::content-manager.explorer.publish	{}	api::pricing-plan.pricing-plan	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.408	2026-01-30 13:28:14.408	2026-01-30 13:28:14.408	\N	\N	\N
365	blajmy3ztt1vh3jhcp3r0lle	plugin::content-manager.explorer.publish	{}	api::solutions-page.solutions-page	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.421	2026-01-30 13:28:14.421	2026-01-30 13:28:14.422	\N	\N	\N
366	bni7anyy15q7kczl3p2li88y	plugin::content-manager.explorer.publish	{}	api::testimonial.testimonial	{"locales": ["en", "ar"]}	[]	2026-01-30 13:28:14.434	2026-01-30 13:28:14.434	2026-01-30 13:28:14.435	\N	\N	\N
373	nhws9fp0udpueeadge9kbz65	plugin::content-manager.explorer.create	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "displayName", "phone", "country", "company", "accountStatus", "salesContactAllowed", "confirmationTokenExpiresAt", "lastLogin"]}	[]	2026-01-31 13:53:21.895	2026-01-31 13:53:21.895	2026-01-31 13:53:21.896	\N	\N	\N
374	jl08sz9fm0k2w37xli4z6v9b	plugin::content-manager.explorer.read	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "displayName", "phone", "country", "company", "accountStatus", "salesContactAllowed", "confirmationTokenExpiresAt", "lastLogin"]}	[]	2026-01-31 13:53:21.906	2026-01-31 13:53:21.906	2026-01-31 13:53:21.906	\N	\N	\N
375	klq7ps81m4w7fo1bwvq7ki5a	plugin::content-manager.explorer.update	{}	plugin::users-permissions.user	{"fields": ["username", "email", "provider", "password", "resetPasswordToken", "confirmationToken", "confirmed", "blocked", "role", "displayName", "phone", "country", "company", "accountStatus", "salesContactAllowed", "confirmationTokenExpiresAt", "lastLogin"]}	[]	2026-01-31 13:53:21.916	2026-01-31 13:53:21.916	2026-01-31 13:53:21.916	\N	\N	\N
\.


--
-- TOC entry 3979 (class 0 OID 106400)
-- Dependencies: 286
-- Data for Name: admin_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	2	1
2	2	2	2
3	3	2	3
4	4	2	4
5	5	2	5
6	6	2	6
7	7	3	1
8	8	3	2
9	9	3	3
10	10	3	4
11	11	3	5
12	12	3	6
16	16	1	4
17	17	1	5
18	18	1	6
19	19	1	7
20	20	1	8
21	21	1	9
22	22	1	10
23	23	1	11
24	24	1	12
25	25	1	13
26	26	1	14
27	27	1	15
28	28	1	16
29	29	1	17
30	30	1	18
31	31	1	19
32	32	1	20
33	33	1	21
34	34	1	22
35	35	1	23
36	36	1	24
37	37	1	25
38	38	1	26
39	39	1	27
40	40	1	28
41	41	1	29
42	42	1	30
43	43	1	31
44	44	1	32
45	45	1	33
46	46	1	34
47	47	1	35
48	48	1	36
49	49	1	37
50	50	1	38
51	51	1	39
52	52	1	40
53	53	1	41
54	54	1	42
55	55	1	43
56	56	1	44
57	57	1	45
58	58	1	46
59	59	1	47
60	60	1	48
61	61	1	49
62	62	1	50
63	63	1	51
64	64	1	52
65	65	1	53
66	66	1	54
67	67	1	55
68	68	1	56
69	69	1	57
70	70	1	58
71	71	1	59
72	72	1	60
73	73	1	61
74	74	1	62
75	75	1	63
76	76	1	64
77	77	1	65
78	78	1	66
79	79	1	67
80	80	1	68
81	81	1	69
242	242	1	70
243	243	1	71
244	244	1	72
245	245	1	73
246	246	1	74
247	247	1	75
248	248	1	76
249	249	1	77
250	250	1	78
251	251	1	79
252	252	1	80
253	253	1	81
254	254	1	82
255	255	1	83
256	256	1	84
257	257	1	85
258	258	1	86
259	259	1	87
260	260	1	88
261	261	1	89
262	262	1	90
263	263	1	91
264	264	1	92
265	265	1	93
266	266	1	94
267	267	1	95
268	268	1	96
269	269	1	97
270	270	1	98
271	271	1	99
272	272	1	100
273	273	1	101
274	274	1	102
275	275	1	103
276	276	1	104
277	277	1	105
278	278	1	106
279	279	1	107
280	280	1	108
281	281	1	109
282	282	1	110
283	283	1	111
284	284	1	112
285	285	1	113
286	286	1	114
287	287	1	115
288	288	1	116
289	289	1	117
290	290	1	118
291	291	1	119
292	292	1	120
293	293	1	121
294	294	1	122
295	295	1	123
296	296	1	124
297	297	1	125
298	298	1	126
299	299	1	127
300	300	1	128
301	301	1	129
302	302	1	130
303	303	1	131
304	304	1	132
305	305	1	133
306	306	1	134
307	307	1	135
308	308	1	136
309	309	1	137
310	310	1	138
311	311	1	139
312	312	1	140
313	313	1	141
314	314	1	142
315	315	1	143
316	316	1	144
317	317	1	145
318	318	1	146
319	319	1	147
320	320	1	148
321	321	1	149
322	322	1	150
323	323	1	151
324	324	1	152
325	325	1	153
326	326	1	154
327	327	1	155
328	328	1	156
329	329	1	157
330	330	1	158
331	331	1	159
332	332	1	160
333	333	1	161
334	334	1	162
335	335	1	163
336	336	1	164
337	337	1	165
338	338	1	166
339	339	1	167
340	340	1	168
341	341	1	169
342	342	1	170
343	343	1	171
344	344	1	172
345	345	1	173
346	346	1	174
347	347	1	175
348	348	1	176
349	349	1	177
350	350	1	178
351	351	1	179
352	352	1	180
353	353	1	181
354	354	1	182
355	355	1	183
356	356	1	184
357	357	1	185
358	358	1	186
359	359	1	187
360	360	1	188
361	361	1	189
362	362	1	190
363	363	1	191
364	364	1	192
365	365	1	193
366	366	1	194
373	373	1	195
374	374	1	196
375	375	1	197
\.


--
-- TOC entry 3939 (class 0 OID 106172)
-- Dependencies: 246
-- Data for Name: admin_roles; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_roles (id, document_id, name, code, description, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	kuv1jr6f9f8r4w9m7grm9e4r	Super Admin	strapi-super-admin	Super Admins can access and manage all features and settings.	2026-01-29 17:06:07.756	2026-01-29 17:06:07.756	2026-01-29 17:06:07.756	\N	\N	\N
2	n2hzdehwdu2nxw3yqopksayr	Editor	strapi-editor	Editors can manage and publish contents including those of other users.	2026-01-29 17:06:07.765	2026-01-29 17:06:07.765	2026-01-29 17:06:07.765	\N	\N	\N
3	il0jllpjtfih6dt7694d6t72	Author	strapi-author	Authors can manage the content they have created.	2026-01-29 17:06:07.772	2026-01-29 17:06:07.772	2026-01-29 17:06:07.772	\N	\N	\N
\.


--
-- TOC entry 3937 (class 0 OID 106160)
-- Dependencies: 244
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_users (id, document_id, firstname, lastname, username, email, password, reset_password_token, registration_token, is_active, blocked, prefered_language, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	j7hyeueiz7kgq2v2u5lu7k07	Admin	User	\N	admin@arabiq.tech	$2a$10$EcjPOngbVn/TNYyKRGXBteNHPGdyuUE1Tqj7ryobLdJaRcdpBxrVu	\N	\N	t	f	\N	2026-01-29 17:09:23.188	2026-01-29 17:09:23.188	2026-01-29 17:09:23.188	\N	\N	\N
\.


--
-- TOC entry 3981 (class 0 OID 106412)
-- Dependencies: 288
-- Data for Name: admin_users_roles_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.admin_users_roles_lnk (id, user_id, role_id, role_ord, user_ord) FROM stdin;
1	1	1	1	1
\.


--
-- TOC entry 3915 (class 0 OID 106018)
-- Dependencies: 222
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files (id, document_id, name, alternative_text, caption, width, height, formats, hash, ext, mime, size, url, preview_url, provider, provider_metadata, folder_path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3963 (class 0 OID 106305)
-- Dependencies: 270
-- Data for Name: files_folder_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files_folder_lnk (id, file_id, folder_id, file_ord) FROM stdin;
\.


--
-- TOC entry 3961 (class 0 OID 106293)
-- Dependencies: 268
-- Data for Name: files_related_mph; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.files_related_mph (id, file_id, related_id, related_type, field, "order") FROM stdin;
\.


--
-- TOC entry 3919 (class 0 OID 106052)
-- Dependencies: 226
-- Data for Name: i18n_locale; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.i18n_locale (id, document_id, name, code, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	rbegwf4a7cpxlujauiepgr2c	English (en)	en	2026-01-29 17:06:07.632	2026-01-29 17:06:07.632	2026-01-29 17:06:07.633	\N	\N	\N
2	uvciv9hntfaf9ihm3kz2v1cj	Arabic (ar)	ar	2026-01-29 18:03:56.991	2026-01-29 18:03:56.991	2026-01-29 18:03:56.992	1	1	\N
\.


--
-- TOC entry 3959 (class 0 OID 106284)
-- Dependencies: 266
-- Data for Name: strapi_ai_localization_jobs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_ai_localization_jobs (id, content_type, related_document_id, source_locale, target_locales, status, created_at, updated_at) FROM stdin;
1	api::nav-item.nav-item	pbhswucxcw73a6wrexgb73qx	en	["ar"]	failed	2026-01-30 13:28:33.988	2026-01-30 13:29:52.722
2	api::nav-item.nav-item	y0hrjua4k44xko9nl1x4dbjf	en	["ar"]	failed	2026-01-30 13:28:34.066	2026-01-30 13:29:52.821
3	api::nav-item.nav-item	z4em4dj8w19lhunc4cu80cw8	en	["ar"]	failed	2026-01-30 13:28:34.137	2026-01-30 13:29:52.899
4	api::nav-item.nav-item	rdwgrxcapmvx0lako7jjx7ff	en	["ar"]	failed	2026-01-30 13:28:34.201	2026-01-30 13:29:52.972
5	api::nav-item.nav-item	hlfvcuck4sxo5g81xk6krfrx	en	["ar"]	failed	2026-01-30 13:28:34.257	2026-01-30 13:29:53.038
6	api::nav-item.nav-item	ryv8lnx7fober5yglsafdi1t	en	["ar"]	failed	2026-01-30 13:28:34.317	2026-01-30 13:29:53.107
7	api::nav-item.nav-item	r2ozsms43zxmuj5nr1snrgkg	en	["ar"]	failed	2026-01-30 13:28:34.375	2026-01-30 13:29:53.167
8	api::nav-item.nav-item	jydmfzzbbcfpgec0w49dyewu	en	["ar"]	failed	2026-01-30 13:28:34.432	2026-01-30 13:29:53.224
9	api::nav-item.nav-item	anpvuicjfnc7jfapmlf09iak	en	["ar"]	failed	2026-01-30 13:28:34.484	2026-01-30 13:29:53.282
10	api::nav-item.nav-item	k0vo6catt99duz7ljqm3josx	en	["ar"]	failed	2026-01-30 13:28:34.543	2026-01-30 13:29:53.338
11	api::nav-item.nav-item	qbs09odlivjoss99uqr2sbc9	en	["ar"]	failed	2026-01-30 13:28:34.6	2026-01-30 13:29:53.394
12	api::nav-item.nav-item	qdkemfmvqpn5bgygtyx7x1bt	en	["ar"]	failed	2026-01-30 13:28:34.649	2026-01-30 13:29:53.451
13	api::nav-item.nav-item	i1turdfe9h1ll6e8gfw46gct	en	["ar"]	failed	2026-01-30 13:28:34.697	2026-01-30 13:29:53.503
14	api::nav-item.nav-item	vz1j59v83ye7nlx1u2g5nnsx	en	["ar"]	failed	2026-01-30 13:28:34.755	2026-01-30 13:29:53.568
15	api::nav-item.nav-item	bs5ghndmi57r5immsbwxmx6s	en	["ar"]	failed	2026-01-30 13:28:34.812	2026-01-30 13:29:53.63
16	api::nav-item.nav-item	wpt37owti2jpg9zkf2ijlow1	en	["ar"]	failed	2026-01-30 13:28:34.864	2026-01-30 13:29:53.683
17	api::nav-item.nav-item	nqakvu7a637v3u693qeii7r7	en	["ar"]	failed	2026-01-30 13:28:34.915	2026-01-30 13:29:53.737
18	api::nav-item.nav-item	s9crjq6hbw3lo440kzuknphb	en	["ar"]	failed	2026-01-30 13:28:34.965	2026-01-30 13:29:53.786
19	api::nav-item.nav-item	o9amdzth44ab88us7dbgbokv	en	["ar"]	failed	2026-01-30 13:28:35.014	2026-01-30 13:29:53.837
20	api::nav-item.nav-item	innibom0y6msnvjy3xsqdqyc	en	["ar"]	failed	2026-01-30 13:28:35.059	2026-01-30 13:29:53.888
21	api::nav-item.nav-item	ftu5ffalyrvjwkn8yp98as8u	en	["ar"]	failed	2026-01-30 13:28:35.16	2026-01-30 13:29:53.995
22	api::nav-item.nav-item	k0hvy01ev9e8duicvyvdijft	en	["ar"]	failed	2026-01-30 13:28:35.207	2026-01-30 13:29:54.048
23	api::nav-item.nav-item	mw3w6o1r2a6kd2gubgfmhyfa	en	["ar"]	failed	2026-01-30 13:28:35.257	2026-01-30 13:29:54.099
24	api::nav-item.nav-item	sow2fywql2g0wa2hfnngvtr0	en	["ar"]	failed	2026-01-30 13:28:35.302	2026-01-30 13:29:54.149
25	api::feature.feature	k1jra03i9lkeztu8x8d22is2	en	["ar"]	failed	2026-01-30 13:28:35.674	2026-01-30 13:29:54.526
26	api::feature.feature	ok3kc66a7i2y6cz9q8i4wmse	en	["ar"]	failed	2026-01-30 13:28:35.738	2026-01-30 13:29:54.607
27	api::feature.feature	y6o04idbwfzsdaay6kofka05	en	["ar"]	failed	2026-01-30 13:28:35.806	2026-01-30 13:29:54.674
28	api::feature.feature	i4dkzjlvl1lu9p235cj2ub7b	en	["ar"]	failed	2026-01-30 13:28:35.87	2026-01-30 13:29:54.742
29	api::feature.feature	x0m30dpz1rxe0k198zsv6ezm	en	["ar"]	failed	2026-01-30 13:28:35.936	2026-01-30 13:29:54.803
30	api::feature.feature	ivnxuc8pbaf7gany3wcruwyn	en	["ar"]	failed	2026-01-30 13:28:36.006	2026-01-30 13:29:54.874
31	api::feature.feature	qsi791uprrxhi6sa796n04rj	en	["ar"]	failed	2026-01-30 13:28:36.075	2026-01-30 13:29:54.936
32	api::feature.feature	iwmchlh2l7dlvd6xymxcx47v	en	["ar"]	failed	2026-01-30 13:28:36.135	2026-01-30 13:29:54.999
33	api::value.value	b7qcdj10g5cxh1mhrhtanwkb	en	["ar"]	failed	2026-01-30 13:28:36.202	2026-01-30 13:29:55.076
34	api::value.value	y03iemvahxiw2nefjrei49uy	en	["ar"]	failed	2026-01-30 13:28:36.263	2026-01-30 13:29:55.145
35	api::value.value	ul9kvvxapz9l9xv1c161bary	en	["ar"]	failed	2026-01-30 13:28:36.324	2026-01-30 13:29:55.21
36	api::value.value	ilhmif7djgk9cqcgay1o36yc	en	["ar"]	failed	2026-01-30 13:28:36.39	2026-01-30 13:29:55.278
37	api::value.value	swit4duvl957rrh12n8pcubn	en	["ar"]	failed	2026-01-30 13:28:36.458	2026-01-30 13:29:55.347
38	api::value.value	w7lo6myxfcpdw967yme1hho6	en	["ar"]	failed	2026-01-30 13:28:36.518	2026-01-30 13:29:55.422
39	api::testimonial.testimonial	hb6z3co41twdz85uasd1t06e	en	["ar"]	failed	2026-01-30 13:28:36.586	2026-01-30 13:29:55.485
40	api::testimonial.testimonial	qbjqccwia98t3aqkfco75zvy	en	["ar"]	failed	2026-01-30 13:28:36.634	2026-01-30 13:29:55.535
41	api::testimonial.testimonial	hcoaoxpwl6v7kmqudxug2zjr	en	["ar"]	failed	2026-01-30 13:28:36.681	2026-01-30 13:29:55.589
42	api::testimonial.testimonial	zu45kb8b0cmz7g0fln9qp268	en	["ar"]	failed	2026-01-30 13:28:36.728	2026-01-30 13:29:55.634
43	api::testimonial.testimonial	dgfwle2xkrrvca30031nubvq	en	["ar"]	failed	2026-01-30 13:28:36.775	2026-01-30 13:29:55.68
44	api::testimonial.testimonial	ae0xtubg69qt3cp70cu87dii	en	["ar"]	failed	2026-01-30 13:28:36.822	2026-01-30 13:29:55.729
45	api::faq.faq	uz319w0xnmgjju7q8xhqmylk	en	["ar"]	failed	2026-01-30 13:28:36.879	2026-01-30 13:29:55.782
46	api::faq.faq	rcf5ficwoibv84orqiwku5h5	en	["ar"]	failed	2026-01-30 13:28:36.931	2026-01-30 13:29:55.833
47	api::faq.faq	b3rvitbxugv00l7569aqx7po	en	["ar"]	failed	2026-01-30 13:28:36.983	2026-01-30 13:29:55.885
48	api::faq.faq	jhbm7a60ps7105hiqye1bdmu	en	["ar"]	failed	2026-01-30 13:28:37.037	2026-01-30 13:29:55.937
49	api::faq.faq	gsv5ahlo7j0wdijcguqffe56	en	["ar"]	failed	2026-01-30 13:28:37.09	2026-01-30 13:29:55.987
50	api::faq.faq	jn8j9qdaxgm6bcmze21fyhp6	en	["ar"]	failed	2026-01-30 13:28:37.145	2026-01-30 13:29:56.037
51	api::faq.faq	ceirb08m3qx33izsut5b09m0	en	["ar"]	failed	2026-01-30 13:28:37.201	2026-01-30 13:29:56.09
52	api::faq.faq	iz3f5f3mlcrhq3b4aaahqd1r	en	["ar"]	failed	2026-01-30 13:28:37.258	2026-01-30 13:29:56.15
53	api::faq.faq	jjwclft4c0za7c5mrz7onmej	en	["ar"]	failed	2026-01-30 13:28:37.309	2026-01-30 13:29:56.211
54	api::faq.faq	qjuq6ouy05zuklrb09bgbjpu	en	["ar"]	failed	2026-01-30 13:28:37.364	2026-01-30 13:29:56.275
55	api::pricing-plan.pricing-plan	zl53fe61n4p94fxngibkuzv5	en	["ar"]	failed	2026-01-30 13:28:37.425	2026-01-30 13:29:56.342
56	api::pricing-plan.pricing-plan	ccyvmzkhpktzmvzzr7qb37fa	en	["ar"]	failed	2026-01-30 13:28:39.271	2026-01-30 13:29:56.397
57	api::pricing-plan.pricing-plan	sjhm9lmc1lgtq2oxl4wkozvs	en	["ar"]	failed	2026-01-30 13:28:39.327	2026-01-30 13:29:56.457
58	api::pricing-plan.pricing-plan	eh6xavp4jxgeh63z0xmanb19	en	["ar"]	failed	2026-01-30 13:28:39.385	2026-01-30 13:29:56.506
59	api::partner.partner	hyok9jxi6onuqhattk1p4c45	en	["ar"]	failed	2026-01-30 13:28:39.448	2026-01-30 13:29:03.919
60	api::partner.partner	fksra64c2epa532kogb0dtme	en	["ar"]	failed	2026-01-30 13:28:39.501	2026-01-30 13:29:03.98
61	api::partner.partner	n2c0d05gwlyls2k7dlmf4zcs	en	["ar"]	failed	2026-01-30 13:28:39.552	2026-01-30 13:29:04.037
62	api::partner.partner	aooct80zbh6cvaz8tlbt9ldt	en	["ar"]	failed	2026-01-30 13:28:39.604	2026-01-30 13:29:04.092
63	api::partner.partner	aryhb53fl806e18un55tdytl	en	["ar"]	failed	2026-01-30 13:28:39.654	2026-01-30 13:29:04.147
64	api::partner.partner	wk5amblec1ez4b6iamzrrj34	en	["ar"]	failed	2026-01-30 13:28:39.705	2026-01-30 13:29:04.203
65	api::nav-item.nav-item	buevkrllfgf0mp998h1r65e9	en	["ar"]	failed	2026-01-30 13:33:00.101	2026-01-30 13:34:31.707
75	api::nav-item.nav-item	cu273jrstb312isfs6w4346j	en	["ar"]	failed	2026-01-30 13:33:00.703	2026-01-30 13:34:32.299
486	api::homepage.homepage	fd3ws4k73m7nfjicvtb0jr6l	en	["ar"]	failed	2026-01-30 18:18:42.835	2026-01-30 18:18:42.851
76	api::nav-item.nav-item	b9iu50vqihxbj75ouj0b5yh3	en	["ar"]	failed	2026-01-30 13:33:00.755	2026-01-30 13:34:32.366
103	api::testimonial.testimonial	wpxb5c1wbkey8ze3auavm3te	en	["ar"]	failed	2026-01-30 13:33:02.7	2026-01-30 13:34:34.334
77	api::nav-item.nav-item	sg1k3nloiggrs1hecfunygn4	en	["ar"]	failed	2026-01-30 13:33:00.808	2026-01-30 13:34:32.461
88	api::nav-item.nav-item	rd9wkqqfecba9drsq001gh38	en	["ar"]	failed	2026-01-30 13:33:01.421	2026-01-30 13:34:33.075
104	api::testimonial.testimonial	n2dpxr050x38ec4fdx6didh5	en	["ar"]	failed	2026-01-30 13:33:02.749	2026-01-30 13:34:34.383
89	api::feature.feature	rahi1n7iba6y8j7eyshd0lzp	en	["ar"]	failed	2026-01-30 13:33:01.743	2026-01-30 13:34:33.397
490	api::pricing-page.pricing-page	lkx5moczi3oe2jztwvsvzqh7	en	["ar"]	failed	2026-01-30 18:18:43.053	2026-01-30 18:18:43.063
105	api::testimonial.testimonial	qxfwemlc2fmgignp32tr754a	en	["ar"]	failed	2026-01-30 13:33:02.796	2026-01-30 13:34:34.433
106	api::testimonial.testimonial	go2r8rajvjy5xpotz57le3rg	en	["ar"]	failed	2026-01-30 13:33:02.84	2026-01-30 13:34:34.482
491	api::solutions-page.solutions-page	m7ti5vgrjw2bs05w39f2ahtt	en	["ar"]	failed	2026-01-30 18:18:43.102	2026-01-30 18:18:43.109
107	api::testimonial.testimonial	epwzk3z6v889cx4r7j4bf5wo	en	["ar"]	failed	2026-01-30 13:33:02.89	2026-01-30 13:34:34.54
492	api::industries-page.industries-page	ifdaxgwgkmwhyqnymx4jr7cj	en	["ar"]	failed	2026-01-30 18:18:43.154	2026-01-30 18:18:43.16
523	api::team-member.team-member	zkj9afum7rkox7d98i8bgzr0	en	["ar"]	failed	2026-01-30 18:18:44.707	2026-01-30 18:18:44.713
524	api::team-member.team-member	ruf8gglwetvtk0wupucbwmm6	en	["ar"]	failed	2026-01-30 18:18:44.753	2026-01-30 18:18:44.76
526	api::team-member.team-member	n8wdzrj8lnse55886m2yq1ds	en	["ar"]	failed	2026-01-30 18:18:44.844	2026-01-30 18:18:44.849
550	api::value.value	tvjktjdvlsnwwu4t5u78xeyh	en	["ar"]	failed	2026-01-30 18:18:45.788	2026-01-30 18:18:45.793
108	api::testimonial.testimonial	g1j7kc4ec9juhdfaj1wc350i	en	["ar"]	failed	2026-01-30 13:33:02.935	2026-01-30 13:33:02.942
109	api::faq.faq	oyamwagh3s8b3kaydhhclaum	en	["ar"]	failed	2026-01-30 13:33:02.982	2026-01-30 13:33:02.992
110	api::faq.faq	plqdxdlsb5nw07r9kdafpodo	en	["ar"]	failed	2026-01-30 13:33:03.051	2026-01-30 13:33:03.06
111	api::faq.faq	xqnu1ugt0812bpgtf9k5sdl9	en	["ar"]	failed	2026-01-30 13:33:03.118	2026-01-30 13:33:03.126
112	api::faq.faq	edq57gassjzvgbvu1dydnh9o	en	["ar"]	failed	2026-01-30 13:33:03.19	2026-01-30 13:33:03.199
115	api::faq.faq	oyiyja58i0ynuulp1ipiu94n	en	["ar"]	failed	2026-01-30 13:33:03.39	2026-01-30 13:33:03.396
116	api::faq.faq	b4qh3uomyrs6papnbggnbg1o	en	["ar"]	failed	2026-01-30 13:33:03.462	2026-01-30 13:33:03.469
119	api::pricing-plan.pricing-plan	su78ippq7l3wamfsu9j5jw5u	en	["ar"]	failed	2026-01-30 13:33:03.67	2026-01-30 13:33:03.679
122	api::pricing-plan.pricing-plan	pbhbzuasdmbqyhtargfxoooq	en	["ar"]	failed	2026-01-30 13:33:03.87	2026-01-30 13:33:03.877
551	api::value.value	i6kg6udk3hiccgl1f2ckgtx1	en	["ar"]	failed	2026-01-30 18:18:45.825	2026-01-30 18:18:45.832
66	api::nav-item.nav-item	gy14b4o8kkd32ct0bcr2mrl0	en	["ar"]	failed	2026-01-30 13:33:00.162	2026-01-30 13:34:31.764
90	api::feature.feature	iuptkjtxcpf4wl0kcke8071h	en	["ar"]	failed	2026-01-30 13:33:01.808	2026-01-30 13:34:33.468
67	api::nav-item.nav-item	xqdibsifqxjvb7gt7bvkbrrd	en	["ar"]	failed	2026-01-30 13:33:00.226	2026-01-30 13:34:31.82
68	api::nav-item.nav-item	fymwss7im1s9h43za1h8y6jl	en	["ar"]	failed	2026-01-30 13:33:00.291	2026-01-30 13:34:31.875
91	api::feature.feature	y6sa1yfm17rjbhh80vlesrix	en	["ar"]	failed	2026-01-30 13:33:01.878	2026-01-30 13:34:33.551
69	api::nav-item.nav-item	cogrf7vgapmayq4cfgoxdqvl	en	["ar"]	failed	2026-01-30 13:33:00.347	2026-01-30 13:34:31.934
552	api::testimonial.testimonial	opq1fmv3lnckbzxhmwwk62ds	en	["ar"]	failed	2026-01-30 18:18:45.868	2026-01-30 18:18:45.875
70	api::nav-item.nav-item	ow5fgb6adr3sfeinhwumgn1l	en	["ar"]	failed	2026-01-30 13:33:00.415	2026-01-30 13:34:31.996
94	api::feature.feature	nw0ft91czxs6fsgz8rwdh5n2	en	["ar"]	failed	2026-01-30 13:33:02.075	2026-01-30 13:34:33.779
71	api::nav-item.nav-item	po5ulk42u9aixbjmdam4pijq	en	["ar"]	failed	2026-01-30 13:33:00.484	2026-01-30 13:34:32.056
72	api::nav-item.nav-item	i33pn3v14bjld466t49dxn6w	en	["ar"]	failed	2026-01-30 13:33:00.542	2026-01-30 13:34:32.113
95	api::feature.feature	bosmjjeton2ga5jhuo0p60cv	en	["ar"]	failed	2026-01-30 13:33:02.154	2026-01-30 13:34:33.836
73	api::nav-item.nav-item	mjsik0uc78nyty73egl21q24	en	["ar"]	failed	2026-01-30 13:33:00.595	2026-01-30 13:34:32.171
554	api::testimonial.testimonial	qb2es65ey3qka86jksib45ki	en	["ar"]	failed	2026-01-30 18:18:45.951	2026-01-30 18:18:45.958
74	api::nav-item.nav-item	nhugwwkiy6hr8a2e6ou51ujz	en	["ar"]	failed	2026-01-30 13:33:00.651	2026-01-30 13:34:32.234
98	api::value.value	j47vlgzbv9c2918xgoejutt7	en	["ar"]	failed	2026-01-30 13:33:02.365	2026-01-30 13:34:34.012
555	api::testimonial.testimonial	xmyhaokucnw2dalfdoavcqxk	en	["ar"]	failed	2026-01-30 18:18:45.988	2026-01-30 18:18:45.994
99	api::value.value	e8u3e6a00flsvpkam17y0ifv	en	["ar"]	failed	2026-01-30 13:33:02.423	2026-01-30 13:34:34.083
100	api::value.value	o3y1gguvx188xjc5gp2heplz	en	["ar"]	failed	2026-01-30 13:33:02.49	2026-01-30 13:34:34.147
573	api::partner.partner	zqj4agqr31qcfosztd68uqq5	en	["ar"]	failed	2026-01-30 18:18:46.688	2026-01-30 18:18:46.697
101	api::value.value	ag1jewvwv8d9f5ktawipry94	en	["ar"]	failed	2026-01-30 13:33:02.55	2026-01-30 13:34:34.209
581	api::demo.demo	zeeuzedqjrhzp8gmkkki41de	en	["ar"]	failed	2026-01-30 18:18:46.99	2026-01-30 18:18:46.997
584	api::case-study.case-study	skq1yjxd7770pz5in55zfgg7	en	["ar"]	failed	2026-01-30 18:18:47.097	2026-01-30 18:18:47.104
586	api::case-study.case-study	qj6gtnln0t7cdf0691h03fkf	en	["ar"]	failed	2026-01-30 18:18:47.162	2026-01-30 18:18:47.167
593	api::solution.solution	p6oj1wlsr0uj7nw7jld866h4	en	["ar"]	failed	2026-01-30 18:18:47.397	2026-01-30 18:18:47.404
597	api::industry.industry	fjz0xzgvdm0hkx4tv4knpeev	en	["ar"]	failed	2026-01-30 18:18:47.53	2026-01-30 18:18:47.536
600	api::industry.industry	y6jskmvdb2f7ac83uglzuqxn	en	["ar"]	failed	2026-01-30 18:18:47.656	2026-01-30 18:18:47.662
718	api::nav-item.nav-item	pdh3c62g5gskqzzvzhukm1e0	en	["ar"]	failed	2026-01-31 14:26:38.559	2026-01-31 14:26:38.565
719	api::nav-item.nav-item	cijuorz93hwe2jgs3fg5591m	en	["ar"]	failed	2026-01-31 14:26:38.596	2026-01-31 14:26:38.603
720	api::nav-item.nav-item	gsfycx4o8lfxd5v04go98ya1	en	["ar"]	failed	2026-01-31 14:26:38.646	2026-01-31 14:26:38.653
721	api::nav-item.nav-item	nyat4riwk2i6qehmwc1yhipq	en	["ar"]	failed	2026-01-31 14:26:38.692	2026-01-31 14:26:38.698
723	api::nav-item.nav-item	g99bhnj0u2xikr8wsueh4euw	en	["ar"]	failed	2026-01-31 14:26:38.765	2026-01-31 14:26:38.773
743	api::team-member.team-member	io2r7x9v72hox4wbpc0iz5c0	en	["ar"]	failed	2026-01-31 14:26:39.823	2026-01-31 14:26:39.83
747	api::team-member.team-member	yl0nobjierkll8u8g691o2rx	en	["ar"]	failed	2026-01-31 14:26:39.989	2026-01-31 14:26:39.996
853	api::team-member.team-member	jc2jofy809ndx7mbwvkxf3wq	en	["ar"]	failed	2026-01-31 14:35:43.672	2026-01-31 14:35:43.677
864	api::process-step.process-step	rtkz4vfwjudopzgirwy9mu54	en	["ar"]	failed	2026-01-31 14:35:44.096	2026-01-31 14:35:44.103
82	api::nav-item.nav-item	hnr85wic2p8q0laqwdx8t0mf	en	["ar"]	failed	2026-01-30 13:33:01.083	2026-01-30 13:34:32.736
134	api::nav-item.nav-item	jd6cph2w1mngvqrj8tsxgxzq	en	["ar"]	failed	2026-01-30 14:07:20.619	2026-01-30 14:07:20.63
135	api::nav-item.nav-item	c9pezgv8otu1ywp151t0zeao	en	["ar"]	failed	2026-01-30 14:07:20.679	2026-01-30 14:07:20.689
136	api::nav-item.nav-item	elkyea8978bagttnlsn4badx	en	["ar"]	failed	2026-01-30 14:07:20.738	2026-01-30 14:07:20.746
137	api::nav-item.nav-item	mybe4y3geqohoxfydqm0vcfx	en	["ar"]	failed	2026-01-30 14:07:20.789	2026-01-30 14:07:20.798
138	api::nav-item.nav-item	yotgk1870id0x6ahorwdpn2r	en	["ar"]	failed	2026-01-30 14:07:20.844	2026-01-30 14:07:20.852
139	api::nav-item.nav-item	e8ylef87taqz4pb3s5bev1q9	en	["ar"]	failed	2026-01-30 14:07:20.902	2026-01-30 14:07:20.908
113	api::faq.faq	w43b4ioqanl9qhen9rwm77y8	en	["ar"]	failed	2026-01-30 13:33:03.256	2026-01-30 13:33:03.263
114	api::faq.faq	mhowux1nkqmngycuh6maj16u	en	["ar"]	failed	2026-01-30 13:33:03.321	2026-01-30 13:33:03.327
117	api::faq.faq	pzbbeueudoei9tfj0damo3b4	en	["ar"]	failed	2026-01-30 13:33:03.525	2026-01-30 13:33:03.535
118	api::faq.faq	yoc2m0xg8bb9esgfy1tyqcmr	en	["ar"]	failed	2026-01-30 13:33:03.605	2026-01-30 13:33:03.614
120	api::pricing-plan.pricing-plan	j04yna0vl3hofjsbu3477osk	en	["ar"]	failed	2026-01-30 13:33:03.74	2026-01-30 13:33:03.749
121	api::pricing-plan.pricing-plan	b3pzgzre97fpnrn9vbmsfx4u	en	["ar"]	failed	2026-01-30 13:33:03.807	2026-01-30 13:33:03.813
123	api::partner.partner	dqce8hkr4wynqtf7k8lgatf6	en	["ar"]	failed	2026-01-30 13:33:03.944	2026-01-30 13:33:03.952
124	api::partner.partner	s4rm8vj9jcmv89z1xq9lekhn	en	["ar"]	failed	2026-01-30 13:33:04.01	2026-01-30 13:33:04.018
125	api::partner.partner	qmhkzs7e1sdjci1g9r2yvh8n	en	["ar"]	failed	2026-01-30 13:33:04.073	2026-01-30 13:33:04.08
126	api::partner.partner	fawy4fl4it2usb5y5ysjw7f8	en	["ar"]	failed	2026-01-30 13:33:04.147	2026-01-30 13:33:04.153
127	api::partner.partner	t5x7smcioig1epbvk512yt14	en	["ar"]	failed	2026-01-30 13:33:04.212	2026-01-30 13:33:04.217
128	api::partner.partner	vkdyvisiwm1mfm1rsi9dqti6	en	["ar"]	failed	2026-01-30 13:33:04.275	2026-01-30 13:33:04.288
83	api::nav-item.nav-item	n5hpxay2ibfs1p5zzr2dmnwt	en	["ar"]	failed	2026-01-30 13:33:01.137	2026-01-30 13:34:32.783
78	api::nav-item.nav-item	x4ieapygihntdpzxf90smhgq	en	["ar"]	failed	2026-01-30 13:33:00.859	2026-01-30 13:34:32.531
140	api::nav-item.nav-item	og49n1evpg14tddd1vvesgvl	en	["ar"]	failed	2026-01-30 14:07:20.959	2026-01-30 14:07:20.966
79	api::nav-item.nav-item	nevp1qwdkassgou2zi34c676	en	["ar"]	failed	2026-01-30 13:33:00.919	2026-01-30 13:34:32.584
84	api::nav-item.nav-item	r7wgihju496rdmpmncu354il	en	["ar"]	failed	2026-01-30 13:33:01.188	2026-01-30 13:34:32.833
80	api::nav-item.nav-item	cbhceshch20w5fhitsiv4opd	en	["ar"]	failed	2026-01-30 13:33:00.973	2026-01-30 13:34:32.638
81	api::nav-item.nav-item	e2ptx42xl8iya8v14fk1iqvz	en	["ar"]	failed	2026-01-30 13:33:01.023	2026-01-30 13:34:32.689
141	api::nav-item.nav-item	klk1v693zu6uargpqya7ik3b	en	["ar"]	failed	2026-01-30 14:07:21.009	2026-01-30 14:07:21.016
85	api::nav-item.nav-item	aktki5ym3i8du57uc7lpbqnc	en	["ar"]	failed	2026-01-30 13:33:01.269	2026-01-30 13:34:32.923
86	api::nav-item.nav-item	vym406frbswht94nl7xcwqns	en	["ar"]	failed	2026-01-30 13:33:01.319	2026-01-30 13:34:32.978
142	api::nav-item.nav-item	dhbmrbni3cmbavrlk553m4lr	en	["ar"]	failed	2026-01-30 14:07:21.064	2026-01-30 14:07:21.073
87	api::nav-item.nav-item	bmfx8usx97aiq2ytvt9bw807	en	["ar"]	failed	2026-01-30 13:33:01.369	2026-01-30 13:34:33.031
92	api::feature.feature	d2vggrtechjs7mnoo4qbyt10	en	["ar"]	failed	2026-01-30 13:33:01.947	2026-01-30 13:34:33.62
143	api::nav-item.nav-item	vuod9ihbmz3dkag8xcsc2vuv	en	["ar"]	failed	2026-01-30 14:07:21.12	2026-01-30 14:07:21.133
93	api::feature.feature	r5he12tjtnhcbygghy8uk6wc	en	["ar"]	failed	2026-01-30 13:33:02.007	2026-01-30 13:34:33.721
96	api::feature.feature	gyukp6kvqjofvjs7nwfdeap5	en	["ar"]	failed	2026-01-30 13:33:02.224	2026-01-30 13:34:33.892
144	api::nav-item.nav-item	r02rd2hrkln35gc641pa8erk	en	["ar"]	failed	2026-01-30 14:07:21.18	2026-01-30 14:07:21.188
97	api::value.value	colwi82db5423qllfogcnqdk	en	["ar"]	failed	2026-01-30 13:33:02.297	2026-01-30 13:34:33.951
102	api::value.value	osvo6jh7ldmn61dxvtkexbk6	en	["ar"]	failed	2026-01-30 13:33:02.616	2026-01-30 13:34:34.268
129	api::nav-item.nav-item	gvy6c9y1icuafxio76f4mvj6	en	["ar"]	failed	2026-01-30 14:07:20.255	2026-01-30 14:07:20.264
130	api::nav-item.nav-item	vu50e31yks8q9usqghpcbvoz	en	["ar"]	failed	2026-01-30 14:07:20.339	2026-01-30 14:07:20.346
131	api::nav-item.nav-item	b12jxebooq63n8w95ic2vg9d	en	["ar"]	failed	2026-01-30 14:07:20.417	2026-01-30 14:07:20.424
132	api::nav-item.nav-item	yi17re197hepw1csm6td2d6v	en	["ar"]	failed	2026-01-30 14:07:20.492	2026-01-30 14:07:20.5
133	api::nav-item.nav-item	gp3dw116zoicklx0152pl6u9	en	["ar"]	failed	2026-01-30 14:07:20.552	2026-01-30 14:07:20.56
145	api::nav-item.nav-item	ojuuqzet84br5frysin8apmm	en	["ar"]	failed	2026-01-30 14:07:21.238	2026-01-30 14:07:21.245
146	api::nav-item.nav-item	l8cu1zwfaexgzx77d5wwp4u4	en	["ar"]	failed	2026-01-30 14:07:21.295	2026-01-30 14:07:21.303
147	api::nav-item.nav-item	qjkaxsqeoo8hg3ia6lcszbbr	en	["ar"]	failed	2026-01-30 14:07:21.348	2026-01-30 14:07:21.355
148	api::nav-item.nav-item	teb4xh94ge9gwq17xhz4jl0j	en	["ar"]	failed	2026-01-30 14:07:21.405	2026-01-30 14:07:21.412
149	api::nav-item.nav-item	c7eyvugqt4yocz9y78irqn9p	en	["ar"]	failed	2026-01-30 14:07:21.505	2026-01-30 14:07:21.512
150	api::nav-item.nav-item	voyoho926sg4vjma12ymmtxn	en	["ar"]	failed	2026-01-30 14:07:21.561	2026-01-30 14:07:21.568
151	api::nav-item.nav-item	x4xc5yqjgvtjrpxemmsss5gj	en	["ar"]	failed	2026-01-30 14:07:21.613	2026-01-30 14:07:21.62
152	api::nav-item.nav-item	k9yv5i47slbr0v6b8fuan2f5	en	["ar"]	failed	2026-01-30 14:07:21.663	2026-01-30 14:07:21.672
153	api::nav-item.nav-item	w6pwm6pfbq8f3n2le5ubpn0y	en	["ar"]	failed	2026-01-30 14:17:22.887	2026-01-30 14:17:22.897
154	api::nav-item.nav-item	znf982pqxr3gkej6lbrzgmg8	en	["ar"]	failed	2026-01-30 14:17:22.953	2026-01-30 14:17:22.96
155	api::nav-item.nav-item	b7dq7vtkaj2t043qyb00fs5n	en	["ar"]	failed	2026-01-30 14:17:23.014	2026-01-30 14:17:23.022
156	api::nav-item.nav-item	hza2sjkxy0pp1nrlv7ibllso	en	["ar"]	failed	2026-01-30 14:17:23.074	2026-01-30 14:17:23.089
157	api::nav-item.nav-item	w9wgqrfmucs4v0442gl8e6hr	en	["ar"]	failed	2026-01-30 14:17:23.141	2026-01-30 14:17:23.148
158	api::nav-item.nav-item	v7n5h2knet4y0sc3vyr7u3za	en	["ar"]	failed	2026-01-30 14:17:23.198	2026-01-30 14:17:23.206
159	api::nav-item.nav-item	dovsyk4d657q5ckev97mmffw	en	["ar"]	failed	2026-01-30 14:17:23.259	2026-01-30 14:17:23.267
160	api::nav-item.nav-item	uqu1mmkrvbusxzevg962oz92	en	["ar"]	failed	2026-01-30 14:17:23.319	2026-01-30 14:17:23.328
161	api::nav-item.nav-item	jwt75ioq51hy9gx73qnnr7dv	en	["ar"]	failed	2026-01-30 14:17:23.379	2026-01-30 14:17:23.391
162	api::nav-item.nav-item	ybhv9g272pjhceftuvknby6t	en	["ar"]	failed	2026-01-30 14:17:23.445	2026-01-30 14:17:23.452
163	api::nav-item.nav-item	bgylxkcm3e7uf5yldyw5lm74	en	["ar"]	failed	2026-01-30 14:17:23.502	2026-01-30 14:17:23.51
164	api::nav-item.nav-item	flxdcuuerwa5djha58vb0suv	en	["ar"]	failed	2026-01-30 14:17:23.556	2026-01-30 14:17:23.564
165	api::nav-item.nav-item	ttkwgzhrfeofsdp3rg6tw7yz	en	["ar"]	failed	2026-01-30 14:17:23.612	2026-01-30 14:17:23.619
166	api::nav-item.nav-item	qvbv12c5gnq3xxcyy8ke7xw8	en	["ar"]	failed	2026-01-30 14:17:23.666	2026-01-30 14:17:23.672
167	api::nav-item.nav-item	vlol84ff0qa2lix656m4a0dp	en	["ar"]	failed	2026-01-30 14:17:23.719	2026-01-30 14:17:23.728
168	api::nav-item.nav-item	fy1egboqs38sfr6dha9v3pc8	en	["ar"]	failed	2026-01-30 14:17:23.772	2026-01-30 14:17:23.788
169	api::nav-item.nav-item	aibaz4x215l4pkb024w93b0e	en	["ar"]	failed	2026-01-30 14:17:23.841	2026-01-30 14:17:23.849
170	api::nav-item.nav-item	lo5w8ygdz0sfxr60b5zhi9ej	en	["ar"]	failed	2026-01-30 14:17:23.889	2026-01-30 14:17:23.897
171	api::nav-item.nav-item	vnommucx1bott3h99wgp2pbw	en	["ar"]	failed	2026-01-30 14:17:23.941	2026-01-30 14:17:23.949
172	api::nav-item.nav-item	e398nv701gbw3z3rhg9dwvd9	en	["ar"]	failed	2026-01-30 14:17:23.996	2026-01-30 14:17:24.006
173	api::nav-item.nav-item	kou5ithukzq1dmghspxeejge	en	["ar"]	failed	2026-01-30 14:17:24.108	2026-01-30 14:17:24.116
174	api::nav-item.nav-item	ejti2khdnehwpi0wvqqitm4a	en	["ar"]	failed	2026-01-30 14:17:24.168	2026-01-30 14:17:24.175
185	api::value.value	jzjr3etn4axripl6xijy2lvb	en	["ar"]	failed	2026-01-30 14:17:25.218	2026-01-30 14:17:25.224
188	api::value.value	t4ke80stt43afyzttli5m16n	en	["ar"]	failed	2026-01-30 14:17:25.422	2026-01-30 14:17:25.428
191	api::testimonial.testimonial	gxagtai07lxq861ulm2vh60s	en	["ar"]	failed	2026-01-30 14:17:25.636	2026-01-30 14:17:25.645
192	api::testimonial.testimonial	uskudlq40ycxx5b5mkbqjs4w	en	["ar"]	failed	2026-01-30 14:17:25.724	2026-01-30 14:17:25.732
193	api::testimonial.testimonial	qs4h0qld9s24zm08yq2abk48	en	["ar"]	failed	2026-01-30 14:17:25.784	2026-01-30 14:17:25.795
194	api::testimonial.testimonial	mjespu8flu14l1tavomcrfcg	en	["ar"]	failed	2026-01-30 14:17:25.836	2026-01-30 14:17:25.844
195	api::testimonial.testimonial	k120st7rswzpbmfkgy0zd4s1	en	["ar"]	failed	2026-01-30 14:17:25.894	2026-01-30 14:17:25.9
196	api::testimonial.testimonial	pg60nvunvxodadnya10vtnpd	en	["ar"]	failed	2026-01-30 14:17:25.945	2026-01-30 14:17:25.952
197	api::faq.faq	fu6t8od3ca193wtkzx2fxnfr	en	["ar"]	failed	2026-01-30 14:17:25.991	2026-01-30 14:17:25.996
198	api::faq.faq	dy6zf932mosoc5tneusf1jj9	en	["ar"]	failed	2026-01-30 14:17:26.05	2026-01-30 14:17:26.057
199	api::faq.faq	x75mu9wbj869gu81f6ca6p55	en	["ar"]	failed	2026-01-30 14:17:26.111	2026-01-30 14:17:26.117
200	api::faq.faq	guo7x3cmr5gs0256mivyq3x9	en	["ar"]	failed	2026-01-30 14:17:26.169	2026-01-30 14:17:26.178
201	api::faq.faq	ahb2k3fe5ey6mrwc8vh4ifz1	en	["ar"]	failed	2026-01-30 14:17:26.228	2026-01-30 14:17:26.236
202	api::faq.faq	n16etyfeah3wwshg2bebwx8z	en	["ar"]	failed	2026-01-30 14:17:26.292	2026-01-30 14:17:26.298
203	api::faq.faq	jbycliu4tvd5miow140g94kd	en	["ar"]	failed	2026-01-30 14:17:26.352	2026-01-30 14:17:26.362
204	api::faq.faq	b7cx0qoqj4xvr2gntexry771	en	["ar"]	failed	2026-01-30 14:17:26.407	2026-01-30 14:17:26.416
205	api::faq.faq	sopnvcr3qq62ki8jppsku3we	en	["ar"]	failed	2026-01-30 14:17:26.464	2026-01-30 14:17:26.47
206	api::faq.faq	csotctz2hxb32fuw09r1ma26	en	["ar"]	failed	2026-01-30 14:17:26.523	2026-01-30 14:17:26.53
207	api::pricing-plan.pricing-plan	inrajg7juckvg55v4ifd39oi	en	["ar"]	failed	2026-01-30 14:17:26.579	2026-01-30 14:17:26.591
208	api::pricing-plan.pricing-plan	kxb4vheko2v5pome0dszjo7a	en	["ar"]	failed	2026-01-30 14:17:26.644	2026-01-30 14:17:26.656
209	api::pricing-plan.pricing-plan	ssv1353ms0p5b0aqhyxnks6u	en	["ar"]	failed	2026-01-30 14:17:26.706	2026-01-30 14:17:26.713
210	api::pricing-plan.pricing-plan	hvnjs4xosc9z36bmf8290ear	en	["ar"]	failed	2026-01-30 14:17:26.767	2026-01-30 14:17:26.775
211	api::partner.partner	nkx4e48wg1k85vcz3v2ouuv3	en	["ar"]	failed	2026-01-30 14:17:26.825	2026-01-30 14:17:26.832
212	api::partner.partner	exk4zbo6uxtjx4xfc8fqqlcc	en	["ar"]	failed	2026-01-30 14:17:26.879	2026-01-30 14:17:26.887
213	api::partner.partner	t8dw46e81hx0misinxqlerzr	en	["ar"]	failed	2026-01-30 14:17:26.942	2026-01-30 14:17:26.948
214	api::partner.partner	e4pm75o5l4cowbucgraxyp44	en	["ar"]	failed	2026-01-30 14:17:27	2026-01-30 14:17:27.007
487	api::about-page.about-page	vbf6jma6n21ku5zgcr6ee324	en	["ar"]	failed	2026-01-30 18:18:42.9	2026-01-30 18:18:42.909
489	api::site-setting.site-setting	x78ut3tqgg2ysm9sdloy9h4n	en	["ar"]	failed	2026-01-30 18:18:42.983	2026-01-30 18:18:42.994
495	api::nav-item.nav-item	raegc8yaa8dmtsawsoel2fgo	en	["ar"]	failed	2026-01-30 18:18:43.31	2026-01-30 18:18:43.319
509	api::nav-item.nav-item	rq2u1jraro076onekzxjlgwv	en	["ar"]	failed	2026-01-30 18:18:43.927	2026-01-30 18:18:43.933
510	api::nav-item.nav-item	f6t0zamugip5yjdqzbq5e5iz	en	["ar"]	failed	2026-01-30 18:18:43.97	2026-01-30 18:18:43.977
511	api::nav-item.nav-item	xkqdrzkqgipbpvrqrsqk5x2f	en	["ar"]	failed	2026-01-30 18:18:44.013	2026-01-30 18:18:44.02
512	api::nav-item.nav-item	ovkqi3j5gb2lgnlr4ouswb74	en	["ar"]	failed	2026-01-30 18:18:44.061	2026-01-30 18:18:44.068
515	api::nav-item.nav-item	jmodresyl36fod3cuwmb8q1e	en	["ar"]	failed	2026-01-30 18:18:44.187	2026-01-30 18:18:44.194
516	api::nav-item.nav-item	si37xkyrmogx8f8gw074j4z8	en	["ar"]	failed	2026-01-30 18:18:44.225	2026-01-30 18:18:44.232
517	api::nav-item.nav-item	o8vvlj8ve51wppzgqriu958d	en	["ar"]	failed	2026-01-30 18:18:44.267	2026-01-30 18:18:44.275
518	api::nav-item.nav-item	rmvrvicx420gwsmttsupir3u	en	["ar"]	failed	2026-01-30 18:18:44.307	2026-01-30 18:18:44.313
519	api::nav-item.nav-item	f8kjfmykuic87n4oq5smwq6i	en	["ar"]	failed	2026-01-30 18:18:44.349	2026-01-30 18:18:44.356
520	api::nav-item.nav-item	ibe5o4f91o2zug9phkntdsh6	en	["ar"]	failed	2026-01-30 18:18:44.397	2026-01-30 18:18:44.405
521	api::nav-item.nav-item	wnuvumue3x4lbte8ytbmr83q	en	["ar"]	failed	2026-01-30 18:18:44.446	2026-01-30 18:18:44.454
522	api::team-member.team-member	wfxkypmk0rpvaivtlbz5drau	en	["ar"]	failed	2026-01-30 18:18:44.661	2026-01-30 18:18:44.669
527	api::team-member.team-member	v9bi4z813g4he5edn4tzgs6v	en	["ar"]	failed	2026-01-30 18:18:44.889	2026-01-30 18:18:44.896
530	api::stat.stat	z99huyjw6zrse61d54nrvln2	en	["ar"]	failed	2026-01-30 18:18:45.007	2026-01-30 18:18:45.014
547	api::value.value	d680w77v6vhw7jk786pi58qc	en	["ar"]	failed	2026-01-30 18:18:45.683	2026-01-30 18:18:45.689
548	api::value.value	p3v9zqx13t56qmsq07eib6pc	en	["ar"]	failed	2026-01-30 18:18:45.719	2026-01-30 18:18:45.725
549	api::value.value	darw2vj9gh9fbzzi6gb3og0h	en	["ar"]	failed	2026-01-30 18:18:45.754	2026-01-30 18:18:45.761
559	api::faq.faq	e5va2j1ibgljs74b05z81k82	en	["ar"]	failed	2026-01-30 18:18:46.148	2026-01-30 18:18:46.155
560	api::faq.faq	v7ywhj37cvl764cezauz0f5b	en	["ar"]	failed	2026-01-30 18:18:46.185	2026-01-30 18:18:46.191
561	api::faq.faq	qf5pq80t9a507yj8aj21zhn2	en	["ar"]	failed	2026-01-30 18:18:46.219	2026-01-30 18:18:46.224
562	api::faq.faq	ipjdyql10frdiatc57uf0y3p	en	["ar"]	failed	2026-01-30 18:18:46.259	2026-01-30 18:18:46.265
563	api::faq.faq	ol7pspiirafqq04g4ary8rkp	en	["ar"]	failed	2026-01-30 18:18:46.294	2026-01-30 18:18:46.3
564	api::faq.faq	jb4wfle7qm7svvk4sbhqy0hq	en	["ar"]	failed	2026-01-30 18:18:46.329	2026-01-30 18:18:46.338
565	api::faq.faq	gpr95kfdlvaugfr2br39ro41	en	["ar"]	failed	2026-01-30 18:18:46.367	2026-01-30 18:18:46.373
566	api::faq.faq	eg3xmm6xkmgwsikgq0x6whr1	en	["ar"]	failed	2026-01-30 18:18:46.409	2026-01-30 18:18:46.417
567	api::faq.faq	q6hnl9m0dha5oj4z85bea7ib	en	["ar"]	failed	2026-01-30 18:18:46.447	2026-01-30 18:18:46.453
175	api::nav-item.nav-item	kh4m2h0znkffd84m59cmpkxb	en	["ar"]	failed	2026-01-30 14:17:24.219	2026-01-30 14:17:24.228
176	api::nav-item.nav-item	nyql2tja2yocq740mg9mf4a6	en	["ar"]	failed	2026-01-30 14:17:24.273	2026-01-30 14:17:24.287
177	api::feature.feature	xmcxff5edk472705mbqb71bl	en	["ar"]	failed	2026-01-30 14:17:24.643	2026-01-30 14:17:24.651
178	api::feature.feature	okon92nasoeif9oychpf026h	en	["ar"]	failed	2026-01-30 14:17:24.715	2026-01-30 14:17:24.722
179	api::feature.feature	mukat5cb666vp5d81toli0rg	en	["ar"]	failed	2026-01-30 14:17:24.785	2026-01-30 14:17:24.796
180	api::feature.feature	xdopmje4njvvqrzrf6ufyp3b	en	["ar"]	failed	2026-01-30 14:17:24.859	2026-01-30 14:17:24.867
181	api::feature.feature	akxamcikpepgsz2i6ypr56xg	en	["ar"]	failed	2026-01-30 14:17:24.928	2026-01-30 14:17:24.94
186	api::value.value	fh5kn0swwxb3ni1k3ddlxaoa	en	["ar"]	failed	2026-01-30 14:17:25.287	2026-01-30 14:17:25.297
187	api::value.value	f9f9lr81alrbdkgdbfs27s2c	en	["ar"]	failed	2026-01-30 14:17:25.36	2026-01-30 14:17:25.366
190	api::value.value	hrersmog4yigihu1wd9kpell	en	["ar"]	failed	2026-01-30 14:17:25.565	2026-01-30 14:17:25.573
488	api::contact-page.contact-page	zdj851gva7noajn8sr0udmkv	en	["ar"]	failed	2026-01-30 18:18:42.942	2026-01-30 18:18:42.952
494	api::case-studies-page.case-studies-page	k1g4t5kgflzg3fxy6mtz4yqu	en	["ar"]	failed	2026-01-30 18:18:43.256	2026-01-30 18:18:43.265
496	api::nav-item.nav-item	l4sgcr496pyn8zq43r8i4n37	en	["ar"]	failed	2026-01-30 18:18:43.356	2026-01-30 18:18:43.363
498	api::nav-item.nav-item	yvfzbkoejrivevwyonbsmlmt	en	["ar"]	failed	2026-01-30 18:18:43.446	2026-01-30 18:18:43.455
499	api::nav-item.nav-item	xgakndqsc0ehefkx5cizlnw7	en	["ar"]	failed	2026-01-30 18:18:43.491	2026-01-30 18:18:43.499
500	api::nav-item.nav-item	a0k9mfymdectpn282l1vajck	en	["ar"]	failed	2026-01-30 18:18:43.535	2026-01-30 18:18:43.542
501	api::nav-item.nav-item	w40u32x8qr65s1s4dcslqcfx	en	["ar"]	failed	2026-01-30 18:18:43.574	2026-01-30 18:18:43.581
502	api::nav-item.nav-item	g83zezotrpr8rpjjufogmmqy	en	["ar"]	failed	2026-01-30 18:18:43.619	2026-01-30 18:18:43.626
503	api::nav-item.nav-item	wv05oxybtxaiy2sp7rzb6sps	en	["ar"]	failed	2026-01-30 18:18:43.663	2026-01-30 18:18:43.669
504	api::nav-item.nav-item	zz5f6w6q4a75ia6ma7658m5u	en	["ar"]	failed	2026-01-30 18:18:43.707	2026-01-30 18:18:43.715
505	api::nav-item.nav-item	qmpjrhlrk6olmghoqkhi6wh2	en	["ar"]	failed	2026-01-30 18:18:43.753	2026-01-30 18:18:43.761
506	api::nav-item.nav-item	qjmbvsnny6jggsbxmpj2kwi3	en	["ar"]	failed	2026-01-30 18:18:43.799	2026-01-30 18:18:43.806
507	api::nav-item.nav-item	agq8sw7l8pzvw7s4bw4y30xk	en	["ar"]	failed	2026-01-30 18:18:43.838	2026-01-30 18:18:43.846
508	api::nav-item.nav-item	jfry982b0mf2csdm875iozrp	en	["ar"]	failed	2026-01-30 18:18:43.879	2026-01-30 18:18:43.887
513	api::nav-item.nav-item	va433bevugruzxp9qwnl2ofp	en	["ar"]	failed	2026-01-30 18:18:44.104	2026-01-30 18:18:44.112
514	api::nav-item.nav-item	whoow9wi4jbdzjxsuj8v6dx5	en	["ar"]	failed	2026-01-30 18:18:44.146	2026-01-30 18:18:44.155
729	api::nav-item.nav-item	rwc5crgcvb29bwvbfu3496za	en	["ar"]	failed	2026-01-31 14:26:39.013	2026-01-31 14:26:39.02
734	api::nav-item.nav-item	ljan3y2oxenu2seh4h7zkw25	en	["ar"]	failed	2026-01-31 14:26:39.201	2026-01-31 14:26:39.207
739	api::nav-item.nav-item	xpu0tzsvctuusywi3yxqyuht	en	["ar"]	failed	2026-01-31 14:26:39.397	2026-01-31 14:26:39.403
742	api::nav-item.nav-item	uo8kk35ao2gsjcp57hpyq4wx	en	["ar"]	failed	2026-01-31 14:26:39.501	2026-01-31 14:26:39.507
745	api::team-member.team-member	icmu9gqifqtiahwha6ewt2f6	en	["ar"]	failed	2026-01-31 14:26:39.911	2026-01-31 14:26:39.917
746	api::team-member.team-member	kqtmhjenix36i44knzbitg99	en	["ar"]	failed	2026-01-31 14:26:39.95	2026-01-31 14:26:39.956
748	api::team-member.team-member	n6fiblolftt8veh0cdxkynes	en	["ar"]	failed	2026-01-31 14:26:40.029	2026-01-31 14:26:40.035
760	api::feature.feature	zrmxz5bitrcgc72mnlk1byot	en	["ar"]	failed	2026-01-31 14:26:40.484	2026-01-31 14:26:40.491
769	api::value.value	xe0l9sz2b63f2fokxmdwhuhc	en	["ar"]	failed	2026-01-31 14:26:40.857	2026-01-31 14:26:40.862
770	api::value.value	fllz5uc6pbswhziffzozowoz	en	["ar"]	failed	2026-01-31 14:26:40.891	2026-01-31 14:26:40.898
771	api::value.value	ghaqlvns18smqw9ocm1uhg6f	en	["ar"]	failed	2026-01-31 14:26:40.929	2026-01-31 14:26:40.935
772	api::value.value	zfge5r155vtn177dnbp0e83z	en	["ar"]	failed	2026-01-31 14:26:40.966	2026-01-31 14:26:40.971
773	api::testimonial.testimonial	q27kez7zf8l5cvvvgpha34r4	en	["ar"]	failed	2026-01-31 14:26:41.009	2026-01-31 14:26:41.014
774	api::testimonial.testimonial	sy63dlv96hk2gspplz1mvhwb	en	["ar"]	failed	2026-01-31 14:26:41.046	2026-01-31 14:26:41.053
775	api::testimonial.testimonial	m1qw4xr03rth2swclnz0s48k	en	["ar"]	failed	2026-01-31 14:26:41.085	2026-01-31 14:26:41.091
777	api::testimonial.testimonial	bhetrmnl61lrzcepyg3o5y9e	en	["ar"]	failed	2026-01-31 14:26:41.161	2026-01-31 14:26:41.167
803	api::demo.demo	ji1wozbyg8grzt3nyyxkrrgu	en	["ar"]	failed	2026-01-31 14:26:42.101	2026-01-31 14:26:42.106
804	api::demo.demo	gny5zskovrx22lut0iiw6y9j	en	["ar"]	failed	2026-01-31 14:26:42.138	2026-01-31 14:26:42.144
805	api::case-study.case-study	lvn1gx7d0prok3xfdalh0grs	en	["ar"]	failed	2026-01-31 14:26:42.179	2026-01-31 14:26:42.185
806	api::case-study.case-study	uguxdzxuixl73kj1zbnzy71z	en	["ar"]	failed	2026-01-31 14:26:42.215	2026-01-31 14:26:42.221
807	api::case-study.case-study	agcveufo0a7pn5hqiy1nko98	en	["ar"]	failed	2026-01-31 14:26:42.252	2026-01-31 14:26:42.258
808	api::case-study.case-study	fjow9bjor6vsnao5gvhho0qg	en	["ar"]	failed	2026-01-31 14:26:42.289	2026-01-31 14:26:42.298
809	api::case-study.case-study	sbddrm25uuk8x0oa9py099f4	en	["ar"]	failed	2026-01-31 14:26:42.33	2026-01-31 14:26:42.335
817	api::industry.industry	w6b1tw88kasd2ekzl6j50dn7	en	["ar"]	failed	2026-01-31 14:26:42.666	2026-01-31 14:26:42.673
818	api::industry.industry	v37xntip938konfu7qtconk7	en	["ar"]	failed	2026-01-31 14:26:42.704	2026-01-31 14:26:42.71
819	api::industry.industry	u9ya1nyxcoqj3gycpuz8lwok	en	["ar"]	failed	2026-01-31 14:26:42.741	2026-01-31 14:26:42.747
820	api::industry.industry	limhvz968pk91dofies61eex	en	["ar"]	failed	2026-01-31 14:26:42.781	2026-01-31 14:26:42.788
821	api::industry.industry	o85yvj2hppc1pb1dav0toejn	en	["ar"]	failed	2026-01-31 14:26:42.819	2026-01-31 14:26:42.825
865	api::process-step.process-step	qsggg0u2r8slbr6ljdo7lst8	en	["ar"]	failed	2026-01-31 14:35:44.133	2026-01-31 14:35:44.14
866	api::process-step.process-step	bytx9ktrnqu01qijgicd5tap	en	["ar"]	failed	2026-01-31 14:35:44.17	2026-01-31 14:35:44.175
867	api::feature.feature	ritl58xtqnksa3jc8g9tvye3	en	["ar"]	failed	2026-01-31 14:35:44.207	2026-01-31 14:35:44.214
871	api::feature.feature	sgimpmjibmqegcx0c4rtqyl4	en	["ar"]	failed	2026-01-31 14:35:44.355	2026-01-31 14:35:44.361
872	api::feature.feature	aqtq9lewtwzn53ajljfegabj	en	["ar"]	failed	2026-01-31 14:35:44.393	2026-01-31 14:35:44.399
873	api::feature.feature	ewykbrhzhm0e19hw86ao6dcr	en	["ar"]	failed	2026-01-31 14:35:44.427	2026-01-31 14:35:44.434
877	api::value.value	rt5o2w3nqwdjv9r51qm7ftjs	en	["ar"]	failed	2026-01-31 14:35:44.575	2026-01-31 14:35:44.58
886	api::testimonial.testimonial	qwebn4ui2xgillairs8bxbor	en	["ar"]	failed	2026-01-31 14:35:44.897	2026-01-31 14:35:44.903
887	api::faq.faq	j6szjj4jy59xrzzf9a27hyn2	en	["ar"]	failed	2026-01-31 14:35:44.944	2026-01-31 14:35:44.949
890	api::faq.faq	n7qq0iytwz2cg3uv5ltg6mym	en	["ar"]	failed	2026-01-31 14:35:45.041	2026-01-31 14:35:45.048
182	api::feature.feature	xxopspqhwd5wa36uklzj09il	en	["ar"]	failed	2026-01-30 14:17:25.001	2026-01-30 14:17:25.007
183	api::feature.feature	apq34e9g85zgu1vzoft5cfwf	en	["ar"]	failed	2026-01-30 14:17:25.071	2026-01-30 14:17:25.077
184	api::feature.feature	gshyklm5wf8whfvfjzy0rs6u	en	["ar"]	failed	2026-01-30 14:17:25.143	2026-01-30 14:17:25.15
189	api::value.value	z9oqtf8yarxhlpfs48nk1anu	en	["ar"]	failed	2026-01-30 14:17:25.495	2026-01-30 14:17:25.504
215	api::partner.partner	g4nubzrjv3a83sbhvr89ncg9	en	["ar"]	failed	2026-01-30 14:17:27.056	2026-01-30 14:17:27.061
216	api::partner.partner	qbw92czgjvqd28c8xtb56s9c	en	["ar"]	failed	2026-01-30 14:17:27.118	2026-01-30 14:17:27.125
217	api::nav-item.nav-item	qml569g7l96ps6g7y6b03rrg	en	["ar"]	failed	2026-01-30 15:39:04.299	2026-01-30 15:39:04.309
218	api::nav-item.nav-item	z17u0ipiy7igighlooomk9jq	en	["ar"]	failed	2026-01-30 15:39:04.361	2026-01-30 15:39:04.371
219	api::nav-item.nav-item	ja37yxbj6s2elnzjiozfoo53	en	["ar"]	failed	2026-01-30 15:39:04.446	2026-01-30 15:39:04.455
220	api::nav-item.nav-item	z7lx9phzz6x75i9sxiyxpsde	en	["ar"]	failed	2026-01-30 15:39:04.508	2026-01-30 15:39:04.515
221	api::nav-item.nav-item	z0qomm9fye27l2xfycp2qzx6	en	["ar"]	failed	2026-01-30 15:39:04.56	2026-01-30 15:39:04.568
222	api::nav-item.nav-item	e1xft54oktx53gvnrhz5r4jk	en	["ar"]	failed	2026-01-30 15:39:04.611	2026-01-30 15:39:04.618
223	api::nav-item.nav-item	ca27i7h5s4dvsdwg7ew6v58a	en	["ar"]	failed	2026-01-30 15:39:04.664	2026-01-30 15:39:04.671
224	api::nav-item.nav-item	c7hhj3roki8ndt97ccm92w7w	en	["ar"]	failed	2026-01-30 15:39:04.719	2026-01-30 15:39:04.733
225	api::nav-item.nav-item	p0mctt5dc1l4umtv2q7ydsdp	en	["ar"]	failed	2026-01-30 15:39:04.771	2026-01-30 15:39:04.782
226	api::nav-item.nav-item	xxggy5zyy8n30fvgq8tpe2a5	en	["ar"]	failed	2026-01-30 15:39:04.831	2026-01-30 15:39:04.839
227	api::nav-item.nav-item	gsprs3d3umli1r29rxx04h0o	en	["ar"]	failed	2026-01-30 15:39:04.882	2026-01-30 15:39:04.889
228	api::nav-item.nav-item	lo9cl8t0ner6tsiaaey3me6l	en	["ar"]	failed	2026-01-30 15:39:04.931	2026-01-30 15:39:04.937
229	api::nav-item.nav-item	ygc4iq5emmv2x3aw1vcgcytg	en	["ar"]	failed	2026-01-30 15:39:04.974	2026-01-30 15:39:04.985
230	api::nav-item.nav-item	pus6nlh4d003j41got08q4ir	en	["ar"]	failed	2026-01-30 15:39:05.023	2026-01-30 15:39:05.033
231	api::nav-item.nav-item	jtfb59hswh6r1dxt5kv0qani	en	["ar"]	failed	2026-01-30 15:39:05.07	2026-01-30 15:39:05.084
232	api::nav-item.nav-item	oxlqgpiscqn33jaoy2s2cnf0	en	["ar"]	failed	2026-01-30 15:39:05.119	2026-01-30 15:39:05.132
233	api::nav-item.nav-item	m7pplg5a08665rpjutax3bl7	en	["ar"]	failed	2026-01-30 15:39:05.167	2026-01-30 15:39:05.173
234	api::nav-item.nav-item	xouri4r4ucagisz5zb5nodl4	en	["ar"]	failed	2026-01-30 15:39:05.21	2026-01-30 15:39:05.217
235	api::nav-item.nav-item	he2t38pnrjvkm899pqn4n0b2	en	["ar"]	failed	2026-01-30 15:39:05.257	2026-01-30 15:39:05.267
236	api::nav-item.nav-item	snf4dt2bc337wrdr7erfejbm	en	["ar"]	failed	2026-01-30 15:39:05.305	2026-01-30 15:39:05.312
237	api::nav-item.nav-item	dhgz8g37i6d3m26rrnjbb35q	en	["ar"]	failed	2026-01-30 15:39:05.402	2026-01-30 15:39:05.41
238	api::nav-item.nav-item	qjy0yb0c1okv3i81070qq6b2	en	["ar"]	failed	2026-01-30 15:39:05.451	2026-01-30 15:39:05.46
239	api::nav-item.nav-item	gdt5f3hi9f4xbob1j3p95r6v	en	["ar"]	failed	2026-01-30 15:39:05.501	2026-01-30 15:39:05.509
240	api::nav-item.nav-item	g9hat6hk31vlwwnnp54mrvw9	en	["ar"]	failed	2026-01-30 15:39:05.546	2026-01-30 15:39:05.552
241	api::feature.feature	y77s571ctmu3li0dt606vv2u	en	["ar"]	failed	2026-01-30 15:39:05.922	2026-01-30 15:39:05.936
242	api::feature.feature	is2137cd7lniwt29mmd28sqz	en	["ar"]	failed	2026-01-30 15:39:05.993	2026-01-30 15:39:05.999
243	api::feature.feature	vjozukabzs1et1d5g0x7sq3v	en	["ar"]	failed	2026-01-30 15:39:06.057	2026-01-30 15:39:06.063
244	api::feature.feature	nuivmcra6032uvfdm40mg1jr	en	["ar"]	failed	2026-01-30 15:39:06.122	2026-01-30 15:39:06.138
245	api::feature.feature	i4l6v2tixeqhkjpvm80m892b	en	["ar"]	failed	2026-01-30 15:39:06.199	2026-01-30 15:39:06.205
246	api::feature.feature	gto31emz30rra4s8b7i9u9py	en	["ar"]	failed	2026-01-30 15:39:06.264	2026-01-30 15:39:06.27
247	api::feature.feature	lqunuw5tc89ikxay1f0xsex2	en	["ar"]	failed	2026-01-30 15:39:06.348	2026-01-30 15:39:06.356
248	api::feature.feature	hlu535ir0p570b2ofdcologe	en	["ar"]	failed	2026-01-30 15:39:06.413	2026-01-30 15:39:06.421
249	api::value.value	fpwomjz7i6zptw1vim490y7f	en	["ar"]	failed	2026-01-30 15:39:06.49	2026-01-30 15:39:06.496
250	api::value.value	hlhvfk49679xo61h7dcuqhnl	en	["ar"]	failed	2026-01-30 15:39:06.554	2026-01-30 15:39:06.56
251	api::value.value	xjua5k5many9sbx6qambqn1i	en	["ar"]	failed	2026-01-30 15:39:06.612	2026-01-30 15:39:06.618
252	api::value.value	ea7f5paszs7eory2fkgnaxv0	en	["ar"]	failed	2026-01-30 15:39:06.673	2026-01-30 15:39:06.687
253	api::value.value	ma75shc2ym033245jgatz8f3	en	["ar"]	failed	2026-01-30 15:39:06.738	2026-01-30 15:39:06.745
254	api::value.value	hgjcpkiinviyi1qk6f1281ix	en	["ar"]	failed	2026-01-30 15:39:06.797	2026-01-30 15:39:06.802
255	api::testimonial.testimonial	xmhsy6ruhv7thgqk8t7xwnro	en	["ar"]	failed	2026-01-30 15:39:06.862	2026-01-30 15:39:06.869
256	api::testimonial.testimonial	d6ss97xsimqipmc2xm8hgo0s	en	["ar"]	failed	2026-01-30 15:39:06.911	2026-01-30 15:39:06.92
257	api::testimonial.testimonial	xebb2lg3o0edxbwhtnu67gve	en	["ar"]	failed	2026-01-30 15:39:06.953	2026-01-30 15:39:06.959
258	api::testimonial.testimonial	o4or4c8hjmewx1roh3fja1b2	en	["ar"]	failed	2026-01-30 15:39:06.997	2026-01-30 15:39:07.003
259	api::testimonial.testimonial	wl3yac9al1s177vcrfg43y50	en	["ar"]	failed	2026-01-30 15:39:07.04	2026-01-30 15:39:07.047
260	api::testimonial.testimonial	b4haoku42786nr6c59xf1az4	en	["ar"]	failed	2026-01-30 15:39:07.086	2026-01-30 15:39:07.092
261	api::faq.faq	vs0rmezicbkl0waxg6g6q3i6	en	["ar"]	failed	2026-01-30 15:39:07.127	2026-01-30 15:39:07.138
262	api::faq.faq	guulfw151451h6f6fzm458xd	en	["ar"]	failed	2026-01-30 15:39:07.177	2026-01-30 15:39:07.187
263	api::faq.faq	hfq9haj80tilvs6u4it8n04z	en	["ar"]	failed	2026-01-30 15:39:07.225	2026-01-30 15:39:07.239
264	api::faq.faq	pnptskjyl3c0u7jrayizkpfi	en	["ar"]	failed	2026-01-30 15:39:07.275	2026-01-30 15:39:07.287
265	api::faq.faq	zt3gagfuydbxsb2czspxwn9a	en	["ar"]	failed	2026-01-30 15:39:07.321	2026-01-30 15:39:07.329
266	api::faq.faq	xmp33zlfyvh4psf7s4546ko9	en	["ar"]	failed	2026-01-30 15:39:07.369	2026-01-30 15:39:07.376
267	api::faq.faq	hsg4mbe35xww4gqs4cmv9qgg	en	["ar"]	failed	2026-01-30 15:39:07.414	2026-01-30 15:39:07.422
268	api::faq.faq	w7zb2m9bs5gys197lg28kzfh	en	["ar"]	failed	2026-01-30 15:39:07.469	2026-01-30 15:39:07.477
269	api::faq.faq	nqirj2c2peeq3dqlho6h2pir	en	["ar"]	failed	2026-01-30 15:39:07.516	2026-01-30 15:39:07.52
270	api::faq.faq	o7urpq87s00uhbw32zg61zek	en	["ar"]	failed	2026-01-30 15:39:07.567	2026-01-30 15:39:07.573
271	api::pricing-plan.pricing-plan	adqdwuavcn5hprfxmp9e1s44	en	["ar"]	failed	2026-01-30 15:39:07.623	2026-01-30 15:39:07.636
272	api::pricing-plan.pricing-plan	ryl7f1q0pn3jf4z4a5kxmesw	en	["ar"]	failed	2026-01-30 15:39:07.676	2026-01-30 15:39:07.69
273	api::pricing-plan.pricing-plan	uk4r69821v4ckadn2ard7eco	en	["ar"]	failed	2026-01-30 15:39:07.727	2026-01-30 15:39:07.74
274	api::pricing-plan.pricing-plan	nj9mtkdeuktyvhqsa19lemx4	en	["ar"]	failed	2026-01-30 15:39:07.782	2026-01-30 15:39:07.799
275	api::partner.partner	m61n9wrzo0dwoqd8dqmzi37d	en	["ar"]	failed	2026-01-30 15:39:07.854	2026-01-30 15:39:07.862
276	api::partner.partner	cr5v6c6ghcufb4xizsgkdrhw	en	["ar"]	failed	2026-01-30 15:39:07.91	2026-01-30 15:39:07.917
493	api::demos-page.demos-page	ykxxlf848bgvbfirle8citsp	en	["ar"]	failed	2026-01-30 18:18:43.203	2026-01-30 18:18:43.211
497	api::nav-item.nav-item	hrzgt72ub8jm4e3ftrms0uyp	en	["ar"]	failed	2026-01-30 18:18:43.396	2026-01-30 18:18:43.404
532	api::stat.stat	ggacr0iflsppqqp77ggyfu1s	en	["ar"]	failed	2026-01-30 18:18:45.089	2026-01-30 18:18:45.094
533	api::stat.stat	pymy6iacdargxg3dw1do183q	en	["ar"]	failed	2026-01-30 18:18:45.132	2026-01-30 18:18:45.139
534	api::process-step.process-step	qqyjxtl2n63w1lcupjhr2pyx	en	["ar"]	failed	2026-01-30 18:18:45.184	2026-01-30 18:18:45.19
535	api::process-step.process-step	y5cfo2qcvfrjyt4i2e1hsp2b	en	["ar"]	failed	2026-01-30 18:18:45.222	2026-01-30 18:18:45.231
536	api::process-step.process-step	xdbuck3q9zdbdi5bkbi7cgpi	en	["ar"]	failed	2026-01-30 18:18:45.264	2026-01-30 18:18:45.27
537	api::process-step.process-step	va2tqarc1dhg7q91rbdfqotz	en	["ar"]	failed	2026-01-30 18:18:45.306	2026-01-30 18:18:45.312
538	api::feature.feature	midl6kjouzvf0w346s7eehce	en	["ar"]	failed	2026-01-30 18:18:45.349	2026-01-30 18:18:45.356
539	api::feature.feature	jnbpf3xbfwd8s6mkrrv4qojl	en	["ar"]	failed	2026-01-30 18:18:45.386	2026-01-30 18:18:45.394
540	api::feature.feature	t6u90g9zii4cf007q64e5ao9	en	["ar"]	failed	2026-01-30 18:18:45.42	2026-01-30 18:18:45.427
541	api::feature.feature	q6sz4zmgh5g7vwrzivuqxy6t	en	["ar"]	failed	2026-01-30 18:18:45.459	2026-01-30 18:18:45.465
542	api::feature.feature	lzx4x43kzzh1ty3qy5yo3hry	en	["ar"]	failed	2026-01-30 18:18:45.496	2026-01-30 18:18:45.503
543	api::feature.feature	gn0lthbliz56shcl2yjnlgw2	en	["ar"]	failed	2026-01-30 18:18:45.533	2026-01-30 18:18:45.539
553	api::testimonial.testimonial	n5savc0wwmy19jtftka6buc6	en	["ar"]	failed	2026-01-30 18:18:45.906	2026-01-30 18:18:45.912
556	api::testimonial.testimonial	xdsfqj4itwrnw086uzh4giwc	en	["ar"]	failed	2026-01-30 18:18:46.023	2026-01-30 18:18:46.029
557	api::testimonial.testimonial	z0ovc7vux0d784b6uw7j9jhk	en	["ar"]	failed	2026-01-30 18:18:46.063	2026-01-30 18:18:46.069
558	api::faq.faq	tu18q591jjftd3d8raojpd16	en	["ar"]	failed	2026-01-30 18:18:46.11	2026-01-30 18:18:46.116
744	api::team-member.team-member	brct95rbw9ert4bxb67f62jf	en	["ar"]	failed	2026-01-31 14:26:39.868	2026-01-31 14:26:39.875
753	api::stat.stat	lss0t6rsstxw4srs1j05xq3p	en	["ar"]	failed	2026-01-31 14:26:40.219	2026-01-31 14:26:40.225
763	api::feature.feature	tvstmle8mdzdtsx82p6gqsp6	en	["ar"]	failed	2026-01-31 14:26:40.599	2026-01-31 14:26:40.606
764	api::feature.feature	ljc3ggo8fxwjna7lopo1hacc	en	["ar"]	failed	2026-01-31 14:26:40.634	2026-01-31 14:26:40.64
776	api::testimonial.testimonial	xsfmprnavacx3nky0co0sakf	en	["ar"]	failed	2026-01-31 14:26:41.123	2026-01-31 14:26:41.129
781	api::faq.faq	azocamosjmmffqd1it00ellf	en	["ar"]	failed	2026-01-31 14:26:41.319	2026-01-31 14:26:41.326
784	api::faq.faq	sg88adwib2gie6v2cz5cd3vo	en	["ar"]	failed	2026-01-31 14:26:41.438	2026-01-31 14:26:41.445
787	api::faq.faq	ddujk6ux0x6z7ah6fl5fo0yt	en	["ar"]	failed	2026-01-31 14:26:41.539	2026-01-31 14:26:41.545
791	api::pricing-plan.pricing-plan	aiki0l86b0aeaw5nak1drq1k	en	["ar"]	failed	2026-01-31 14:26:41.675	2026-01-31 14:26:41.683
793	api::partner.partner	d3sst9e86v80gl8fa84svet5	en	["ar"]	failed	2026-01-31 14:26:41.751	2026-01-31 14:26:41.758
795	api::partner.partner	nxp95lk0bl0zxjbqf41uvovb	en	["ar"]	failed	2026-01-31 14:26:41.817	2026-01-31 14:26:41.824
798	api::partner.partner	ln7ejzycsald3n6c9a2p4s3f	en	["ar"]	failed	2026-01-31 14:26:41.915	2026-01-31 14:26:41.922
815	api::solution.solution	uvrf543q8ulw6jc0d6hp02hf	en	["ar"]	failed	2026-01-31 14:26:42.577	2026-01-31 14:26:42.584
870	api::feature.feature	ehz9le81mb7heqodnrvfiw7p	en	["ar"]	failed	2026-01-31 14:35:44.314	2026-01-31 14:35:44.321
878	api::value.value	qikrt12hi03z8yk0pak3fvz2	en	["ar"]	failed	2026-01-31 14:35:44.608	2026-01-31 14:35:44.614
879	api::value.value	zj51fsiqglsse6m4t34zti9g	en	["ar"]	failed	2026-01-31 14:35:44.642	2026-01-31 14:35:44.649
880	api::value.value	m4ei5uwdzrl94wt3lpsv2ezh	en	["ar"]	failed	2026-01-31 14:35:44.677	2026-01-31 14:35:44.685
881	api::testimonial.testimonial	z34979mu5fowbz0hjayzcknl	en	["ar"]	failed	2026-01-31 14:35:44.718	2026-01-31 14:35:44.724
884	api::testimonial.testimonial	kwn7ot9ap3wd5ct4bnf6ss8h	en	["ar"]	failed	2026-01-31 14:35:44.825	2026-01-31 14:35:44.831
885	api::testimonial.testimonial	s4qy02kiymfxe4xzgkuo2kfm	en	["ar"]	failed	2026-01-31 14:35:44.857	2026-01-31 14:35:44.863
889	api::faq.faq	kn7jmqjbnj0lph84r81sujmi	en	["ar"]	failed	2026-01-31 14:35:45.009	2026-01-31 14:35:45.015
892	api::faq.faq	bohm3ty49r1k7sbupy6w0nsv	en	["ar"]	failed	2026-01-31 14:35:45.109	2026-01-31 14:35:45.117
897	api::pricing-plan.pricing-plan	c3gh6kzb48w4xzy5e1fd6hxd	en	["ar"]	failed	2026-01-31 14:35:45.272	2026-01-31 14:35:45.279
899	api::pricing-plan.pricing-plan	qjlnor7ltn3rumsbpc7uekem	en	["ar"]	failed	2026-01-31 14:35:45.344	2026-01-31 14:35:45.35
901	api::partner.partner	npliz7sod11ydtne3i34m984	en	["ar"]	failed	2026-01-31 14:35:45.412	2026-01-31 14:35:45.418
904	api::partner.partner	trns63r4ly0ha57tw7tg2bre	en	["ar"]	failed	2026-01-31 14:35:45.516	2026-01-31 14:35:45.522
907	api::demo.demo	k4at4uhkvjx9xq2zezl9codx	en	["ar"]	failed	2026-01-31 14:35:45.62	2026-01-31 14:35:45.627
912	api::demo.demo	nk76rp8s866opunq4flaswna	en	["ar"]	failed	2026-01-31 14:35:45.787	2026-01-31 14:35:45.793
916	api::case-study.case-study	iekewxuoxsj7v590zpbjpv73	en	["ar"]	failed	2026-01-31 14:35:45.912	2026-01-31 14:35:45.919
918	api::solution.solution	ddid1j92wotw99icwo3v8tzw	en	["ar"]	failed	2026-01-31 14:35:45.985	2026-01-31 14:35:45.992
921	api::solution.solution	k2au8vr1jiwdfhfkl6g4csmr	en	["ar"]	failed	2026-01-31 14:35:46.086	2026-01-31 14:35:46.093
925	api::industry.industry	y5vnon5ve9j3qf4w44gbizib	en	["ar"]	failed	2026-01-31 14:35:46.221	2026-01-31 14:35:46.228
927	api::industry.industry	l8y989fvzxuct77glkd5ex11	en	["ar"]	failed	2026-01-31 14:35:46.292	2026-01-31 14:35:46.299
929	api::industry.industry	fwc60idj87cy2os1ukl60bp1	en	["ar"]	failed	2026-01-31 14:35:46.358	2026-01-31 14:35:46.364
962	api::team-member.team-member	c0h7nfbqvx43h9tm6k7518s3	en	["ar"]	failed	2026-01-31 14:38:47.285	2026-01-31 14:38:47.292
1054	api::nav-item.nav-item	noppdtunqx2ve0q9wsiw2m5y	en	["ar"]	failed	2026-01-31 14:46:03.808	2026-01-31 14:46:03.815
1055	api::nav-item.nav-item	evwg5v2tcjbp24x1tfdsaga4	en	["ar"]	failed	2026-01-31 14:46:03.858	2026-01-31 14:46:03.865
1056	api::nav-item.nav-item	qbs91ywr2xelk81yorx5mtex	en	["ar"]	failed	2026-01-31 14:46:03.904	2026-01-31 14:46:03.909
1057	api::nav-item.nav-item	zqv5dkxrax93pxahzy7th2ra	en	["ar"]	failed	2026-01-31 14:46:03.943	2026-01-31 14:46:03.95
1058	api::nav-item.nav-item	p8e0f1b93zes4jc2u2cgz18f	en	["ar"]	failed	2026-01-31 14:46:03.983	2026-01-31 14:46:03.994
1059	api::nav-item.nav-item	epfyx5w8m9xcucm7cs4dixbp	en	["ar"]	failed	2026-01-31 14:46:04.028	2026-01-31 14:46:04.035
1060	api::nav-item.nav-item	eb7gp11w11t4z3p5c3xe73hy	en	["ar"]	failed	2026-01-31 14:46:04.07	2026-01-31 14:46:04.077
1061	api::nav-item.nav-item	xef2k6vn90fx1jmw9ogc3cp0	en	["ar"]	failed	2026-01-31 14:46:04.117	2026-01-31 14:46:04.124
1062	api::nav-item.nav-item	kd9lyoc6cetjhud64bgb09cy	en	["ar"]	failed	2026-01-31 14:46:04.164	2026-01-31 14:46:04.17
1065	api::team-member.team-member	iv604epv4q8a3wacjxzyfzog	en	["ar"]	failed	2026-01-31 14:46:04.625	2026-01-31 14:46:04.631
277	api::partner.partner	oes2yvpfn7znpx0jp3x3604p	en	["ar"]	failed	2026-01-30 15:39:07.956	2026-01-30 15:39:07.962
278	api::partner.partner	h4vealnnkkmm1yojfr7z9g5i	en	["ar"]	failed	2026-01-30 15:39:08.006	2026-01-30 15:39:08.012
279	api::partner.partner	mfrub78sruw9oidymwqpfb8g	en	["ar"]	failed	2026-01-30 15:39:08.054	2026-01-30 15:39:08.061
525	api::team-member.team-member	p92k1mn0eki62w9n7m9eyuef	en	["ar"]	failed	2026-01-30 18:18:44.799	2026-01-30 18:18:44.805
528	api::stat.stat	typ511z4s15pwanppld4djbw	en	["ar"]	failed	2026-01-30 18:18:44.93	2026-01-30 18:18:44.939
529	api::stat.stat	o1xivj864s582431slikv69g	en	["ar"]	failed	2026-01-30 18:18:44.969	2026-01-30 18:18:44.976
531	api::stat.stat	bmj7p348829pw5f8bcxykezf	en	["ar"]	failed	2026-01-30 18:18:45.05	2026-01-30 18:18:45.057
544	api::feature.feature	qaagrpp7iu495nq6rhigp911	en	["ar"]	failed	2026-01-30 18:18:45.571	2026-01-30 18:18:45.578
545	api::feature.feature	vxcazdvukyt62ad8ozwmvntk	en	["ar"]	failed	2026-01-30 18:18:45.608	2026-01-30 18:18:45.614
546	api::value.value	cyus3i632uky9wpccoaefv84	en	["ar"]	failed	2026-01-30 18:18:45.648	2026-01-30 18:18:45.654
568	api::pricing-plan.pricing-plan	ft3fhikbzqzqaokaf5mrr1kx	en	["ar"]	failed	2026-01-30 18:18:46.491	2026-01-30 18:18:46.498
579	api::demo.demo	l7pvfpt36e6lpyzs1h2ams5e	en	["ar"]	failed	2026-01-30 18:18:46.925	2026-01-30 18:18:46.931
582	api::demo.demo	a66vegjhpjstd93rnenqgv2x	en	["ar"]	failed	2026-01-30 18:18:47.028	2026-01-30 18:18:47.035
585	api::case-study.case-study	gatf4vjguywsjam79sw73bsn	en	["ar"]	failed	2026-01-30 18:18:47.131	2026-01-30 18:18:47.137
588	api::case-study.case-study	u7b7vlfvpfl6eyam7oxml33d	en	["ar"]	failed	2026-01-30 18:18:47.231	2026-01-30 18:18:47.238
590	api::solution.solution	jttjl27jparr5i4e0b1x7qri	en	["ar"]	failed	2026-01-30 18:18:47.302	2026-01-30 18:18:47.307
592	api::solution.solution	tp1v0g9mwwc85l8cr06uph1k	en	["ar"]	failed	2026-01-30 18:18:47.368	2026-01-30 18:18:47.374
595	api::industry.industry	bn3pijiba064cpswricg4tyj	en	["ar"]	failed	2026-01-30 18:18:47.466	2026-01-30 18:18:47.471
598	api::industry.industry	ahi4chuql6uq3voxc68rybjd	en	["ar"]	failed	2026-01-30 18:18:47.592	2026-01-30 18:18:47.599
755	api::process-step.process-step	a9dzen7q425u8pkq1holvgnk	en	["ar"]	failed	2026-01-31 14:26:40.295	2026-01-31 14:26:40.302
756	api::process-step.process-step	j2og0abaon047vl64t7o2vdy	en	["ar"]	failed	2026-01-31 14:26:40.333	2026-01-31 14:26:40.339
757	api::process-step.process-step	dc7szsgcpo9ew5acrwvjlke6	en	["ar"]	failed	2026-01-31 14:26:40.369	2026-01-31 14:26:40.375
758	api::process-step.process-step	pi7xpxz9gyi3ifw40g9xzq9c	en	["ar"]	failed	2026-01-31 14:26:40.409	2026-01-31 14:26:40.415
759	api::feature.feature	hlqo5y18cqw6kiidqbx0uku7	en	["ar"]	failed	2026-01-31 14:26:40.447	2026-01-31 14:26:40.452
765	api::feature.feature	rxp1y9oeczxtjtwsoe7y2dur	en	["ar"]	failed	2026-01-31 14:26:40.671	2026-01-31 14:26:40.681
766	api::feature.feature	t9mwu7lx6bdnlwct3dv6xcji	en	["ar"]	failed	2026-01-31 14:26:40.736	2026-01-31 14:26:40.743
767	api::value.value	tlt8mq3ei9adl61b1yhpun1z	en	["ar"]	failed	2026-01-31 14:26:40.778	2026-01-31 14:26:40.787
768	api::value.value	dw68kt5834uw4gszn3fpl5th	en	["ar"]	failed	2026-01-31 14:26:40.819	2026-01-31 14:26:40.825
778	api::testimonial.testimonial	nktjeb2o7mb0c87xp3hidss1	en	["ar"]	failed	2026-01-31 14:26:41.197	2026-01-31 14:26:41.203
780	api::faq.faq	ka7q1gy5zjgwdynmzqpl57ek	en	["ar"]	failed	2026-01-31 14:26:41.27	2026-01-31 14:26:41.277
783	api::faq.faq	p1zwo5yalq701oderu5vo6ab	en	["ar"]	failed	2026-01-31 14:26:41.405	2026-01-31 14:26:41.412
786	api::faq.faq	jssi069q9lwwobdiv1fn3v7f	en	["ar"]	failed	2026-01-31 14:26:41.507	2026-01-31 14:26:41.514
788	api::faq.faq	b37lyskokje9j6ipkog2kldf	en	["ar"]	failed	2026-01-31 14:26:41.571	2026-01-31 14:26:41.578
790	api::pricing-plan.pricing-plan	lw5w9wwvbhh6u0fvsc9vtmbe	en	["ar"]	failed	2026-01-31 14:26:41.639	2026-01-31 14:26:41.646
794	api::partner.partner	eqkzjep6z6wzv71hftfnaco3	en	["ar"]	failed	2026-01-31 14:26:41.783	2026-01-31 14:26:41.789
797	api::partner.partner	uc85trsxapc2ycxqarv3plfc	en	["ar"]	failed	2026-01-31 14:26:41.882	2026-01-31 14:26:41.889
799	api::demo.demo	k9lac8yx6v4mep7w8fr8gb43	en	["ar"]	failed	2026-01-31 14:26:41.949	2026-01-31 14:26:41.955
800	api::demo.demo	n6binqvdsfdtwgmlka23rfth	en	["ar"]	failed	2026-01-31 14:26:41.989	2026-01-31 14:26:41.996
801	api::demo.demo	qcsiay0jc2jql1czp7gjazrf	en	["ar"]	failed	2026-01-31 14:26:42.025	2026-01-31 14:26:42.031
810	api::solution.solution	ftz7es9hv1j7klvyh89o1tst	en	["ar"]	failed	2026-01-31 14:26:42.372	2026-01-31 14:26:42.379
811	api::solution.solution	i9c4ztamcs8vk22cyf1z0w3f	en	["ar"]	failed	2026-01-31 14:26:42.413	2026-01-31 14:26:42.42
812	api::solution.solution	rx8d2ya9d2kt1afcdvakymgt	en	["ar"]	failed	2026-01-31 14:26:42.457	2026-01-31 14:26:42.465
813	api::solution.solution	wbdeijw70qertqrai4rhhypf	en	["ar"]	failed	2026-01-31 14:26:42.501	2026-01-31 14:26:42.508
814	api::solution.solution	jkk8150oepq98odyieb6rk9i	en	["ar"]	failed	2026-01-31 14:26:42.538	2026-01-31 14:26:42.544
816	api::industry.industry	m7bybwg4xo42evtshteovh4s	en	["ar"]	failed	2026-01-31 14:26:42.624	2026-01-31 14:26:42.631
893	api::faq.faq	b2toaivuppluoftd54725jev	en	["ar"]	failed	2026-01-31 14:35:45.142	2026-01-31 14:35:45.148
895	api::faq.faq	rfzk21ke53c1hbyfynlj6b8b	en	["ar"]	failed	2026-01-31 14:35:45.203	2026-01-31 14:35:45.209
898	api::pricing-plan.pricing-plan	pivpia9kuv5qdt6nrmzq1lgn	en	["ar"]	failed	2026-01-31 14:35:45.31	2026-01-31 14:35:45.318
900	api::pricing-plan.pricing-plan	shv9ttqs2y5yfus9o94zh1yx	en	["ar"]	failed	2026-01-31 14:35:45.379	2026-01-31 14:35:45.386
903	api::partner.partner	zyldx49hjrnl273iwcnro8nt	en	["ar"]	failed	2026-01-31 14:35:45.48	2026-01-31 14:35:45.486
905	api::partner.partner	h0btbbzxp07zfon9pba6zm2p	en	["ar"]	failed	2026-01-31 14:35:45.546	2026-01-31 14:35:45.554
908	api::demo.demo	rpljblipk4kafh9ion3v5wub	en	["ar"]	failed	2026-01-31 14:35:45.652	2026-01-31 14:35:45.66
910	api::demo.demo	n55g3ak16smizih4foc0y3x6	en	["ar"]	failed	2026-01-31 14:35:45.721	2026-01-31 14:35:45.727
914	api::case-study.case-study	ayr4e7j9qqqm0s9ry43k47m7	en	["ar"]	failed	2026-01-31 14:35:45.849	2026-01-31 14:35:45.857
920	api::solution.solution	g87bspoqi7qcwrt7jtuvjjsz	en	["ar"]	failed	2026-01-31 14:35:46.051	2026-01-31 14:35:46.058
922	api::solution.solution	x0elgergusqxke4p5q88ldbh	en	["ar"]	failed	2026-01-31 14:35:46.115	2026-01-31 14:35:46.123
924	api::industry.industry	vh4olzrv0aqfa3zzf1gnp7lk	en	["ar"]	failed	2026-01-31 14:35:46.186	2026-01-31 14:35:46.192
926	api::industry.industry	hqnm1dccebmbck47qob4014k	en	["ar"]	failed	2026-01-31 14:35:46.255	2026-01-31 14:35:46.262
928	api::industry.industry	ydqb6d67cyr8p89z8hgtllq7	en	["ar"]	failed	2026-01-31 14:35:46.326	2026-01-31 14:35:46.333
1036	api::faq.faq	ysy3a3ncg13607su9rvmtw0w	en	["ar"]	failed	2026-01-31 14:40:13.491	2026-01-31 14:40:13.497
1063	api::nav-item.nav-item	zyfexely47xgupfuyw8hcpcc	en	["ar"]	failed	2026-01-31 14:46:04.207	2026-01-31 14:46:04.214
1069	api::team-member.team-member	d25vadc8zngkl32tegtwbthp	en	["ar"]	failed	2026-01-31 14:46:04.814	2026-01-31 14:46:04.82
1072	api::stat.stat	s5e50is1s81en981qj818z8z	en	["ar"]	failed	2026-01-31 14:46:04.969	2026-01-31 14:46:04.976
1073	api::stat.stat	psnnforlbbfq6hhj84r54kk5	en	["ar"]	failed	2026-01-31 14:46:05.016	2026-01-31 14:46:05.021
1074	api::stat.stat	dtvu6easu3nrcobomwwjoy9i	en	["ar"]	failed	2026-01-31 14:46:05.062	2026-01-31 14:46:05.068
280	api::partner.partner	dxxum777dql70wiq2ulz3jwt	en	["ar"]	failed	2026-01-30 15:39:08.102	2026-01-30 15:39:08.109
281	api::nav-item.nav-item	ps4i21nbk18w51pykh08zylk	en	["ar"]	failed	2026-01-30 15:44:48.436	2026-01-30 15:44:48.449
282	api::nav-item.nav-item	epne1m36npf10mv8ogti885z	en	["ar"]	failed	2026-01-30 15:44:48.489	2026-01-30 15:44:48.502
283	api::nav-item.nav-item	c7a3ubob0errty4zkrf1354i	en	["ar"]	failed	2026-01-30 15:44:48.548	2026-01-30 15:44:48.559
284	api::nav-item.nav-item	fupjkrw5k4t8uyl8glkrvq75	en	["ar"]	failed	2026-01-30 15:44:48.601	2026-01-30 15:44:48.609
285	api::nav-item.nav-item	c3goqgiwll6g0vx0fd7lsq90	en	["ar"]	failed	2026-01-30 15:44:48.648	2026-01-30 15:44:48.657
286	api::nav-item.nav-item	mmeykzwkx2uhaqj6q4x0iqdn	en	["ar"]	failed	2026-01-30 15:44:48.693	2026-01-30 15:44:48.701
287	api::nav-item.nav-item	tyvocjzhqxu53g82ghe9jg4g	en	["ar"]	failed	2026-01-30 15:44:48.737	2026-01-30 15:44:48.747
288	api::nav-item.nav-item	mdnlsd8zts0jkin79o6zln5y	en	["ar"]	failed	2026-01-30 15:44:48.785	2026-01-30 15:44:48.791
289	api::nav-item.nav-item	rtdyfqgbbjtedtk3yh63rjc7	en	["ar"]	failed	2026-01-30 15:44:48.835	2026-01-30 15:44:48.845
290	api::nav-item.nav-item	bhcvol97mjs390xnh4s4agxp	en	["ar"]	failed	2026-01-30 15:44:48.886	2026-01-30 15:44:48.892
291	api::nav-item.nav-item	chhq2a72tntqfdks0kycmhxr	en	["ar"]	failed	2026-01-30 15:44:48.936	2026-01-30 15:44:48.942
292	api::nav-item.nav-item	v5nezviti4gnl75fq05pdt8g	en	["ar"]	failed	2026-01-30 15:44:48.985	2026-01-30 15:44:48.991
293	api::nav-item.nav-item	o1upa6a7wca5vldvlrtp0r5y	en	["ar"]	failed	2026-01-30 15:44:49.046	2026-01-30 15:44:49.055
294	api::nav-item.nav-item	n5l1y6dih1jdjbjv2v6ch0cp	en	["ar"]	failed	2026-01-30 15:44:49.112	2026-01-30 15:44:49.121
295	api::nav-item.nav-item	pqc4qya1cp80qkgrpkckvan2	en	["ar"]	failed	2026-01-30 15:44:49.173	2026-01-30 15:44:49.181
296	api::nav-item.nav-item	ihxdzzg3rcllc571xxyphnj7	en	["ar"]	failed	2026-01-30 15:44:49.22	2026-01-30 15:44:49.227
297	api::nav-item.nav-item	qu9gkhln381km7k4eo44eab2	en	["ar"]	failed	2026-01-30 15:44:49.267	2026-01-30 15:44:49.275
298	api::nav-item.nav-item	n7t6k8d3rvnl83fyjineqin9	en	["ar"]	failed	2026-01-30 15:44:49.317	2026-01-30 15:44:49.341
299	api::nav-item.nav-item	wimbuo7acu8q18mw0omr2pov	en	["ar"]	failed	2026-01-30 15:44:49.38	2026-01-30 15:44:49.387
300	api::nav-item.nav-item	a8fqop5rid567hot7lvcqvmk	en	["ar"]	failed	2026-01-30 15:44:49.423	2026-01-30 15:44:49.431
301	api::nav-item.nav-item	vtsrp7zdnscp5i2fakg34dtd	en	["ar"]	failed	2026-01-30 15:44:49.47	2026-01-30 15:44:49.478
302	api::nav-item.nav-item	p42t1hvwpgzlwmx76fev4r6i	en	["ar"]	failed	2026-01-30 15:44:49.517	2026-01-30 15:44:49.525
303	api::nav-item.nav-item	efsweabyp2y18kpvt294r39m	en	["ar"]	failed	2026-01-30 15:44:49.563	2026-01-30 15:44:49.57
304	api::nav-item.nav-item	xbezgrrpcv3lgqxm5h1ozxwp	en	["ar"]	failed	2026-01-30 15:44:49.606	2026-01-30 15:44:49.615
305	api::nav-item.nav-item	dq4kspt4unjzh1pup2yw6183	en	["ar"]	failed	2026-01-30 15:44:49.652	2026-01-30 15:44:49.659
306	api::nav-item.nav-item	x3p18c70rpgl61hf7wglkpjg	en	["ar"]	failed	2026-01-30 15:44:49.704	2026-01-30 15:44:49.712
307	api::nav-item.nav-item	lmevf5vvfn2cpf93pxldsjs4	en	["ar"]	failed	2026-01-30 15:44:49.748	2026-01-30 15:44:49.755
308	api::feature.feature	hec0f37j7o9cfpznte5fb1c3	en	["ar"]	failed	2026-01-30 15:44:50.192	2026-01-30 15:44:50.204
309	api::feature.feature	v9w8w3jjvmgfdqp53belefb8	en	["ar"]	failed	2026-01-30 15:44:50.263	2026-01-30 15:44:50.269
310	api::feature.feature	s3wmah977wh3ltipkhtckd5c	en	["ar"]	failed	2026-01-30 15:44:50.329	2026-01-30 15:44:50.337
311	api::feature.feature	e4awgqqf6l4mhs126qx09n7t	en	["ar"]	failed	2026-01-30 15:44:50.392	2026-01-30 15:44:50.399
312	api::feature.feature	xyhe8dvj5dbaga9m092psvij	en	["ar"]	failed	2026-01-30 15:44:50.453	2026-01-30 15:44:50.46
313	api::feature.feature	ucpfvjxlpx11bkuek63vonq4	en	["ar"]	failed	2026-01-30 15:44:50.512	2026-01-30 15:44:50.518
314	api::feature.feature	ncafeqdsm0nvdancfpis8w1a	en	["ar"]	failed	2026-01-30 15:44:50.568	2026-01-30 15:44:50.574
315	api::feature.feature	alui35tqffv4867y9n0hi2hz	en	["ar"]	failed	2026-01-30 15:44:50.623	2026-01-30 15:44:50.63
316	api::value.value	nzgiqobb646jnnrjhqz5dljx	en	["ar"]	failed	2026-01-30 15:44:50.689	2026-01-30 15:44:50.696
317	api::value.value	lbgf9c8sai5mosiuehk4kqng	en	["ar"]	failed	2026-01-30 15:44:50.745	2026-01-30 15:44:50.751
318	api::value.value	r8eo4ra2x7k7atzqvas0r94e	en	["ar"]	failed	2026-01-30 15:44:50.802	2026-01-30 15:44:50.808
319	api::value.value	h72d0htxexq9h2q7aiu9t56l	en	["ar"]	failed	2026-01-30 15:44:50.856	2026-01-30 15:44:50.863
320	api::value.value	pf8zm81srdyvnzf2qylljqu7	en	["ar"]	failed	2026-01-30 15:44:50.909	2026-01-30 15:44:50.914
321	api::value.value	a55n7kc28to30rpjxs3e03wt	en	["ar"]	failed	2026-01-30 15:44:50.965	2026-01-30 15:44:50.972
322	api::testimonial.testimonial	zk71jumbk8hcmawb0z16h0mr	en	["ar"]	failed	2026-01-30 15:44:51.024	2026-01-30 15:44:51.03
323	api::testimonial.testimonial	amxum6ei6q2c6zv1lp1s6s3s	en	["ar"]	failed	2026-01-30 15:44:51.062	2026-01-30 15:44:51.069
324	api::testimonial.testimonial	unpi8ti73w7hqi00vh01ahsm	en	["ar"]	failed	2026-01-30 15:44:51.098	2026-01-30 15:44:51.105
325	api::testimonial.testimonial	dfcaiaqg6y2je705i9rvfs5y	en	["ar"]	failed	2026-01-30 15:44:51.142	2026-01-30 15:44:51.151
326	api::testimonial.testimonial	uu6o6oo0jptd5g6ghtr5tjxv	en	["ar"]	failed	2026-01-30 15:44:51.18	2026-01-30 15:44:51.185
327	api::testimonial.testimonial	tsgr7vsklp8are0kmfhrv0h9	en	["ar"]	failed	2026-01-30 15:44:51.217	2026-01-30 15:44:51.223
328	api::faq.faq	ep80lpoxicrnms9tktx69nnd	en	["ar"]	failed	2026-01-30 15:44:51.261	2026-01-30 15:44:51.269
329	api::faq.faq	vtr88u1ox8n7lku6c4i9etfk	en	["ar"]	failed	2026-01-30 15:44:51.319	2026-01-30 15:44:51.325
330	api::faq.faq	d7o7sqyxo5pfglkb594sqqya	en	["ar"]	failed	2026-01-30 15:44:51.372	2026-01-30 15:44:51.381
331	api::faq.faq	qturimm7isxacjm2eeqpax2g	en	["ar"]	failed	2026-01-30 15:44:51.424	2026-01-30 15:44:51.43
332	api::faq.faq	axtkqhkyo32enzg5tfwf0z21	en	["ar"]	failed	2026-01-30 15:44:51.479	2026-01-30 15:44:51.484
333	api::faq.faq	ndtt39q91lpt3dukoabgvui9	en	["ar"]	failed	2026-01-30 15:44:51.531	2026-01-30 15:44:51.537
334	api::faq.faq	jao6wu3o6222i9qw7uli14mw	en	["ar"]	failed	2026-01-30 15:44:51.584	2026-01-30 15:44:51.589
335	api::faq.faq	yowclj3uye9a553sid0jnozr	en	["ar"]	failed	2026-01-30 15:44:51.647	2026-01-30 15:44:51.655
336	api::faq.faq	uky0vuki15q786s08ym5psox	en	["ar"]	failed	2026-01-30 15:44:51.7	2026-01-30 15:44:51.707
337	api::faq.faq	vfkr91p9hszn90yb5351h5r8	en	["ar"]	failed	2026-01-30 15:44:51.781	2026-01-30 15:44:51.788
338	api::pricing-plan.pricing-plan	qy1k5jwsy9h6mafi7a73y9y5	en	["ar"]	failed	2026-01-30 15:44:51.843	2026-01-30 15:44:51.85
339	api::pricing-plan.pricing-plan	yknmpj3jz0fmon5penqglh6f	en	["ar"]	failed	2026-01-30 15:44:51.893	2026-01-30 15:44:51.9
340	api::pricing-plan.pricing-plan	mlev1x549s7l3o0r2ptsxqks	en	["ar"]	failed	2026-01-30 15:44:51.944	2026-01-30 15:44:51.95
341	api::pricing-plan.pricing-plan	en09b9suhjzupzpzgzgxvk5e	en	["ar"]	failed	2026-01-30 15:44:51.996	2026-01-30 15:44:52.001
342	api::partner.partner	btbq10ee3z3ns2inqtmdez3y	en	["ar"]	failed	2026-01-30 15:44:52.055	2026-01-30 15:44:52.063
343	api::partner.partner	bz7jpl9vy6frcj4d957pkyak	en	["ar"]	failed	2026-01-30 15:44:52.113	2026-01-30 15:44:52.12
344	api::partner.partner	knbllycimdvzhnjkjb6axk48	en	["ar"]	failed	2026-01-30 15:44:52.168	2026-01-30 15:44:52.175
345	api::partner.partner	pewvvx7vwe4a8de0smsa3pz0	en	["ar"]	failed	2026-01-30 15:44:52.219	2026-01-30 15:44:52.227
569	api::pricing-plan.pricing-plan	ao40ftksyfzfjnwz1fuap352	en	["ar"]	failed	2026-01-30 18:18:46.529	2026-01-30 18:18:46.538
570	api::pricing-plan.pricing-plan	kr3oiddgej4uxv2qnvhw0ips	en	["ar"]	failed	2026-01-30 18:18:46.57	2026-01-30 18:18:46.577
571	api::pricing-plan.pricing-plan	q36bxbo8jscv8kfgk2zoiicl	en	["ar"]	failed	2026-01-30 18:18:46.609	2026-01-30 18:18:46.615
572	api::partner.partner	bsvd4p89j0yb94c16fzeeiff	en	["ar"]	failed	2026-01-30 18:18:46.648	2026-01-30 18:18:46.655
574	api::partner.partner	q6vkq0ff1cvnky8z9vvs5itv	en	["ar"]	failed	2026-01-30 18:18:46.736	2026-01-30 18:18:46.741
575	api::partner.partner	al9qg47mf902yrf1lw56y6au	en	["ar"]	failed	2026-01-30 18:18:46.77	2026-01-30 18:18:46.777
576	api::partner.partner	z4nuwywgrr9ht59qutmgtwc2	en	["ar"]	failed	2026-01-30 18:18:46.806	2026-01-30 18:18:46.813
577	api::partner.partner	crqrxytx9c5t3zl5m4c41zvq	en	["ar"]	failed	2026-01-30 18:18:46.843	2026-01-30 18:18:46.85
578	api::demo.demo	j112ribw4k841vuisw962l9s	en	["ar"]	failed	2026-01-30 18:18:46.89	2026-01-30 18:18:46.896
580	api::demo.demo	vrpeuc4o1es5bixrakcojgbw	en	["ar"]	failed	2026-01-30 18:18:46.957	2026-01-30 18:18:46.963
583	api::demo.demo	i6mc8bb1lpjpgg2nxe3f9ptc	en	["ar"]	failed	2026-01-30 18:18:47.062	2026-01-30 18:18:47.07
587	api::case-study.case-study	ipj2ah2vev2rppewt3d0fycn	en	["ar"]	failed	2026-01-30 18:18:47.196	2026-01-30 18:18:47.202
589	api::solution.solution	y2oa3frissstsgakqseygyaa	en	["ar"]	failed	2026-01-30 18:18:47.27	2026-01-30 18:18:47.276
591	api::solution.solution	oitp7u9upvj6zq665q0isv9a	en	["ar"]	failed	2026-01-30 18:18:47.334	2026-01-30 18:18:47.341
594	api::solution.solution	com7pqvstu1ar0n4mdqpawgm	en	["ar"]	failed	2026-01-30 18:18:47.431	2026-01-30 18:18:47.438
596	api::industry.industry	mxl9hxj99r2zpiiqb4kmu1mv	en	["ar"]	failed	2026-01-30 18:18:47.498	2026-01-30 18:18:47.504
599	api::industry.industry	q25s86r5acs1poy2jjp1glw7	en	["ar"]	failed	2026-01-30 18:18:47.625	2026-01-30 18:18:47.631
822	api::faq.faq	inc1itq62weqxto0a8tntxzy	en	["ar"]	failed	2026-01-31 14:29:12.734	2026-01-31 14:29:12.741
604	api::site-setting.site-setting	qopwd3h1hitrbnwisv8tkrcx	en	["ar"]	failed	2026-01-31 14:24:39.915	2026-01-31 14:47:49.465
936	api::nav-item.nav-item	komsl8qg36xxt9hnfrq2vgfy	en	["ar"]	failed	2026-01-31 14:38:46.012	2026-01-31 14:38:46.019
937	api::nav-item.nav-item	cr5nr22fjo9j4nlszivb311l	en	["ar"]	failed	2026-01-31 14:38:46.053	2026-01-31 14:38:46.059
965	api::stat.stat	d5m29gc6q8diusplxzunsy8m	en	["ar"]	failed	2026-01-31 14:38:47.4	2026-01-31 14:38:47.405
966	api::stat.stat	vh5vicmlx5z8upvgu7ap0vwb	en	["ar"]	failed	2026-01-31 14:38:47.433	2026-01-31 14:38:47.44
967	api::stat.stat	ml7fc84ulh0ud7xmb21n4epf	en	["ar"]	failed	2026-01-31 14:38:47.471	2026-01-31 14:38:47.477
968	api::stat.stat	ozccj6bqnlcqpr4w2xx0bhy9	en	["ar"]	failed	2026-01-31 14:38:47.506	2026-01-31 14:38:47.511
969	api::process-step.process-step	tzf52o0cez9z3117oep4yhb9	en	["ar"]	failed	2026-01-31 14:38:47.54	2026-01-31 14:38:47.546
970	api::process-step.process-step	wr5z7b357q7qtvi2lp34iesm	en	["ar"]	failed	2026-01-31 14:38:47.573	2026-01-31 14:38:47.579
971	api::process-step.process-step	aj38ekw9mpb4rq447qc6aite	en	["ar"]	failed	2026-01-31 14:38:47.607	2026-01-31 14:38:47.613
972	api::process-step.process-step	hjeuke1g7sfx6vru0iw41kr3	en	["ar"]	failed	2026-01-31 14:38:47.644	2026-01-31 14:38:47.65
973	api::feature.feature	gzpthx7vohvx4kg8qszlh87x	en	["ar"]	failed	2026-01-31 14:38:47.677	2026-01-31 14:38:47.683
974	api::feature.feature	i5cx9wc9du386zy63xd8rv3v	en	["ar"]	failed	2026-01-31 14:38:47.711	2026-01-31 14:38:47.718
975	api::feature.feature	axthn1xxnbx3k3n1054eh8df	en	["ar"]	failed	2026-01-31 14:38:47.745	2026-01-31 14:38:47.752
976	api::feature.feature	x2x0pecnur63wb5ne0lz48tq	en	["ar"]	failed	2026-01-31 14:38:47.779	2026-01-31 14:38:47.786
977	api::feature.feature	fvprgtxk3usz9k23d6mqkdim	en	["ar"]	failed	2026-01-31 14:38:47.813	2026-01-31 14:38:47.82
978	api::feature.feature	s0wddrjbv3xhw2eigr6ccp12	en	["ar"]	failed	2026-01-31 14:38:47.852	2026-01-31 14:38:47.858
979	api::feature.feature	q12lpbh97lc93l42mjcdq301	en	["ar"]	failed	2026-01-31 14:38:47.887	2026-01-31 14:38:47.893
980	api::feature.feature	boozxx75b3z6xaifkj5e2jtq	en	["ar"]	failed	2026-01-31 14:38:47.922	2026-01-31 14:38:47.929
989	api::testimonial.testimonial	mw1l7ndw5xxt0wrk228vvexv	en	["ar"]	failed	2026-01-31 14:38:48.241	2026-01-31 14:38:48.247
991	api::testimonial.testimonial	sz26bm2skz13yv0o5tkrbh7x	en	["ar"]	failed	2026-01-31 14:38:48.307	2026-01-31 14:38:48.312
992	api::testimonial.testimonial	iedli0bbq3w4u7p1vqkqmtyy	en	["ar"]	failed	2026-01-31 14:38:48.34	2026-01-31 14:38:48.345
993	api::faq.faq	ef6t8f4ghhiw2j8mxje2z54t	en	["ar"]	failed	2026-01-31 14:38:48.378	2026-01-31 14:38:48.384
995	api::faq.faq	dnebxcfkizsrlauest7a9j5k	en	["ar"]	failed	2026-01-31 14:38:48.443	2026-01-31 14:38:48.449
998	api::faq.faq	h6qaix8nt1mqh6d9iidhlw68	en	["ar"]	failed	2026-01-31 14:38:48.533	2026-01-31 14:38:48.54
1003	api::pricing-plan.pricing-plan	zjupwa03rzeiqhp1ivpshpob	en	["ar"]	failed	2026-01-31 14:38:48.698	2026-01-31 14:38:48.705
1005	api::pricing-plan.pricing-plan	ge4ukotaznebfhdbjv7obyp2	en	["ar"]	failed	2026-01-31 14:38:48.769	2026-01-31 14:38:48.776
1008	api::partner.partner	xbzkdnn457ya9vp7cjtdxo0y	en	["ar"]	failed	2026-01-31 14:38:48.869	2026-01-31 14:38:48.876
1012	api::partner.partner	cqhp72igl6b01yl56ih5t4wy	en	["ar"]	failed	2026-01-31 14:38:49.003	2026-01-31 14:38:49.008
1016	api::demo.demo	husc2tbfti3xrndqu4ap38up	en	["ar"]	failed	2026-01-31 14:38:49.144	2026-01-31 14:38:49.15
1019	api::case-study.case-study	j5p9fat0hn0259zr9rxoh7sb	en	["ar"]	failed	2026-01-31 14:38:49.24	2026-01-31 14:38:49.247
1021	api::case-study.case-study	cisdlst3p1eb6u2nwshbgk2o	en	["ar"]	failed	2026-01-31 14:38:49.303	2026-01-31 14:38:49.309
1024	api::solution.solution	u1izwfiqrwpmk87wvdp8xvmv	en	["ar"]	failed	2026-01-31 14:38:49.399	2026-01-31 14:38:49.406
1026	api::solution.solution	oeprev2uqgx3yxcl40cvb7ac	en	["ar"]	failed	2026-01-31 14:38:49.46	2026-01-31 14:38:49.466
1030	api::industry.industry	nogeibe6nba975jtifqafwnx	en	["ar"]	failed	2026-01-31 14:38:49.589	2026-01-31 14:38:49.595
1032	api::industry.industry	alyigmemi1wg388k4k3uklyt	en	["ar"]	failed	2026-01-31 14:38:49.648	2026-01-31 14:38:49.656
1035	api::industry.industry	j223sxyys2kvg7qcp4kpjswk	en	["ar"]	failed	2026-01-31 14:38:49.75	2026-01-31 14:38:49.755
603	api::contact-page.contact-page	pnduqksd0rcvstmgdb3jxwqq	en	["ar"]	failed	2026-01-31 14:24:39.865	2026-01-31 14:47:49.431
1037	api::nav-item.nav-item	cubzldiuuome30zetktofv63	en	["ar"]	failed	2026-01-31 14:46:03.015	2026-01-31 14:46:03.022
1038	api::nav-item.nav-item	rbww4c68mkmu5igx0vo0kyre	en	["ar"]	failed	2026-01-31 14:46:03.066	2026-01-31 14:46:03.072
1039	api::nav-item.nav-item	d51f8ve9w0kq394m8ztths47	en	["ar"]	failed	2026-01-31 14:46:03.118	2026-01-31 14:46:03.125
1047	api::nav-item.nav-item	yfkcrmllueho4s32ig5ttiph	en	["ar"]	failed	2026-01-31 14:46:03.471	2026-01-31 14:46:03.478
1048	api::nav-item.nav-item	cqxno82oucyzocpy9imnhz1j	en	["ar"]	failed	2026-01-31 14:46:03.517	2026-01-31 14:46:03.523
1049	api::nav-item.nav-item	c4rlkxj7etp11qdzq7mu2cew	en	["ar"]	failed	2026-01-31 14:46:03.563	2026-01-31 14:46:03.57
1050	api::nav-item.nav-item	zrn964y3fjmis1jnwj9phkwl	en	["ar"]	failed	2026-01-31 14:46:03.616	2026-01-31 14:46:03.623
346	api::partner.partner	iesx0qmwzg75gq8c2wuxki7u	en	["ar"]	failed	2026-01-30 15:44:52.27	2026-01-30 15:44:52.275
354	api::case-study.case-study	x7m58n60s5ma4gn20yp5lkku	en	["ar"]	failed	2026-01-30 15:44:52.66	2026-01-30 15:44:52.666
355	api::case-study.case-study	nieg3dvr2ylgqk3yujmj8df8	en	["ar"]	failed	2026-01-30 15:44:52.703	2026-01-30 15:44:52.713
356	api::case-study.case-study	o6xljb5lajwdoj64909po338	en	["ar"]	failed	2026-01-30 15:44:52.747	2026-01-30 15:44:52.753
357	api::case-study.case-study	ty92z32dt3egbn7cbfim9fty	en	["ar"]	failed	2026-01-30 15:44:52.788	2026-01-30 15:44:52.794
358	api::case-study.case-study	c812i67rbqz5mu5q92cpa5qc	en	["ar"]	failed	2026-01-30 15:44:52.831	2026-01-30 15:44:52.837
359	api::solution.solution	ffjxszg5b4wgqsyu169eurq8	en	["ar"]	failed	2026-01-30 15:44:52.873	2026-01-30 15:44:52.88
360	api::solution.solution	zbkotqqwspimugbx6wyvb1az	en	["ar"]	failed	2026-01-30 15:44:52.92	2026-01-30 15:44:52.925
364	api::solution.solution	savbmcncma7j4jumkqxj0tbp	en	["ar"]	failed	2026-01-30 15:44:53.102	2026-01-30 15:44:53.109
365	api::industry.industry	xksrm492b7vlqyx4hnsuktvs	en	["ar"]	failed	2026-01-30 15:44:53.151	2026-01-30 15:44:53.159
366	api::industry.industry	uyvknsx7gf2v1s1dmnmt2d2n	en	["ar"]	failed	2026-01-30 15:44:53.194	2026-01-30 15:44:53.203
367	api::industry.industry	lrhhjtzl8gu3zbq8mdy0p2x1	en	["ar"]	failed	2026-01-30 15:44:53.238	2026-01-30 15:44:53.245
368	api::industry.industry	g4ig23xrc0od21alqqrbsqpc	en	["ar"]	failed	2026-01-30 15:44:53.283	2026-01-30 15:44:53.29
369	api::industry.industry	auc8l4bhcxg8c7v3395nu6tt	en	["ar"]	failed	2026-01-30 15:44:53.33	2026-01-30 15:44:53.336
370	api::industry.industry	n2pxy0u2c6ativ1gckrtbe6u	en	["ar"]	failed	2026-01-30 15:44:53.379	2026-01-30 15:44:53.384
931	api::nav-item.nav-item	fs1qyrtywarydwjbf8m0clxf	en	["ar"]	failed	2026-01-31 14:38:45.82	2026-01-31 14:38:45.827
932	api::nav-item.nav-item	w9gsvenqy3iik6a2a5sre97z	en	["ar"]	failed	2026-01-31 14:38:45.859	2026-01-31 14:38:45.864
933	api::nav-item.nav-item	usxydnubp5rins5knec64xxu	en	["ar"]	failed	2026-01-31 14:38:45.9	2026-01-31 14:38:45.907
619	api::nav-item.nav-item	v3gikacum4fw6u3gezyrqjh9	en	["ar"]	failed	2026-01-31 14:24:40.682	2026-01-31 14:24:40.689
620	api::nav-item.nav-item	bfajml5uliiolq0d3kvxz2jy	en	["ar"]	failed	2026-01-31 14:24:40.725	2026-01-31 14:24:40.732
621	api::nav-item.nav-item	xz7w3kgnhqb222gng8hvefas	en	["ar"]	failed	2026-01-31 14:24:40.765	2026-01-31 14:24:40.772
622	api::nav-item.nav-item	am0r6n636ypwjv7ecq6zhtva	en	["ar"]	failed	2026-01-31 14:24:40.81	2026-01-31 14:24:40.818
624	api::nav-item.nav-item	opswuesou05obkypl60elvf1	en	["ar"]	failed	2026-01-31 14:24:40.899	2026-01-31 14:24:40.906
625	api::nav-item.nav-item	oovlek1s1vx0r8tpulbb05f1	en	["ar"]	failed	2026-01-31 14:24:40.94	2026-01-31 14:24:40.949
635	api::nav-item.nav-item	w6kmch1wmm8w7eb8fqce9u92	en	["ar"]	failed	2026-01-31 14:24:41.394	2026-01-31 14:24:41.401
636	api::nav-item.nav-item	oxt2qed4qqtms4ds6jh0fn33	en	["ar"]	failed	2026-01-31 14:24:41.457	2026-01-31 14:24:41.474
638	api::team-member.team-member	a8uzaqfqj9lbbacaenjpbz4b	en	["ar"]	failed	2026-01-31 14:24:41.863	2026-01-31 14:24:41.871
641	api::team-member.team-member	e4vyztpxwz1ph53a7f9s795r	en	["ar"]	failed	2026-01-31 14:24:41.991	2026-01-31 14:24:41.997
662	api::value.value	y09sja5qxj0m7yka9km74zeh	en	["ar"]	failed	2026-01-31 14:24:42.812	2026-01-31 14:24:42.817
663	api::value.value	pancfkfc5j64o9qvdf0pl84s	en	["ar"]	failed	2026-01-31 14:24:42.848	2026-01-31 14:24:42.855
664	api::value.value	l7xo1hi72o8dgkopm1kctdgi	en	["ar"]	failed	2026-01-31 14:24:42.886	2026-01-31 14:24:42.893
680	api::faq.faq	tbkv76u3j1mugqgwmqnnmtan	en	["ar"]	failed	2026-01-31 14:24:43.511	2026-01-31 14:24:43.517
681	api::faq.faq	f940gj1ebw7ilnj2q2e8oklx	en	["ar"]	failed	2026-01-31 14:24:43.549	2026-01-31 14:24:43.554
601	api::homepage.homepage	armljo9r9dahz6gpkgblmv11	en	["ar"]	failed	2026-01-31 14:24:39.761	2026-01-31 14:47:49.353
934	api::nav-item.nav-item	kg3qvmzk11qom1cbq7hmv51b	en	["ar"]	failed	2026-01-31 14:38:45.937	2026-01-31 14:38:45.943
606	api::solutions-page.solutions-page	bw5cwvotcm2hr9vobeh2n566	en	["ar"]	failed	2026-01-31 14:24:40.041	2026-01-31 14:47:49.55
935	api::nav-item.nav-item	w0rqvgeqwgqaizev0uuq5sn1	en	["ar"]	failed	2026-01-31 14:38:45.977	2026-01-31 14:38:45.984
607	api::industries-page.industries-page	ikxk6ov04uioy9iw6gtmckc2	en	["ar"]	failed	2026-01-31 14:24:40.098	2026-01-31 14:47:49.592
938	api::nav-item.nav-item	u1lv3qms7gmx7ldzmj6r4842	en	["ar"]	failed	2026-01-31 14:38:46.088	2026-01-31 14:38:46.094
608	api::demos-page.demos-page	mcj5auc9zmr21qkl349kuk1l	en	["ar"]	failed	2026-01-31 14:24:40.157	2026-01-31 14:47:49.636
939	api::nav-item.nav-item	gdxvzsaw1w2oubn33rd5w2jp	en	["ar"]	failed	2026-01-31 14:38:46.121	2026-01-31 14:38:46.128
609	api::case-studies-page.case-studies-page	wwfm0mifg8yy0vhrk98n35na	en	["ar"]	failed	2026-01-31 14:24:40.216	2026-01-31 14:47:49.68
823	api::solution.solution	xmdq0f19alwiqb1l7rb2om26	en	["ar"]	failed	2026-01-31 14:31:49.227	2026-01-31 14:32:22.379
930	api::nav-item.nav-item	e605z7udadgkno71xduve58t	en	["ar"]	failed	2026-01-31 14:38:45.782	2026-01-31 14:38:45.787
940	api::nav-item.nav-item	v07pnw3hvg0mlna69051imu6	en	["ar"]	failed	2026-01-31 14:38:46.157	2026-01-31 14:38:46.163
941	api::nav-item.nav-item	r5i1tp5k1tdy05y2ymgv3di4	en	["ar"]	failed	2026-01-31 14:38:46.194	2026-01-31 14:38:46.199
942	api::nav-item.nav-item	sdsqtxr004slkrkdcm00kyzq	en	["ar"]	failed	2026-01-31 14:38:46.234	2026-01-31 14:38:46.239
943	api::nav-item.nav-item	pv8wdhu516zouc3cms5a578f	en	["ar"]	failed	2026-01-31 14:38:46.268	2026-01-31 14:38:46.274
944	api::nav-item.nav-item	ll0abqxhhsa9f19t8h4u6tc8	en	["ar"]	failed	2026-01-31 14:38:46.309	2026-01-31 14:38:46.316
945	api::nav-item.nav-item	ujku8doulzqnqtsxwudnnkgc	en	["ar"]	failed	2026-01-31 14:38:46.346	2026-01-31 14:38:46.351
946	api::nav-item.nav-item	avto0pvo7b16sbtd74plf3cl	en	["ar"]	failed	2026-01-31 14:38:46.381	2026-01-31 14:38:46.387
947	api::nav-item.nav-item	mg4leqgz5ces4nq8epk5ra6w	en	["ar"]	failed	2026-01-31 14:38:46.416	2026-01-31 14:38:46.422
948	api::nav-item.nav-item	v8d3askjf7z6snhxfhzbu0l5	en	["ar"]	failed	2026-01-31 14:38:46.451	2026-01-31 14:38:46.457
949	api::nav-item.nav-item	pl9j4a9p15b80si3ueczs12z	en	["ar"]	failed	2026-01-31 14:38:46.486	2026-01-31 14:38:46.493
950	api::nav-item.nav-item	wfll9nkm4codm6rvssofjopv	en	["ar"]	failed	2026-01-31 14:38:46.523	2026-01-31 14:38:46.531
951	api::nav-item.nav-item	wrac6m3ze16fluvyy2rzo8pp	en	["ar"]	failed	2026-01-31 14:38:46.56	2026-01-31 14:38:46.567
952	api::nav-item.nav-item	y4gq34w8qlk4s2fcp2g4eb8a	en	["ar"]	failed	2026-01-31 14:38:46.598	2026-01-31 14:38:46.603
953	api::nav-item.nav-item	ror557w000fg0sd9awg40e9z	en	["ar"]	failed	2026-01-31 14:38:46.631	2026-01-31 14:38:46.636
954	api::nav-item.nav-item	t837nx50jpm97jq8yct40qss	en	["ar"]	failed	2026-01-31 14:38:46.665	2026-01-31 14:38:46.671
955	api::nav-item.nav-item	pzb03on4iy4gbkooase9dt08	en	["ar"]	failed	2026-01-31 14:38:46.699	2026-01-31 14:38:46.704
956	api::nav-item.nav-item	zlo3ga0h3j45jazcqt4k2cta	en	["ar"]	failed	2026-01-31 14:38:46.734	2026-01-31 14:38:46.74
957	api::team-member.team-member	ljbgsdlvtncpl6b9zoii0g65	en	["ar"]	failed	2026-01-31 14:38:47.087	2026-01-31 14:38:47.094
347	api::partner.partner	dvm22n865twlw1o9z6qnc7uz	en	["ar"]	failed	2026-01-30 15:44:52.32	2026-01-30 15:44:52.326
349	api::demo.demo	tzobm52hdsy44yai1f8rpv72	en	["ar"]	failed	2026-01-30 15:44:52.433	2026-01-30 15:44:52.441
350	api::demo.demo	w5unflyo5hud7k9jj75o2bxv	en	["ar"]	failed	2026-01-30 15:44:52.476	2026-01-30 15:44:52.483
351	api::demo.demo	c7p81shsi9dow7xmllopgdjq	en	["ar"]	failed	2026-01-30 15:44:52.517	2026-01-30 15:44:52.524
352	api::demo.demo	elbxmz415z1dhol7qlskjyw9	en	["ar"]	failed	2026-01-30 15:44:52.56	2026-01-30 15:44:52.567
353	api::demo.demo	vhkfyhxhkvl4rgrz5ks9l98d	en	["ar"]	failed	2026-01-30 15:44:52.608	2026-01-30 15:44:52.617
983	api::value.value	zuqmdcjdgaxn7grycsl5qvva	en	["ar"]	failed	2026-01-31 14:38:48.026	2026-01-31 14:38:48.032
610	api::nav-item.nav-item	t5tso5mylv57x35kjloxcb62	en	["ar"]	failed	2026-01-31 14:24:40.279	2026-01-31 14:24:40.289
629	api::nav-item.nav-item	yme9rnzzqnms4qu3rzlumfzz	en	["ar"]	failed	2026-01-31 14:24:41.127	2026-01-31 14:24:41.136
630	api::nav-item.nav-item	r1xd6abzj3pari62xd93h1mv	en	["ar"]	failed	2026-01-31 14:24:41.177	2026-01-31 14:24:41.185
631	api::nav-item.nav-item	zuxraed2sc20qx0pxpk0tdoo	en	["ar"]	failed	2026-01-31 14:24:41.223	2026-01-31 14:24:41.23
632	api::nav-item.nav-item	c1ilzlkf6ekjnk5yzroo7qr2	en	["ar"]	failed	2026-01-31 14:24:41.266	2026-01-31 14:24:41.273
633	api::nav-item.nav-item	twa44ry80qxdhufww99ra6lb	en	["ar"]	failed	2026-01-31 14:24:41.307	2026-01-31 14:24:41.313
637	api::team-member.team-member	w7tqorz1o8ol46n0892aqpko	en	["ar"]	failed	2026-01-31 14:24:41.819	2026-01-31 14:24:41.828
990	api::testimonial.testimonial	tqzd0zwzujfkvctcwsc98byz	en	["ar"]	failed	2026-01-31 14:38:48.274	2026-01-31 14:38:48.279
996	api::faq.faq	n9prsyz4991v26qjrjmg9en0	en	["ar"]	failed	2026-01-31 14:38:48.475	2026-01-31 14:38:48.481
1000	api::faq.faq	erp7x3g1y7v3fnn20wje9joi	en	["ar"]	failed	2026-01-31 14:38:48.594	2026-01-31 14:38:48.601
1002	api::faq.faq	dmfsvitnlhfywb353gwvpw9h	en	["ar"]	failed	2026-01-31 14:38:48.663	2026-01-31 14:38:48.67
824	api::nav-item.nav-item	kgveathw024uz7ul90i07h3g	en	["ar"]	failed	2026-01-31 14:35:42.285	2026-01-31 14:35:42.291
825	api::nav-item.nav-item	ytjeq44z7e79vbtn8gjwqasx	en	["ar"]	failed	2026-01-31 14:35:42.324	2026-01-31 14:35:42.33
826	api::nav-item.nav-item	ga0rmqlrf2hqjiqx26t3tmnt	en	["ar"]	failed	2026-01-31 14:35:42.359	2026-01-31 14:35:42.365
827	api::nav-item.nav-item	teb9pd4hepgxsl0ucnl5fsg0	en	["ar"]	failed	2026-01-31 14:35:42.4	2026-01-31 14:35:42.406
828	api::nav-item.nav-item	pfcehyliuxjub3e42usl830h	en	["ar"]	failed	2026-01-31 14:35:42.435	2026-01-31 14:35:42.444
843	api::nav-item.nav-item	jucwx6p3zgqpgayh2dyuw5cc	en	["ar"]	failed	2026-01-31 14:35:42.989	2026-01-31 14:35:42.995
845	api::nav-item.nav-item	k793tzuiwq54z1qz44o21vey	en	["ar"]	failed	2026-01-31 14:35:43.057	2026-01-31 14:35:43.064
863	api::process-step.process-step	ha07dy8ie7s2f9szb9d4tbju	en	["ar"]	failed	2026-01-31 14:35:44.058	2026-01-31 14:35:44.065
1007	api::partner.partner	trb0e34du0dzknzl3debg018	en	["ar"]	failed	2026-01-31 14:38:48.837	2026-01-31 14:38:48.842
1041	api::nav-item.nav-item	wdegys8bxg230u45fwmu2l2n	en	["ar"]	failed	2026-01-31 14:46:03.209	2026-01-31 14:46:03.215
958	api::team-member.team-member	bzk1kpgt550ggw5h8qdpbnf3	en	["ar"]	failed	2026-01-31 14:38:47.13	2026-01-31 14:38:47.136
981	api::value.value	nnwjx80la2nhr9kwgxtabq9z	en	["ar"]	failed	2026-01-31 14:38:47.959	2026-01-31 14:38:47.966
982	api::value.value	zdh8yy4c2rt8imy8e4395utg	en	["ar"]	failed	2026-01-31 14:38:47.991	2026-01-31 14:38:47.997
1009	api::partner.partner	de1u3wz0mu4zfrkidfwct0oj	en	["ar"]	failed	2026-01-31 14:38:48.9	2026-01-31 14:38:48.906
1011	api::partner.partner	xbkiz0s6zusw4dai7t6ijpqw	en	["ar"]	failed	2026-01-31 14:38:48.964	2026-01-31 14:38:48.97
1014	api::demo.demo	m6tuzxlpj27ce4zvm1hi85mb	en	["ar"]	failed	2026-01-31 14:38:49.078	2026-01-31 14:38:49.085
1017	api::demo.demo	klhb96xqk0lsbpp8qg4cm6rs	en	["ar"]	failed	2026-01-31 14:38:49.177	2026-01-31 14:38:49.183
1023	api::case-study.case-study	i1wj8lwlmnosjpac1ic3f9ap	en	["ar"]	failed	2026-01-31 14:38:49.366	2026-01-31 14:38:49.373
1027	api::solution.solution	nb5tvtirj8vdunuxqxgvwevp	en	["ar"]	failed	2026-01-31 14:38:49.492	2026-01-31 14:38:49.498
1029	api::solution.solution	e9twydhmf47ythz3zecftzx6	en	["ar"]	failed	2026-01-31 14:38:49.554	2026-01-31 14:38:49.562
1034	api::industry.industry	gm1ocimut72ota2ixcj4ahe8	en	["ar"]	failed	2026-01-31 14:38:49.718	2026-01-31 14:38:49.724
602	api::about-page.about-page	ivyurv1e55quoabmsj7l2av8	en	["ar"]	failed	2026-01-31 14:24:39.817	2026-01-31 14:47:49.4
1042	api::nav-item.nav-item	c1vha5327isp0nj6669q3yv1	en	["ar"]	failed	2026-01-31 14:46:03.252	2026-01-31 14:46:03.258
605	api::pricing-page.pricing-page	smsp40f6fke2606whqubkhaw	en	["ar"]	failed	2026-01-31 14:24:39.973	2026-01-31 14:47:49.505
1040	api::nav-item.nav-item	nx15zzs9gqsxo3n8h1zq37y2	en	["ar"]	failed	2026-01-31 14:46:03.164	2026-01-31 14:46:03.171
1046	api::nav-item.nav-item	ry0khkjbn2xv9lpa0d8pdrwy	en	["ar"]	failed	2026-01-31 14:46:03.425	2026-01-31 14:46:03.431
1064	api::team-member.team-member	guyddovx332q78mbd4k2alv2	en	["ar"]	failed	2026-01-31 14:46:04.577	2026-01-31 14:46:04.582
1067	api::team-member.team-member	aksarocashxnimpkkh82moer	en	["ar"]	failed	2026-01-31 14:46:04.715	2026-01-31 14:46:04.721
1070	api::stat.stat	oroh7lv3bhjees4xunc01on5	en	["ar"]	failed	2026-01-31 14:46:04.872	2026-01-31 14:46:04.878
1071	api::stat.stat	rjm57s960b1lt6nt7rs4ugug	en	["ar"]	failed	2026-01-31 14:46:04.921	2026-01-31 14:46:04.927
1075	api::stat.stat	u2dxpumwro9bk2r29gu48ipj	en	["ar"]	failed	2026-01-31 14:46:05.107	2026-01-31 14:46:05.114
1076	api::process-step.process-step	eh0w8hy6ap8320nr7ghycew7	en	["ar"]	failed	2026-01-31 14:46:05.154	2026-01-31 14:46:05.16
1077	api::process-step.process-step	t6q8jwr2dyqumfy1h959mexo	en	["ar"]	failed	2026-01-31 14:46:05.19	2026-01-31 14:46:05.2
1078	api::process-step.process-step	iuskxn270bwste5fjdgwy93e	en	["ar"]	failed	2026-01-31 14:46:05.232	2026-01-31 14:46:05.239
1079	api::process-step.process-step	qkjxhmh7kb1lzc13opbjjf4s	en	["ar"]	failed	2026-01-31 14:46:05.271	2026-01-31 14:46:05.277
1080	api::feature.feature	eytvlnmmj92vphbagni1nkeo	en	["ar"]	failed	2026-01-31 14:46:05.316	2026-01-31 14:46:05.323
1081	api::feature.feature	psfxjmx35j46a010pgv1jaej	en	["ar"]	failed	2026-01-31 14:46:05.365	2026-01-31 14:46:05.371
1082	api::feature.feature	ib10y9no81qqq7imvznlk4ho	en	["ar"]	failed	2026-01-31 14:46:05.412	2026-01-31 14:46:05.419
1083	api::feature.feature	bu622svrs9h5y14t60qn2gll	en	["ar"]	failed	2026-01-31 14:46:05.46	2026-01-31 14:46:05.523
1084	api::feature.feature	h3ohqxdpljarhkjf95tz3igf	en	["ar"]	failed	2026-01-31 14:46:05.557	2026-01-31 14:46:05.562
1085	api::feature.feature	o4i0l68et61xcr2tbmufehhh	en	["ar"]	failed	2026-01-31 14:46:05.6	2026-01-31 14:46:05.608
1086	api::feature.feature	hknvi1s1lzemxkvqrsq88065	en	["ar"]	failed	2026-01-31 14:46:05.644	2026-01-31 14:46:05.65
1087	api::feature.feature	echo29kxiwbrcixb80jl8v1r	en	["ar"]	failed	2026-01-31 14:46:05.695	2026-01-31 14:46:05.702
1088	api::value.value	ty4mov8q37fpykiig9w2jq6a	en	["ar"]	failed	2026-01-31 14:46:05.739	2026-01-31 14:46:05.751
1089	api::value.value	vojqim2lalnygi4wotbtfiau	en	["ar"]	failed	2026-01-31 14:46:05.785	2026-01-31 14:46:05.794
1090	api::value.value	jopg44qbd5eyi5cnhu5ymgim	en	["ar"]	failed	2026-01-31 14:46:05.831	2026-01-31 14:46:05.838
348	api::demo.demo	ev9dtut7hr5xptoqsqjbfkzf	en	["ar"]	failed	2026-01-30 15:44:52.388	2026-01-30 15:44:52.396
361	api::solution.solution	vp6tq8t7flxt0kjhea4lm1qu	en	["ar"]	failed	2026-01-30 15:44:52.966	2026-01-30 15:44:52.973
362	api::solution.solution	t4bsj5swho2txvbgzgk3untx	en	["ar"]	failed	2026-01-30 15:44:53.012	2026-01-30 15:44:53.019
363	api::solution.solution	j7yuyzcg3ov34l3ljvjrozj7	en	["ar"]	failed	2026-01-30 15:44:53.057	2026-01-30 15:44:53.064
371	api::nav-item.nav-item	li8eii5oth0vcbu01ekxfouw	en	["ar"]	failed	2026-01-30 15:52:03.296	2026-01-30 15:57:23.084
372	api::nav-item.nav-item	ycwb2yfo76r959rc238gd634	en	["ar"]	failed	2026-01-30 15:52:03.376	2026-01-30 15:57:23.127
373	api::nav-item.nav-item	ek5yile60yudupxqodme4oyy	en	["ar"]	failed	2026-01-30 15:52:03.466	2026-01-30 15:57:23.17
374	api::nav-item.nav-item	i098u1xhemlaj12aue4fcei9	en	["ar"]	failed	2026-01-30 15:52:03.531	2026-01-30 15:57:23.213
375	api::nav-item.nav-item	xc1x4uwkvf2wvqvdx152mc5y	en	["ar"]	failed	2026-01-30 15:52:03.608	2026-01-30 15:57:23.256
376	api::nav-item.nav-item	unoxybhcvtvvk5ahg8cpv15s	en	["ar"]	failed	2026-01-30 15:52:03.669	2026-01-30 15:57:23.295
377	api::nav-item.nav-item	n067etr6bna7ofyu7fd4irqr	en	["ar"]	failed	2026-01-30 15:52:03.733	2026-01-30 15:57:23.334
378	api::nav-item.nav-item	yq2prflfirksbtplbsnzzmqp	en	["ar"]	failed	2026-01-30 15:52:03.798	2026-01-30 15:57:23.385
379	api::nav-item.nav-item	jan411b1cotvupc44ayhljca	en	["ar"]	failed	2026-01-30 15:52:03.85	2026-01-30 15:57:23.419
380	api::nav-item.nav-item	tdipyzsi5fpr51thkgus5bvh	en	["ar"]	failed	2026-01-30 15:52:03.902	2026-01-30 15:57:23.455
381	api::nav-item.nav-item	vooxc5att8ztp25ewbd8lsc9	en	["ar"]	failed	2026-01-30 15:52:03.954	2026-01-30 15:57:23.491
382	api::nav-item.nav-item	n3xavg35dt50ikwjjw6n6ptv	en	["ar"]	failed	2026-01-30 15:52:04.007	2026-01-30 15:57:23.529
383	api::nav-item.nav-item	twnpzwse8z9cjee67fj74iox	en	["ar"]	failed	2026-01-30 15:52:04.064	2026-01-30 15:57:23.566
384	api::nav-item.nav-item	a89qsi2bzsbuc0375lxeglbx	en	["ar"]	failed	2026-01-30 15:52:04.12	2026-01-30 15:57:23.616
385	api::nav-item.nav-item	yffgdkplocanwsvst9u1e703	en	["ar"]	failed	2026-01-30 15:52:04.173	2026-01-30 15:57:23.651
386	api::nav-item.nav-item	jc87gt0ax82q41m662h8uxkn	en	["ar"]	failed	2026-01-30 15:52:04.234	2026-01-30 15:57:23.684
387	api::nav-item.nav-item	bz82gbr3thr9oo6nakcb9xog	en	["ar"]	failed	2026-01-30 15:52:04.286	2026-01-30 15:57:23.719
388	api::nav-item.nav-item	augs6gaq21hqcel11piqgygi	en	["ar"]	failed	2026-01-30 15:52:04.34	2026-01-30 15:57:23.769
389	api::nav-item.nav-item	oyrhzxylwrcwep6y3i8xrlso	en	["ar"]	failed	2026-01-30 15:52:04.395	2026-01-30 15:57:23.805
390	api::nav-item.nav-item	gxx1xt5rnaysesnw9yvp6mn9	en	["ar"]	failed	2026-01-30 15:52:04.452	2026-01-30 15:57:23.84
391	api::nav-item.nav-item	lzrwz0dmfcyvuozpuufuglo4	en	["ar"]	failed	2026-01-30 15:52:04.504	2026-01-30 15:57:23.878
392	api::nav-item.nav-item	jke79aukr4e9fb5fygm0ucdp	en	["ar"]	failed	2026-01-30 15:52:04.558	2026-01-30 15:57:23.914
393	api::nav-item.nav-item	o5jk56xh2j9oag98ylwwnzy3	en	["ar"]	failed	2026-01-30 15:52:04.619	2026-01-30 15:57:23.95
394	api::nav-item.nav-item	cjvxdz3zv3th6tyknw5e8mej	en	["ar"]	failed	2026-01-30 15:52:04.67	2026-01-30 15:57:23.992
395	api::nav-item.nav-item	ymrtmt5zzot4nrhy9otcof58	en	["ar"]	failed	2026-01-30 15:52:04.722	2026-01-30 15:57:24.029
396	api::nav-item.nav-item	zwxsf16impopd9ix70ujvwm3	en	["ar"]	failed	2026-01-30 15:52:04.772	2026-01-30 15:57:24.064
397	api::nav-item.nav-item	wva6loz9r8b0b31k6ud6y5so	en	["ar"]	failed	2026-01-30 15:52:04.823	2026-01-30 15:57:24.099
398	api::team-member.team-member	ratfggrnxrgjlufh9gdyv5ex	en	["ar"]	failed	2026-01-30 15:52:05.088	2026-01-30 15:57:24.33
399	api::team-member.team-member	vg80t18dlu027c5x9oofkvf0	en	["ar"]	failed	2026-01-30 15:52:05.147	2026-01-30 15:57:24.372
400	api::team-member.team-member	um949s21ds3yzom7i1hve2zi	en	["ar"]	failed	2026-01-30 15:52:05.204	2026-01-30 15:57:24.412
401	api::team-member.team-member	ji9kdq7u51s14m37iylr4sdp	en	["ar"]	failed	2026-01-30 15:52:05.256	2026-01-30 15:57:24.453
402	api::team-member.team-member	hci3bxv8czxgboeehckcephs	en	["ar"]	failed	2026-01-30 15:52:05.311	2026-01-30 15:57:24.492
403	api::team-member.team-member	sjcueiw7p3aach0age0yegm5	en	["ar"]	failed	2026-01-30 15:52:05.361	2026-01-30 15:57:24.539
404	api::stat.stat	syq87zvb012qmnbsx7w3qa00	en	["ar"]	failed	2026-01-30 15:52:05.417	2026-01-30 15:57:24.583
405	api::stat.stat	vtiumfkxbdpjbxgc4iypuyky	en	["ar"]	failed	2026-01-30 15:52:05.475	2026-01-30 15:57:24.614
406	api::stat.stat	cl03vmsbu9jqt18tegvp41qq	en	["ar"]	failed	2026-01-30 15:52:05.523	2026-01-30 15:57:24.649
407	api::stat.stat	thu6c3os0rzvobiz1xmr2da2	en	["ar"]	failed	2026-01-30 15:52:05.581	2026-01-30 15:57:24.688
408	api::stat.stat	v5je0e1s40m5dp0pxoa2941k	en	["ar"]	failed	2026-01-30 15:52:05.635	2026-01-30 15:57:24.727
409	api::stat.stat	a7nf9gvn2v2nzr3cfpse7myz	en	["ar"]	failed	2026-01-30 15:52:05.688	2026-01-30 15:57:24.762
410	api::process-step.process-step	t93kots3xg2l9gj87dflsahy	en	["ar"]	failed	2026-01-30 15:52:05.74	2026-01-30 15:57:24.802
411	api::process-step.process-step	x5jwgop82ooju0qlp19xicj8	en	["ar"]	failed	2026-01-30 15:52:07.292	2026-01-30 15:57:24.841
412	api::process-step.process-step	zqoy0o0j31vh3yjfjr7wc1t3	en	["ar"]	failed	2026-01-30 15:52:07.37	2026-01-30 15:57:24.878
413	api::process-step.process-step	m2k6mvyxum9uub3zg81p2wx3	en	["ar"]	failed	2026-01-30 15:52:07.445	2026-01-30 15:57:24.917
414	api::feature.feature	tiw1teg61x2lk0mz0zepy1v8	en	["ar"]	failed	2026-01-30 15:52:07.522	2026-01-30 15:57:24.957
415	api::feature.feature	m4ca28no4yuspkzzzgekaaze	en	["ar"]	failed	2026-01-30 15:52:07.597	2026-01-30 15:57:24.994
416	api::feature.feature	huvvf5qpvwe48y5ywysuo83d	en	["ar"]	failed	2026-01-30 15:52:07.674	2026-01-30 15:57:25.026
417	api::feature.feature	v61slytfxdd6uvxc9xrui9jg	en	["ar"]	failed	2026-01-30 15:52:07.746	2026-01-30 15:57:25.063
418	api::feature.feature	smbb1p2qsx6exbeq6htbvy76	en	["ar"]	failed	2026-01-30 15:52:07.818	2026-01-30 15:57:25.098
419	api::feature.feature	uwp2n6e6c330hoc0z2kf8crm	en	["ar"]	failed	2026-01-30 15:52:07.891	2026-01-30 15:57:25.137
420	api::feature.feature	o35orwx2qlu6agosr70b98e0	en	["ar"]	failed	2026-01-30 15:52:07.96	2026-01-30 15:57:25.172
421	api::feature.feature	jcse0opj0vmu04j18k6ij57r	en	["ar"]	failed	2026-01-30 15:52:08.036	2026-01-30 15:57:25.206
422	api::value.value	hhmw3o2gvzeaqq9cvd7exchd	en	["ar"]	failed	2026-01-30 15:52:08.109	2026-01-30 15:57:25.243
423	api::value.value	iwrgyhke0r8krpqtvnip1578	en	["ar"]	failed	2026-01-30 15:52:08.18	2026-01-30 15:57:25.283
424	api::value.value	dajbb1ffsrtwchww9k6ljtqv	en	["ar"]	failed	2026-01-30 15:52:08.248	2026-01-30 15:57:25.316
425	api::value.value	cxlonubo05h1mlbi17bulxuh	en	["ar"]	failed	2026-01-30 15:52:08.319	2026-01-30 15:57:25.357
426	api::value.value	zhon2rf98wudk7mad2bddb8i	en	["ar"]	failed	2026-01-30 15:52:08.396	2026-01-30 15:57:25.398
427	api::value.value	v5h7n3vem0puf5502faq0ct2	en	["ar"]	failed	2026-01-30 15:52:08.466	2026-01-30 15:57:25.432
428	api::testimonial.testimonial	qblduchtbmhn4uftwydkbyjn	en	["ar"]	failed	2026-01-30 15:52:08.546	2026-01-30 15:57:25.475
429	api::testimonial.testimonial	b2gn6hv9bsnbdfhiqsfpiduu	en	["ar"]	failed	2026-01-30 15:52:08.594	2026-01-30 15:57:25.51
441	api::faq.faq	yr47d44qynjkxzeqc0rl1aj0	en	["ar"]	failed	2026-01-30 15:52:09.232	2026-01-30 15:57:25.972
463	api::case-study.case-study	ljyr0huxhcub87emb9c6azy4	en	["ar"]	failed	2026-01-30 15:52:10.457	2026-01-30 15:57:26.897
442	api::faq.faq	welleff0673pmtq15udxhug4	en	["ar"]	failed	2026-01-30 15:52:09.291	2026-01-30 15:57:26.015
617	api::nav-item.nav-item	ivfrdq9wgmrafoa0asdati65	en	["ar"]	failed	2026-01-31 14:24:40.597	2026-01-31 14:24:40.606
443	api::faq.faq	gbopv2y8rx7n3lrw1i64cmv8	en	["ar"]	failed	2026-01-30 15:52:09.352	2026-01-30 15:57:26.06
618	api::nav-item.nav-item	wenqi96btnratqa3xs0787e5	en	["ar"]	failed	2026-01-31 14:24:40.639	2026-01-31 14:24:40.646
467	api::solution.solution	whs2ps1yxocmtgw3sznx5xfp	en	["ar"]	failed	2026-01-30 15:52:10.653	2026-01-30 15:57:27.048
444	api::pricing-plan.pricing-plan	o9bt9u7clz7v3tr78tyt0rzm	en	["ar"]	failed	2026-01-30 15:52:09.421	2026-01-30 15:57:26.103
623	api::nav-item.nav-item	hkj9osm2l4wbsdhmsmh42q3i	en	["ar"]	failed	2026-01-31 14:24:40.856	2026-01-31 14:24:40.863
640	api::team-member.team-member	hv0kd3sui1bjx77ziztj1kfm	en	["ar"]	failed	2026-01-31 14:24:41.946	2026-01-31 14:24:41.953
445	api::pricing-plan.pricing-plan	b8p9jj009stq4pnwcyu6ucay	en	["ar"]	failed	2026-01-30 15:52:09.479	2026-01-30 15:57:26.146
468	api::solution.solution	eib72gfjeua5lrlbqp6vud0u	en	["ar"]	failed	2026-01-30 15:52:10.698	2026-01-30 15:57:27.089
446	api::pricing-plan.pricing-plan	vnjp157p7fz4krghbihsxdiu	en	["ar"]	failed	2026-01-30 15:52:09.536	2026-01-30 15:57:26.186
447	api::pricing-plan.pricing-plan	jv6728bgrvs485v0lf5u0v2n	en	["ar"]	failed	2026-01-30 15:52:09.604	2026-01-30 15:57:26.225
469	api::solution.solution	u1e3ht4dhd8i71iuro0mir1p	en	["ar"]	failed	2026-01-30 15:52:10.744	2026-01-30 15:57:27.127
448	api::partner.partner	xkdbpq8wruclvpygni92uw4q	en	["ar"]	failed	2026-01-30 15:52:09.664	2026-01-30 15:57:26.27
643	api::stat.stat	ute23ussjipq5xfz0zx0nz7i	en	["ar"]	failed	2026-01-31 14:24:42.075	2026-01-31 14:24:42.082
449	api::partner.partner	opx1h1y4gy0truat2r2i7nf4	en	["ar"]	failed	2026-01-30 15:52:09.722	2026-01-30 15:57:26.315
470	api::solution.solution	bup4lkho82zekaxbd42xbrdy	en	["ar"]	failed	2026-01-30 15:52:10.794	2026-01-30 15:57:27.175
450	api::partner.partner	xaq0zo4k2uq8j8u2ykxmidv4	en	["ar"]	failed	2026-01-30 15:52:09.771	2026-01-30 15:57:26.36
451	api::partner.partner	mr86fp1f2fwqn40z8uwsid6v	en	["ar"]	failed	2026-01-30 15:52:09.819	2026-01-30 15:57:26.396
659	api::feature.feature	gnt44e2n2994v02y2x9kcgzz	en	["ar"]	failed	2026-01-31 14:24:42.698	2026-01-31 14:24:42.705
471	api::industry.industry	kaomv6jfmax5mqpa329al313	en	["ar"]	failed	2026-01-30 15:52:10.844	2026-01-30 15:57:27.22
457	api::demo.demo	n3002idwlm51m1k5hv1hgkwf	en	["ar"]	failed	2026-01-30 15:52:10.136	2026-01-30 15:57:26.65
660	api::feature.feature	eti7e3yaypnkznve00xmfw24	en	["ar"]	failed	2026-01-31 14:24:42.734	2026-01-31 14:24:42.74
472	api::industry.industry	ud72w3h4nt812vdkqxfn3lrx	en	["ar"]	failed	2026-01-30 15:52:10.901	2026-01-30 15:57:27.266
458	api::demo.demo	ljny8wcyia47u3m0280xxeyb	en	["ar"]	failed	2026-01-30 15:52:10.185	2026-01-30 15:57:26.7
661	api::value.value	zl433p91k61jn3go323ibow1	en	["ar"]	failed	2026-01-31 14:24:42.775	2026-01-31 14:24:42.782
473	api::industry.industry	hnmtp1jcdzg9uczkl8elwf52	en	["ar"]	failed	2026-01-30 15:52:10.945	2026-01-30 15:57:27.304
474	api::industry.industry	oocndczvifwcjfpm6td0jlim	en	["ar"]	failed	2026-01-30 15:52:10.992	2026-01-30 15:57:27.347
671	api::testimonial.testimonial	ybmjji0jk0c2iez86muklh90	en	["ar"]	failed	2026-01-31 14:24:43.167	2026-01-31 14:24:43.174
459	api::demo.demo	gbtiw59s69bi8qkhn8jcf7xz	en	["ar"]	failed	2026-01-30 15:52:10.237	2026-01-30 15:57:26.735
475	api::industry.industry	dmi4jw9ord0aylbbbr0tk1d7	en	["ar"]	failed	2026-01-30 15:52:11.043	2026-01-30 15:57:27.377
684	api::pricing-plan.pricing-plan	g5wruakb2pjih1d13b7y0job	en	["ar"]	failed	2026-01-31 14:24:43.67	2026-01-31 14:24:43.676
476	api::industry.industry	wzgd2y1crn99y4am92u39suk	en	["ar"]	failed	2026-01-30 15:52:11.093	2026-01-30 15:57:27.414
685	api::pricing-plan.pricing-plan	wflrbcxzdkvqwcuol5l8yqrl	en	["ar"]	failed	2026-01-31 14:24:43.711	2026-01-31 14:24:43.718
430	api::testimonial.testimonial	j9ukked0i5pt1fo2zc47d7y9	en	["ar"]	failed	2026-01-30 15:52:08.64	2026-01-30 15:57:25.543
460	api::case-study.case-study	fu41u40s44xjskgln4pcim98	en	["ar"]	failed	2026-01-30 15:52:10.293	2026-01-30 15:57:26.78
686	api::pricing-plan.pricing-plan	lsnb31300q7iessdj6zjksmt	en	["ar"]	failed	2026-01-31 14:24:43.755	2026-01-31 14:24:43.762
432	api::testimonial.testimonial	vs4oelsqpdytlcj9fzm8vb53	en	["ar"]	failed	2026-01-30 15:52:08.739	2026-01-30 15:57:25.617
687	api::partner.partner	ycxei0hqjux2ksj6zcyj3blu	en	["ar"]	failed	2026-01-31 14:24:43.8	2026-01-31 14:24:43.806
688	api::partner.partner	tee3vccbyihaglratsig3nll	en	["ar"]	failed	2026-01-31 14:24:43.844	2026-01-31 14:24:43.851
462	api::case-study.case-study	k5l6xd0c1kw3wwbyxgzphk5g	en	["ar"]	failed	2026-01-30 15:52:10.407	2026-01-30 15:57:26.857
689	api::partner.partner	babh9d865knby3j5vcdahaty	en	["ar"]	failed	2026-01-31 14:24:43.883	2026-01-31 14:24:43.889
690	api::partner.partner	hxhfs1l67t1zihppz71n6vcg	en	["ar"]	failed	2026-01-31 14:24:43.921	2026-01-31 14:24:43.928
691	api::partner.partner	f6bmjttcel5rdcc60d3f33ts	en	["ar"]	failed	2026-01-31 14:24:43.967	2026-01-31 14:24:43.973
692	api::partner.partner	e652z9mgnrm3ki0qhx5fhnjx	en	["ar"]	failed	2026-01-31 14:24:44.006	2026-01-31 14:24:44.013
693	api::demo.demo	iyb5c476sexbqs83h32nm4kf	en	["ar"]	failed	2026-01-31 14:24:44.055	2026-01-31 14:24:44.062
695	api::demo.demo	v41kniwmg2jw1kharuwl5em5	en	["ar"]	failed	2026-01-31 14:24:44.127	2026-01-31 14:24:44.134
698	api::demo.demo	rqhp0yh8rpxtapm1uetjiqbp	en	["ar"]	failed	2026-01-31 14:24:44.237	2026-01-31 14:24:44.245
702	api::case-study.case-study	uphay5ezw0lrxp6cz2sc33ec	en	["ar"]	failed	2026-01-31 14:24:44.398	2026-01-31 14:24:44.405
708	api::solution.solution	v34e5n6kmdyoptzdxkhvker6	en	["ar"]	failed	2026-01-31 14:24:44.609	2026-01-31 14:24:44.616
713	api::industry.industry	fz6cnh4p1ukoic8n9kz311qm	en	["ar"]	failed	2026-01-31 14:24:44.787	2026-01-31 14:24:44.794
715	api::industry.industry	gdry3my6liyyt1m247rfhpjv	en	["ar"]	failed	2026-01-31 14:24:44.857	2026-01-31 14:24:44.865
829	api::nav-item.nav-item	ljoaam9axwhnpt7jt3vwfika	en	["ar"]	failed	2026-01-31 14:35:42.472	2026-01-31 14:35:42.479
830	api::nav-item.nav-item	mp0kxdv9opf7tmwg3a5wl4pg	en	["ar"]	failed	2026-01-31 14:35:42.508	2026-01-31 14:35:42.515
831	api::nav-item.nav-item	k10rrqi886wwm93n00qij53v	en	["ar"]	failed	2026-01-31 14:35:42.545	2026-01-31 14:35:42.555
832	api::nav-item.nav-item	t95o7zy8bv7u2bwom1vcpbw2	en	["ar"]	failed	2026-01-31 14:35:42.589	2026-01-31 14:35:42.596
833	api::nav-item.nav-item	g5z4702gjryy9yzb9f969jff	en	["ar"]	failed	2026-01-31 14:35:42.627	2026-01-31 14:35:42.632
834	api::nav-item.nav-item	w7fskde807jjf987siv7ueu1	en	["ar"]	failed	2026-01-31 14:35:42.661	2026-01-31 14:35:42.668
835	api::nav-item.nav-item	c6585vfv9lf5xi1ntnotj2bo	en	["ar"]	failed	2026-01-31 14:35:42.702	2026-01-31 14:35:42.708
838	api::nav-item.nav-item	rqmarwo4znmiu7dp9vwufnqb	en	["ar"]	failed	2026-01-31 14:35:42.815	2026-01-31 14:35:42.82
839	api::nav-item.nav-item	g7igo7k9ps55f3wgvswurx3q	en	["ar"]	failed	2026-01-31 14:35:42.851	2026-01-31 14:35:42.858
611	api::nav-item.nav-item	s8j662a1f2bff1bdwbjybfwa	en	["ar"]	failed	2026-01-31 14:24:40.329	2026-01-31 14:24:40.338
612	api::nav-item.nav-item	wnmwezjbjdg401aa2ifnpqm1	en	["ar"]	failed	2026-01-31 14:24:40.377	2026-01-31 14:24:40.384
613	api::nav-item.nav-item	c6ggefc05jnt6nzc19av8akv	en	["ar"]	failed	2026-01-31 14:24:40.423	2026-01-31 14:24:40.431
614	api::nav-item.nav-item	xo04fai81e239nx9ipv3kvfi	en	["ar"]	failed	2026-01-31 14:24:40.466	2026-01-31 14:24:40.474
615	api::nav-item.nav-item	ub37s0p16uqeam2dt46qsg5b	en	["ar"]	failed	2026-01-31 14:24:40.51	2026-01-31 14:24:40.517
616	api::nav-item.nav-item	w5tgo7d249iuk5f4fxxjymle	en	["ar"]	failed	2026-01-31 14:24:40.554	2026-01-31 14:24:40.561
626	api::nav-item.nav-item	sc6oy1cwruolrfsdvqzqffsl	en	["ar"]	failed	2026-01-31 14:24:40.982	2026-01-31 14:24:40.988
627	api::nav-item.nav-item	sym8j02k1kqcgtcz9q5l371b	en	["ar"]	failed	2026-01-31 14:24:41.025	2026-01-31 14:24:41.036
628	api::nav-item.nav-item	rlt3ovtxjiechsrth7fjys60	en	["ar"]	failed	2026-01-31 14:24:41.073	2026-01-31 14:24:41.09
634	api::nav-item.nav-item	jv5rub8lv3586nnm5vcv7sp7	en	["ar"]	failed	2026-01-31 14:24:41.346	2026-01-31 14:24:41.354
639	api::team-member.team-member	s9grona1u0av4vo01u4hrysy	en	["ar"]	failed	2026-01-31 14:24:41.907	2026-01-31 14:24:41.913
644	api::stat.stat	uy6gbuwqo39z37br78bjkb0t	en	["ar"]	failed	2026-01-31 14:24:42.118	2026-01-31 14:24:42.124
645	api::stat.stat	osh40x6eznhvtfchrf6hwnbk	en	["ar"]	failed	2026-01-31 14:24:42.155	2026-01-31 14:24:42.162
431	api::testimonial.testimonial	cnnfhkqwres2jtlxg2rup67p	en	["ar"]	failed	2026-01-30 15:52:08.687	2026-01-30 15:57:25.578
646	api::stat.stat	twhxnm9ayjjkhmhxgbi7aigi	en	["ar"]	failed	2026-01-31 14:24:42.194	2026-01-31 14:24:42.202
435	api::faq.faq	etvwt69s4vc89qw02k6kdm4l	en	["ar"]	failed	2026-01-30 15:52:08.908	2026-01-30 15:57:25.743
436	api::faq.faq	rddyinfrxv2dc11nvbt5542k	en	["ar"]	failed	2026-01-30 15:52:08.963	2026-01-30 15:57:25.78
647	api::stat.stat	sm7nush3u3mlmj2gvferuvda	en	["ar"]	failed	2026-01-31 14:24:42.235	2026-01-31 14:24:42.242
437	api::faq.faq	pslh3j1q2le4ogy8j2e4jl8i	en	["ar"]	failed	2026-01-30 15:52:09.019	2026-01-30 15:57:25.817
438	api::faq.faq	z0x3ekls4wvpwpioq52se95z	en	["ar"]	failed	2026-01-30 15:52:09.073	2026-01-30 15:57:25.853
648	api::stat.stat	k8h79vfi1m95kvmr5289b6cj	en	["ar"]	failed	2026-01-31 14:24:42.273	2026-01-31 14:24:42.279
439	api::faq.faq	kot3dc461ui374jjtbsl65ts	en	["ar"]	failed	2026-01-30 15:52:09.125	2026-01-30 15:57:25.892
440	api::faq.faq	hwgzncpa2ofpq0q4keihpznc	en	["ar"]	failed	2026-01-30 15:52:09.18	2026-01-30 15:57:25.928
649	api::process-step.process-step	z1wysyjv3z7zb0ppexspqbey	en	["ar"]	failed	2026-01-31 14:24:42.311	2026-01-31 14:24:42.318
461	api::case-study.case-study	lac1c8pgovgea4jiqn2tco4t	en	["ar"]	failed	2026-01-30 15:52:10.352	2026-01-30 15:57:26.818
466	api::solution.solution	hghyc8ff7t66ppsuzcq6iojj	en	["ar"]	failed	2026-01-30 15:52:10.608	2026-01-30 15:57:27.01
650	api::process-step.process-step	txnwrthc3xhykm8303wowm2k	en	["ar"]	failed	2026-01-31 14:24:42.349	2026-01-31 14:24:42.356
651	api::process-step.process-step	cnnokfmn85izjqtcmj229niz	en	["ar"]	failed	2026-01-31 14:24:42.389	2026-01-31 14:24:42.396
652	api::process-step.process-step	c291u3cay7q4p5zwp8uygecz	en	["ar"]	failed	2026-01-31 14:24:42.43	2026-01-31 14:24:42.435
653	api::feature.feature	seb042jr0c8l1zk94c6gam62	en	["ar"]	failed	2026-01-31 14:24:42.471	2026-01-31 14:24:42.478
654	api::feature.feature	w9g5r3jrd75x0el0z8m1v1lu	en	["ar"]	failed	2026-01-31 14:24:42.505	2026-01-31 14:24:42.513
655	api::feature.feature	excytlp4h2wu0dw1dmy4dw8a	en	["ar"]	failed	2026-01-31 14:24:42.544	2026-01-31 14:24:42.55
656	api::feature.feature	r56toikejeuegz60hrwzjubg	en	["ar"]	failed	2026-01-31 14:24:42.587	2026-01-31 14:24:42.593
657	api::feature.feature	hnskuoj69718u78h9fasu7dw	en	["ar"]	failed	2026-01-31 14:24:42.623	2026-01-31 14:24:42.629
658	api::feature.feature	p3jkhx1sgbcch922pr4vjzoj	en	["ar"]	failed	2026-01-31 14:24:42.658	2026-01-31 14:24:42.665
665	api::value.value	ntapv0zj4vgr3vi1qpc2okiw	en	["ar"]	failed	2026-01-31 14:24:42.929	2026-01-31 14:24:42.936
666	api::value.value	pvr5q710auicl2fjvgrba2ar	en	["ar"]	failed	2026-01-31 14:24:42.965	2026-01-31 14:24:42.972
667	api::testimonial.testimonial	xcdggjhgukcprqo7a2zjglx6	en	["ar"]	failed	2026-01-31 14:24:43.008	2026-01-31 14:24:43.015
668	api::testimonial.testimonial	pmkcdsg84vanaz1q5qzq17yd	en	["ar"]	failed	2026-01-31 14:24:43.049	2026-01-31 14:24:43.056
669	api::testimonial.testimonial	aa5z0fc0icrqdxchwlnk2lz8	en	["ar"]	failed	2026-01-31 14:24:43.089	2026-01-31 14:24:43.095
670	api::testimonial.testimonial	pzvrrqh0f9e160hbs16gwmoz	en	["ar"]	failed	2026-01-31 14:24:43.129	2026-01-31 14:24:43.137
672	api::testimonial.testimonial	i4ry0buvk91ctmcx3f6rasbe	en	["ar"]	failed	2026-01-31 14:24:43.205	2026-01-31 14:24:43.211
673	api::faq.faq	v0ow6u4s0jzwfxogxuju2su5	en	["ar"]	failed	2026-01-31 14:24:43.244	2026-01-31 14:24:43.251
674	api::faq.faq	wkt6h2zanvemyf43u5wazqwk	en	["ar"]	failed	2026-01-31 14:24:43.283	2026-01-31 14:24:43.289
675	api::faq.faq	jy32k2q3nj30lluci5vldi50	en	["ar"]	failed	2026-01-31 14:24:43.323	2026-01-31 14:24:43.33
676	api::faq.faq	oy5e0q1a8z7n5nhi3m2s823t	en	["ar"]	failed	2026-01-31 14:24:43.36	2026-01-31 14:24:43.366
677	api::faq.faq	f5j8gik538wvdq3ycvxx9med	en	["ar"]	failed	2026-01-31 14:24:43.399	2026-01-31 14:24:43.405
678	api::faq.faq	uub5r4e6cg6s3dal00pwi56s	en	["ar"]	failed	2026-01-31 14:24:43.436	2026-01-31 14:24:43.442
679	api::faq.faq	z9kxr2kd50kxu14yrl48x6m7	en	["ar"]	failed	2026-01-31 14:24:43.474	2026-01-31 14:24:43.481
682	api::faq.faq	ypkarpy73flag9re4w7hpgoh	en	["ar"]	failed	2026-01-31 14:24:43.585	2026-01-31 14:24:43.591
683	api::pricing-plan.pricing-plan	vjoztkrjxnodcbzvi4ai9ziz	en	["ar"]	failed	2026-01-31 14:24:43.627	2026-01-31 14:24:43.635
697	api::demo.demo	st04cufizjg31xif9xghy8lc	en	["ar"]	failed	2026-01-31 14:24:44.201	2026-01-31 14:24:44.207
700	api::case-study.case-study	zv5r7fr7kzr5gi2xtzmt0kfj	en	["ar"]	failed	2026-01-31 14:24:44.316	2026-01-31 14:24:44.322
703	api::case-study.case-study	me195q6j30e5w9nirkcot0zf	en	["ar"]	failed	2026-01-31 14:24:44.435	2026-01-31 14:24:44.442
705	api::solution.solution	xff83zjfygw252ph4gv2utkx	en	["ar"]	failed	2026-01-31 14:24:44.508	2026-01-31 14:24:44.514
707	api::solution.solution	rzg4nwfhon89brk96cduq59e	en	["ar"]	failed	2026-01-31 14:24:44.578	2026-01-31 14:24:44.584
710	api::industry.industry	umk6i84zbw38gebvhdreqgfe	en	["ar"]	failed	2026-01-31 14:24:44.682	2026-01-31 14:24:44.688
712	api::industry.industry	j9fn150g2dwqjbxa65yzj8vl	en	["ar"]	failed	2026-01-31 14:24:44.755	2026-01-31 14:24:44.761
836	api::nav-item.nav-item	xd8d3ioy4927yd9ibzony4yi	en	["ar"]	failed	2026-01-31 14:35:42.742	2026-01-31 14:35:42.749
837	api::nav-item.nav-item	phv1i7fsz4agxlfw2grcdn38	en	["ar"]	failed	2026-01-31 14:35:42.777	2026-01-31 14:35:42.783
844	api::nav-item.nav-item	ady96lgy3sroguksdoywv6tc	en	["ar"]	failed	2026-01-31 14:35:43.023	2026-01-31 14:35:43.029
849	api::nav-item.nav-item	rqcgsili9dmbnj4yc7x454w2	en	["ar"]	failed	2026-01-31 14:35:43.231	2026-01-31 14:35:43.237
850	api::nav-item.nav-item	yaq3o6em7behudvhfk32ikfx	en	["ar"]	failed	2026-01-31 14:35:43.273	2026-01-31 14:35:43.278
851	api::team-member.team-member	nay0f3tuxbrqucv8f9amullh	en	["ar"]	failed	2026-01-31 14:35:43.588	2026-01-31 14:35:43.595
854	api::team-member.team-member	jpnbs5373sey8fs2df9xfnl0	en	["ar"]	failed	2026-01-31 14:35:43.712	2026-01-31 14:35:43.719
642	api::team-member.team-member	xt3ll8tl8nsfogs679a8s69i	en	["ar"]	failed	2026-01-31 14:24:42.032	2026-01-31 14:24:42.038
694	api::demo.demo	z2auulejzgsjd88su5ni6pmu	en	["ar"]	failed	2026-01-31 14:24:44.092	2026-01-31 14:24:44.098
696	api::demo.demo	rgblu192uif3n2gaw21fjouc	en	["ar"]	failed	2026-01-31 14:24:44.164	2026-01-31 14:24:44.17
699	api::case-study.case-study	v7jehtpeo22ql1nvtd4zg5s9	en	["ar"]	failed	2026-01-31 14:24:44.279	2026-01-31 14:24:44.284
701	api::case-study.case-study	ol3x0k67z10wsni6ou46jith	en	["ar"]	failed	2026-01-31 14:24:44.35	2026-01-31 14:24:44.359
704	api::solution.solution	wob66fxoegfdve347o8mdyi0	en	["ar"]	failed	2026-01-31 14:24:44.471	2026-01-31 14:24:44.477
706	api::solution.solution	g5cnyreaqg0vhn4yqwakpol8	en	["ar"]	failed	2026-01-31 14:24:44.541	2026-01-31 14:24:44.547
433	api::testimonial.testimonial	ldd10igmczfl4jqf118cyqgd	en	["ar"]	failed	2026-01-30 15:52:08.791	2026-01-30 15:57:25.657
709	api::solution.solution	f3b9h52bhsf7dosvcqd8v6ce	en	["ar"]	failed	2026-01-31 14:24:44.646	2026-01-31 14:24:44.653
434	api::faq.faq	cowvs2t800dl3e68phhvr5va	en	["ar"]	failed	2026-01-30 15:52:08.849	2026-01-30 15:57:25.707
456	api::demo.demo	cegq9uar2a7wg3u4sekzjvez	en	["ar"]	failed	2026-01-30 15:52:10.082	2026-01-30 15:57:26.606
711	api::industry.industry	ix0nmpvel8311m02iwaggh76	en	["ar"]	failed	2026-01-31 14:24:44.713	2026-01-31 14:24:44.72
464	api::case-study.case-study	r7felbje3u95hcujnc7geoc5	en	["ar"]	failed	2026-01-30 15:52:10.502	2026-01-30 15:57:26.931
465	api::solution.solution	ak6fr4wtqn6va3phwr0aw8n3	en	["ar"]	failed	2026-01-30 15:52:10.555	2026-01-30 15:57:26.971
714	api::industry.industry	urekbl4vzen6k0x2pam94p5y	en	["ar"]	failed	2026-01-31 14:24:44.82	2026-01-31 14:24:44.826
840	api::nav-item.nav-item	sjsais0smgho4kti88dl9oxi	en	["ar"]	failed	2026-01-31 14:35:42.892	2026-01-31 14:35:42.897
841	api::nav-item.nav-item	xi5ovis4rfma5gpq4ipihrjq	en	["ar"]	failed	2026-01-31 14:35:42.925	2026-01-31 14:35:42.93
842	api::nav-item.nav-item	qrwofycuuxm1enf5167lesxn	en	["ar"]	failed	2026-01-31 14:35:42.958	2026-01-31 14:35:42.963
846	api::nav-item.nav-item	bl8ap3q7fqcjcrk0s0c6g78d	en	["ar"]	failed	2026-01-31 14:35:43.093	2026-01-31 14:35:43.099
847	api::nav-item.nav-item	m3v5szka7fpm7olj8z86bxv9	en	["ar"]	failed	2026-01-31 14:35:43.128	2026-01-31 14:35:43.133
848	api::nav-item.nav-item	t5lwx4sc24nwl7rm1stxtwot	en	["ar"]	failed	2026-01-31 14:35:43.164	2026-01-31 14:35:43.171
856	api::team-member.team-member	es8xtf9ov75lt6oqzlpod3gu	en	["ar"]	failed	2026-01-31 14:35:43.791	2026-01-31 14:35:43.796
859	api::stat.stat	ucwor19ls9a1976o9tvjdixa	en	["ar"]	failed	2026-01-31 14:35:43.902	2026-01-31 14:35:43.908
882	api::testimonial.testimonial	zxwedzwbtnl8wp7604s81m6m	en	["ar"]	failed	2026-01-31 14:35:44.755	2026-01-31 14:35:44.762
883	api::testimonial.testimonial	sb83hqp2te16uduw47rmljah	en	["ar"]	failed	2026-01-31 14:35:44.792	2026-01-31 14:35:44.797
888	api::faq.faq	mr61uojamzmm275hhad6cagm	en	["ar"]	failed	2026-01-31 14:35:44.972	2026-01-31 14:35:44.976
891	api::faq.faq	ym0gvzr20skz08cwrnbqku9e	en	["ar"]	failed	2026-01-31 14:35:45.073	2026-01-31 14:35:45.079
894	api::faq.faq	j4l9sc6hz0ufjnfl0fa22it0	en	["ar"]	failed	2026-01-31 14:35:45.172	2026-01-31 14:35:45.178
896	api::faq.faq	piwzjvmhjwfuhmjyeibz49wp	en	["ar"]	failed	2026-01-31 14:35:45.234	2026-01-31 14:35:45.244
902	api::partner.partner	lxuqdxi38ohewsh81rhroa7j	en	["ar"]	failed	2026-01-31 14:35:45.444	2026-01-31 14:35:45.452
906	api::partner.partner	c5q4hiswo52duy7czhmuyuo6	en	["ar"]	failed	2026-01-31 14:35:45.582	2026-01-31 14:35:45.588
909	api::demo.demo	x31gpugoika5btid3finpu80	en	["ar"]	failed	2026-01-31 14:35:45.687	2026-01-31 14:35:45.693
911	api::demo.demo	l9w5i8o0wff0poq9oq73pl7r	en	["ar"]	failed	2026-01-31 14:35:45.753	2026-01-31 14:35:45.76
913	api::case-study.case-study	rd6tsf1ndba24o5mtkzcg1zh	en	["ar"]	failed	2026-01-31 14:35:45.819	2026-01-31 14:35:45.825
915	api::case-study.case-study	jccldwrusgooe1gp212o7k4d	en	["ar"]	failed	2026-01-31 14:35:45.883	2026-01-31 14:35:45.889
917	api::case-study.case-study	fg35oj0oy923l5jl14vt4f9q	en	["ar"]	failed	2026-01-31 14:35:45.948	2026-01-31 14:35:45.955
919	api::solution.solution	fds4flkd53b8ipbnomo6musf	en	["ar"]	failed	2026-01-31 14:35:46.017	2026-01-31 14:35:46.025
923	api::solution.solution	otw6mvcnsfvjav7e53hhxqil	en	["ar"]	failed	2026-01-31 14:35:46.152	2026-01-31 14:35:46.158
959	api::team-member.team-member	mmmm08o2eydwv7ug3oicidv5	en	["ar"]	failed	2026-01-31 14:38:47.174	2026-01-31 14:38:47.18
960	api::team-member.team-member	ouq69nlcwcrj57lkkbyfsp1q	en	["ar"]	failed	2026-01-31 14:38:47.211	2026-01-31 14:38:47.217
963	api::stat.stat	f1bumxf4k1golsabztx05sh4	en	["ar"]	failed	2026-01-31 14:38:47.328	2026-01-31 14:38:47.334
964	api::stat.stat	q995ob3d807nktpym5g50dyt	en	["ar"]	failed	2026-01-31 14:38:47.362	2026-01-31 14:38:47.369
987	api::testimonial.testimonial	reccmlzbohpv31zpzgv6wsvk	en	["ar"]	failed	2026-01-31 14:38:48.171	2026-01-31 14:38:48.177
988	api::testimonial.testimonial	g9z32e5vq6fckxd1dpr1aft8	en	["ar"]	failed	2026-01-31 14:38:48.204	2026-01-31 14:38:48.212
994	api::faq.faq	ud54f8nddcsxr23xcrau7fql	en	["ar"]	failed	2026-01-31 14:38:48.411	2026-01-31 14:38:48.416
997	api::faq.faq	miki32dzhy5kiovhhazvwsc1	en	["ar"]	failed	2026-01-31 14:38:48.503	2026-01-31 14:38:48.509
999	api::faq.faq	e0k55f17dj2i96nlj78439d4	en	["ar"]	failed	2026-01-31 14:38:48.562	2026-01-31 14:38:48.568
1001	api::faq.faq	xdfcqlgqam5d1jdmal3khrgv	en	["ar"]	failed	2026-01-31 14:38:48.634	2026-01-31 14:38:48.641
1004	api::pricing-plan.pricing-plan	gz12g1k9yp2zxfew0cfjv7sv	en	["ar"]	failed	2026-01-31 14:38:48.731	2026-01-31 14:38:48.739
1006	api::pricing-plan.pricing-plan	pt6ruvkfoe2up0d03vh3e28t	en	["ar"]	failed	2026-01-31 14:38:48.803	2026-01-31 14:38:48.81
1010	api::partner.partner	cjqssvi3dkn4nmdvkfs5w5le	en	["ar"]	failed	2026-01-31 14:38:48.933	2026-01-31 14:38:48.939
1013	api::demo.demo	e9kcb6ltcazj6i5ovxvqjehv	en	["ar"]	failed	2026-01-31 14:38:49.038	2026-01-31 14:38:49.043
1015	api::demo.demo	jwar2vn701ng15n30e5xsp0d	en	["ar"]	failed	2026-01-31 14:38:49.113	2026-01-31 14:38:49.12
1018	api::demo.demo	yst2bnr3sn4et4ebbwlg77mg	en	["ar"]	failed	2026-01-31 14:38:49.207	2026-01-31 14:38:49.212
1020	api::case-study.case-study	k2bo8rd56vr1ilzcyq9307xa	en	["ar"]	failed	2026-01-31 14:38:49.273	2026-01-31 14:38:49.278
1022	api::case-study.case-study	bd8ix03bk09d91rog473fit7	en	["ar"]	failed	2026-01-31 14:38:49.334	2026-01-31 14:38:49.342
1025	api::solution.solution	s5y6s1bh875ntqo00n5qz2t5	en	["ar"]	failed	2026-01-31 14:38:49.43	2026-01-31 14:38:49.436
1028	api::solution.solution	dv6e0pw7letbp4nsed49oupq	en	["ar"]	failed	2026-01-31 14:38:49.522	2026-01-31 14:38:49.529
1031	api::industry.industry	stwbkykfijbk9t8mvchksqa7	en	["ar"]	failed	2026-01-31 14:38:49.62	2026-01-31 14:38:49.625
1033	api::industry.industry	rskeqj6820z6oks6qflslpml	en	["ar"]	failed	2026-01-31 14:38:49.68	2026-01-31 14:38:49.687
1043	api::nav-item.nav-item	o3ngoin1orf21o4bumuzvjon	en	["ar"]	failed	2026-01-31 14:46:03.294	2026-01-31 14:46:03.301
1044	api::nav-item.nav-item	ndqemifx786fcmzwc4artgrd	en	["ar"]	failed	2026-01-31 14:46:03.334	2026-01-31 14:46:03.347
1045	api::nav-item.nav-item	wwvo5gik27e7rz0hk1b119zq	en	["ar"]	failed	2026-01-31 14:46:03.383	2026-01-31 14:46:03.394
1066	api::team-member.team-member	eq2dzqsi32qc6ei6h70dnrs0	en	["ar"]	failed	2026-01-31 14:46:04.667	2026-01-31 14:46:04.673
1068	api::team-member.team-member	br8t1g4n9duzh7zul47hroym	en	["ar"]	failed	2026-01-31 14:46:04.765	2026-01-31 14:46:04.771
716	api::nav-item.nav-item	j5d013dajzg90881ux5lo0zg	en	["ar"]	failed	2026-01-31 14:26:38.458	2026-01-31 14:26:38.467
717	api::nav-item.nav-item	fufmixvhdr82oas9g7aibk7w	en	["ar"]	failed	2026-01-31 14:26:38.518	2026-01-31 14:26:38.526
722	api::nav-item.nav-item	c9f414xhtukn9ewmv3nw3ak2	en	["ar"]	failed	2026-01-31 14:26:38.73	2026-01-31 14:26:38.737
724	api::nav-item.nav-item	wya4pfmsr685e14qro38anof	en	["ar"]	failed	2026-01-31 14:26:38.812	2026-01-31 14:26:38.819
725	api::nav-item.nav-item	kwt67ivp0oof876tubjfag6c	en	["ar"]	failed	2026-01-31 14:26:38.852	2026-01-31 14:26:38.857
726	api::nav-item.nav-item	bprbkiovc22vqano1veeciu6	en	["ar"]	failed	2026-01-31 14:26:38.889	2026-01-31 14:26:38.894
727	api::nav-item.nav-item	f0a6a4d2mbc6v0zzd6447u4q	en	["ar"]	failed	2026-01-31 14:26:38.928	2026-01-31 14:26:38.936
728	api::nav-item.nav-item	bjdf5g6e6d742alv0il7whl5	en	["ar"]	failed	2026-01-31 14:26:38.972	2026-01-31 14:26:38.977
730	api::nav-item.nav-item	wreoo9n1spq3sm46xvfqiinx	en	["ar"]	failed	2026-01-31 14:26:39.05	2026-01-31 14:26:39.057
477	api::homepage.homepage	seosxqr4oho1hh4c3jb2tv38	en	["ar"]	failed	2026-01-30 15:55:15.181	2026-01-30 15:57:22.705
483	api::about-page.about-page	rwmt90uu03ab6769dlwf9mmz	en	["ar"]	failed	2026-01-30 15:57:22.737	2026-01-30 15:57:22.745
484	api::contact-page.contact-page	ixev5sy4qg1obchjlirmkshy	en	["ar"]	failed	2026-01-30 15:57:22.773	2026-01-30 15:57:22.783
485	api::site-setting.site-setting	d3g3nzs62511l94o8nmv6uqw	en	["ar"]	failed	2026-01-30 15:57:22.814	2026-01-30 15:57:22.822
478	api::pricing-page.pricing-page	qzusqgqk8gfiuzkuz49d1562	en	["ar"]	failed	2026-01-30 15:55:15.262	2026-01-30 15:57:22.862
731	api::nav-item.nav-item	d5tzfjk71x9l6x7r3z1q3o42	en	["ar"]	failed	2026-01-31 14:26:39.089	2026-01-31 14:26:39.095
479	api::solutions-page.solutions-page	wkzeoejahwkrkjxsmns02w2r	en	["ar"]	failed	2026-01-30 15:55:15.305	2026-01-30 15:57:22.899
480	api::industries-page.industries-page	pmyktga6m2p6lhv3jx6nhvaf	en	["ar"]	failed	2026-01-30 15:55:15.352	2026-01-30 15:57:22.942
732	api::nav-item.nav-item	ch4z448cpyae3qswwh1hdrcw	en	["ar"]	failed	2026-01-31 14:26:39.128	2026-01-31 14:26:39.135
481	api::demos-page.demos-page	epbl5l6urmqownlxg3hm4b3v	en	["ar"]	failed	2026-01-30 15:55:15.406	2026-01-30 15:57:22.991
482	api::case-studies-page.case-studies-page	u8gd9wweu2t98qfyz6d9b0r6	en	["ar"]	failed	2026-01-30 15:55:15.49	2026-01-30 15:57:23.033
733	api::nav-item.nav-item	xayrkqwckchostnis2xktj1o	en	["ar"]	failed	2026-01-31 14:26:39.164	2026-01-31 14:26:39.171
452	api::partner.partner	xzddab1fcmq8v0esao73h7ta	en	["ar"]	failed	2026-01-30 15:52:09.874	2026-01-30 15:57:26.435
453	api::partner.partner	c1q5hr4y4ozydichnc4g4obf	en	["ar"]	failed	2026-01-30 15:52:09.927	2026-01-30 15:57:26.474
735	api::nav-item.nav-item	y5b8jyqxxq9zul7r3ey0skby	en	["ar"]	failed	2026-01-31 14:26:39.241	2026-01-31 14:26:39.247
454	api::demo.demo	u8hpfg3lh3rtffp23hvjvocu	en	["ar"]	failed	2026-01-30 15:52:09.981	2026-01-30 15:57:26.523
455	api::demo.demo	kojy0zkjj5r0bklv3pk045cr	en	["ar"]	failed	2026-01-30 15:52:10.031	2026-01-30 15:57:26.564
736	api::nav-item.nav-item	w3ld6zvou012om199q0v6kt0	en	["ar"]	failed	2026-01-31 14:26:39.277	2026-01-31 14:26:39.284
737	api::nav-item.nav-item	ub00o2aie1jiyuodkksyzkwt	en	["ar"]	failed	2026-01-31 14:26:39.316	2026-01-31 14:26:39.321
738	api::nav-item.nav-item	qryaiufg2d7ue8ljfplria54	en	["ar"]	failed	2026-01-31 14:26:39.355	2026-01-31 14:26:39.362
740	api::nav-item.nav-item	myck24ycxenew5kcm0kwgkef	en	["ar"]	failed	2026-01-31 14:26:39.431	2026-01-31 14:26:39.438
741	api::nav-item.nav-item	n5jmtsf8jdpmypoaqp3m8vpj	en	["ar"]	failed	2026-01-31 14:26:39.466	2026-01-31 14:26:39.472
749	api::stat.stat	kx6ph658248o813gmrwtcsim	en	["ar"]	failed	2026-01-31 14:26:40.07	2026-01-31 14:26:40.077
750	api::stat.stat	n29ubft61u6ajr6wrrtbepek	en	["ar"]	failed	2026-01-31 14:26:40.112	2026-01-31 14:26:40.118
751	api::stat.stat	mpry8lnp0g1iddit7dfprt1q	en	["ar"]	failed	2026-01-31 14:26:40.148	2026-01-31 14:26:40.154
752	api::stat.stat	lv5n0wi0kufb6uxn4jxlibnh	en	["ar"]	failed	2026-01-31 14:26:40.182	2026-01-31 14:26:40.189
754	api::stat.stat	l8x8xak9t4p9aadwsxjucnsx	en	["ar"]	failed	2026-01-31 14:26:40.255	2026-01-31 14:26:40.261
761	api::feature.feature	fo9oibunhrml9smvayuq6wo1	en	["ar"]	failed	2026-01-31 14:26:40.522	2026-01-31 14:26:40.528
762	api::feature.feature	q7vh7p6u15yi9zqzedq6pyyv	en	["ar"]	failed	2026-01-31 14:26:40.559	2026-01-31 14:26:40.565
779	api::faq.faq	v1p5rdwiiyosuyqxfroqylip	en	["ar"]	failed	2026-01-31 14:26:41.239	2026-01-31 14:26:41.245
782	api::faq.faq	hpynfngvgecdpgpppeugwswt	en	["ar"]	failed	2026-01-31 14:26:41.37	2026-01-31 14:26:41.376
785	api::faq.faq	zd7mwbt6rix31tie18534tdc	en	["ar"]	failed	2026-01-31 14:26:41.475	2026-01-31 14:26:41.481
789	api::pricing-plan.pricing-plan	xxevhoyb0rm3swh1zxvxe5ob	en	["ar"]	failed	2026-01-31 14:26:41.607	2026-01-31 14:26:41.615
792	api::pricing-plan.pricing-plan	y65ra8p01c71efkyrik2qt3h	en	["ar"]	failed	2026-01-31 14:26:41.713	2026-01-31 14:26:41.723
796	api::partner.partner	dgfutjdd52jz75ocv4rtbryi	en	["ar"]	failed	2026-01-31 14:26:41.851	2026-01-31 14:26:41.857
802	api::demo.demo	cvbjvdtj42sdxc2gzp0f5blk	en	["ar"]	failed	2026-01-31 14:26:42.063	2026-01-31 14:26:42.07
852	api::team-member.team-member	m89wdkirzsbhe069220jec71	en	["ar"]	failed	2026-01-31 14:35:43.631	2026-01-31 14:35:43.638
855	api::team-member.team-member	y22prko30bwzsma29kcc34p7	en	["ar"]	failed	2026-01-31 14:35:43.753	2026-01-31 14:35:43.757
857	api::stat.stat	uqvz7ctsaozkmmr62lihxc8h	en	["ar"]	failed	2026-01-31 14:35:43.833	2026-01-31 14:35:43.84
858	api::stat.stat	q0iw507jn0ccwojs0do71hwx	en	["ar"]	failed	2026-01-31 14:35:43.868	2026-01-31 14:35:43.874
860	api::stat.stat	wsq6whpi5w127uwh0rr8loyy	en	["ar"]	failed	2026-01-31 14:35:43.944	2026-01-31 14:35:43.949
861	api::stat.stat	dqqe5jw8qf0l6wns6by0tidm	en	["ar"]	failed	2026-01-31 14:35:43.984	2026-01-31 14:35:43.99
862	api::stat.stat	lyviv9rpfo0jiaftwbuz43mo	en	["ar"]	failed	2026-01-31 14:35:44.016	2026-01-31 14:35:44.023
868	api::feature.feature	bn5gk0thaz70ofcvv01c0qea	en	["ar"]	failed	2026-01-31 14:35:44.242	2026-01-31 14:35:44.248
869	api::feature.feature	ibtbjarl89ybm5gs8ikbhlnp	en	["ar"]	failed	2026-01-31 14:35:44.278	2026-01-31 14:35:44.289
874	api::feature.feature	fw6jfkfxfw1x9nkgtpxva2yu	en	["ar"]	failed	2026-01-31 14:35:44.464	2026-01-31 14:35:44.469
875	api::value.value	tv3gdn0qcmd95l00nk7e8us2	en	["ar"]	failed	2026-01-31 14:35:44.5	2026-01-31 14:35:44.506
876	api::value.value	kexuow5ri5ybsy7tb1pafslo	en	["ar"]	failed	2026-01-31 14:35:44.532	2026-01-31 14:35:44.539
961	api::team-member.team-member	vk5z14os5vezfzpcthyd9e3r	en	["ar"]	failed	2026-01-31 14:38:47.25	2026-01-31 14:38:47.256
984	api::value.value	fhjj3zf49w3m1khp3j1i13m0	en	["ar"]	failed	2026-01-31 14:38:48.058	2026-01-31 14:38:48.066
985	api::value.value	sxdzvdzz0t6ml0ly3qozx4p0	en	["ar"]	failed	2026-01-31 14:38:48.097	2026-01-31 14:38:48.103
986	api::value.value	nj6o18x3ainhnpg79tz605jf	en	["ar"]	failed	2026-01-31 14:38:48.133	2026-01-31 14:38:48.14
1051	api::nav-item.nav-item	c0z7f2giflrddwqui0pct42x	en	["ar"]	failed	2026-01-31 14:46:03.664	2026-01-31 14:46:03.67
1052	api::nav-item.nav-item	b1hos20vqvmc4ttymha1moci	en	["ar"]	failed	2026-01-31 14:46:03.712	2026-01-31 14:46:03.718
1053	api::nav-item.nav-item	etpwvw1y0fjfawydskjzzube	en	["ar"]	failed	2026-01-31 14:46:03.758	2026-01-31 14:46:03.765
1091	api::value.value	mg9t8qfokoeveglksljjjmqo	en	["ar"]	failed	2026-01-31 14:46:05.871	2026-01-31 14:46:05.877
1092	api::value.value	ofsqypuns1kj5zqjkr0g4yx9	en	["ar"]	failed	2026-01-31 14:46:05.916	2026-01-31 14:46:05.922
1093	api::value.value	s6fnxil2ombgxivxc8rckiwo	en	["ar"]	failed	2026-01-31 14:46:05.961	2026-01-31 14:46:05.967
1094	api::testimonial.testimonial	cw3pltvbd0wq7uni3zx3f07d	en	["ar"]	failed	2026-01-31 14:46:06.011	2026-01-31 14:46:06.019
1101	api::faq.faq	brfsmidacboqph8boeynk324	en	["ar"]	failed	2026-01-31 14:46:06.325	2026-01-31 14:46:06.331
1104	api::faq.faq	jvmxtry3h5a4ygckl46ogf0t	en	["ar"]	failed	2026-01-31 14:46:06.451	2026-01-31 14:46:06.458
1108	api::faq.faq	yqrkjayhkmuxcmvp3ab3l1zx	en	["ar"]	failed	2026-01-31 14:46:06.612	2026-01-31 14:46:06.618
1113	api::pricing-plan.pricing-plan	dz09vjr0k1el4v65ajekz4i3	en	["ar"]	failed	2026-01-31 14:46:06.832	2026-01-31 14:46:06.838
1115	api::partner.partner	fwd7c54bzbr9zo4h0mx79u5k	en	["ar"]	failed	2026-01-31 14:46:06.972	2026-01-31 14:46:06.979
1117	api::partner.partner	xvacy724yc7b5c9cbg8b97c0	en	["ar"]	failed	2026-01-31 14:46:07.064	2026-01-31 14:46:07.07
1123	api::demo.demo	ji4b0uozfmgk8fnpmrc274bv	en	["ar"]	failed	2026-01-31 14:46:07.327	2026-01-31 14:46:07.333
1126	api::case-study.case-study	vxwtfw49kthdssal4brrx3j6	en	["ar"]	failed	2026-01-31 14:46:07.457	2026-01-31 14:46:07.463
1129	api::case-study.case-study	bfmah3my4lwzf4kg590zyhzv	en	["ar"]	failed	2026-01-31 14:46:07.575	2026-01-31 14:46:07.584
1131	api::solution.solution	arstgw5ez03tfa7xq88jnvc5	en	["ar"]	failed	2026-01-31 14:46:07.66	2026-01-31 14:46:07.666
1133	api::solution.solution	r07n1cp2pcdr1z7jvnh0cajt	en	["ar"]	failed	2026-01-31 14:46:07.737	2026-01-31 14:46:07.749
1136	api::solution.solution	y2k00h2dk6l6225seghtldar	en	["ar"]	failed	2026-01-31 14:46:07.859	2026-01-31 14:46:07.865
1138	api::industry.industry	y5jv2mec1i8gdrq5ao9wahvn	en	["ar"]	failed	2026-01-31 14:46:07.933	2026-01-31 14:46:07.939
1140	api::industry.industry	jfil375a147ha9tb473wbixc	en	["ar"]	failed	2026-01-31 14:46:08.011	2026-01-31 14:46:08.02
1095	api::testimonial.testimonial	sm6el20go2gy30owecc8tdsb	en	["ar"]	failed	2026-01-31 14:46:06.058	2026-01-31 14:46:06.065
1096	api::testimonial.testimonial	syfxx4iycsidlwunscis53x8	en	["ar"]	failed	2026-01-31 14:46:06.101	2026-01-31 14:46:06.108
1103	api::faq.faq	rp6m6vz3obj5k0e8kzl025rj	en	["ar"]	failed	2026-01-31 14:46:06.41	2026-01-31 14:46:06.415
1106	api::faq.faq	airfm8l19xtcr2dhb875zjbq	en	["ar"]	failed	2026-01-31 14:46:06.527	2026-01-31 14:46:06.535
1109	api::faq.faq	ougfv7lnm8ll5u05nq29nnhj	en	["ar"]	failed	2026-01-31 14:46:06.653	2026-01-31 14:46:06.66
1111	api::pricing-plan.pricing-plan	j7ws4psft8p8l0j7466489xb	en	["ar"]	failed	2026-01-31 14:46:06.737	2026-01-31 14:46:06.747
1114	api::partner.partner	wuqa7p9gwg2ainm1a3130te4	en	["ar"]	failed	2026-01-31 14:46:06.883	2026-01-31 14:46:06.89
1116	api::partner.partner	c8fiuxzr83rknuub2td7bxdo	en	["ar"]	failed	2026-01-31 14:46:07.021	2026-01-31 14:46:07.027
1119	api::partner.partner	m8piv5wtj9zxpa0eru7747ti	en	["ar"]	failed	2026-01-31 14:46:07.151	2026-01-31 14:46:07.157
1121	api::demo.demo	y1rg8qprnr5ie8exj5zkml13	en	["ar"]	failed	2026-01-31 14:46:07.241	2026-01-31 14:46:07.251
1124	api::demo.demo	tj0p4iiiylssggg3okseuehw	en	["ar"]	failed	2026-01-31 14:46:07.372	2026-01-31 14:46:07.378
1127	api::case-study.case-study	ci9ax5r9diqn0wu67uf7f16z	en	["ar"]	failed	2026-01-31 14:46:07.491	2026-01-31 14:46:07.504
1130	api::case-study.case-study	jqujmitceo7gnsuzyxvmc0c0	en	["ar"]	failed	2026-01-31 14:46:07.62	2026-01-31 14:46:07.627
1132	api::solution.solution	gyycgmqlqyow2qoxgycup86p	en	["ar"]	failed	2026-01-31 14:46:07.704	2026-01-31 14:46:07.711
1135	api::solution.solution	lwi5sdgxaks0ez6z6d8g3j11	en	["ar"]	failed	2026-01-31 14:46:07.818	2026-01-31 14:46:07.824
1141	api::industry.industry	xmy4xgrg3bca4f6aqs4wwdps	en	["ar"]	failed	2026-01-31 14:46:08.048	2026-01-31 14:46:08.055
1097	api::testimonial.testimonial	pif1r16tcnqrtp8p22lx4umo	en	["ar"]	failed	2026-01-31 14:46:06.149	2026-01-31 14:46:06.155
1098	api::testimonial.testimonial	zehw3cclj4y0u37kun8b8ati	en	["ar"]	failed	2026-01-31 14:46:06.188	2026-01-31 14:46:06.201
1099	api::testimonial.testimonial	pt8igablrp2ummpkdek4bkif	en	["ar"]	failed	2026-01-31 14:46:06.232	2026-01-31 14:46:06.239
1100	api::faq.faq	a4j9x8quo7vvcm3aoe44lhq2	en	["ar"]	failed	2026-01-31 14:46:06.281	2026-01-31 14:46:06.289
1102	api::faq.faq	tz2lc4hr405t9dc4kqrnhcjv	en	["ar"]	failed	2026-01-31 14:46:06.365	2026-01-31 14:46:06.371
1105	api::faq.faq	m8zr4eigyfin3urgetqelg2n	en	["ar"]	failed	2026-01-31 14:46:06.487	2026-01-31 14:46:06.497
1107	api::faq.faq	l1g4l2eqpj2v9utjbd8m3jc1	en	["ar"]	failed	2026-01-31 14:46:06.568	2026-01-31 14:46:06.575
1110	api::pricing-plan.pricing-plan	inzdv0plxxlnh6kp41av8ode	en	["ar"]	failed	2026-01-31 14:46:06.693	2026-01-31 14:46:06.701
1112	api::pricing-plan.pricing-plan	zwv8he1420rp60vvpvkrcmuk	en	["ar"]	failed	2026-01-31 14:46:06.784	2026-01-31 14:46:06.791
1118	api::partner.partner	lllyj489pelrwj5ws3b9a02n	en	["ar"]	failed	2026-01-31 14:46:07.11	2026-01-31 14:46:07.116
1120	api::demo.demo	p8f5lc2kkhtnh3eiewysp8ap	en	["ar"]	failed	2026-01-31 14:46:07.203	2026-01-31 14:46:07.209
1122	api::demo.demo	pduvs64818nrs0tkd5eo6naw	en	["ar"]	failed	2026-01-31 14:46:07.284	2026-01-31 14:46:07.29
1125	api::demo.demo	w5vh0ipfoydet7qcj9xstqrj	en	["ar"]	failed	2026-01-31 14:46:07.418	2026-01-31 14:46:07.423
1128	api::case-study.case-study	o1zueb8hjwo2hbrszxyz1lmy	en	["ar"]	failed	2026-01-31 14:46:07.533	2026-01-31 14:46:07.539
1134	api::solution.solution	t2r2abzom8ygmpyv2sxudqcz	en	["ar"]	failed	2026-01-31 14:46:07.776	2026-01-31 14:46:07.783
1137	api::industry.industry	nn3a3r014j6u1dc725lis8kp	en	["ar"]	failed	2026-01-31 14:46:07.893	2026-01-31 14:46:07.902
1139	api::industry.industry	e8ltzwc7ikn6qytl6jr3ch3c	en	["ar"]	failed	2026-01-31 14:46:07.971	2026-01-31 14:46:07.978
1142	api::industry.industry	mjya0gpqqtbs9pr5hxqwkv7s	en	["ar"]	failed	2026-01-31 14:46:08.084	2026-01-31 14:46:08.09
1143	api::nav-item.nav-item	j8j7k459wb93alkslohjffka	en	["ar"]	failed	2026-01-31 14:47:49.724	2026-01-31 14:47:49.73
1144	api::nav-item.nav-item	a2rogoy3wpkn22ncpeh0qlum	en	["ar"]	failed	2026-01-31 14:47:49.766	2026-01-31 14:47:49.772
1145	api::nav-item.nav-item	wujm9cjj3xw2c82a5ugk6fni	en	["ar"]	failed	2026-01-31 14:47:49.812	2026-01-31 14:47:49.818
1146	api::nav-item.nav-item	gfev94l4um1qe2rde8p5r84y	en	["ar"]	failed	2026-01-31 14:47:49.86	2026-01-31 14:47:49.866
1147	api::nav-item.nav-item	m46suvs7y6q6k9l0den0g5n9	en	["ar"]	failed	2026-01-31 14:47:49.9	2026-01-31 14:47:49.906
1148	api::nav-item.nav-item	u9mg1avojubodm35evdzdy3u	en	["ar"]	failed	2026-01-31 14:47:49.941	2026-01-31 14:47:49.949
1149	api::nav-item.nav-item	fjznm5w8dj1oyx52siu979gh	en	["ar"]	failed	2026-01-31 14:47:49.98	2026-01-31 14:47:49.988
1150	api::nav-item.nav-item	he79wgq8dly4hrx5xdr49lrh	en	["ar"]	failed	2026-01-31 14:47:50.02	2026-01-31 14:47:50.026
1151	api::nav-item.nav-item	covi51wz6aslm0xc4k2hv2rh	en	["ar"]	failed	2026-01-31 14:47:50.06	2026-01-31 14:47:50.067
1152	api::nav-item.nav-item	tke01b2tcx4wv2aw808vf059	en	["ar"]	failed	2026-01-31 14:47:50.105	2026-01-31 14:47:50.112
1153	api::nav-item.nav-item	utls91ktc5tc4sdwb41m0ayn	en	["ar"]	failed	2026-01-31 14:47:50.144	2026-01-31 14:47:50.153
1154	api::nav-item.nav-item	ueqqjvwwzrlmb5prxxebzuuf	en	["ar"]	failed	2026-01-31 14:47:50.192	2026-01-31 14:47:50.199
1155	api::nav-item.nav-item	gdy95rfqhb4mq1sk3vf8nc7j	en	["ar"]	failed	2026-01-31 14:47:50.233	2026-01-31 14:47:50.238
1156	api::nav-item.nav-item	xs6ksn5rydmphhk4j8wr7z9j	en	["ar"]	failed	2026-01-31 14:47:50.273	2026-01-31 14:47:50.279
1157	api::nav-item.nav-item	zwp3pyaet5uoeuvs7qwqbobx	en	["ar"]	failed	2026-01-31 14:47:50.311	2026-01-31 14:47:50.317
1158	api::nav-item.nav-item	rbyep54v7txsn3a096xajjfh	en	["ar"]	failed	2026-01-31 14:47:50.354	2026-01-31 14:47:50.361
1159	api::nav-item.nav-item	vc5ykuqeql4lc87yxapkgzao	en	["ar"]	failed	2026-01-31 14:47:50.417	2026-01-31 14:47:50.431
1160	api::nav-item.nav-item	fno4xzq4cl6jvuxfmadsibuc	en	["ar"]	failed	2026-01-31 14:47:50.467	2026-01-31 14:47:50.473
1161	api::nav-item.nav-item	n2wxertlwj5hp6xh9d9arl9o	en	["ar"]	failed	2026-01-31 14:47:50.504	2026-01-31 14:47:50.511
1162	api::nav-item.nav-item	j94fgf5ewuf5f9h3qclp0dp6	en	["ar"]	failed	2026-01-31 14:47:50.545	2026-01-31 14:47:50.557
1163	api::nav-item.nav-item	o7ke8p6wb4kdnllhoq45ne5y	en	["ar"]	failed	2026-01-31 14:47:50.587	2026-01-31 14:47:50.593
1164	api::nav-item.nav-item	zs71vvgrmi6499z04x7kyuiz	en	["ar"]	failed	2026-01-31 14:47:50.624	2026-01-31 14:47:50.633
1165	api::nav-item.nav-item	uxq1ccl063gkrzly3s7jh4s8	en	["ar"]	failed	2026-01-31 14:47:50.663	2026-01-31 14:47:50.67
1166	api::nav-item.nav-item	uw2uum1c2dnbadylol2s0w49	en	["ar"]	failed	2026-01-31 14:47:50.702	2026-01-31 14:47:50.708
1167	api::nav-item.nav-item	gwtug8b2iunt20um6osyn1gl	en	["ar"]	failed	2026-01-31 14:47:50.738	2026-01-31 14:47:50.746
1168	api::nav-item.nav-item	rfv8ctemgc7u6g4kdgxk8db9	en	["ar"]	failed	2026-01-31 14:47:50.77	2026-01-31 14:47:50.779
1169	api::nav-item.nav-item	icfpa2ftqvp3lpqmciyyt3m7	en	["ar"]	failed	2026-01-31 14:47:50.809	2026-01-31 14:47:50.814
1170	api::team-member.team-member	w5bvdzmxcdd6dt9joshwvtv2	en	["ar"]	failed	2026-01-31 14:47:51.131	2026-01-31 14:47:51.138
1171	api::team-member.team-member	hxanfqvtfeotznrezmmzoa86	en	["ar"]	failed	2026-01-31 14:47:51.173	2026-01-31 14:47:51.18
1172	api::team-member.team-member	fbkb8w15jhrs4cv2cjulvhde	en	["ar"]	failed	2026-01-31 14:47:51.211	2026-01-31 14:47:51.217
1173	api::team-member.team-member	aeiiocdjkmm0qlimbe8jz9og	en	["ar"]	failed	2026-01-31 14:47:51.253	2026-01-31 14:47:51.259
1174	api::team-member.team-member	rbt67v3ft04q09xujryr5ovb	en	["ar"]	failed	2026-01-31 14:47:51.294	2026-01-31 14:47:51.301
1175	api::team-member.team-member	ag6pex14x1ubff9avf4nq48x	en	["ar"]	failed	2026-01-31 14:47:51.331	2026-01-31 14:47:51.337
1176	api::stat.stat	zmyd3qmhg9ma2decrvls8mqf	en	["ar"]	failed	2026-01-31 14:47:51.371	2026-01-31 14:47:51.377
1177	api::stat.stat	stkeiczokw8bya5mj6zwa15r	en	["ar"]	failed	2026-01-31 14:47:51.406	2026-01-31 14:47:51.415
1178	api::stat.stat	pqa1jfwirwykwccruvjeo2v3	en	["ar"]	failed	2026-01-31 14:47:51.445	2026-01-31 14:47:51.452
1179	api::stat.stat	ztxe9ceksp83vh1o2yslcf9p	en	["ar"]	failed	2026-01-31 14:47:51.51	2026-01-31 14:47:51.521
1180	api::stat.stat	vc9ua4cjbvn4ko4mnkfm05jm	en	["ar"]	failed	2026-01-31 14:47:51.552	2026-01-31 14:47:51.56
1181	api::stat.stat	s50yb1by2ez80xrd103igk1m	en	["ar"]	failed	2026-01-31 14:47:51.588	2026-01-31 14:47:51.594
1182	api::process-step.process-step	juvmtamiukxw5c7farzxfej8	en	["ar"]	failed	2026-01-31 14:47:51.629	2026-01-31 14:47:51.635
1183	api::process-step.process-step	cdtju2ez9vedpjk3qd2v3wu9	en	["ar"]	failed	2026-01-31 14:47:51.665	2026-01-31 14:47:51.671
1184	api::process-step.process-step	zzop88u13i93pmjrez1913i5	en	["ar"]	failed	2026-01-31 14:47:51.699	2026-01-31 14:47:51.705
1185	api::process-step.process-step	f6umbpk4qfi7s8bxlum7jxhd	en	["ar"]	failed	2026-01-31 14:47:51.733	2026-01-31 14:47:51.74
1186	api::feature.feature	tnq48gsbvtnhwa1yjk6y705e	en	["ar"]	failed	2026-01-31 14:47:51.773	2026-01-31 14:47:51.779
1187	api::feature.feature	c5e9lt1jpryormqva8iiwc2c	en	["ar"]	failed	2026-01-31 14:47:51.81	2026-01-31 14:47:51.816
1188	api::feature.feature	vko57m7ld749fcjmjf7oz5xj	en	["ar"]	failed	2026-01-31 14:47:51.844	2026-01-31 14:47:51.849
1189	api::feature.feature	rzepfai2dog9q0zwy3888sw2	en	["ar"]	failed	2026-01-31 14:47:51.88	2026-01-31 14:47:51.885
1190	api::feature.feature	qtya8bpmv353rr3y7locu0q5	en	["ar"]	failed	2026-01-31 14:47:51.924	2026-01-31 14:47:51.933
1209	api::faq.faq	d5yxta3ofatd248w2kxc052l	en	["ar"]	failed	2026-01-31 14:47:52.635	2026-01-31 14:47:52.642
1212	api::faq.faq	yxizony720zomrle7vv5oxbi	en	["ar"]	failed	2026-01-31 14:47:52.741	2026-01-31 14:47:52.747
1215	api::faq.faq	n25mol2hgukfzipjwkd2w1x3	en	["ar"]	failed	2026-01-31 14:47:52.841	2026-01-31 14:47:52.847
1219	api::pricing-plan.pricing-plan	lci77hnxjkoee2jqctgcqdm5	en	["ar"]	failed	2026-01-31 14:47:52.977	2026-01-31 14:47:52.986
1221	api::partner.partner	sao5wmnsasb9cm3qukflqete	en	["ar"]	failed	2026-01-31 14:47:53.047	2026-01-31 14:47:53.054
1223	api::partner.partner	geh081d464qrlkvk29muvqak	en	["ar"]	failed	2026-01-31 14:47:53.116	2026-01-31 14:47:53.124
1226	api::demo.demo	utezrhwlpn34t4oboml3ihdd	en	["ar"]	failed	2026-01-31 14:47:53.225	2026-01-31 14:47:53.231
1228	api::demo.demo	lysk8zxrm6b5h09baltpsn32	en	["ar"]	failed	2026-01-31 14:47:53.291	2026-01-31 14:47:53.298
1231	api::demo.demo	uc3h9djcpslc96y143si8it1	en	["ar"]	failed	2026-01-31 14:47:53.394	2026-01-31 14:47:53.402
1234	api::case-study.case-study	qvfzk4d2ltxvyghqwwqcaytr	en	["ar"]	failed	2026-01-31 14:47:53.497	2026-01-31 14:47:53.504
1237	api::solution.solution	tqsdu5hd1oobky3j3lih6vf0	en	["ar"]	failed	2026-01-31 14:47:53.599	2026-01-31 14:47:53.604
1240	api::solution.solution	otts9a92bqt1aug0i57oevqq	en	["ar"]	failed	2026-01-31 14:47:53.697	2026-01-31 14:47:53.706
1243	api::industry.industry	w4ozlcjrl2vlqy4fzehifrtj	en	["ar"]	failed	2026-01-31 14:47:53.802	2026-01-31 14:47:53.807
1245	api::industry.industry	lkz4o78zj6wq00iibu5au76c	en	["ar"]	failed	2026-01-31 14:47:53.866	2026-01-31 14:47:53.873
1191	api::feature.feature	qeuzq09205su9zxkqlyxrl1a	en	["ar"]	failed	2026-01-31 14:47:51.958	2026-01-31 14:47:51.965
1192	api::feature.feature	ikrvheuhkf3vyc1kbemp2eq9	en	["ar"]	failed	2026-01-31 14:47:51.997	2026-01-31 14:47:52.002
1193	api::feature.feature	i1o1m1zgtc0ryqskhgj7yefg	en	["ar"]	failed	2026-01-31 14:47:52.033	2026-01-31 14:47:52.038
1194	api::value.value	d5na83vbo28uvl6gyhpa0yal	en	["ar"]	failed	2026-01-31 14:47:52.073	2026-01-31 14:47:52.079
1195	api::value.value	v82y0gg5w7ps0u4hiuqy3w0c	en	["ar"]	failed	2026-01-31 14:47:52.107	2026-01-31 14:47:52.115
1196	api::value.value	f9emkqq2y2jbm7gxzgb0cl4n	en	["ar"]	failed	2026-01-31 14:47:52.141	2026-01-31 14:47:52.147
1197	api::value.value	lnuigoqv5txgraoyki6ve2sa	en	["ar"]	failed	2026-01-31 14:47:52.181	2026-01-31 14:47:52.187
1198	api::value.value	cffzfh7uxxgp754apizosmxc	en	["ar"]	failed	2026-01-31 14:47:52.221	2026-01-31 14:47:52.231
1199	api::value.value	woy60pt0icicoq4neumglcfq	en	["ar"]	failed	2026-01-31 14:47:52.263	2026-01-31 14:47:52.27
1201	api::testimonial.testimonial	r6y1wwnj9psp8rx3ro8ti5jk	en	["ar"]	failed	2026-01-31 14:47:52.342	2026-01-31 14:47:52.349
1202	api::testimonial.testimonial	nhmj6eq2zs03huqvafqipuww	en	["ar"]	failed	2026-01-31 14:47:52.384	2026-01-31 14:47:52.39
1203	api::testimonial.testimonial	viingupdokhwzfli1l00xl28	en	["ar"]	failed	2026-01-31 14:47:52.42	2026-01-31 14:47:52.426
1207	api::faq.faq	tgvc6csnd3v3hi03jh0jz6yo	en	["ar"]	failed	2026-01-31 14:47:52.569	2026-01-31 14:47:52.575
1211	api::faq.faq	q5mg9e0ny1itzxanpq7monqx	en	["ar"]	failed	2026-01-31 14:47:52.704	2026-01-31 14:47:52.711
1214	api::faq.faq	lubhchez9fy73ololtxm1id4	en	["ar"]	failed	2026-01-31 14:47:52.804	2026-01-31 14:47:52.811
1217	api::pricing-plan.pricing-plan	ygbpps6wf2682jwt83m6k7i6	en	["ar"]	failed	2026-01-31 14:47:52.908	2026-01-31 14:47:52.915
1222	api::partner.partner	bxrw9aaizl1zl2tn0zp3rslo	en	["ar"]	failed	2026-01-31 14:47:53.084	2026-01-31 14:47:53.091
1224	api::partner.partner	r77f5oofhedf0so59d12r4c6	en	["ar"]	failed	2026-01-31 14:47:53.154	2026-01-31 14:47:53.161
1229	api::demo.demo	j7zw5u1ocf26wr35ooig70s3	en	["ar"]	failed	2026-01-31 14:47:53.326	2026-01-31 14:47:53.332
1232	api::case-study.case-study	to0lggyq1pu783gafuhj3e7x	en	["ar"]	failed	2026-01-31 14:47:53.43	2026-01-31 14:47:53.436
1235	api::case-study.case-study	ri8l1eaypma7ki7v5s91hzl8	en	["ar"]	failed	2026-01-31 14:47:53.532	2026-01-31 14:47:53.539
1239	api::solution.solution	ckvetn59xckik1ps63fvsmkn	en	["ar"]	failed	2026-01-31 14:47:53.665	2026-01-31 14:47:53.671
1242	api::solution.solution	pf2zi5ahf8macx1bty76ep71	en	["ar"]	failed	2026-01-31 14:47:53.769	2026-01-31 14:47:53.776
1244	api::industry.industry	nb56q3v3otqm6memjo1pemdh	en	["ar"]	failed	2026-01-31 14:47:53.834	2026-01-31 14:47:53.839
1247	api::industry.industry	kmv5jw4dzj0unptizjatvuxo	en	["ar"]	failed	2026-01-31 14:47:53.931	2026-01-31 14:47:53.937
1200	api::testimonial.testimonial	pe5e46x7mkijvcmh1rubxvnq	en	["ar"]	failed	2026-01-31 14:47:52.304	2026-01-31 14:47:52.311
1204	api::testimonial.testimonial	i9fvik285qncktv200jhm4ey	en	["ar"]	failed	2026-01-31 14:47:52.456	2026-01-31 14:47:52.465
1206	api::faq.faq	y61nbvifjz44kpgtb0oqmlui	en	["ar"]	failed	2026-01-31 14:47:52.532	2026-01-31 14:47:52.538
1208	api::faq.faq	ybqhmtq1rc1x79hzazgz6f6n	en	["ar"]	failed	2026-01-31 14:47:52.601	2026-01-31 14:47:52.609
1210	api::faq.faq	anvrjnyv0jt2rgyo02la7vnu	en	["ar"]	failed	2026-01-31 14:47:52.669	2026-01-31 14:47:52.675
1213	api::faq.faq	du0wau1ia21vp6xcdbo3i917	en	["ar"]	failed	2026-01-31 14:47:52.772	2026-01-31 14:47:52.78
1216	api::pricing-plan.pricing-plan	be9bwj5ym5s8sncede6r5bft	en	["ar"]	failed	2026-01-31 14:47:52.875	2026-01-31 14:47:52.881
1218	api::pricing-plan.pricing-plan	i5sryv7gr9sy1rs76ibgiluo	en	["ar"]	failed	2026-01-31 14:47:52.943	2026-01-31 14:47:52.949
1220	api::partner.partner	umvd8zrad79x9m7ov2jdmtin	en	["ar"]	failed	2026-01-31 14:47:53.016	2026-01-31 14:47:53.021
1225	api::partner.partner	k1ol05cf5vc8sinhd1rge7ub	en	["ar"]	failed	2026-01-31 14:47:53.188	2026-01-31 14:47:53.197
1227	api::demo.demo	c6splpc0z2jclcva2ubnuppv	en	["ar"]	failed	2026-01-31 14:47:53.257	2026-01-31 14:47:53.263
1230	api::demo.demo	irogs1v119qe1uexcva5uxr0	en	["ar"]	failed	2026-01-31 14:47:53.361	2026-01-31 14:47:53.368
1233	api::case-study.case-study	eqhthn4oz577coa0sx96atf2	en	["ar"]	failed	2026-01-31 14:47:53.465	2026-01-31 14:47:53.472
1236	api::case-study.case-study	lcy9mlow2fne1hfen475jgon	en	["ar"]	failed	2026-01-31 14:47:53.566	2026-01-31 14:47:53.572
1238	api::solution.solution	yeg5y5p942g09zswcmo6pqbl	en	["ar"]	failed	2026-01-31 14:47:53.632	2026-01-31 14:47:53.638
1241	api::solution.solution	l0jk3ies4e569l18qw8yip2n	en	["ar"]	failed	2026-01-31 14:47:53.732	2026-01-31 14:47:53.739
1246	api::industry.industry	guky4akfgat76c9kwnpcpp5b	en	["ar"]	failed	2026-01-31 14:47:53.898	2026-01-31 14:47:53.906
1248	api::industry.industry	g8d5w0fxtzyfi1i0t8yisn0e	en	["ar"]	failed	2026-01-31 14:47:53.963	2026-01-31 14:47:53.969
1205	api::testimonial.testimonial	a9gdzteylfmoopjovhquoapq	en	["ar"]	failed	2026-01-31 14:47:52.488	2026-01-31 14:47:52.495
1249	api::homepage.homepage	dm9booqzqd2apwowc85ue5x3	en	["ar"]	failed	2026-01-31 14:50:19.197	2026-01-31 14:50:19.205
1250	api::about-page.about-page	gm07jmenpyfu25eclg08bqq0	en	["ar"]	failed	2026-01-31 14:50:19.263	2026-01-31 14:50:19.274
1251	api::contact-page.contact-page	y09o7nbox2j9ahvrnwyjpg49	en	["ar"]	failed	2026-01-31 14:50:19.322	2026-01-31 14:50:19.328
1252	api::site-setting.site-setting	h9ju54gqk13tvirlvdlvkkyl	en	["ar"]	failed	2026-01-31 14:50:19.365	2026-01-31 14:50:19.374
1253	api::pricing-page.pricing-page	rlqai8txywdximi6o619d1jc	en	["ar"]	failed	2026-01-31 14:50:19.419	2026-01-31 14:50:19.439
1254	api::solutions-page.solutions-page	dd3xf68pzfl8mp3q9up4m63s	en	["ar"]	failed	2026-01-31 14:50:19.492	2026-01-31 14:50:19.498
1255	api::industries-page.industries-page	rh5dcnhm2u038kiq8jq92wvk	en	["ar"]	failed	2026-01-31 14:50:19.545	2026-01-31 14:50:19.551
1256	api::demos-page.demos-page	kffojzf3ro7q8xcn1pxgrlzq	en	["ar"]	failed	2026-01-31 14:50:19.591	2026-01-31 14:50:19.6
1257	api::case-studies-page.case-studies-page	pctx33kphcee6mpjton4psbb	en	["ar"]	failed	2026-01-31 14:50:19.638	2026-01-31 14:50:19.645
1258	api::nav-item.nav-item	fbebnd34m9wkozdcjg72fi42	en	["ar"]	failed	2026-01-31 14:50:19.699	2026-01-31 14:50:19.708
1259	api::nav-item.nav-item	xqky7bwfqf3vei86hv95c27v	en	["ar"]	failed	2026-01-31 14:50:19.746	2026-01-31 14:50:19.752
1260	api::nav-item.nav-item	obhqylhd17dh1j4gbk2dhemc	en	["ar"]	failed	2026-01-31 14:50:19.795	2026-01-31 14:50:19.801
1261	api::nav-item.nav-item	o71khe5xfwvf563qszskmosi	en	["ar"]	failed	2026-01-31 14:50:19.848	2026-01-31 14:50:19.855
1262	api::nav-item.nav-item	i6644sxavjrr5aq4qd6aa3zb	en	["ar"]	failed	2026-01-31 14:50:19.895	2026-01-31 14:50:19.903
1263	api::nav-item.nav-item	v0x11tjwbgk44kz8am6f5xkz	en	["ar"]	failed	2026-01-31 14:50:19.951	2026-01-31 14:50:19.959
1264	api::nav-item.nav-item	wzlzbinf74fcrt2k2ukufb4k	en	["ar"]	failed	2026-01-31 14:50:19.999	2026-01-31 14:50:20.007
1265	api::nav-item.nav-item	u59c4zdjbqle2tya0k66v2rt	en	["ar"]	failed	2026-01-31 14:50:20.045	2026-01-31 14:50:20.053
1266	api::nav-item.nav-item	uqrhkwu14l07se0lbmtebd15	en	["ar"]	failed	2026-01-31 14:50:20.095	2026-01-31 14:50:20.103
1267	api::nav-item.nav-item	v92nvmv6x00ts7gpyhjna00b	en	["ar"]	failed	2026-01-31 14:50:20.145	2026-01-31 14:50:20.151
1268	api::nav-item.nav-item	wjt0vh7d7rz9p1ejbo214oxj	en	["ar"]	failed	2026-01-31 14:50:20.195	2026-01-31 14:50:20.203
1269	api::nav-item.nav-item	j45h3pywcul01bnhifmnfbxi	en	["ar"]	failed	2026-01-31 14:50:20.241	2026-01-31 14:50:20.247
1270	api::nav-item.nav-item	si2tv94dcbyfvt7brawxzqh0	en	["ar"]	failed	2026-01-31 14:50:20.286	2026-01-31 14:50:20.292
1271	api::nav-item.nav-item	yw8bdb4n38ddl1kym6wgjbgq	en	["ar"]	failed	2026-01-31 14:50:20.329	2026-01-31 14:50:20.335
1272	api::nav-item.nav-item	hvvw4ylfwlmzrwlivxbvc75e	en	["ar"]	failed	2026-01-31 14:50:20.372	2026-01-31 14:50:20.381
1273	api::nav-item.nav-item	ccbm2kw4syn57s9utq85n5p0	en	["ar"]	failed	2026-01-31 14:50:20.421	2026-01-31 14:50:20.428
1274	api::nav-item.nav-item	pd73r7i41fr0shmtr7o5oedr	en	["ar"]	failed	2026-01-31 14:50:20.467	2026-01-31 14:50:20.473
1275	api::nav-item.nav-item	m13o8846siytosam3su9rzti	en	["ar"]	failed	2026-01-31 14:50:20.508	2026-01-31 14:50:20.518
1276	api::nav-item.nav-item	gj9a4vc3q38c6zbfvsef32jc	en	["ar"]	failed	2026-01-31 14:50:20.55	2026-01-31 14:50:20.557
1277	api::nav-item.nav-item	ra7qmz7gsn1jr0ett1s0zl6p	en	["ar"]	failed	2026-01-31 14:50:20.592	2026-01-31 14:50:20.599
1278	api::nav-item.nav-item	e2ts84hxk0gjqmdum7grtq3t	en	["ar"]	failed	2026-01-31 14:50:20.636	2026-01-31 14:50:20.644
1279	api::nav-item.nav-item	i6pswxuvqi17buuzhx6gtls0	en	["ar"]	failed	2026-01-31 14:50:20.682	2026-01-31 14:50:20.687
1280	api::nav-item.nav-item	zvi5k6yg9aqcpedsjtzwbfem	en	["ar"]	failed	2026-01-31 14:50:20.731	2026-01-31 14:50:20.739
1281	api::nav-item.nav-item	gwd3up18p7ehyuiez8grt533	en	["ar"]	failed	2026-01-31 14:50:20.783	2026-01-31 14:50:20.789
1282	api::nav-item.nav-item	nqr5iufedpnpj30vjt3i7vel	en	["ar"]	failed	2026-01-31 14:50:20.829	2026-01-31 14:50:20.836
1283	api::nav-item.nav-item	iy6770o6u7vc5mlsuut4z01j	en	["ar"]	failed	2026-01-31 14:50:20.878	2026-01-31 14:50:20.885
1284	api::nav-item.nav-item	psm779i6v8hhu8we69881fjr	en	["ar"]	failed	2026-01-31 14:50:20.925	2026-01-31 14:50:20.931
1285	api::team-member.team-member	tdkcu5jmwlhpjhjjq84z02qe	en	["ar"]	failed	2026-01-31 14:50:21.306	2026-01-31 14:50:21.312
1286	api::team-member.team-member	urwxgvj4z2rkjwzlrvjbm2ch	en	["ar"]	failed	2026-01-31 14:50:21.359	2026-01-31 14:50:21.37
1287	api::team-member.team-member	ltkie7rs7bhfoxfngee9bnsd	en	["ar"]	failed	2026-01-31 14:50:21.412	2026-01-31 14:50:21.421
1288	api::team-member.team-member	bfnv3ndo9m2p94qaeudetla5	en	["ar"]	failed	2026-01-31 14:50:21.465	2026-01-31 14:50:21.474
1289	api::team-member.team-member	l2dvvw5qtunh8o6xrp0ij6yp	en	["ar"]	failed	2026-01-31 14:50:21.51	2026-01-31 14:50:21.524
1290	api::team-member.team-member	i99urmozmuglbldp7qo3opej	en	["ar"]	failed	2026-01-31 14:50:21.564	2026-01-31 14:50:21.573
1291	api::stat.stat	z9gy4zo22ue388rwu7um45p2	en	["ar"]	failed	2026-01-31 14:50:21.611	2026-01-31 14:50:21.629
1292	api::stat.stat	tckwzkgfm6mt247869gr2b1w	en	["ar"]	failed	2026-01-31 14:50:21.672	2026-01-31 14:50:21.678
1293	api::stat.stat	mpwk8y1wwyfj4s4s0wg2328c	en	["ar"]	failed	2026-01-31 14:50:21.715	2026-01-31 14:50:21.723
1294	api::stat.stat	ghbkgcnce3yxkhgrs35zd05j	en	["ar"]	failed	2026-01-31 14:50:21.779	2026-01-31 14:50:21.785
1295	api::stat.stat	l7rzc8ps9g9le4uf31eywkxe	en	["ar"]	failed	2026-01-31 14:50:21.821	2026-01-31 14:50:21.828
1296	api::stat.stat	xkeun30trrvzjt2md2dl4i8l	en	["ar"]	failed	2026-01-31 14:50:21.86	2026-01-31 14:50:21.873
1297	api::process-step.process-step	zp6gacmmsjhvaipoz8uocb9w	en	["ar"]	failed	2026-01-31 14:50:21.923	2026-01-31 14:50:21.929
1298	api::process-step.process-step	wmxa7mgndvhtlhm0k4fc9rbv	en	["ar"]	failed	2026-01-31 14:50:21.96	2026-01-31 14:50:21.975
1299	api::process-step.process-step	o7w8m2jwzq7b2zyore4sxqy2	en	["ar"]	failed	2026-01-31 14:50:22.018	2026-01-31 14:50:22.027
1300	api::process-step.process-step	aetvmde8wqhovvffszyjfsxk	en	["ar"]	failed	2026-01-31 14:50:22.059	2026-01-31 14:50:22.071
1301	api::feature.feature	h6z6bhyqmkmrkbgh4gs0s1p7	en	["ar"]	failed	2026-01-31 14:50:22.109	2026-01-31 14:50:22.118
1302	api::feature.feature	u9cvg9xoxeul9jtuppkzksb0	en	["ar"]	failed	2026-01-31 14:50:22.151	2026-01-31 14:50:22.157
1303	api::feature.feature	alj4e07lnsnfcbi0ghqzrx1f	en	["ar"]	failed	2026-01-31 14:50:22.192	2026-01-31 14:50:22.199
1304	api::feature.feature	kv74rrll27kia5328zrhrfek	en	["ar"]	failed	2026-01-31 14:50:22.235	2026-01-31 14:50:22.241
1305	api::feature.feature	f752vdvvff36qwtx2hv0ve1l	en	["ar"]	failed	2026-01-31 14:50:22.276	2026-01-31 14:50:22.283
1306	api::feature.feature	i7okun36qdbtrkwar6z0uv7m	en	["ar"]	failed	2026-01-31 14:50:22.314	2026-01-31 14:50:22.325
1307	api::feature.feature	ljz1iti6uh8r0nl7cvnt7e01	en	["ar"]	failed	2026-01-31 14:50:22.357	2026-01-31 14:50:22.365
1308	api::feature.feature	yuuvkyf56eh4adjt7ge956b4	en	["ar"]	failed	2026-01-31 14:50:22.397	2026-01-31 14:50:22.404
1309	api::value.value	opwivbhxmtidufos625qqiex	en	["ar"]	failed	2026-01-31 14:50:22.444	2026-01-31 14:50:22.451
1310	api::value.value	xp1nqyo6fdy6mo90yhmvmgr5	en	["ar"]	failed	2026-01-31 14:50:22.488	2026-01-31 14:50:22.494
1311	api::value.value	th87jiygapbju7rpuxect2m7	en	["ar"]	failed	2026-01-31 14:50:22.527	2026-01-31 14:50:22.533
1316	api::testimonial.testimonial	yt1fyyoeuz9m6z01rafmx1qq	en	["ar"]	failed	2026-01-31 14:50:22.77	2026-01-31 14:50:22.778
1326	api::faq.faq	kcbm7v2aus268qd5151myppj	en	["ar"]	failed	2026-01-31 14:50:25.402	2026-01-31 14:50:25.408
1327	api::faq.faq	qbbd5hxigkbbocjwzegtr6eh	en	["ar"]	failed	2026-01-31 14:50:25.443	2026-01-31 14:50:25.449
1328	api::faq.faq	eu2hgqcl3wl3gv034cq2vhdj	en	["ar"]	failed	2026-01-31 14:50:25.48	2026-01-31 14:50:25.49
1329	api::faq.faq	hxdgod2qjlh07l1fbuc4ifv5	en	["ar"]	failed	2026-01-31 14:50:25.524	2026-01-31 14:50:25.529
1330	api::faq.faq	tqpqwqr722n7kv0os2xlccdc	en	["ar"]	failed	2026-01-31 14:50:25.566	2026-01-31 14:50:25.571
1331	api::pricing-plan.pricing-plan	gt0j6dlz1rzkpm9eap4wre1x	en	["ar"]	failed	2026-01-31 14:50:25.615	2026-01-31 14:50:25.622
1332	api::pricing-plan.pricing-plan	zhgk4316c3t5g9nys8bik0fn	en	["ar"]	failed	2026-01-31 14:50:25.669	2026-01-31 14:50:25.675
1333	api::pricing-plan.pricing-plan	qllvhde7n2btxegdvafmzkf1	en	["ar"]	failed	2026-01-31 14:50:25.718	2026-01-31 14:50:25.725
1334	api::pricing-plan.pricing-plan	mq22mxwbxhgwergkimjorchx	en	["ar"]	failed	2026-01-31 14:50:25.773	2026-01-31 14:50:25.781
1335	api::partner.partner	hqf2hjpli6th35s4irhszf95	en	["ar"]	failed	2026-01-31 14:50:25.825	2026-01-31 14:50:25.832
1312	api::value.value	vl227d6ug7lt6bhuevuhjm8c	en	["ar"]	failed	2026-01-31 14:50:22.576	2026-01-31 14:50:22.584
1313	api::value.value	lie48spizm9irwua0l32zq9i	en	["ar"]	failed	2026-01-31 14:50:22.624	2026-01-31 14:50:22.633
1314	api::value.value	u8p54ed10hfmr89iq3k7u4pi	en	["ar"]	failed	2026-01-31 14:50:22.669	2026-01-31 14:50:22.676
1315	api::testimonial.testimonial	o1ptgma4rv1csh91guyqbtes	en	["ar"]	failed	2026-01-31 14:50:22.714	2026-01-31 14:50:22.725
1320	api::testimonial.testimonial	h7zmuig5z33oynuakd52x0oi	en	["ar"]	failed	2026-01-31 14:50:22.957	2026-01-31 14:50:22.963
1322	api::faq.faq	c8mgyp3ou731hjp8h2ot2wt3	en	["ar"]	failed	2026-01-31 14:50:25.227	2026-01-31 14:50:25.237
1323	api::faq.faq	qzfu8o76et9ky4cpz5a4rvml	en	["ar"]	failed	2026-01-31 14:50:25.275	2026-01-31 14:50:25.281
1324	api::faq.faq	ago5n6xpp7tr2kwf43gs0mxg	en	["ar"]	failed	2026-01-31 14:50:25.317	2026-01-31 14:50:25.322
1325	api::faq.faq	u38psn6e4zp3xe6htw7ku3wq	en	["ar"]	failed	2026-01-31 14:50:25.361	2026-01-31 14:50:25.371
1348	api::case-study.case-study	dzsc4vjrch13zhap96zxi07f	en	["ar"]	failed	2026-01-31 14:50:26.428	2026-01-31 14:50:26.435
1353	api::solution.solution	s7s48co2kvadq24ldetkou1m	en	["ar"]	failed	2026-01-31 14:50:26.665	2026-01-31 14:50:26.671
1354	api::solution.solution	rmirvohyti8169g1c96jko0l	en	["ar"]	failed	2026-01-31 14:50:26.707	2026-01-31 14:50:26.715
1355	api::solution.solution	r0wgaloejv19q4ahnykrw6o3	en	["ar"]	failed	2026-01-31 14:50:26.749	2026-01-31 14:50:26.755
1356	api::solution.solution	qd6osma8at0nklexpmwagujw	en	["ar"]	failed	2026-01-31 14:50:26.788	2026-01-31 14:50:26.799
1357	api::solution.solution	ilc5q2aoqlr53t2jrmmwr0mx	en	["ar"]	failed	2026-01-31 14:50:26.835	2026-01-31 14:50:26.845
1360	api::industry.industry	c1csedausox9tmj4b3uwtau8	en	["ar"]	failed	2026-01-31 14:50:26.972	2026-01-31 14:50:26.979
1361	api::industry.industry	xrlczdibhnerk6xky548ru1b	en	["ar"]	failed	2026-01-31 14:50:27.015	2026-01-31 14:50:27.021
1362	api::industry.industry	kgd2cjoy66uvlberxi7zl1hn	en	["ar"]	failed	2026-01-31 14:50:27.058	2026-01-31 14:50:27.063
1317	api::testimonial.testimonial	qx2xp9dvr9wv4ba7vwlowf09	en	["ar"]	failed	2026-01-31 14:50:22.812	2026-01-31 14:50:22.826
1318	api::testimonial.testimonial	hlfutjeoh27y1odwv62xx050	en	["ar"]	failed	2026-01-31 14:50:22.861	2026-01-31 14:50:22.872
1319	api::testimonial.testimonial	clufedcs42xdth5fvitftd33	en	["ar"]	failed	2026-01-31 14:50:22.909	2026-01-31 14:50:22.916
1345	api::demo.demo	gxnuxwbqhz4giio8k5d2iv3c	en	["ar"]	failed	2026-01-31 14:50:26.298	2026-01-31 14:50:26.305
1349	api::case-study.case-study	pxw7thni2mzceykilvu1n6qk	en	["ar"]	failed	2026-01-31 14:50:26.472	2026-01-31 14:50:26.481
1350	api::case-study.case-study	dwkowpnrp19qw6dxdwaygi5i	en	["ar"]	failed	2026-01-31 14:50:26.52	2026-01-31 14:50:26.527
1321	api::faq.faq	vlt5j87u059gg41iytse62oj	en	["ar"]	failed	2026-01-31 14:50:25.176	2026-01-31 14:50:25.183
1336	api::partner.partner	ti1218qasixv3qlcgm2tji1t	en	["ar"]	failed	2026-01-31 14:50:25.868	2026-01-31 14:50:25.876
1337	api::partner.partner	s7si7a3duv2qu9bt6my68a62	en	["ar"]	failed	2026-01-31 14:50:25.92	2026-01-31 14:50:25.926
1338	api::partner.partner	coey4m18t68ufl5hf2xggyxu	en	["ar"]	failed	2026-01-31 14:50:25.966	2026-01-31 14:50:25.973
1339	api::partner.partner	kx3g6gsmqir5x85m209atvru	en	["ar"]	failed	2026-01-31 14:50:26.016	2026-01-31 14:50:26.023
1340	api::partner.partner	tpb88kg1fxbrbaesqvydxgkw	en	["ar"]	failed	2026-01-31 14:50:26.063	2026-01-31 14:50:26.07
1341	api::demo.demo	ak8vrrf3f2wgayxai0s9houb	en	["ar"]	failed	2026-01-31 14:50:26.113	2026-01-31 14:50:26.121
1342	api::demo.demo	p3k11momjmk9f809z7ia0e9h	en	["ar"]	failed	2026-01-31 14:50:26.16	2026-01-31 14:50:26.167
1343	api::demo.demo	yz3c18xpcq9vttu698u96y2l	en	["ar"]	failed	2026-01-31 14:50:26.207	2026-01-31 14:50:26.214
1344	api::demo.demo	ol2sabxa7ezx4xlxjvxavpd2	en	["ar"]	failed	2026-01-31 14:50:26.255	2026-01-31 14:50:26.261
1346	api::demo.demo	sqi0woxlapt6w1xqzd1x4mjb	en	["ar"]	failed	2026-01-31 14:50:26.336	2026-01-31 14:50:26.348
1347	api::case-study.case-study	ma3798ungocfpx7juof6j29f	en	["ar"]	failed	2026-01-31 14:50:26.384	2026-01-31 14:50:26.396
1351	api::case-study.case-study	p9b44oxvjo2apc2oldm9whzu	en	["ar"]	failed	2026-01-31 14:50:26.564	2026-01-31 14:50:26.571
1352	api::solution.solution	aegjtyc1ygh0n190wlk8al1f	en	["ar"]	failed	2026-01-31 14:50:26.615	2026-01-31 14:50:26.622
1358	api::industry.industry	i746r9yvwlcchw0lb40y2b6p	en	["ar"]	failed	2026-01-31 14:50:26.883	2026-01-31 14:50:26.89
1359	api::industry.industry	snq8uybhrftoyg4g1j57qw80	en	["ar"]	failed	2026-01-31 14:50:26.932	2026-01-31 14:50:26.937
1363	api::industry.industry	mczh2rxlkiwgnexfwgbzonw1	en	["ar"]	failed	2026-01-31 14:50:27.111	2026-01-31 14:50:27.117
\.


--
-- TOC entry 3943 (class 0 OID 106196)
-- Dependencies: 250
-- Data for Name: strapi_api_token_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3983 (class 0 OID 106425)
-- Dependencies: 290
-- Data for Name: strapi_api_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_token_permissions_token_lnk (id, api_token_permission_id, api_token_id, api_token_permission_ord) FROM stdin;
\.


--
-- TOC entry 3941 (class 0 OID 106184)
-- Dependencies: 248
-- Data for Name: strapi_api_tokens; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_api_tokens (id, document_id, name, description, type, access_key, encrypted_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	bok0bny67zh3h38rh2ql7bel	Read Only	A default API token with read-only permissions, only used for accessing resources	read-only	ad1492d339ee1d9e918cced776f5fa5cc65634ffc561ae6b7c9176fcf0e2347ec435062610e69d8614d3174bccfe927cc144cfad3345dd9e5a3ac0fbd42074f3	v1:70a226796c26a8cd71c196f80a80d70b:0861467c19738266a9f87447b4ebf779ec9bef9e3e91d6233711221b99ec8346be35cceb098cee01398759eb881002575227d8db3970e2cf3464192e8d26c0aaaf37386ed1baed1d757a39d2816de4ab65c4cf1b5875a0afb4792c05a631cc9157e6081ba6f775d1d5bce1d32d2aaa3ba3e60bddec5894ca4bee0220ce690c99147df9e067ce39db22268c45407cfd70a7456d7337de05e48122adae1929d1ec523fd06fbcfe8976f1cbd406cd6304f27b9afb5fd38e130ad6739f7d4100eb635c9b4414dc1efbfc94c6111f59f9be0eebd094a978b69aa9299ff192032289b55e10e6239f3a1a6e20a681c00a86cb2badce0ea3692bc9862070b15299d75bcc:64f8d89a6527f7db48bec7219b8644bf	\N	\N	\N	2026-01-29 17:06:08.665	2026-01-29 17:06:08.665	2026-01-29 17:06:08.665	\N	\N	\N
3	afmoyccfxa2hxk49zc40uvbe	Seeding Token	Token for seeding and web API access	full-access	b59a3b87b9eda08f4ef79af1a122c3d3baee42c39660d38f073e38f3f26b9341988b69ada549d79292f139611ff0248da525dee86cb60496a93cc87e74f5195f	v1:e116866152ffa1ad4b930d20dcb2b1d1:5068e7fd652c04a61a320471ee79a9531c155677981c85bcdd5d8c7477552206fb95da67f2ab18f4881b3c2776646810147556cf5ddb1052bec77f0bcde3d1b21de002fb6794c69099de5f77d402995d1157d7b989e5ffbaabc9a32b763eecee986e2a28fe4e62808ec6105fec5af23e564554e726c8c9969ff5bc9424b11fd960d53f91163471d0e33c03d8752d7bc46edf358a84402b27c009881200fa3e8c495f331a7060d9565dd70205052a99ecb2d484d41dd393d9157b2a7857401b108634b7274d526592dabafda08ee41ef00d3f1fb89523518b030b6c90bb993132ab28d5c17d921f40e695c2440b544244c356880c1dde8c9d75482e28077bcfd2:51aeb0f9136a45c4f39e255f95014d3e	\N	\N	\N	2026-01-29 17:10:40.96	2026-01-29 17:10:40.96	2026-01-29 17:10:40.96	\N	\N	\N
2	a4tn5pc4dd03bop1yadjk05f	Full Access	A default API token with full access permissions, used for accessing or modifying resources	full-access	55926713de9c1c5f05c1679f791da1a35b317b00c03a1ad08873ad821640153849dadab66ebc770a81d51b4b40d055e97b20b88682a6ac9708b2eeca7251c91d	v1:4301f3633b67f026b90074c30340f689:aff6265e00fa97e77dc1561d702c7ed7c77acd272e260e857207d5134d742868e6d2b45ddc1c53652b3c46e4fd416a6e8f27067ac1767b6c78eb4aa6bfe74210d0574d55c901cb28def0aa5d18b519254bf769f2d27fb1a129f31a329fc22e1f7f16b0a00428bc94ffc8d71c2469033d1ac13f00326aba03cef2bc8a3b9b912c52890ced1d56a0003b297437e63a382b16e1eb478b302b7bcb3e9ce59993a0b22946aa2e6343fa6cd30f513461988a117d79b4773d5adf41bd3258758c94f1f92803b66d626c333b8fef28feb4c846dca67766c0c09280bc89e80dd881a4f6948818b0a53f5030595035798a566958f20a844588cee37fc34c81d2cd6bf02357:97a17886c8efbe7d10f8fc9d5d9e56e3	2026-01-31 14:23:06.391	\N	\N	2026-01-29 17:06:08.674	2026-01-31 14:23:06.391	2026-01-29 17:06:08.674	\N	\N	\N
4	dk1cvekbcvj4wj6o2jtrr3oz	web		full-access	11dc49c0219f54d96e9007df1eb9e11172b6c650851a2f9b7b1bdd3cdc3b3e314352e6e817a0f4201bea12cd8c8f83d31e3858b112fe801e1b65c265f6a9a72f	v1:e520cec169856fcb814655ee46754fa6:a87685c231a4c019566af619f939d0683799be4a68c8c2ce248ac41887b9c8013a360db6425e0a45c848460297b8a9dcd523a064c84525b44a2a186731382dc5896a4a45f65b7d09e1359f7c973692d2fb0b697eff7663c2f34d61fbe1c3de8cfe185690220aa1705c5573dc488c63bd0ff5d9173938b6fc85c1939573606900c2250e80bfbd55914c1cb323ae839a201bfe8fe9ebf52613a3e7ebb9f06f61012101447c246311b58fd41ca2c2795e4d530ac014d04eff6748d79facdbf7695d296d44b0a789c66626575117479781a51c8c059a71d3021043f9b09bb91fd87924d30fe262b014a9831049cb3408118fafe48c6c1d3a0520174e9208298db252:e4a6054c4a72b8e92e783c34e404adf5	2026-01-31 21:23:51.327	\N	\N	2026-01-29 19:06:30.079	2026-01-31 21:23:51.327	2026-01-29 19:06:30.079	\N	\N	\N
\.


--
-- TOC entry 3951 (class 0 OID 106244)
-- Dependencies: 258
-- Data for Name: strapi_audit_logs; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_audit_logs (id, document_id, action, date, payload, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3987 (class 0 OID 106449)
-- Dependencies: 294
-- Data for Name: strapi_audit_logs_user_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_audit_logs_user_lnk (id, audit_log_id, user_id) FROM stdin;
\.


--
-- TOC entry 3953 (class 0 OID 106256)
-- Dependencies: 260
-- Data for Name: strapi_core_store_settings; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_core_store_settings (id, key, value, type, environment, tag) FROM stdin;
1	strapi_unidirectional-join-table-repair-ran	true	boolean	\N	\N
4	plugin_content_manager_configuration_content_types::plugin::i18n.locale	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","createdAt"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}]]},"uid":"plugin::i18n.locale"}	object	\N	\N
6	plugin_content_manager_configuration_content_types::plugin::upload.folder	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"pathId":{"edit":{"label":"pathId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"pathId","searchable":true,"sortable":true}},"parent":{"edit":{"label":"parent","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"parent","searchable":true,"sortable":true}},"children":{"edit":{"label":"children","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"children","searchable":false,"sortable":false}},"files":{"edit":{"label":"files","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"files","searchable":false,"sortable":false}},"path":{"edit":{"label":"path","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"path","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","pathId","parent"],"edit":[[{"name":"name","size":6},{"name":"pathId","size":4}],[{"name":"parent","size":6},{"name":"children","size":6}],[{"name":"files","size":6},{"name":"path","size":6}]]},"uid":"plugin::upload.folder"}	object	\N	\N
5	plugin_content_manager_configuration_content_types::plugin::upload.file	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"alternativeText":{"edit":{"label":"alternativeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"alternativeText","searchable":true,"sortable":true}},"caption":{"edit":{"label":"caption","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caption","searchable":true,"sortable":true}},"width":{"edit":{"label":"width","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"width","searchable":true,"sortable":true}},"height":{"edit":{"label":"height","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"height","searchable":true,"sortable":true}},"formats":{"edit":{"label":"formats","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formats","searchable":false,"sortable":false}},"hash":{"edit":{"label":"hash","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hash","searchable":true,"sortable":true}},"ext":{"edit":{"label":"ext","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ext","searchable":true,"sortable":true}},"mime":{"edit":{"label":"mime","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"mime","searchable":true,"sortable":true}},"size":{"edit":{"label":"size","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"size","searchable":true,"sortable":true}},"url":{"edit":{"label":"url","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"url","searchable":true,"sortable":true}},"previewUrl":{"edit":{"label":"previewUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"previewUrl","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"provider_metadata":{"edit":{"label":"provider_metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"provider_metadata","searchable":false,"sortable":false}},"folder":{"edit":{"label":"folder","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"folder","searchable":true,"sortable":true}},"folderPath":{"edit":{"label":"folderPath","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"folderPath","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","alternativeText","caption"],"edit":[[{"name":"name","size":6},{"name":"alternativeText","size":6}],[{"name":"caption","size":6},{"name":"width","size":4}],[{"name":"height","size":4}],[{"name":"formats","size":12}],[{"name":"hash","size":6},{"name":"ext","size":6}],[{"name":"mime","size":6},{"name":"size","size":4}],[{"name":"url","size":6},{"name":"previewUrl","size":6}],[{"name":"provider","size":6}],[{"name":"provider_metadata","size":12}],[{"name":"folder","size":6},{"name":"folderPath","size":6}]]},"uid":"plugin::upload.file"}	object	\N	\N
7	plugin_content_manager_configuration_content_types::plugin::content-releases.release	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"releasedAt":{"edit":{"label":"releasedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"releasedAt","searchable":true,"sortable":true}},"scheduledAt":{"edit":{"label":"scheduledAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"scheduledAt","searchable":true,"sortable":true}},"timezone":{"edit":{"label":"timezone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"timezone","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"actions":{"edit":{"label":"actions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"contentType"},"list":{"label":"actions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","releasedAt","scheduledAt"],"edit":[[{"name":"name","size":6},{"name":"releasedAt","size":6}],[{"name":"scheduledAt","size":6},{"name":"timezone","size":6}],[{"name":"status","size":6},{"name":"actions","size":6}]]},"uid":"plugin::content-releases.release"}	object	\N	\N
8	plugin_content_manager_configuration_content_types::plugin::content-releases.release-action	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"contentType","defaultSortBy":"contentType","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"contentType":{"edit":{"label":"contentType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentType","searchable":true,"sortable":true}},"entryDocumentId":{"edit":{"label":"entryDocumentId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"entryDocumentId","searchable":true,"sortable":true}},"release":{"edit":{"label":"release","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"release","searchable":true,"sortable":true}},"isEntryValid":{"edit":{"label":"isEntryValid","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isEntryValid","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","type","contentType","entryDocumentId"],"edit":[[{"name":"type","size":6},{"name":"contentType","size":6}],[{"name":"entryDocumentId","size":6},{"name":"release","size":6}],[{"name":"isEntryValid","size":4}]]},"uid":"plugin::content-releases.release-action"}	object	\N	\N
9	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"stages":{"edit":{"label":"stages","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stages","searchable":false,"sortable":false}},"stageRequiredToPublish":{"edit":{"label":"stageRequiredToPublish","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"stageRequiredToPublish","searchable":true,"sortable":true}},"contentTypes":{"edit":{"label":"contentTypes","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contentTypes","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","stages","stageRequiredToPublish"],"edit":[[{"name":"name","size":6},{"name":"stages","size":6}],[{"name":"stageRequiredToPublish","size":6}],[{"name":"contentTypes","size":12}]]},"uid":"plugin::review-workflows.workflow"}	object	\N	\N
10	plugin_content_manager_configuration_content_types::plugin::review-workflows.workflow-stage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"color":{"edit":{"label":"color","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"color","searchable":true,"sortable":true}},"workflow":{"edit":{"label":"workflow","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"workflow","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","color","workflow"],"edit":[[{"name":"name","size":6},{"name":"color","size":6}],[{"name":"workflow","size":6},{"name":"permissions","size":6}]]},"uid":"plugin::review-workflows.workflow-stage"}	object	\N	\N
3	strapi_content_types_schema	{"plugin::upload.file":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"files"}}},"indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null}],"plugin":"upload","globalId":"UploadFile","uid":"plugin::upload.file","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"files","info":{"singularName":"file","pluralName":"files","displayName":"File","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false,"required":true},"alternativeText":{"type":"text","configurable":false},"caption":{"type":"text","configurable":false},"width":{"type":"integer","configurable":false},"height":{"type":"integer","configurable":false},"formats":{"type":"json","configurable":false},"hash":{"type":"string","configurable":false,"required":true},"ext":{"type":"string","configurable":false},"mime":{"type":"string","configurable":false,"required":true},"size":{"type":"decimal","configurable":false,"required":true},"url":{"type":"text","configurable":false,"required":true},"previewUrl":{"type":"text","configurable":false},"provider":{"type":"string","configurable":false,"required":true},"provider_metadata":{"type":"json","configurable":false},"related":{"type":"relation","relation":"morphToMany","configurable":false},"folder":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"files","private":true},"folderPath":{"type":"string","minLength":1,"required":true,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"file"},"plugin::upload.folder":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"upload_folders"}}},"indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"}],"plugin":"upload","globalId":"UploadFolder","uid":"plugin::upload.folder","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"upload_folders","info":{"singularName":"folder","pluralName":"folders","displayName":"Folder"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"required":true},"pathId":{"type":"integer","unique":true,"required":true},"parent":{"type":"relation","relation":"manyToOne","target":"plugin::upload.folder","inversedBy":"children"},"children":{"type":"relation","relation":"oneToMany","target":"plugin::upload.folder","mappedBy":"parent"},"files":{"type":"relation","relation":"oneToMany","target":"plugin::upload.file","mappedBy":"folder"},"path":{"type":"string","minLength":1,"required":true}},"kind":"collectionType"},"modelName":"folder"},"plugin::i18n.locale":{"info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::i18n.locale","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"i18n_locale"}}},"plugin":"i18n","collectionName":"i18n_locale","globalId":"I18NLocale","uid":"plugin::i18n.locale","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"i18n_locale","info":{"singularName":"locale","pluralName":"locales","collectionName":"locales","displayName":"Locale","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","min":1,"max":50,"configurable":false},"code":{"type":"string","unique":true,"configurable":false}},"kind":"collectionType"},"modelName":"locale"},"plugin::content-releases.release":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_releases"}}},"plugin":"content-releases","globalId":"ContentReleasesRelease","uid":"plugin::content-releases.release","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_releases","info":{"singularName":"release","pluralName":"releases","displayName":"Release"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true},"releasedAt":{"type":"datetime"},"scheduledAt":{"type":"datetime"},"timezone":{"type":"string"},"status":{"type":"enumeration","enum":["ready","blocked","failed","done","empty"],"required":true},"actions":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","mappedBy":"release"}},"kind":"collectionType"},"modelName":"release"},"plugin::content-releases.release-action":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::content-releases.release-action","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_release_actions"}}},"plugin":"content-releases","globalId":"ContentReleasesReleaseAction","uid":"plugin::content-releases.release-action","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_release_actions","info":{"singularName":"release-action","pluralName":"release-actions","displayName":"Release Action"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"type":{"type":"enumeration","enum":["publish","unpublish"],"required":true},"contentType":{"type":"string","required":true},"entryDocumentId":{"type":"string"},"locale":{"type":"string"},"release":{"type":"relation","relation":"manyToOne","target":"plugin::content-releases.release","inversedBy":"actions"},"isEntryValid":{"type":"boolean"}},"kind":"collectionType"},"modelName":"release-action"},"plugin::review-workflows.workflow":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflow","uid":"plugin::review-workflows.workflow","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows","info":{"name":"Workflow","description":"","singularName":"workflow","pluralName":"workflows","displayName":"Workflow"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","required":true,"unique":true},"stages":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToMany","mappedBy":"workflow"},"stageRequiredToPublish":{"type":"relation","target":"plugin::review-workflows.workflow-stage","relation":"oneToOne","required":false},"contentTypes":{"type":"json","required":true,"default":"[]"}},"kind":"collectionType"},"modelName":"workflow"},"plugin::review-workflows.workflow-stage":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0","draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::review-workflows.workflow-stage","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_workflows_stages"}}},"plugin":"review-workflows","globalId":"ReviewWorkflowsWorkflowStage","uid":"plugin::review-workflows.workflow-stage","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_workflows_stages","info":{"name":"Workflow Stage","description":"","singularName":"workflow-stage","pluralName":"workflow-stages","displayName":"Stages"},"options":{"version":"1.1.0"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","configurable":false},"color":{"type":"string","configurable":false,"default":"#4945FF"},"workflow":{"type":"relation","target":"plugin::review-workflows.workflow","relation":"manyToOne","inversedBy":"stages","configurable":false},"permissions":{"type":"relation","target":"admin::permission","relation":"manyToMany","configurable":false}},"kind":"collectionType"},"modelName":"workflow-stage"},"plugin::users-permissions.permission":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_permissions"}}},"plugin":"users-permissions","globalId":"UsersPermissionsPermission","uid":"plugin::users-permissions.permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_permissions","info":{"name":"permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"permissions","configurable":false}},"kind":"collectionType"},"modelName":"permission","options":{"draftAndPublish":false}},"plugin::users-permissions.role":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_roles"}}},"plugin":"users-permissions","globalId":"UsersPermissionsRole","uid":"plugin::users-permissions.role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_roles","info":{"name":"role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":3,"required":true,"configurable":false},"description":{"type":"string","configurable":false},"type":{"type":"string","unique":true,"configurable":false},"permissions":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.permission","mappedBy":"role","configurable":false},"users":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","mappedBy":"role","configurable":false}},"kind":"collectionType"},"modelName":"role","options":{"draftAndPublish":false}},"plugin::users-permissions.user":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true,"draftAndPublish":false},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"displayName":{"type":"string"},"phone":{"type":"string"},"country":{"type":"string"},"company":{"type":"string"},"accountStatus":{"type":"enumeration","enum":["pending","active","suspended"],"default":"pending"},"salesContactAllowed":{"type":"boolean","default":true},"confirmationTokenExpiresAt":{"type":"datetime"},"lastLogin":{"type":"datetime"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"plugin::users-permissions.user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"up_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"confirmationToken":{"hidden":true},"provider":{"hidden":true}}},"plugin":"users-permissions","globalId":"UsersPermissionsUser","uid":"plugin::users-permissions.user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"up_users","info":{"name":"user","description":"","singularName":"user","pluralName":"users","displayName":"User"},"options":{"timestamps":true},"attributes":{"username":{"type":"string","minLength":3,"unique":true,"configurable":false,"required":true},"email":{"type":"email","minLength":6,"configurable":false,"required":true},"provider":{"type":"string","configurable":false},"password":{"type":"password","minLength":6,"configurable":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"confirmed":{"type":"boolean","default":false,"configurable":false},"blocked":{"type":"boolean","default":false,"configurable":false},"role":{"type":"relation","relation":"manyToOne","target":"plugin::users-permissions.role","inversedBy":"users","configurable":false},"displayName":{"type":"string"},"phone":{"type":"string"},"country":{"type":"string"},"company":{"type":"string"},"accountStatus":{"type":"enumeration","enum":["pending","active","suspended"],"default":"pending"},"salesContactAllowed":{"type":"boolean","default":true},"confirmationTokenExpiresAt":{"type":"datetime"},"lastLogin":{"type":"datetime"}},"kind":"collectionType"},"modelName":"user"},"admin::permission":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_permissions"}}},"plugin":"admin","globalId":"AdminPermission","uid":"admin::permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_permissions","info":{"name":"Permission","description":"","singularName":"permission","pluralName":"permissions","displayName":"Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"actionParameters":{"type":"json","configurable":false,"required":false,"default":{}},"subject":{"type":"string","minLength":1,"configurable":false,"required":false},"properties":{"type":"json","configurable":false,"required":false,"default":{}},"conditions":{"type":"json","configurable":false,"required":false,"default":[]},"role":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::role"}},"kind":"collectionType"},"modelName":"permission"},"admin::user":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::user","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_users"}}},"config":{"attributes":{"resetPasswordToken":{"hidden":true},"registrationToken":{"hidden":true}}},"plugin":"admin","globalId":"AdminUser","uid":"admin::user","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_users","info":{"name":"User","description":"","singularName":"user","pluralName":"users","displayName":"User"},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"firstname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"lastname":{"type":"string","unique":false,"minLength":1,"configurable":false,"required":false},"username":{"type":"string","unique":false,"configurable":false,"required":false},"email":{"type":"email","minLength":6,"configurable":false,"required":true,"unique":true,"private":true},"password":{"type":"password","minLength":6,"configurable":false,"required":false,"private":true,"searchable":false},"resetPasswordToken":{"type":"string","configurable":false,"private":true,"searchable":false},"registrationToken":{"type":"string","configurable":false,"private":true,"searchable":false},"isActive":{"type":"boolean","default":false,"configurable":false,"private":true},"roles":{"configurable":false,"private":true,"type":"relation","relation":"manyToMany","inversedBy":"users","target":"admin::role","collectionName":"strapi_users_roles"},"blocked":{"type":"boolean","default":false,"configurable":false,"private":true},"preferedLanguage":{"type":"string","configurable":false,"required":false,"searchable":false}},"kind":"collectionType"},"modelName":"user","options":{"draftAndPublish":false}},"admin::role":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::role","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"admin_roles"}}},"plugin":"admin","globalId":"AdminRole","uid":"admin::role","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"admin_roles","info":{"name":"Role","description":"","singularName":"role","pluralName":"roles","displayName":"Role"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"code":{"type":"string","minLength":1,"unique":true,"configurable":false,"required":true},"description":{"type":"string","configurable":false},"users":{"configurable":false,"type":"relation","relation":"manyToMany","mappedBy":"roles","target":"admin::user"},"permissions":{"configurable":false,"type":"relation","relation":"oneToMany","mappedBy":"role","target":"admin::permission"}},"kind":"collectionType"},"modelName":"role"},"admin::api-token":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_tokens"}}},"plugin":"admin","globalId":"AdminApiToken","uid":"admin::api-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_tokens","info":{"name":"Api Token","singularName":"api-token","pluralName":"api-tokens","displayName":"Api Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"type":{"type":"enumeration","enum":["read-only","full-access","custom"],"configurable":false,"required":true,"default":"read-only"},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true,"searchable":false},"encryptedKey":{"type":"text","minLength":1,"configurable":false,"required":false,"searchable":false},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::api-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"api-token"},"admin::api-token-permission":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::api-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_api_token_permissions"}}},"plugin":"admin","globalId":"AdminApiTokenPermission","uid":"admin::api-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_api_token_permissions","info":{"name":"API Token Permission","description":"","singularName":"api-token-permission","pluralName":"api-token-permissions","displayName":"API Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::api-token"}},"kind":"collectionType"},"modelName":"api-token-permission"},"admin::transfer-token":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_tokens"}}},"plugin":"admin","globalId":"AdminTransferToken","uid":"admin::transfer-token","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_tokens","info":{"name":"Transfer Token","singularName":"transfer-token","pluralName":"transfer-tokens","displayName":"Transfer Token","description":""},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"name":{"type":"string","minLength":1,"configurable":false,"required":true,"unique":true},"description":{"type":"string","minLength":1,"configurable":false,"required":false,"default":""},"accessKey":{"type":"string","minLength":1,"configurable":false,"required":true},"lastUsedAt":{"type":"datetime","configurable":false,"required":false},"permissions":{"type":"relation","target":"admin::transfer-token-permission","relation":"oneToMany","mappedBy":"token","configurable":false,"required":false},"expiresAt":{"type":"datetime","configurable":false,"required":false},"lifespan":{"type":"biginteger","configurable":false,"required":false}},"kind":"collectionType"},"modelName":"transfer-token"},"admin::transfer-token-permission":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::transfer-token-permission","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_transfer_token_permissions"}}},"plugin":"admin","globalId":"AdminTransferTokenPermission","uid":"admin::transfer-token-permission","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_transfer_token_permissions","info":{"name":"Transfer Token Permission","description":"","singularName":"transfer-token-permission","pluralName":"transfer-token-permissions","displayName":"Transfer Token Permission"},"options":{},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","minLength":1,"configurable":false,"required":true},"token":{"configurable":false,"type":"relation","relation":"manyToOne","inversedBy":"permissions","target":"admin::transfer-token"}},"kind":"collectionType"},"modelName":"transfer-token-permission"},"admin::session":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::session","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_sessions"}}},"plugin":"admin","globalId":"AdminSession","uid":"admin::session","modelType":"contentType","kind":"collectionType","__schema__":{"collectionName":"strapi_sessions","info":{"name":"Session","description":"Session Manager storage","singularName":"session","pluralName":"sessions","displayName":"Session"},"options":{"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false},"i18n":{"localized":false}},"attributes":{"userId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"sessionId":{"type":"string","unique":true,"required":true,"configurable":false,"private":true,"searchable":false},"childId":{"type":"string","configurable":false,"private":true,"searchable":false},"deviceId":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"origin":{"type":"string","required":true,"configurable":false,"private":true,"searchable":false},"expiresAt":{"type":"datetime","required":true,"configurable":false,"private":true,"searchable":false},"absoluteExpiresAt":{"type":"datetime","configurable":false,"private":true,"searchable":false},"status":{"type":"string","configurable":false,"private":true,"searchable":false},"type":{"type":"string","configurable":false,"private":true,"searchable":false}},"kind":"collectionType"},"modelName":"session"},"admin::audit-log":{"kind":"collectionType","collectionName":"strapi_audit_logs","info":{"singularName":"audit-log","pluralName":"audit-logs","displayName":"Audit Log"},"options":{"timestamps":false,"draftAndPublish":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true},"date":{"type":"datetime","required":true},"user":{"type":"relation","relation":"oneToOne","target":"admin::user"},"payload":{"type":"json"},"createdAt":{"type":"datetime"},"updatedAt":{"type":"datetime"},"publishedAt":{"type":"datetime","configurable":false,"writable":true,"visible":true},"createdBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"updatedBy":{"type":"relation","relation":"oneToOne","target":"admin::user","configurable":false,"writable":false,"visible":false,"useJoinTable":false,"private":true},"locale":{"writable":true,"private":true,"configurable":false,"visible":false,"type":"string"},"localizations":{"type":"relation","relation":"oneToMany","target":"admin::audit-log","writable":false,"private":true,"configurable":false,"visible":false,"unstable_virtual":true,"joinColumn":{"name":"document_id","referencedColumn":"document_id","referencedTable":"strapi_audit_logs"}}},"plugin":"admin","globalId":"AdminAuditLog","uid":"admin::audit-log","modelType":"contentType","__schema__":{"collectionName":"strapi_audit_logs","info":{"singularName":"audit-log","pluralName":"audit-logs","displayName":"Audit Log"},"options":{"timestamps":false},"pluginOptions":{"content-manager":{"visible":false},"content-type-builder":{"visible":false}},"attributes":{"action":{"type":"string","required":true},"date":{"type":"datetime","required":true},"user":{"type":"relation","relation":"oneToOne","target":"admin::user"},"payload":{"type":"json"}},"kind":"collectionType"},"modelName":"audit-log"}}	object	\N	\N
65	plugin_content_manager_configuration_content_types::api::about-page.about-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"missionTitle":{"edit":{"label":"missionTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"missionTitle","searchable":true,"sortable":true}},"missionText":{"edit":{"label":"missionText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"missionText","searchable":true,"sortable":true}},"visionTitle":{"edit":{"label":"visionTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"visionTitle","searchable":true,"sortable":true}},"visionText":{"edit":{"label":"visionText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"visionText","searchable":true,"sortable":true}},"valuesTitle":{"edit":{"label":"valuesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"valuesTitle","searchable":true,"sortable":true}},"value1Title":{"edit":{"label":"value1Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value1Title","searchable":true,"sortable":true}},"value1Text":{"edit":{"label":"value1Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value1Text","searchable":true,"sortable":true}},"value2Title":{"edit":{"label":"value2Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value2Title","searchable":true,"sortable":true}},"value2Text":{"edit":{"label":"value2Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value2Text","searchable":true,"sortable":true}},"value3Title":{"edit":{"label":"value3Title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value3Title","searchable":true,"sortable":true}},"value3Text":{"edit":{"label":"value3Text","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value3Text","searchable":true,"sortable":true}},"teamTitle":{"edit":{"label":"teamTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"teamTitle","searchable":true,"sortable":true}},"teamSubtitle":{"edit":{"label":"teamSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"teamSubtitle","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","missionTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"missionTitle","size":6},{"name":"missionText","size":6}],[{"name":"visionTitle","size":6},{"name":"visionText","size":6}],[{"name":"valuesTitle","size":6},{"name":"value1Title","size":6}],[{"name":"value1Text","size":6},{"name":"value2Title","size":6}],[{"name":"value2Text","size":6},{"name":"value3Title","size":6}],[{"name":"value3Text","size":6},{"name":"teamTitle","size":6}],[{"name":"teamSubtitle","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::about-page.about-page"}	object	\N	\N
75	plugin_content_manager_configuration_content_types::api::contact-page.contact-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"formTitle":{"edit":{"label":"formTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"formTitle","searchable":true,"sortable":true}},"nameLabel":{"edit":{"label":"nameLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"nameLabel","searchable":true,"sortable":true}},"emailLabel":{"edit":{"label":"emailLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"emailLabel","searchable":true,"sortable":true}},"phoneLabel":{"edit":{"label":"phoneLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"phoneLabel","searchable":true,"sortable":true}},"messageLabel":{"edit":{"label":"messageLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"messageLabel","searchable":true,"sortable":true}},"submitButton":{"edit":{"label":"submitButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"submitButton","searchable":true,"sortable":true}},"infoTitle":{"edit":{"label":"infoTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"infoTitle","searchable":true,"sortable":true}},"address":{"edit":{"label":"address","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"address","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"phone":{"edit":{"label":"phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"phone","searchable":true,"sortable":true}},"hoursTitle":{"edit":{"label":"hoursTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hoursTitle","searchable":true,"sortable":true}},"hoursText":{"edit":{"label":"hoursText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"hoursText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","formTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"formTitle","size":6},{"name":"nameLabel","size":6}],[{"name":"emailLabel","size":6},{"name":"phoneLabel","size":6}],[{"name":"messageLabel","size":6},{"name":"submitButton","size":6}],[{"name":"infoTitle","size":6},{"name":"address","size":6}],[{"name":"email","size":6},{"name":"phone","size":6}],[{"name":"hoursTitle","size":6},{"name":"hoursText","size":6}]]},"uid":"api::contact-page.contact-page"}	object	\N	\N
11	plugin_content_manager_configuration_content_types::plugin::users-permissions.permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","role","createdAt"],"edit":[[{"name":"action","size":6},{"name":"role","size":6}]]},"uid":"plugin::users-permissions.permission"}	object	\N	\N
17	plugin_content_manager_configuration_content_types::admin::api-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::api-token-permission"}	object	\N	\N
66	plugin_content_manager_configuration_content_types::api::case-study.case-study	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"client":{"edit":{"label":"client","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"client","searchable":true,"sortable":true}},"industry":{"edit":{"label":"industry","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industry","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","client"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"client","size":6},{"name":"industry","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"allowedRoles","size":12}]]},"uid":"api::case-study.case-study"}	object	\N	\N
85	plugin_content_manager_configuration_content_types::api::demos-page.demos-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterMatterport":{"edit":{"label":"filterMatterport","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterMatterport","searchable":true,"sortable":true}},"filterAi":{"edit":{"label":"filterAi","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAi","searchable":true,"sortable":true}},"filterVfair":{"edit":{"label":"filterVfair","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterVfair","searchable":true,"sortable":true}},"accessPublic":{"edit":{"label":"accessPublic","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessPublic","searchable":true,"sortable":true}},"accessAuth":{"edit":{"label":"accessAuth","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessAuth","searchable":true,"sortable":true}},"accessEnterprise":{"edit":{"label":"accessEnterprise","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessEnterprise","searchable":true,"sortable":true}},"tryNowButton":{"edit":{"label":"tryNowButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"tryNowButton","searchable":true,"sortable":true}},"requestAccessButton":{"edit":{"label":"requestAccessButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"requestAccessButton","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterMatterport","size":6}],[{"name":"filterAi","size":6},{"name":"filterVfair","size":6}],[{"name":"accessPublic","size":6},{"name":"accessAuth","size":6}],[{"name":"accessEnterprise","size":6},{"name":"tryNowButton","size":6}],[{"name":"requestAccessButton","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaSubtitle","size":6},{"name":"ctaButton","size":6}]]},"uid":"api::demos-page.demos-page"}	object	\N	\N
14	plugin_content_manager_configuration_content_types::admin::permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"actionParameters":{"edit":{"label":"actionParameters","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"actionParameters","searchable":false,"sortable":false}},"subject":{"edit":{"label":"subject","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"subject","searchable":true,"sortable":true}},"properties":{"edit":{"label":"properties","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"properties","searchable":false,"sortable":false}},"conditions":{"edit":{"label":"conditions","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"conditions","searchable":false,"sortable":false}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","subject","role"],"edit":[[{"name":"action","size":6}],[{"name":"actionParameters","size":12}],[{"name":"subject","size":6}],[{"name":"properties","size":12}],[{"name":"conditions","size":12}],[{"name":"role","size":6}]]},"uid":"admin::permission"}	object	\N	\N
16	plugin_content_manager_configuration_content_types::admin::role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"code":{"edit":{"label":"code","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"code","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"users","searchable":false,"sortable":false}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","code","description"],"edit":[[{"name":"name","size":6},{"name":"code","size":6}],[{"name":"description","size":6},{"name":"users","size":6}],[{"name":"permissions","size":6}]]},"uid":"admin::role"}	object	\N	\N
19	plugin_content_manager_configuration_content_types::admin::transfer-token-permission	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"token":{"edit":{"label":"token","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"token","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","token","createdAt"],"edit":[[{"name":"action","size":6},{"name":"token","size":6}]]},"uid":"admin::transfer-token-permission"}	object	\N	\N
23	core_persisted_tables	[{"name":"strapi_history_versions"}]	object	\N	\N
28	plugin_users-permissions_grant	{"email":{"icon":"envelope","enabled":true},"discord":{"icon":"discord","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/discord/callback","scope":["identify","email"]},"facebook":{"icon":"facebook-square","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/facebook/callback","scope":["email"]},"google":{"icon":"google","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/google/callback","scope":["email"]},"github":{"icon":"github","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/github/callback","scope":["user","user:email"]},"microsoft":{"icon":"windows","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/microsoft/callback","scope":["user.read"]},"twitter":{"icon":"twitter","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitter/callback"},"instagram":{"icon":"instagram","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/instagram/callback","scope":["user_profile"]},"vk":{"icon":"vk","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/vk/callback","scope":["email"]},"twitch":{"icon":"twitch","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/twitch/callback","scope":["user:read:email"]},"linkedin":{"icon":"linkedin","enabled":false,"key":"","secret":"","callbackUrl":"api/auth/linkedin/callback","scope":["r_liteprofile","r_emailaddress"]},"cognito":{"icon":"aws","enabled":false,"key":"","secret":"","subdomain":"my.subdomain.com","callback":"api/auth/cognito/callback","scope":["email","openid","profile"]},"reddit":{"icon":"reddit","enabled":false,"key":"","secret":"","callback":"api/auth/reddit/callback","scope":["identity"]},"auth0":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"my-tenant.eu","callback":"api/auth/auth0/callback","scope":["openid","email","profile"]},"cas":{"icon":"book","enabled":false,"key":"","secret":"","callback":"api/auth/cas/callback","scope":["openid email"],"subdomain":"my.subdomain.com/cas"},"patreon":{"icon":"","enabled":false,"key":"","secret":"","callback":"api/auth/patreon/callback","scope":["identity","identity[email]"]},"keycloak":{"icon":"","enabled":false,"key":"","secret":"","subdomain":"myKeycloakProvider.com/realms/myrealm","callback":"api/auth/keycloak/callback","scope":["openid","email","profile"]}}	object	\N	\N
29	plugin_users-permissions_email	{"reset_password":{"display":"Email.template.reset_password","icon":"sync","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Reset password","message":"<p>We heard that you lost your password. Sorry about that!</p>\\n\\n<p>But don’t worry! You can use the following link to reset your password:</p>\\n<p><%= URL %>?code=<%= TOKEN %></p>\\n\\n<p>Thanks.</p>"}},"email_confirmation":{"display":"Email.template.email_confirmation","icon":"check-square","options":{"from":{"name":"Administration Panel","email":"no-reply@strapi.io"},"response_email":"","object":"Account confirmation","message":"<p>Thank you for registering!</p>\\n\\n<p>You have to confirm your email address. Please click on the link below.</p>\\n\\n<p><%= URL %>?confirmation=<%= CODE %></p>\\n\\n<p>Thanks.</p>"}}}	object	\N	\N
30	plugin_users-permissions_advanced	{"unique_email":true,"allow_register":true,"email_confirmation":false,"email_reset_password":null,"email_confirmation_redirection":null,"default_role":"authenticated"}	object	\N	\N
67	plugin_content_manager_configuration_content_types::api::demo.demo	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"demoType":{"edit":{"label":"demoType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demoType","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"accessLevel":{"edit":{"label":"accessLevel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessLevel","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","demoType"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"demoType","size":6},{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}],[{"name":"allowedRoles","size":12}],[{"name":"accessLevel","size":6}]]},"uid":"api::demo.demo"}	object	\N	\N
79	plugin_content_manager_configuration_content_types::api::site-setting.site-setting	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"contactEmail":{"edit":{"label":"contactEmail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contactEmail","searchable":true,"sortable":true}},"contactPhone":{"edit":{"label":"contactPhone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"contactPhone","searchable":true,"sortable":true}},"footerCompanyTitle":{"edit":{"label":"footerCompanyTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerCompanyTitle","searchable":true,"sortable":true}},"footerProductsTitle":{"edit":{"label":"footerProductsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerProductsTitle","searchable":true,"sortable":true}},"footerResourcesTitle":{"edit":{"label":"footerResourcesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerResourcesTitle","searchable":true,"sortable":true}},"footerConnectTitle":{"edit":{"label":"footerConnectTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"footerConnectTitle","searchable":true,"sortable":true}},"copyrightText":{"edit":{"label":"copyrightText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"copyrightText","searchable":true,"sortable":true}},"loginButtonText":{"edit":{"label":"loginButtonText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"loginButtonText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","contactEmail"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"contactEmail","size":6},{"name":"contactPhone","size":6}],[{"name":"footerCompanyTitle","size":6},{"name":"footerProductsTitle","size":6}],[{"name":"footerResourcesTitle","size":6},{"name":"footerConnectTitle","size":6}],[{"name":"copyrightText","size":6},{"name":"loginButtonText","size":6}]]},"uid":"api::site-setting.site-setting"}	object	\N	\N
31	ee_disabled_users	[]	object	\N	\N
32	core_admin_auth	{"providers":{"autoRegister":false,"defaultRole":null,"ssoLockedRoles":null}}	object	\N	\N
12	plugin_content_manager_configuration_content_types::plugin::users-permissions.role	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"users":{"edit":{"label":"users","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"users","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"permissions","size":6}],[{"name":"users","size":6}]]},"uid":"plugin::users-permissions.role"}	object	\N	\N
20	plugin_content_manager_configuration_content_types::admin::session	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"userId","defaultSortBy":"userId","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"userId":{"edit":{"label":"userId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userId","searchable":true,"sortable":true}},"sessionId":{"edit":{"label":"sessionId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"sessionId","searchable":true,"sortable":true}},"childId":{"edit":{"label":"childId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"childId","searchable":true,"sortable":true}},"deviceId":{"edit":{"label":"deviceId","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"deviceId","searchable":true,"sortable":true}},"origin":{"edit":{"label":"origin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"origin","searchable":true,"sortable":true}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"absoluteExpiresAt":{"edit":{"label":"absoluteExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"absoluteExpiresAt","searchable":true,"sortable":true}},"status":{"edit":{"label":"status","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"status","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","userId","sessionId","childId"],"edit":[[{"name":"userId","size":6},{"name":"sessionId","size":6}],[{"name":"childId","size":6},{"name":"deviceId","size":6}],[{"name":"origin","size":6},{"name":"expiresAt","size":6}],[{"name":"absoluteExpiresAt","size":6},{"name":"status","size":6}],[{"name":"type","size":6}]]},"uid":"admin::session"}	object	\N	\N
68	plugin_content_manager_configuration_content_types::api::homepage.homepage	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"heroPrimaryCta":{"edit":{"label":"heroPrimaryCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroPrimaryCta","searchable":true,"sortable":true}},"heroSecondaryCta":{"edit":{"label":"heroSecondaryCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSecondaryCta","searchable":true,"sortable":true}},"heroBadge":{"edit":{"label":"heroBadge","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroBadge","searchable":true,"sortable":true}},"trustAward":{"edit":{"label":"trustAward","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustAward","searchable":true,"sortable":true}},"trustGlobal":{"edit":{"label":"trustGlobal","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustGlobal","searchable":true,"sortable":true}},"trustFast":{"edit":{"label":"trustFast","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustFast","searchable":true,"sortable":true}},"showStatsSection":{"edit":{"label":"showStatsSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showStatsSection","searchable":true,"sortable":true}},"showTrustedBySection":{"edit":{"label":"showTrustedBySection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showTrustedBySection","searchable":true,"sortable":true}},"trustedByTitle":{"edit":{"label":"trustedByTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"trustedByTitle","searchable":true,"sortable":true}},"showHowItWorksSection":{"edit":{"label":"showHowItWorksSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showHowItWorksSection","searchable":true,"sortable":true}},"howItWorksTitle":{"edit":{"label":"howItWorksTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"howItWorksTitle","searchable":true,"sortable":true}},"howItWorksSubtitle":{"edit":{"label":"howItWorksSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"howItWorksSubtitle","searchable":true,"sortable":true}},"showFeaturesSection":{"edit":{"label":"showFeaturesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showFeaturesSection","searchable":true,"sortable":true}},"featuresTitle":{"edit":{"label":"featuresTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresTitle","searchable":true,"sortable":true}},"featuresSubtitle":{"edit":{"label":"featuresSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresSubtitle","searchable":true,"sortable":true}},"showSolutionsSection":{"edit":{"label":"showSolutionsSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showSolutionsSection","searchable":true,"sortable":true}},"solutionsTitle":{"edit":{"label":"solutionsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"solutionsTitle","searchable":true,"sortable":true}},"solutionsSubtitle":{"edit":{"label":"solutionsSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"solutionsSubtitle","searchable":true,"sortable":true}},"showIndustriesSection":{"edit":{"label":"showIndustriesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showIndustriesSection","searchable":true,"sortable":true}},"industriesTitle":{"edit":{"label":"industriesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industriesTitle","searchable":true,"sortable":true}},"industriesSubtitle":{"edit":{"label":"industriesSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"industriesSubtitle","searchable":true,"sortable":true}},"showCaseStudiesSection":{"edit":{"label":"showCaseStudiesSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showCaseStudiesSection","searchable":true,"sortable":true}},"caseStudiesTitle":{"edit":{"label":"caseStudiesTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caseStudiesTitle","searchable":true,"sortable":true}},"caseStudiesSubtitle":{"edit":{"label":"caseStudiesSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"caseStudiesSubtitle","searchable":true,"sortable":true}},"showDemosSection":{"edit":{"label":"showDemosSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showDemosSection","searchable":true,"sortable":true}},"demosTitle":{"edit":{"label":"demosTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demosTitle","searchable":true,"sortable":true}},"demosSubtitle":{"edit":{"label":"demosSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"demosSubtitle","searchable":true,"sortable":true}},"showCtaSection":{"edit":{"label":"showCtaSection","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"showCtaSection","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaPrimaryButton":{"edit":{"label":"ctaPrimaryButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaPrimaryButton","searchable":true,"sortable":true}},"ctaSecondaryButton":{"edit":{"label":"ctaSecondaryButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSecondaryButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","heroPrimaryCta"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"heroPrimaryCta","size":6},{"name":"heroSecondaryCta","size":6}],[{"name":"heroBadge","size":6},{"name":"trustAward","size":6}],[{"name":"trustGlobal","size":6},{"name":"trustFast","size":6}],[{"name":"showStatsSection","size":4},{"name":"showTrustedBySection","size":4}],[{"name":"trustedByTitle","size":6},{"name":"showHowItWorksSection","size":4}],[{"name":"howItWorksTitle","size":6},{"name":"howItWorksSubtitle","size":6}],[{"name":"showFeaturesSection","size":4},{"name":"featuresTitle","size":6}],[{"name":"featuresSubtitle","size":6},{"name":"showSolutionsSection","size":4}],[{"name":"solutionsTitle","size":6},{"name":"solutionsSubtitle","size":6}],[{"name":"showIndustriesSection","size":4},{"name":"industriesTitle","size":6}],[{"name":"industriesSubtitle","size":6},{"name":"showCaseStudiesSection","size":4}],[{"name":"caseStudiesTitle","size":6},{"name":"caseStudiesSubtitle","size":6}],[{"name":"showDemosSection","size":4},{"name":"demosTitle","size":6}],[{"name":"demosSubtitle","size":6},{"name":"showCtaSection","size":4}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaPrimaryButton","size":6},{"name":"ctaSecondaryButton","size":6}]]},"uid":"api::homepage.homepage"}	object	\N	\N
86	plugin_content_manager_configuration_content_types::api::pricing-page.pricing-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"monthlyLabel":{"edit":{"label":"monthlyLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"monthlyLabel","searchable":true,"sortable":true}},"annualLabel":{"edit":{"label":"annualLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"annualLabel","searchable":true,"sortable":true}},"annualDiscount":{"edit":{"label":"annualDiscount","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"annualDiscount","searchable":true,"sortable":true}},"popularBadge":{"edit":{"label":"popularBadge","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"popularBadge","searchable":true,"sortable":true}},"featuresTitle":{"edit":{"label":"featuresTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featuresTitle","searchable":true,"sortable":true}},"feature1":{"edit":{"label":"feature1","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature1","searchable":true,"sortable":true}},"feature2":{"edit":{"label":"feature2","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature2","searchable":true,"sortable":true}},"feature3":{"edit":{"label":"feature3","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature3","searchable":true,"sortable":true}},"feature4":{"edit":{"label":"feature4","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature4","searchable":true,"sortable":true}},"feature5":{"edit":{"label":"feature5","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"feature5","searchable":true,"sortable":true}},"comparisonTitle":{"edit":{"label":"comparisonTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"comparisonTitle","searchable":true,"sortable":true}},"enterpriseTitle":{"edit":{"label":"enterpriseTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseTitle","searchable":true,"sortable":true}},"enterpriseSubtitle":{"edit":{"label":"enterpriseSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseSubtitle","searchable":true,"sortable":true}},"enterpriseCta":{"edit":{"label":"enterpriseCta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"enterpriseCta","searchable":true,"sortable":true}},"faqTitle":{"edit":{"label":"faqTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"faqTitle","searchable":true,"sortable":true}},"guaranteeTitle":{"edit":{"label":"guaranteeTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"guaranteeTitle","searchable":true,"sortable":true}},"guaranteeText":{"edit":{"label":"guaranteeText","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"guaranteeText","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","monthlyLabel"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"monthlyLabel","size":6},{"name":"annualLabel","size":6}],[{"name":"annualDiscount","size":6},{"name":"popularBadge","size":6}],[{"name":"featuresTitle","size":6},{"name":"feature1","size":6}],[{"name":"feature2","size":6},{"name":"feature3","size":6}],[{"name":"feature4","size":6},{"name":"feature5","size":6}],[{"name":"comparisonTitle","size":6},{"name":"enterpriseTitle","size":6}],[{"name":"enterpriseSubtitle","size":6},{"name":"enterpriseCta","size":6}],[{"name":"faqTitle","size":6},{"name":"guaranteeTitle","size":6}],[{"name":"guaranteeText","size":6}]]},"uid":"api::pricing-page.pricing-page"}	object	\N	\N
15	plugin_content_manager_configuration_content_types::admin::user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"firstname","defaultSortBy":"firstname","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"firstname":{"edit":{"label":"firstname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"firstname","searchable":true,"sortable":true}},"lastname":{"edit":{"label":"lastname","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastname","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"registrationToken":{"edit":{"label":"registrationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"registrationToken","searchable":true,"sortable":true}},"isActive":{"edit":{"label":"isActive","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isActive","searchable":true,"sortable":true}},"roles":{"edit":{"label":"roles","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"roles","searchable":false,"sortable":false}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"preferedLanguage":{"edit":{"label":"preferedLanguage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"preferedLanguage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","firstname","lastname","username"],"edit":[[{"name":"firstname","size":6},{"name":"lastname","size":6}],[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"isActive","size":4}],[{"name":"roles","size":6},{"name":"blocked","size":4}],[{"name":"preferedLanguage","size":6}]]},"uid":"admin::user"}	object	\N	\N
18	plugin_content_manager_configuration_content_types::admin::transfer-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","accessKey"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"accessKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::transfer-token"}	object	\N	\N
21	plugin_content_manager_configuration_content_types::admin::audit-log	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"action","defaultSortBy":"action","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"date":{"edit":{"label":"date","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"date","searchable":true,"sortable":true}},"user":{"edit":{"label":"user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"firstname"},"list":{"label":"user","searchable":true,"sortable":true}},"payload":{"edit":{"label":"payload","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"payload","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","action","date","user"],"edit":[[{"name":"action","size":6},{"name":"date","size":6}],[{"name":"user","size":6}],[{"name":"payload","size":12}]]},"uid":"admin::audit-log"}	object	\N	\N
22	plugin_content_manager_configuration_content_types::admin::api-token	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"type":{"edit":{"label":"type","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"type","searchable":true,"sortable":true}},"accessKey":{"edit":{"label":"accessKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accessKey","searchable":true,"sortable":true}},"encryptedKey":{"edit":{"label":"encryptedKey","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"encryptedKey","searchable":true,"sortable":true}},"lastUsedAt":{"edit":{"label":"lastUsedAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastUsedAt","searchable":true,"sortable":true}},"permissions":{"edit":{"label":"permissions","description":"","placeholder":"","visible":true,"editable":true,"mainField":"action"},"list":{"label":"permissions","searchable":false,"sortable":false}},"expiresAt":{"edit":{"label":"expiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"expiresAt","searchable":true,"sortable":true}},"lifespan":{"edit":{"label":"lifespan","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lifespan","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","description","type"],"edit":[[{"name":"name","size":6},{"name":"description","size":6}],[{"name":"type","size":6},{"name":"accessKey","size":6}],[{"name":"encryptedKey","size":6},{"name":"lastUsedAt","size":6}],[{"name":"permissions","size":6},{"name":"expiresAt","size":6}],[{"name":"lifespan","size":4}]]},"uid":"admin::api-token"}	object	\N	\N
24	plugin_upload_settings	{"sizeOptimization":true,"responsiveDimensions":true,"autoOrientation":false,"aiMetadata":true}	object	\N	\N
25	plugin_upload_view_configuration	{"pageSize":10,"sort":"createdAt:DESC"}	object	\N	\N
27	plugin_i18n_default_locale	"en"	string	\N	\N
69	plugin_content_manager_configuration_content_types::api::industry.industry	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","summary"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}]]},"uid":"api::industry.industry"}	object	\N	\N
77	plugin_content_manager_configuration_content_types::api::user-audit-log.user-audit-log	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"ipAddress","defaultSortBy":"ipAddress","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"user":{"edit":{"label":"user","description":"","placeholder":"","visible":true,"editable":true,"mainField":"username"},"list":{"label":"user","searchable":true,"sortable":true}},"action":{"edit":{"label":"action","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"action","searchable":true,"sortable":true}},"ipAddress":{"edit":{"label":"ipAddress","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ipAddress","searchable":true,"sortable":true}},"userAgent":{"edit":{"label":"userAgent","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"userAgent","searchable":true,"sortable":true}},"targetDemo":{"edit":{"label":"targetDemo","description":"","placeholder":"","visible":true,"editable":true,"mainField":"title"},"list":{"label":"targetDemo","searchable":true,"sortable":true}},"metadata":{"edit":{"label":"metadata","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"metadata","searchable":false,"sortable":false}},"success":{"edit":{"label":"success","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"success","searchable":true,"sortable":true}},"errorMessage":{"edit":{"label":"errorMessage","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"errorMessage","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","user","action","ipAddress"],"edit":[[{"name":"user","size":6},{"name":"action","size":6}],[{"name":"ipAddress","size":6},{"name":"userAgent","size":6}],[{"name":"targetDemo","size":6}],[{"name":"metadata","size":12}],[{"name":"success","size":4},{"name":"errorMessage","size":6}]]},"uid":"api::user-audit-log.user-audit-log"}	object	\N	\N
26	plugin_upload_metrics	{"weeklySchedule":"49 6 17 * * 4","lastWeeklyUpdate":1769699209402}	object	\N	\N
87	plugin_content_manager_configuration_content_types::api::solutions-page.solutions-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterPlatforms":{"edit":{"label":"filterPlatforms","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterPlatforms","searchable":true,"sortable":true}},"filterServices":{"edit":{"label":"filterServices","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterServices","searchable":true,"sortable":true}},"filterAi":{"edit":{"label":"filterAi","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAi","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterPlatforms","size":6}],[{"name":"filterServices","size":6},{"name":"filterAi","size":6}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::solutions-page.solutions-page"}	object	\N	\N
13	plugin_content_manager_configuration_content_types::plugin::users-permissions.user	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"username","defaultSortBy":"username","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"username":{"edit":{"label":"username","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"username","searchable":true,"sortable":true}},"email":{"edit":{"label":"email","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"email","searchable":true,"sortable":true}},"provider":{"edit":{"label":"provider","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"provider","searchable":true,"sortable":true}},"password":{"edit":{"label":"password","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"password","searchable":true,"sortable":true}},"resetPasswordToken":{"edit":{"label":"resetPasswordToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"resetPasswordToken","searchable":true,"sortable":true}},"confirmationToken":{"edit":{"label":"confirmationToken","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"confirmationToken","searchable":true,"sortable":true}},"confirmed":{"edit":{"label":"confirmed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmed","searchable":true,"sortable":true}},"blocked":{"edit":{"label":"blocked","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"blocked","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true,"mainField":"name"},"list":{"label":"role","searchable":true,"sortable":true}},"displayName":{"edit":{"label":"displayName","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"displayName","searchable":true,"sortable":true}},"phone":{"edit":{"label":"phone","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"phone","searchable":true,"sortable":true}},"country":{"edit":{"label":"country","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"country","searchable":true,"sortable":true}},"company":{"edit":{"label":"company","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"company","searchable":true,"sortable":true}},"accountStatus":{"edit":{"label":"accountStatus","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"accountStatus","searchable":true,"sortable":true}},"salesContactAllowed":{"edit":{"label":"salesContactAllowed","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"salesContactAllowed","searchable":true,"sortable":true}},"confirmationTokenExpiresAt":{"edit":{"label":"confirmationTokenExpiresAt","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"confirmationTokenExpiresAt","searchable":true,"sortable":true}},"lastLogin":{"edit":{"label":"lastLogin","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"lastLogin","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","username","email","confirmed"],"edit":[[{"name":"username","size":6},{"name":"email","size":6}],[{"name":"password","size":6},{"name":"confirmed","size":4}],[{"name":"blocked","size":4},{"name":"role","size":6}],[{"name":"displayName","size":6},{"name":"phone","size":6}],[{"name":"country","size":6},{"name":"company","size":6}],[{"name":"accountStatus","size":6},{"name":"salesContactAllowed","size":4}],[{"name":"lastLogin","size":6},{"name":"confirmationTokenExpiresAt","size":6}]]},"uid":"plugin::users-permissions.user"}	object	\N	\N
70	plugin_content_manager_configuration_content_types::api::process-step.process-step	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"step":{"edit":{"label":"step","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"step","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","step","title","description"],"edit":[[{"name":"step","size":4},{"name":"title","size":6}],[{"name":"description","size":6},{"name":"icon","size":6}]]},"uid":"api::process-step.process-step"}	object	\N	\N
88	plugin_content_manager_configuration_content_types::api::pricing-plan.pricing-plan	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"popular":{"edit":{"label":"popular","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"popular","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"price":{"edit":{"label":"price","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"price","searchable":true,"sortable":true}},"currency":{"edit":{"label":"currency","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"currency","searchable":true,"sortable":true}},"period":{"edit":{"label":"period","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"period","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"features":{"edit":{"label":"features","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"features","searchable":true,"sortable":true}},"limitations":{"edit":{"label":"limitations","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"limitations","searchable":true,"sortable":true}},"cta":{"edit":{"label":"cta","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"cta","searchable":true,"sortable":true}},"idealFor":{"edit":{"label":"idealFor","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"idealFor","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","order","popular"],"edit":[[{"name":"slug","size":6},{"name":"order","size":4}],[{"name":"popular","size":4},{"name":"name","size":6}],[{"name":"price","size":6},{"name":"currency","size":6}],[{"name":"period","size":6},{"name":"description","size":6}],[{"name":"features","size":6},{"name":"limitations","size":6}],[{"name":"cta","size":6},{"name":"idealFor","size":6}]]},"uid":"api::pricing-plan.pricing-plan"}	object	\N	\N
71	plugin_content_manager_configuration_content_types::api::feature.feature	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","icon"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"icon","size":6},{"name":"order","size":4}]]},"uid":"api::feature.feature"}	object	\N	\N
81	plugin_i18n_settings	{"aiLocalizations":true}	object	\N	\N
89	plugin_content_manager_configuration_content_types::api::partner.partner	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"partnerType":{"edit":{"label":"partnerType","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"partnerType","searchable":true,"sortable":true}},"logoUrl":{"edit":{"label":"logoUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"logoUrl","searchable":true,"sortable":true}},"websiteUrl":{"edit":{"label":"websiteUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"websiteUrl","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"partnership":{"edit":{"label":"partnership","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"partnership","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","order","partnerType"],"edit":[[{"name":"slug","size":6},{"name":"order","size":4}],[{"name":"partnerType","size":6},{"name":"logoUrl","size":6}],[{"name":"websiteUrl","size":6},{"name":"name","size":6}],[{"name":"description","size":6},{"name":"partnership","size":6}]]},"uid":"api::partner.partner"}	object	\N	\N
72	plugin_content_manager_configuration_content_types::api::nav-item.nav-item	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"label","defaultSortBy":"label","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"label":{"edit":{"label":"label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"label","searchable":true,"sortable":true}},"href":{"edit":{"label":"href","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"href","searchable":true,"sortable":true}},"location":{"edit":{"label":"location","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"location","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"isExternal":{"edit":{"label":"isExternal","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"isExternal","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","label","href","location"],"edit":[[{"name":"label","size":6},{"name":"href","size":6}],[{"name":"location","size":6},{"name":"order","size":4}],[{"name":"isExternal","size":4}]]},"uid":"api::nav-item.nav-item"}	object	\N	\N
80	plugin_content_manager_configuration_content_types::api::team-member.team-member	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"position":{"edit":{"label":"position","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"position","searchable":true,"sortable":true}},"bio":{"edit":{"label":"bio","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"bio","searchable":true,"sortable":true}},"photo":{"edit":{"label":"photo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"photo","searchable":false,"sortable":false}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"linkedinUrl":{"edit":{"label":"linkedinUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"linkedinUrl","searchable":true,"sortable":true}},"twitterUrl":{"edit":{"label":"twitterUrl","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"twitterUrl","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","position","bio"],"edit":[[{"name":"name","size":6},{"name":"position","size":6}],[{"name":"bio","size":6},{"name":"photo","size":6}],[{"name":"order","size":4},{"name":"linkedinUrl","size":6}],[{"name":"twitterUrl","size":6}]]},"uid":"api::team-member.team-member"}	object	\N	\N
82	plugin_content_manager_configuration_content_types::api::faq.faq	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"slug","defaultSortBy":"slug","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"category":{"edit":{"label":"category","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"category","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"question":{"edit":{"label":"question","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"question","searchable":true,"sortable":true}},"answer":{"edit":{"label":"answer","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"answer","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","category","order"],"edit":[[{"name":"slug","size":6},{"name":"category","size":6}],[{"name":"order","size":4},{"name":"question","size":6}],[{"name":"answer","size":12}]]},"uid":"api::faq.faq"}	object	\N	\N
90	plugin_content_manager_configuration_content_types::api::testimonial.testimonial	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"author","defaultSortBy":"author","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"rating":{"edit":{"label":"rating","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"rating","searchable":true,"sortable":true}},"featured":{"edit":{"label":"featured","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"featured","searchable":true,"sortable":true}},"quote":{"edit":{"label":"quote","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"quote","searchable":true,"sortable":true}},"author":{"edit":{"label":"author","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"author","searchable":true,"sortable":true}},"role":{"edit":{"label":"role","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"role","searchable":true,"sortable":true}},"company":{"edit":{"label":"company","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"company","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","order","rating","featured"],"edit":[[{"name":"order","size":4},{"name":"rating","size":4},{"name":"featured","size":4}],[{"name":"quote","size":6},{"name":"author","size":6}],[{"name":"role","size":6},{"name":"company","size":6}]]},"uid":"api::testimonial.testimonial"}	object	\N	\N
73	plugin_content_manager_configuration_content_types::api::solution.solution	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"slug":{"edit":{"label":"slug","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"slug","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"summary":{"edit":{"label":"summary","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"summary","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":false,"sortable":false}},"body":{"edit":{"label":"body","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"body","searchable":false,"sortable":false}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"allowedRoles":{"edit":{"label":"allowedRoles","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"allowedRoles","searchable":false,"sortable":false}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","slug","title","summary"],"edit":[[{"name":"slug","size":6},{"name":"title","size":6}],[{"name":"summary","size":6}],[{"name":"description","size":12}],[{"name":"body","size":12}],[{"name":"icon","size":6}],[{"name":"allowedRoles","size":12}]]},"uid":"api::solution.solution"}	object	\N	\N
78	plugin_content_manager_configuration_content_types::api::value.value	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"title","defaultSortBy":"title","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"title":{"edit":{"label":"title","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"title","searchable":true,"sortable":true}},"description":{"edit":{"label":"description","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"description","searchable":true,"sortable":true}},"icon":{"edit":{"label":"icon","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"icon","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","title","description","icon"],"edit":[[{"name":"title","size":6},{"name":"description","size":6}],[{"name":"icon","size":6},{"name":"order","size":4}]]},"uid":"api::value.value"}	object	\N	\N
83	plugin_content_manager_configuration_content_types::api::case-studies-page.case-studies-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"filterAll":{"edit":{"label":"filterAll","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterAll","searchable":true,"sortable":true}},"filterRetail":{"edit":{"label":"filterRetail","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterRetail","searchable":true,"sortable":true}},"filterRealEstate":{"edit":{"label":"filterRealEstate","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterRealEstate","searchable":true,"sortable":true}},"filterTourism":{"edit":{"label":"filterTourism","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterTourism","searchable":true,"sortable":true}},"filterEvents":{"edit":{"label":"filterEvents","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterEvents","searchable":true,"sortable":true}},"filterEducation":{"edit":{"label":"filterEducation","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"filterEducation","searchable":true,"sortable":true}},"resultsLabel":{"edit":{"label":"resultsLabel","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"resultsLabel","searchable":true,"sortable":true}},"readMoreButton":{"edit":{"label":"readMoreButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"readMoreButton","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","filterAll"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"filterAll","size":6},{"name":"filterRetail","size":6}],[{"name":"filterRealEstate","size":6},{"name":"filterTourism","size":6}],[{"name":"filterEvents","size":6},{"name":"filterEducation","size":6}],[{"name":"resultsLabel","size":6},{"name":"readMoreButton","size":6}],[{"name":"ctaTitle","size":6},{"name":"ctaSubtitle","size":6}],[{"name":"ctaButton","size":6}]]},"uid":"api::case-studies-page.case-studies-page"}	object	\N	\N
2	ee_information	{"lastCheckAt":1769889139738,"license":"TmQrMURRUlQvZjc0MjFXcjROcVNMVWRrbWszTTJtNzlKRUNlN0FVMGgxNis3QXpFQnhNMHUrZytUNHg2WXB6RWMreE9vSXJYMmVmWFZmVU1OMEY5b2F6OE5JVDF2QllkbTl5ajFrYiswd0pOUGEzbmFKdGowZTRqWDVOVEpsN3QrNFFFTnE2SDRXc3ZtVTAzRmR0V2dDZExEOUY4MVM1VmpkamhZSVZOTnM5ck13TFJZM1Y5b0Z3MEg3NlNlL05xUVBtTFlCdXZZOGp4elR2T25xOGJKcWdQR2NhWUwxSnJITjI0eWZMZ08zdkNLdFREbDhlYS9xRnZ6RFl6ZnMyczZwTURuS0hSZDNMNHhqMERQZWlhVTFEVXZ2dE5MMlV1Vlgva25ibmZiWVhKRlRrQU1MMm05bmZoNmpON0crRGU1OTYydC8zSXBYRFZkUUk5ZmtDVXJnPT0KZXlKc2FXTmxibk5sUzJWNUlqb2lNelUyT0Rkak5qRXRNVEU0T1MwME9XTTFMVGc0T1RjdFlqSm1Oemt6TXpsbU9URmxJaXdpZEhsd1pTSTZJbk5wYkhabGNpSXNJbWx6VkhKcFlXd2lPblJ5ZFdVc0ltVjRjR2x5WlVGMElqb3hOemN3TURZeE9UUXhOamM0TENKelpXRjBjeUk2TVRBd01Dd2labVZoZEhWeVpYTWlPbHQ3SW01aGJXVWlPaUp6YzI4aWZTeDdJbTVoYldVaU9pSmpiWE10WVdraUxDSnZjSFJwYjI1eklqcDdJbU55WldScGRITkNZWE5sSWpveE1Dd2lZM0psWkdsMGMwMWhlRlZ6WVdkbElqb3hNSDE5TEhzaWJtRnRaU0k2SW1OdGN5MWpiMjUwWlc1MExXaHBjM1J2Y25raUxDSnZjSFJwYjI1eklqcDdJbkpsZEdWdWRHbHZia1JoZVhNaU9qTXdmWDBzZXlKdVlXMWxJam9pWTIxekxXRmtkbUZ1WTJWa0xYQnlaWFpwWlhjaWZTeDdJbTVoYldVaU9pSmpiWE10WTI5dWRHVnVkQzF5Wld4bFlYTmxjeUlzSW05d2RHbHZibk1pT25zaWJXRjRhVzExYlZKbGJHVmhjMlZ6SWpvNU9UazVPVGw5ZlYwc0ltTjFjM1J2YldWeVNXUWlPaUpCZWxwYVMycFdPVE52ZG1Kb01uRjJkeUlzSW5OMVluTmpjbWx3ZEdsdmJrbGtJam9pUVhweFYzVmxWamt6YjNweFF6SnhNREFpTENKd2JHRnVVSEpwWTJWSlpDSTZJbWR5YjNkMGFDMXpjMjh0WTJ4cExYWXlMVlZUUkMxTmIyNTBhR3g1SW4wPQ=="}	\N	\N	\N
84	plugin_content_manager_configuration_content_types::api::industries-page.industries-page	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"heroTitle","defaultSortBy":"heroTitle","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"heroTitle":{"edit":{"label":"heroTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroTitle","searchable":true,"sortable":true}},"heroSubtitle":{"edit":{"label":"heroSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"heroSubtitle","searchable":true,"sortable":true}},"statsTitle":{"edit":{"label":"statsTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"statsTitle","searchable":true,"sortable":true}},"ctaTitle":{"edit":{"label":"ctaTitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaTitle","searchable":true,"sortable":true}},"ctaSubtitle":{"edit":{"label":"ctaSubtitle","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaSubtitle","searchable":true,"sortable":true}},"ctaButton":{"edit":{"label":"ctaButton","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"ctaButton","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","heroTitle","heroSubtitle","statsTitle"],"edit":[[{"name":"heroTitle","size":6},{"name":"heroSubtitle","size":6}],[{"name":"statsTitle","size":6},{"name":"ctaTitle","size":6}],[{"name":"ctaSubtitle","size":6},{"name":"ctaButton","size":6}]]},"uid":"api::industries-page.industries-page"}	object	\N	\N
74	plugin_content_manager_configuration_content_types::api::stat.stat	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"value","defaultSortBy":"value","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"value":{"edit":{"label":"value","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"value","searchable":true,"sortable":true}},"label":{"edit":{"label":"label","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"label","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","value","label","order"],"edit":[[{"name":"value","size":6},{"name":"label","size":6}],[{"name":"order","size":4}]]},"uid":"api::stat.stat"}	object	\N	\N
76	plugin_content_manager_configuration_content_types::api::trusted-company.trusted-company	{"settings":{"bulkable":true,"filterable":true,"searchable":true,"pageSize":10,"mainField":"name","defaultSortBy":"name","defaultSortOrder":"ASC"},"metadatas":{"id":{"edit":{},"list":{"label":"id","searchable":true,"sortable":true}},"name":{"edit":{"label":"name","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"name","searchable":true,"sortable":true}},"logo":{"edit":{"label":"logo","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"logo","searchable":true,"sortable":true}},"website":{"edit":{"label":"website","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"website","searchable":true,"sortable":true}},"order":{"edit":{"label":"order","description":"","placeholder":"","visible":true,"editable":true},"list":{"label":"order","searchable":true,"sortable":true}},"createdAt":{"edit":{"label":"createdAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"createdAt","searchable":true,"sortable":true}},"updatedAt":{"edit":{"label":"updatedAt","description":"","placeholder":"","visible":false,"editable":true},"list":{"label":"updatedAt","searchable":true,"sortable":true}},"createdBy":{"edit":{"label":"createdBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"createdBy","searchable":true,"sortable":true}},"updatedBy":{"edit":{"label":"updatedBy","description":"","placeholder":"","visible":false,"editable":true,"mainField":"firstname"},"list":{"label":"updatedBy","searchable":true,"sortable":true}},"documentId":{"edit":{},"list":{"label":"documentId","searchable":true,"sortable":true}}},"layouts":{"list":["id","name","logo","website"],"edit":[[{"name":"name","size":6},{"name":"logo","size":6}],[{"name":"website","size":6},{"name":"order","size":4}]]},"uid":"api::trusted-company.trusted-company"}	object	\N	\N
\.


--
-- TOC entry 3913 (class 0 OID 106009)
-- Dependencies: 220
-- Data for Name: strapi_database_schema; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_database_schema (id, schema, "time", hash) FROM stdin;
51	{"tables":[{"name":"files","indexes":[{"name":"upload_files_folder_path_index","columns":["folder_path"],"type":null},{"name":"upload_files_created_at_index","columns":["created_at"],"type":null},{"name":"upload_files_updated_at_index","columns":["updated_at"],"type":null},{"name":"upload_files_name_index","columns":["name"],"type":null},{"name":"upload_files_size_index","columns":["size"],"type":null},{"name":"upload_files_ext_index","columns":["ext"],"type":null},{"name":"files_documents_idx","columns":["document_id","locale","published_at"]},{"name":"files_created_by_id_fk","columns":["created_by_id"]},{"name":"files_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"files_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"files_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"alternative_text","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"caption","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"width","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"height","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"formats","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"hash","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"ext","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"mime","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"size","type":"decimal","args":[10,2],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"preview_url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider_metadata","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"folder_path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"upload_folders","indexes":[{"name":"upload_folders_path_id_index","columns":["path_id"],"type":"unique"},{"name":"upload_folders_path_index","columns":["path"],"type":"unique"},{"name":"upload_folders_documents_idx","columns":["document_id","locale","published_at"]},{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"]},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"upload_folders_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"upload_folders_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"path","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"i18n_locale","indexes":[{"name":"i18n_locale_documents_idx","columns":["document_id","locale","published_at"]},{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"]},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"i18n_locale_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"i18n_locale_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_releases","indexes":[{"name":"strapi_releases_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_releases_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_releases_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"released_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"scheduled_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"timezone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_release_actions","indexes":[{"name":"strapi_release_actions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_release_actions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_release_actions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"entry_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_entry_valid","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows","indexes":[{"name":"strapi_workflows_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"content_types","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_workflows_stages","indexes":[{"name":"strapi_workflows_stages_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_workflows_stages_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_workflows_stages_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"color","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_permissions","indexes":[{"name":"up_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_roles","indexes":[{"name":"up_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"up_users","indexes":[{"name":"up_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"up_users_created_by_id_fk","columns":["created_by_id"]},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"up_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"up_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"provider","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"display_name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"phone","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"country","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"company","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"account_status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"sales_contact_allowed","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"confirmation_token_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_login","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_permissions","indexes":[{"name":"admin_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action_parameters","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"subject","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"properties","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"conditions","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_users","indexes":[{"name":"admin_users_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_users_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_users_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_users_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"firstname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lastname","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"username","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"email","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"password","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"reset_password_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"registration_token","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"is_active","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"blocked","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"prefered_language","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"admin_roles","indexes":[{"name":"admin_roles_documents_idx","columns":["document_id","locale","published_at"]},{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"]},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"admin_roles_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"admin_roles_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"code","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_tokens","indexes":[{"name":"strapi_api_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"encrypted_key","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_api_token_permissions","indexes":[{"name":"strapi_api_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_api_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_tokens","indexes":[{"name":"strapi_transfer_tokens_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_tokens_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_tokens_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"description","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"access_key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"last_used_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"lifespan","type":"bigInteger","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_transfer_token_permissions","indexes":[{"name":"strapi_transfer_token_permissions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_transfer_token_permissions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_sessions","indexes":[{"name":"strapi_sessions_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_sessions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_sessions_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"user_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"session_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"child_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"device_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"origin","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"absolute_expires_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_audit_logs","indexes":[{"name":"strapi_audit_logs_documents_idx","columns":["document_id","locale","published_at"]},{"name":"strapi_audit_logs_created_by_id_fk","columns":["created_by_id"]},{"name":"strapi_audit_logs_updated_by_id_fk","columns":["updated_by_id"]}],"foreignKeys":[{"name":"strapi_audit_logs_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"},{"name":"strapi_audit_logs_updated_by_id_fk","columns":["updated_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"action","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"date","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"payload","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"published_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"updated_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_core_store_settings","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"key","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"value","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"environment","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"tag","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_webhooks","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"name","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"url","type":"text","args":["longtext"],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"headers","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"events","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"enabled","type":"boolean","args":[],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"strapi_history_versions","indexes":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"]}],"foreignKeys":[{"name":"strapi_history_versions_created_by_id_fk","columns":["created_by_id"],"referencedTable":"admin_users","referencedColumns":["id"],"onDelete":"SET NULL"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"locale","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"data","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"schema","type":"jsonb","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"created_by_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_ai_localization_jobs","indexes":[],"foreignKeys":[],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"content_type","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"related_document_id","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"source_locale","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"target_locales","type":"jsonb","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"status","type":"string","args":[],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"created_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"updated_at","type":"datetime","args":[{"useTz":false,"precision":6}],"defaultTo":null,"notNullable":false,"unsigned":false}]},{"name":"files_related_mph","indexes":[{"name":"files_related_mph_fk","columns":["file_id"]},{"name":"files_related_mph_oidx","columns":["order"]},{"name":"files_related_mph_idix","columns":["related_id"]}],"foreignKeys":[{"name":"files_related_mph_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"related_type","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"field","type":"string","args":[],"defaultTo":null,"notNullable":false,"unsigned":false},{"name":"order","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"files_folder_lnk","indexes":[{"name":"files_folder_lnk_fk","columns":["file_id"]},{"name":"files_folder_lnk_ifk","columns":["folder_id"]},{"name":"files_folder_lnk_uq","columns":["file_id","folder_id"],"type":"unique"},{"name":"files_folder_lnk_oifk","columns":["file_ord"]}],"foreignKeys":[{"name":"files_folder_lnk_fk","columns":["file_id"],"referencedColumns":["id"],"referencedTable":"files","onDelete":"CASCADE"},{"name":"files_folder_lnk_ifk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"file_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"file_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"upload_folders_parent_lnk","indexes":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"]},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"]},{"name":"upload_folders_parent_lnk_uq","columns":["folder_id","inv_folder_id"],"type":"unique"},{"name":"upload_folders_parent_lnk_oifk","columns":["folder_ord"]}],"foreignKeys":[{"name":"upload_folders_parent_lnk_fk","columns":["folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"},{"name":"upload_folders_parent_lnk_ifk","columns":["inv_folder_id"],"referencedColumns":["id"],"referencedTable":"upload_folders","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"inv_folder_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"folder_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_release_actions_release_lnk","indexes":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"]},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"]},{"name":"strapi_release_actions_release_lnk_uq","columns":["release_action_id","release_id"],"type":"unique"},{"name":"strapi_release_actions_release_lnk_oifk","columns":["release_action_ord"]}],"foreignKeys":[{"name":"strapi_release_actions_release_lnk_fk","columns":["release_action_id"],"referencedColumns":["id"],"referencedTable":"strapi_release_actions","onDelete":"CASCADE"},{"name":"strapi_release_actions_release_lnk_ifk","columns":["release_id"],"referencedColumns":["id"],"referencedTable":"strapi_releases","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"release_action_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"release_action_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stage_required_to_publish_lnk","indexes":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stage_required_to_publish_lnk_uq","columns":["workflow_id","workflow_stage_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_workflows_stage_required_to_publish_lnk_fk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"},{"name":"strapi_workflows_stage_required_to_publish_lnk_ifk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_workflow_lnk","indexes":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"]},{"name":"strapi_workflows_stages_workflow_lnk_uq","columns":["workflow_stage_id","workflow_id"],"type":"unique"},{"name":"strapi_workflows_stages_workflow_lnk_oifk","columns":["workflow_stage_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_workflow_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_workflow_lnk_ifk","columns":["workflow_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"workflow_stage_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_workflows_stages_permissions_lnk","indexes":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"]},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"]},{"name":"strapi_workflows_stages_permissions_lnk_uq","columns":["workflow_stage_id","permission_id"],"type":"unique"},{"name":"strapi_workflows_stages_permissions_lnk_ofk","columns":["permission_ord"]}],"foreignKeys":[{"name":"strapi_workflows_stages_permissions_lnk_fk","columns":["workflow_stage_id"],"referencedColumns":["id"],"referencedTable":"strapi_workflows_stages","onDelete":"CASCADE"},{"name":"strapi_workflows_stages_permissions_lnk_ifk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"workflow_stage_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_permissions_role_lnk","indexes":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"up_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"up_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"up_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"up_permissions","onDelete":"CASCADE"},{"name":"up_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"up_users_role_lnk","indexes":[{"name":"up_users_role_lnk_fk","columns":["user_id"]},{"name":"up_users_role_lnk_ifk","columns":["role_id"]},{"name":"up_users_role_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"up_users_role_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"up_users_role_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"up_users","onDelete":"CASCADE"},{"name":"up_users_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"up_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_permissions_role_lnk","indexes":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"]},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"]},{"name":"admin_permissions_role_lnk_uq","columns":["permission_id","role_id"],"type":"unique"},{"name":"admin_permissions_role_lnk_oifk","columns":["permission_ord"]}],"foreignKeys":[{"name":"admin_permissions_role_lnk_fk","columns":["permission_id"],"referencedColumns":["id"],"referencedTable":"admin_permissions","onDelete":"CASCADE"},{"name":"admin_permissions_role_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"admin_users_roles_lnk","indexes":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"]},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"]},{"name":"admin_users_roles_lnk_uq","columns":["user_id","role_id"],"type":"unique"},{"name":"admin_users_roles_lnk_ofk","columns":["role_ord"]},{"name":"admin_users_roles_lnk_oifk","columns":["user_ord"]}],"foreignKeys":[{"name":"admin_users_roles_lnk_fk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"},{"name":"admin_users_roles_lnk_ifk","columns":["role_id"],"referencedColumns":["id"],"referencedTable":"admin_roles","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"role_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_api_token_permissions_token_lnk","indexes":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"]},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"]},{"name":"strapi_api_token_permissions_token_lnk_uq","columns":["api_token_permission_id","api_token_id"],"type":"unique"},{"name":"strapi_api_token_permissions_token_lnk_oifk","columns":["api_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_api_token_permissions_token_lnk_fk","columns":["api_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_token_permissions","onDelete":"CASCADE"},{"name":"strapi_api_token_permissions_token_lnk_ifk","columns":["api_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_api_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"api_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"api_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_transfer_token_permissions_token_lnk","indexes":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"]},{"name":"strapi_transfer_token_permissions_token_lnk_uq","columns":["transfer_token_permission_id","transfer_token_id"],"type":"unique"},{"name":"strapi_transfer_token_permissions_token_lnk_oifk","columns":["transfer_token_permission_ord"]}],"foreignKeys":[{"name":"strapi_transfer_token_permissions_token_lnk_fk","columns":["transfer_token_permission_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_token_permissions","onDelete":"CASCADE"},{"name":"strapi_transfer_token_permissions_token_lnk_ifk","columns":["transfer_token_id"],"referencedColumns":["id"],"referencedTable":"strapi_transfer_tokens","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"transfer_token_permission_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"transfer_token_permission_ord","type":"double","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]},{"name":"strapi_audit_logs_user_lnk","indexes":[{"name":"strapi_audit_logs_user_lnk_fk","columns":["audit_log_id"]},{"name":"strapi_audit_logs_user_lnk_ifk","columns":["user_id"]},{"name":"strapi_audit_logs_user_lnk_uq","columns":["audit_log_id","user_id"],"type":"unique"}],"foreignKeys":[{"name":"strapi_audit_logs_user_lnk_fk","columns":["audit_log_id"],"referencedColumns":["id"],"referencedTable":"strapi_audit_logs","onDelete":"CASCADE"},{"name":"strapi_audit_logs_user_lnk_ifk","columns":["user_id"],"referencedColumns":["id"],"referencedTable":"admin_users","onDelete":"CASCADE"}],"columns":[{"name":"id","type":"increments","args":[{"primary":true,"primaryKey":true}],"defaultTo":null,"notNullable":true,"unsigned":false},{"name":"audit_log_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true},{"name":"user_id","type":"integer","args":[],"defaultTo":null,"notNullable":false,"unsigned":true}]}]}	2026-01-31 21:52:19.728	3152205ae66157c345e111afca2f3a3e15ccd0699365cafa152e9ea38c752b33
\.


--
-- TOC entry 3957 (class 0 OID 106274)
-- Dependencies: 264
-- Data for Name: strapi_history_versions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_history_versions (id, content_type, related_document_id, locale, status, data, schema, created_at, created_by_id) FROM stdin;
\.


--
-- TOC entry 3909 (class 0 OID 105995)
-- Dependencies: 216
-- Data for Name: strapi_migrations; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_migrations (id, name, "time") FROM stdin;
\.


--
-- TOC entry 3911 (class 0 OID 106002)
-- Dependencies: 218
-- Data for Name: strapi_migrations_internal; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_migrations_internal (id, name, "time") FROM stdin;
1	5.0.0-rename-identifiers-longer-than-max-length	2026-01-29 17:06:04.732
2	5.0.0-02-created-document-id	2026-01-29 17:06:04.761
3	5.0.0-03-created-locale	2026-01-29 17:06:04.784
4	5.0.0-04-created-published-at	2026-01-29 17:06:04.809
5	5.0.0-05-drop-slug-fields-index	2026-01-29 17:06:04.831
6	core::5.0.0-discard-drafts	2026-01-29 17:06:04.854
7	content-releases::5.0.0-add-entry-document-id-to-release-actions	2026-01-29 17:06:04.862
\.


--
-- TOC entry 3923 (class 0 OID 106076)
-- Dependencies: 230
-- Data for Name: strapi_release_actions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_release_actions (id, document_id, type, content_type, entry_document_id, locale, is_entry_valid, created_at, updated_at, published_at, created_by_id, updated_by_id) FROM stdin;
\.


--
-- TOC entry 3967 (class 0 OID 106329)
-- Dependencies: 274
-- Data for Name: strapi_release_actions_release_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_release_actions_release_lnk (id, release_action_id, release_id, release_action_ord) FROM stdin;
\.


--
-- TOC entry 3921 (class 0 OID 106064)
-- Dependencies: 228
-- Data for Name: strapi_releases; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_releases (id, document_id, name, released_at, scheduled_at, timezone, status, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3949 (class 0 OID 106232)
-- Dependencies: 256
-- Data for Name: strapi_sessions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_sessions (id, document_id, user_id, session_id, child_id, device_id, origin, expires_at, absolute_expires_at, status, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	onj2no8yp1by71n5x6kypz71	1	34f2d98e55538a1c6c40506a4ded1aca	\N	3f3aa7d3-da50-4035-80c1-c196542276e5	admin	2026-01-29 19:09:23.216	2026-02-28 17:09:23.216	active	session	2026-01-29 17:09:23.216	2026-01-29 17:09:23.216	2026-01-29 17:09:23.217	\N	\N	\N
2	b3j2sjs1fhmppnzzun167leq	1	a2755321270d0b38bdc6de61d79ee3d7	\N	1fe7d24d-1931-45ef-92df-5265fdb0e526	admin	2026-01-29 19:10:21.206	2026-02-28 17:10:21.206	active	session	2026-01-29 17:10:21.206	2026-01-29 17:10:21.206	2026-01-29 17:10:21.206	\N	\N	\N
3	namifktb98skfsf3xln1l5i9	1	d8d53c76552a3d0e30ad7182c9e4a229	\N	de473add-67e4-4a69-b3b4-767a361a871a	admin	2026-01-29 19:53:36.454	2026-02-28 17:53:36.454	active	session	2026-01-29 17:53:36.454	2026-01-29 17:53:36.454	2026-01-29 17:53:36.455	\N	\N	\N
4	zdjf1qfznw3nshpbqsn0yqx4	1	76d0714dff10d9a578089fbf612d1986	\N	2f0dfce9-3659-4f20-b13c-8778ec7972b6	admin	2026-01-29 19:54:09.012	2026-02-28 17:54:09.012	active	session	2026-01-29 17:54:09.012	2026-01-29 17:54:09.012	2026-01-29 17:54:09.013	\N	\N	\N
6	dj7hyqf2baafwmx641fqaxi3	1	b4acc3014741cfd866cbd5eefa8a1593	\N	f30c5aed-438c-4066-be91-c78a52617203	admin	2026-01-29 20:04:56.067	2026-02-28 18:04:56.067	active	session	2026-01-29 18:04:56.067	2026-01-29 18:04:56.067	2026-01-29 18:04:56.068	\N	\N	\N
7	c31g4nalroipqthutb775uw9	1	078194c5532355b87087a6ee9429e690	\N	308bb0e6-d585-454a-9119-d63a14fa67fe	admin	2026-01-29 20:17:54.232	2026-02-28 18:17:54.232	active	session	2026-01-29 18:17:54.232	2026-01-29 18:17:54.232	2026-01-29 18:17:54.232	\N	\N	\N
8	oie9orwa4em4jzg1nkllaugq	1	07d61444bb0cb19bb001a23fce6e60d3	\N	8e7aac5e-b1ce-4169-b804-a9669e11a94d	admin	2026-01-29 20:18:03.502	2026-02-28 18:18:03.502	active	session	2026-01-29 18:18:03.502	2026-01-29 18:18:03.502	2026-01-29 18:18:03.502	\N	\N	\N
9	c0xlstizwr1ru5xf3ve1twz7	1	5160c929477ac4d59bc3a8037a834d95	\N	77fc3888-42da-40f2-8a41-87c78c55342d	admin	2026-01-29 20:26:09.033	2026-02-28 18:26:09.033	active	session	2026-01-29 18:26:09.033	2026-01-29 18:26:09.033	2026-01-29 18:26:09.033	\N	\N	\N
10	vx3snf5c0wwshb8cbm55z79e	1	e20c412d00156c28fd8882a5012e4696	\N	1852e675-18f7-4c14-94ff-bfaaaef65272	admin	2026-01-29 20:26:30.372	2026-02-28 18:26:30.372	active	session	2026-01-29 18:26:30.372	2026-01-29 18:26:30.372	2026-01-29 18:26:30.372	\N	\N	\N
11	zwiszefrslqllzme5a6iedjr	1	3b2d9583bedf9f372901b50818af5873	\N	b36b097a-c034-4600-889b-392164ccf9b8	admin	2026-01-29 20:27:10.304	2026-02-28 18:27:10.304	active	session	2026-01-29 18:27:10.304	2026-01-29 18:27:10.304	2026-01-29 18:27:10.304	\N	\N	\N
12	jxb5s2imqvaxc1korgp62c6m	1	bad351c4edf674a33a9dfe1221056996	\N	56835123-b9fb-4114-9789-cabba2a3133a	admin	2026-01-29 20:27:28.29	2026-02-28 18:27:28.29	active	session	2026-01-29 18:27:28.29	2026-01-29 18:27:28.29	2026-01-29 18:27:28.29	\N	\N	\N
13	f5uhza342sxfg7ico7oe7ua8	1	ca04776f30c6c3c9a6529f5f7a95c421	\N	1f73756e-1b3a-41f1-a562-c280ac6d303d	admin	2026-01-29 20:33:05.536	2026-02-28 18:33:05.536	active	session	2026-01-29 18:33:05.536	2026-01-29 18:33:05.536	2026-01-29 18:33:05.536	\N	\N	\N
14	eqjh72vn7mz8uhagn5n4uxfh	1	ec594be000ce2d09facf3a46cf91f219	\N	f529b411-aca5-4406-b8a0-fb35fcd73156	admin	2026-01-29 20:37:27.807	2026-02-28 18:37:27.807	active	session	2026-01-29 18:37:27.807	2026-01-29 18:37:27.807	2026-01-29 18:37:27.807	\N	\N	\N
5	lb4hb40zckxa6v9vxa6im9ja	1	78a7878d3b28c8e61fbe1fef922378f0	1e9055334f19b6691f2e3b73df7caa79	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-12 18:01:26.784	2026-02-28 18:01:26.784	rotated	refresh	2026-01-29 18:01:26.784	2026-01-29 18:41:48.805	2026-01-29 18:01:26.784	\N	\N	\N
15	k5bwww36otrraoncqniv3lf0	1	1e9055334f19b6691f2e3b73df7caa79	501a0aef5a2bef0280966f244b294b92	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-12 18:41:48.793	2026-02-28 18:01:26.784	rotated	refresh	2026-01-29 18:41:48.793	2026-01-30 11:34:52.014	2026-01-29 18:41:48.795	\N	\N	\N
17	rq3ifjqpzni6vucde1w187hh	1	83a10bc7fc537b46346c81f08ff0ff48	\N	42aa97d0-d17e-4be9-aa40-109b75159070	admin	2026-01-30 13:54:34.693	2026-03-01 11:54:34.693	active	session	2026-01-30 11:54:34.693	2026-01-30 11:54:34.693	2026-01-30 11:54:34.694	\N	\N	\N
18	yu1hv8g27urx0uaq24e7jpjt	1	fad36c4a8f08d453773dd01371aefead	\N	8ff3a8ce-22ac-4568-99bc-7ea3706c2293	admin	2026-01-30 13:54:42.766	2026-03-01 11:54:42.766	active	session	2026-01-30 11:54:42.766	2026-01-30 11:54:42.766	2026-01-30 11:54:42.767	\N	\N	\N
19	dfft2ih34f1fhp54izi1mwpg	1	4863d0a5b3412b902971c1c699a3d50e	\N	7c8b90a5-bd98-457b-8f14-924d88fac190	admin	2026-01-30 13:56:10.732	2026-03-01 11:56:10.732	active	session	2026-01-30 11:56:10.732	2026-01-30 11:56:10.732	2026-01-30 11:56:10.733	\N	\N	\N
16	m2kxvusuh4m2s0mbsp5sovoq	1	501a0aef5a2bef0280966f244b294b92	e5bfff3826d0122e0042ac5957127797	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 11:34:52	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 11:34:52.001	2026-01-30 12:09:22.733	2026-01-30 11:34:52.002	\N	\N	\N
20	cvg4cg6hh3p9c0rc3asriwi8	1	e5bfff3826d0122e0042ac5957127797	4ec3a0061c2a678476d3900ee952033c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 12:09:22.712	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 12:09:22.712	2026-01-30 13:20:28.262	2026-01-30 12:09:22.713	\N	\N	\N
21	w709nfabu5bkd0w5t9geekbz	1	4ec3a0061c2a678476d3900ee952033c	14ca561cf7344ed7eae1dd50fdb7f97c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 13:20:28.252	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 13:20:28.253	2026-01-30 13:52:18.43	2026-01-30 13:20:28.254	\N	\N	\N
22	e05lrw3wg4qx87pf7k6fzf2e	1	14ca561cf7344ed7eae1dd50fdb7f97c	3c1f2a75865b538f87f4efafc05ca13c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 13:52:18.414	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 13:52:18.414	2026-01-30 15:18:53.28	2026-01-30 13:52:18.415	\N	\N	\N
23	zf0sgo1jba581vo47w9zfj3s	1	3c1f2a75865b538f87f4efafc05ca13c	5f57577348a073edcce1649e57828423	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 15:18:53.269	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 15:18:53.27	2026-01-30 15:52:20.072	2026-01-30 15:18:53.27	\N	\N	\N
24	jd6051c3mhdeornouq1lvply	1	5f57577348a073edcce1649e57828423	93ba33a054bae4ea10013d533e9e76bf	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 15:52:20.06	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 15:52:20.06	2026-01-30 18:08:04.721	2026-01-30 15:52:20.06	\N	\N	\N
25	ni092tn3mr6cz3u02n4yv7et	1	93ba33a054bae4ea10013d533e9e76bf	6671df8f375f9a2184452cc5bb7ea50c	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 18:08:04.711	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 18:08:04.711	2026-01-30 18:58:45.702	2026-01-30 18:08:04.712	\N	\N	\N
26	ok9a36lkj75j2a84j7mbhbna	1	6671df8f375f9a2184452cc5bb7ea50c	42bb0969f028a6853b358e0dc6131134	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-13 18:58:45.689	2026-02-28 18:01:26.784	rotated	refresh	2026-01-30 18:58:45.689	2026-01-31 00:47:58.016	2026-01-30 18:58:45.69	\N	\N	\N
27	e2086l8df154pzhn1aocru6k	1	42bb0969f028a6853b358e0dc6131134	57717525871ed357354d886ec904cb0e	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 00:47:57.993	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 00:47:57.993	2026-01-31 11:49:00.684	2026-01-31 00:47:57.995	\N	\N	\N
28	fz0x2ooptjibj2dil85c8npt	1	57717525871ed357354d886ec904cb0e	a2c1f4641b5867ed0531176ecfdb8e46	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 11:49:00.672	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 11:49:00.673	2026-01-31 12:30:22.644	2026-01-31 11:49:00.673	\N	\N	\N
29	bf4vpkr0yxa8qkg6vmh45kej	1	a2c1f4641b5867ed0531176ecfdb8e46	93b229634642f932fa76d1be2aa4c1d4	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 12:30:22.635	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 12:30:22.636	2026-01-31 13:01:42.74	2026-01-31 12:30:22.637	\N	\N	\N
30	z8p1295b005emnjhfaestxww	1	93b229634642f932fa76d1be2aa4c1d4	e627559a6108c9b069ea185b7798bb1b	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 13:01:42.705	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 13:01:42.705	2026-01-31 13:57:44.102	2026-01-31 13:01:42.706	\N	\N	\N
31	vpxudoxrewboqm2axschlwdx	1	e627559a6108c9b069ea185b7798bb1b	ef374e7863612f79d195f4788e7047f4	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 13:57:44.093	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 13:57:44.093	2026-01-31 14:34:37.127	2026-01-31 13:57:44.094	\N	\N	\N
32	rwptzxjhje28x6jh0wnsn1l9	1	ef374e7863612f79d195f4788e7047f4	1844d0fb554b3b3033d662bb2de36bcc	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 14:34:37.111	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 14:34:37.111	2026-01-31 15:10:52.143	2026-01-31 14:34:37.112	\N	\N	\N
34	n4dc91vs4e3o1v16n47jqb3l	1	9cac5217d8701cf0c953905fe88c119e	\N	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 21:27:23.574	2026-02-28 18:01:26.784	active	refresh	2026-01-31 21:27:23.575	2026-01-31 21:27:23.575	2026-01-31 21:27:23.575	\N	\N	\N
33	odbjhno85itxd8m9ubraljtm	1	1844d0fb554b3b3033d662bb2de36bcc	9cac5217d8701cf0c953905fe88c119e	5170c3c9-fa2a-49f0-9d71-aef6242aa1dc	admin	2026-02-14 15:10:52.126	2026-02-28 18:01:26.784	rotated	refresh	2026-01-31 15:10:52.126	2026-01-31 21:27:23.589	2026-01-31 15:10:52.126	\N	\N	\N
\.


--
-- TOC entry 3947 (class 0 OID 106220)
-- Dependencies: 254
-- Data for Name: strapi_transfer_token_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_token_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3985 (class 0 OID 106437)
-- Dependencies: 292
-- Data for Name: strapi_transfer_token_permissions_token_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_token_permissions_token_lnk (id, transfer_token_permission_id, transfer_token_id, transfer_token_permission_ord) FROM stdin;
\.


--
-- TOC entry 3945 (class 0 OID 106208)
-- Dependencies: 252
-- Data for Name: strapi_transfer_tokens; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_transfer_tokens (id, document_id, name, description, access_key, last_used_at, expires_at, lifespan, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3955 (class 0 OID 106265)
-- Dependencies: 262
-- Data for Name: strapi_webhooks; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_webhooks (id, name, url, headers, events, enabled) FROM stdin;
\.


--
-- TOC entry 3925 (class 0 OID 106088)
-- Dependencies: 232
-- Data for Name: strapi_workflows; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows (id, document_id, name, content_types, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3969 (class 0 OID 106341)
-- Dependencies: 276
-- Data for Name: strapi_workflows_stage_required_to_publish_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stage_required_to_publish_lnk (id, workflow_id, workflow_stage_id) FROM stdin;
\.


--
-- TOC entry 3927 (class 0 OID 106100)
-- Dependencies: 234
-- Data for Name: strapi_workflows_stages; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages (id, document_id, name, color, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3973 (class 0 OID 106364)
-- Dependencies: 280
-- Data for Name: strapi_workflows_stages_permissions_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages_permissions_lnk (id, workflow_stage_id, permission_id, permission_ord) FROM stdin;
\.


--
-- TOC entry 3971 (class 0 OID 106352)
-- Dependencies: 278
-- Data for Name: strapi_workflows_stages_workflow_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.strapi_workflows_stages_workflow_lnk (id, workflow_stage_id, workflow_id, workflow_stage_ord) FROM stdin;
\.


--
-- TOC entry 3929 (class 0 OID 106112)
-- Dependencies: 236
-- Data for Name: up_permissions; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_permissions (id, document_id, action, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	ghysqdwedlr6utz9jq3v003q	plugin::users-permissions.auth.logout	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
2	ogmyoaahvw9y1vk392n9cyje	plugin::users-permissions.user.me	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
3	pvgqddrlka4wvvdriorn7ry2	plugin::users-permissions.auth.changePassword	2026-01-29 17:06:07.689	2026-01-29 17:06:07.689	2026-01-29 17:06:07.69	\N	\N	\N
4	gpp396rtmiogbywcrsey6919	plugin::users-permissions.auth.callback	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
5	kc3p4nb898hqr60mojg0se5g	plugin::users-permissions.auth.connect	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
6	bjwy4y9j5hgcocjj3zwuk4vu	plugin::users-permissions.auth.forgotPassword	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
7	hdy7pbqddmrg3ev0w8xgb0eb	plugin::users-permissions.auth.register	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
8	eriy2nc5mwj79o96oo80f4po	plugin::users-permissions.auth.resetPassword	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
9	vwxo66oep47ym1tl48n5n8dr	plugin::users-permissions.auth.sendEmailConfirmation	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
11	ke6ky8fmeasu2878bki1wf4t	plugin::users-permissions.auth.refresh	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
10	x3c57n62aboqgkw7h1855vpg	plugin::users-permissions.auth.emailConfirmation	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	2026-01-29 17:06:07.707	\N	\N	\N
16	\N	api::custom-auth.custom-auth.me	2026-01-30 18:52:07.755782	2026-01-30 18:52:07.755782	\N	\N	\N	\N
15	0c4a4009b1018e503a9d8b4882e12a38	api::site-setting.site-setting.find	2026-01-29 18:22:23.304281	2026-01-31 21:47:43.708	\N	\N	\N	\N
14	a313abcf5771954c6b1926023eb86744	api::nav-item.nav-item.find	2026-01-29 18:22:23.304281	2026-01-31 21:47:43.714	\N	\N	\N	\N
12	6f264cc116e845cd196b2d56a47d0519	api::nav-item.nav-item.findOne	2026-01-29 18:22:23.304281	2026-01-31 21:47:43.719	\N	\N	\N	\N
\.


--
-- TOC entry 3975 (class 0 OID 106376)
-- Dependencies: 282
-- Data for Name: up_permissions_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_permissions_role_lnk (id, permission_id, role_id, permission_ord) FROM stdin;
1	1	1	1
2	3	1	1
3	2	1	1
4	4	2	1
5	5	2	1
6	10	2	1
7	6	2	1
8	11	2	1
9	8	2	2
10	9	2	2
11	7	2	2
12	12	2	\N
14	14	2	\N
15	15	2	\N
16	2	3	1
17	16	3	1
\.


--
-- TOC entry 3931 (class 0 OID 106124)
-- Dependencies: 238
-- Data for Name: up_roles; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_roles (id, document_id, name, description, type, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
1	sfhvqo48zt7cytfh10bgye82	Authenticated	Default role given to authenticated user.	authenticated	2026-01-29 17:06:07.674	2026-01-29 17:06:07.674	2026-01-29 17:06:07.674	\N	\N	\N
2	e03sz2xsq6v3p4rernfq818x	Public	Default role given to unauthenticated user.	public	2026-01-29 17:06:07.681	2026-01-29 17:06:07.681	2026-01-29 17:06:07.681	\N	\N	\N
3	b3zab4fbk17fc7h48b291rim	Potential Customer	New users awaiting approval, limited access to public content	potential-customer	2026-01-29 17:06:08.708	2026-01-29 17:06:08.708	2026-01-29 17:06:08.708	\N	\N	\N
4	oe2snc6ib3wi33d2zumi84ny	Client	Approved clients with access to premium demos and content	client	2026-01-29 17:06:08.715	2026-01-29 17:06:08.715	2026-01-29 17:06:08.715	\N	\N	\N
5	yyakiogp1s54z4ep27me2kav	Premium	Premium tier clients with full access to all demos	premium	2026-01-29 17:06:08.72	2026-01-29 17:06:08.72	2026-01-29 17:06:08.72	\N	\N	\N
\.


--
-- TOC entry 3933 (class 0 OID 106136)
-- Dependencies: 240
-- Data for Name: up_users; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_users (id, document_id, username, email, provider, password, reset_password_token, confirmation_token, confirmed, blocked, created_at, updated_at, published_at, created_by_id, updated_by_id, locale, phone, country, company, sales_contact_allowed, display_name, account_status, last_login, confirmation_token_expires_at) FROM stdin;
1	oufwhzowb8b131uhieo40htg	test999	test999@example.com	local	$2a$10$NOcTyuOKaD68dGwIDDw2rODET4DYzRU1zBDkUCVlrw0iKgXYbrRNW	\N	\N	t	f	2026-01-30 17:30:19.152	2026-01-30 17:30:19.152	2026-01-30 17:30:19.152	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
2	vbbtnq637bjf9v1bq8ibev3e	newuser123	newuser123@example.com	local	$2a$10$bFdwB.s.90MXQDn4RtD/C.dFLDPkCa3kayRZXwkMMfYTZcrSqD5ZG	\N	\N	t	f	2026-01-30 17:33:01.964	2026-01-30 17:33:01.964	2026-01-30 17:33:01.965	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
3	k7oihcgku3xpxvhd37rkz2qp	anotheruser	another@example.com	local	$2a$10$zDg3H60dNxN1Lhjdmdhpd.wBkwU.SNCHtmi4E0PMKyIWu.2F.hLu2	\N	\N	t	f	2026-01-30 17:33:27.673	2026-01-30 17:33:27.673	2026-01-30 17:33:27.673	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
4	arkyzihwtdmv3uri10dq2eds	fulluser	fulluser@example.com	local	$2a$10$3YXGbdXeHZMyUWchfqddL.wVBWESeRPeImP2sEVyRIQkL6Jv3zZtu	\N	\N	t	f	2026-01-30 17:33:48.076	2026-01-30 17:33:48.076	2026-01-30 17:33:48.076	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
5	qynjxi8eh9u7qml7cgolvncv	phoneuser	phoneuser@example.com	local	$2a$10$wrWitXLSgCsDMzhIhyy78ewkH526EPoQhxsTXqwm.zbHAJCh84YnW	\N	\N	t	f	2026-01-30 17:37:41.136	2026-01-30 17:37:41.149	2026-01-30 17:37:41.137	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
6	bswy8gikl06vfdqo6joq9qz8	finaltest	finaltest@example.com	local	$2a$10$dLMohC67.qVTIDMlb.oQ6et7r4sD79.FeXw7pTsGLmhKZf0Lp0tK6	\N	\N	t	f	2026-01-30 17:39:46.461	2026-01-30 17:39:46.473	2026-01-30 17:39:46.462	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
7	sq2t3u8n0qtnovms7jjz0y7u	testfinal	testfinal@example.com	local	$2a$10$pMlBmtEdXozWHWEOs7PJPunAaTb.U9yTtJ4WfveFNdELkTUCHWyDa	\N	\N	t	f	2026-01-30 17:54:47.151	2026-01-30 17:54:47.165	2026-01-30 17:54:47.151	\N	\N	\N	\N	\N	\N	t	\N	pending	\N	\N
8	dsq21abmwj6iq4k1clz465km	knextest	knextest@example.com	local	$2a$10$guWuFARD1YzMKrlRxm0eiOVPzaNaH0MZRBDuQ.JX5PoAX7NDvpmQS	\N	\N	t	f	2026-01-30 17:58:17.119	2026-01-30 17:58:17.119	2026-01-30 17:58:17.12	\N	\N	\N	+1444444444	Egypt	Knex Co	t	Knex Test	pending	\N	\N
9	kf51r5dzgff6v7yfk04t816r	webtest	webtest@test.com	local	$2a$10$Mj3exdfFdIHKtoa4XsBEt.Z/eMaO9/bfMutXqL4hZEmfKl5/TYKBi	\N	\N	t	f	2026-01-30 18:10:40.183	2026-01-30 18:10:40.183	2026-01-30 18:10:40.184	\N	\N	\N	+20123456789	\N	\N	t	webtest	pending	\N	\N
11	hjhjqv1jnsaubbjqx0b8bi9k	diagtest	diag@example.com	local	$2a$10$LN1fOg7rxigFtQlYxu1YKu3xPhfLYtYJk9kfJiy5otpq4SqfgTSFK	\N	\N	t	f	2026-01-30 18:32:44.931	2026-01-30 18:32:44.931	2026-01-30 18:32:44.931	\N	\N	\N	+201234567890	EG	TestCo	t	Diag User	pending	\N	\N
12	cinpqdbwvdfoc7cev5ke6xmn	testuser1	testuser1@example.com	local	$2a$10$UvrSdCbyi6vxveS4Tq.6Nu3lRFtIeMwDpQXzWqsW6Gbi6yjreiZ..	\N	\N	t	f	2026-01-31 12:48:16.976	2026-01-31 12:48:16.976	2026-01-31 12:48:16.976	\N	\N	\N	+966501234567	Saudi Arabia	Test Company	t	Test User One	pending	\N	\N
14	v91nu7xpl3asaym9qyg8vdwj	ali	ahmed.se@gmail.com	local	$2a$10$UnbNkEy3VsdWPkudaFD3wOaBVc8lv5ewaY2f34YxruB39tcz.TrNW	\N	\N	t	f	2026-01-31 21:36:58.354	2026-01-31 21:36:58.354	2026-01-31 21:36:58.354	\N	\N	\N	+201069937577	Egypt	ClearTurn Techs	t	ali	pending	\N	\N
\.


--
-- TOC entry 3977 (class 0 OID 106388)
-- Dependencies: 284
-- Data for Name: up_users_role_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.up_users_role_lnk (id, user_id, role_id, user_ord) FROM stdin;
1	1	3	1
2	2	3	2
3	3	3	3
4	4	3	4
5	5	3	5
6	6	3	6
7	7	3	7
8	8	3	8
9	9	3	9
11	11	3	11
12	12	3	12
14	14	3	13
\.


--
-- TOC entry 3917 (class 0 OID 106036)
-- Dependencies: 224
-- Data for Name: upload_folders; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.upload_folders (id, document_id, name, path_id, path, created_at, updated_at, published_at, created_by_id, updated_by_id, locale) FROM stdin;
\.


--
-- TOC entry 3965 (class 0 OID 106317)
-- Dependencies: 272
-- Data for Name: upload_folders_parent_lnk; Type: TABLE DATA; Schema: public; Owner: arabiq
--

COPY public.upload_folders_parent_lnk (id, folder_id, inv_folder_id, folder_ord) FROM stdin;
\.


--
-- TOC entry 4034 (class 0 OID 0)
-- Dependencies: 241
-- Name: admin_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_permissions_id_seq', 375, true);


--
-- TOC entry 4035 (class 0 OID 0)
-- Dependencies: 285
-- Name: admin_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_permissions_role_lnk_id_seq', 375, true);


--
-- TOC entry 4036 (class 0 OID 0)
-- Dependencies: 245
-- Name: admin_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_roles_id_seq', 3, true);


--
-- TOC entry 4037 (class 0 OID 0)
-- Dependencies: 243
-- Name: admin_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_users_id_seq', 1, true);


--
-- TOC entry 4038 (class 0 OID 0)
-- Dependencies: 287
-- Name: admin_users_roles_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.admin_users_roles_lnk_id_seq', 1, true);


--
-- TOC entry 4039 (class 0 OID 0)
-- Dependencies: 269
-- Name: files_folder_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_folder_lnk_id_seq', 1, false);


--
-- TOC entry 4040 (class 0 OID 0)
-- Dependencies: 221
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_id_seq', 1, false);


--
-- TOC entry 4041 (class 0 OID 0)
-- Dependencies: 267
-- Name: files_related_mph_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.files_related_mph_id_seq', 1, false);


--
-- TOC entry 4042 (class 0 OID 0)
-- Dependencies: 225
-- Name: i18n_locale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.i18n_locale_id_seq', 2, true);


--
-- TOC entry 4043 (class 0 OID 0)
-- Dependencies: 265
-- Name: strapi_ai_localization_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_ai_localization_jobs_id_seq', 1363, true);


--
-- TOC entry 4044 (class 0 OID 0)
-- Dependencies: 249
-- Name: strapi_api_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_id_seq', 1, false);


--
-- TOC entry 4045 (class 0 OID 0)
-- Dependencies: 289
-- Name: strapi_api_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_token_permissions_token_lnk_id_seq', 1, false);


--
-- TOC entry 4046 (class 0 OID 0)
-- Dependencies: 247
-- Name: strapi_api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_api_tokens_id_seq', 4, true);


--
-- TOC entry 4047 (class 0 OID 0)
-- Dependencies: 257
-- Name: strapi_audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_audit_logs_id_seq', 1, false);


--
-- TOC entry 4048 (class 0 OID 0)
-- Dependencies: 293
-- Name: strapi_audit_logs_user_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_audit_logs_user_lnk_id_seq', 1, false);


--
-- TOC entry 4049 (class 0 OID 0)
-- Dependencies: 259
-- Name: strapi_core_store_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_core_store_settings_id_seq', 90, true);


--
-- TOC entry 4050 (class 0 OID 0)
-- Dependencies: 219
-- Name: strapi_database_schema_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_database_schema_id_seq', 51, true);


--
-- TOC entry 4051 (class 0 OID 0)
-- Dependencies: 263
-- Name: strapi_history_versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_history_versions_id_seq', 1, false);


--
-- TOC entry 4052 (class 0 OID 0)
-- Dependencies: 215
-- Name: strapi_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_migrations_id_seq', 1, false);


--
-- TOC entry 4053 (class 0 OID 0)
-- Dependencies: 217
-- Name: strapi_migrations_internal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_migrations_internal_id_seq', 7, true);


--
-- TOC entry 4054 (class 0 OID 0)
-- Dependencies: 229
-- Name: strapi_release_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_release_actions_id_seq', 1, false);


--
-- TOC entry 4055 (class 0 OID 0)
-- Dependencies: 273
-- Name: strapi_release_actions_release_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_release_actions_release_lnk_id_seq', 1, false);


--
-- TOC entry 4056 (class 0 OID 0)
-- Dependencies: 227
-- Name: strapi_releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_releases_id_seq', 1, false);


--
-- TOC entry 4057 (class 0 OID 0)
-- Dependencies: 255
-- Name: strapi_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_sessions_id_seq', 34, true);


--
-- TOC entry 4058 (class 0 OID 0)
-- Dependencies: 253
-- Name: strapi_transfer_token_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_id_seq', 1, false);


--
-- TOC entry 4059 (class 0 OID 0)
-- Dependencies: 291
-- Name: strapi_transfer_token_permissions_token_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_token_permissions_token_lnk_id_seq', 1, false);


--
-- TOC entry 4060 (class 0 OID 0)
-- Dependencies: 251
-- Name: strapi_transfer_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_transfer_tokens_id_seq', 1, false);


--
-- TOC entry 4061 (class 0 OID 0)
-- Dependencies: 261
-- Name: strapi_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_webhooks_id_seq', 1, false);


--
-- TOC entry 4062 (class 0 OID 0)
-- Dependencies: 231
-- Name: strapi_workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_id_seq', 1, false);


--
-- TOC entry 4063 (class 0 OID 0)
-- Dependencies: 275
-- Name: strapi_workflows_stage_required_to_publish_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stage_required_to_publish_lnk_id_seq', 1, false);


--
-- TOC entry 4064 (class 0 OID 0)
-- Dependencies: 233
-- Name: strapi_workflows_stages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_id_seq', 1, false);


--
-- TOC entry 4065 (class 0 OID 0)
-- Dependencies: 279
-- Name: strapi_workflows_stages_permissions_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_permissions_lnk_id_seq', 1, false);


--
-- TOC entry 4066 (class 0 OID 0)
-- Dependencies: 277
-- Name: strapi_workflows_stages_workflow_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.strapi_workflows_stages_workflow_lnk_id_seq', 1, false);


--
-- TOC entry 4067 (class 0 OID 0)
-- Dependencies: 235
-- Name: up_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_permissions_id_seq', 16, true);


--
-- TOC entry 4068 (class 0 OID 0)
-- Dependencies: 281
-- Name: up_permissions_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_permissions_role_lnk_id_seq', 17, true);


--
-- TOC entry 4069 (class 0 OID 0)
-- Dependencies: 237
-- Name: up_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_roles_id_seq', 5, true);


--
-- TOC entry 4070 (class 0 OID 0)
-- Dependencies: 239
-- Name: up_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_users_id_seq', 14, true);


--
-- TOC entry 4071 (class 0 OID 0)
-- Dependencies: 283
-- Name: up_users_role_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.up_users_role_lnk_id_seq', 14, true);


--
-- TOC entry 4072 (class 0 OID 0)
-- Dependencies: 223
-- Name: upload_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.upload_folders_id_seq', 1, false);


--
-- TOC entry 4073 (class 0 OID 0)
-- Dependencies: 271
-- Name: upload_folders_parent_lnk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: arabiq
--

SELECT pg_catalog.setval('public.upload_folders_parent_lnk_id_seq', 1, false);


--
-- TOC entry 3553 (class 2606 OID 106155)
-- Name: admin_permissions admin_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3668 (class 2606 OID 106405)
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3670 (class 2606 OID 106409)
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- TOC entry 3563 (class 2606 OID 106179)
-- Name: admin_roles admin_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3558 (class 2606 OID 106167)
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3676 (class 2606 OID 106417)
-- Name: admin_users_roles_lnk admin_users_roles_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3678 (class 2606 OID 106421)
-- Name: admin_users_roles_lnk admin_users_roles_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_uq UNIQUE (user_id, role_id);


--
-- TOC entry 3613 (class 2606 OID 106310)
-- Name: files_folder_lnk files_folder_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3615 (class 2606 OID 106314)
-- Name: files_folder_lnk files_folder_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_uq UNIQUE (file_id, folder_id);


--
-- TOC entry 3493 (class 2606 OID 106025)
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- TOC entry 3608 (class 2606 OID 106300)
-- Name: files_related_mph files_related_mph_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_pkey PRIMARY KEY (id);


--
-- TOC entry 3513 (class 2606 OID 106059)
-- Name: i18n_locale i18n_locale_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_pkey PRIMARY KEY (id);


--
-- TOC entry 3603 (class 2606 OID 106291)
-- Name: strapi_ai_localization_jobs strapi_ai_localization_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_ai_localization_jobs
    ADD CONSTRAINT strapi_ai_localization_jobs_pkey PRIMARY KEY (id);


--
-- TOC entry 3573 (class 2606 OID 106203)
-- Name: strapi_api_token_permissions strapi_api_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3683 (class 2606 OID 106430)
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3685 (class 2606 OID 106434)
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_uq UNIQUE (api_token_permission_id, api_token_id);


--
-- TOC entry 3568 (class 2606 OID 106191)
-- Name: strapi_api_tokens strapi_api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3593 (class 2606 OID 106251)
-- Name: strapi_audit_logs strapi_audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3696 (class 2606 OID 106454)
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3698 (class 2606 OID 106458)
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_uq UNIQUE (audit_log_id, user_id);


--
-- TOC entry 3596 (class 2606 OID 106263)
-- Name: strapi_core_store_settings strapi_core_store_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_core_store_settings
    ADD CONSTRAINT strapi_core_store_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3489 (class 2606 OID 106016)
-- Name: strapi_database_schema strapi_database_schema_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_database_schema
    ADD CONSTRAINT strapi_database_schema_pkey PRIMARY KEY (id);


--
-- TOC entry 3601 (class 2606 OID 106281)
-- Name: strapi_history_versions strapi_history_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_pkey PRIMARY KEY (id);


--
-- TOC entry 3487 (class 2606 OID 106007)
-- Name: strapi_migrations_internal strapi_migrations_internal_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations_internal
    ADD CONSTRAINT strapi_migrations_internal_pkey PRIMARY KEY (id);


--
-- TOC entry 3485 (class 2606 OID 106001)
-- Name: strapi_migrations strapi_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_migrations
    ADD CONSTRAINT strapi_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3523 (class 2606 OID 106083)
-- Name: strapi_release_actions strapi_release_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_pkey PRIMARY KEY (id);


--
-- TOC entry 3627 (class 2606 OID 106334)
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3629 (class 2606 OID 106338)
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_uq UNIQUE (release_action_id, release_id);


--
-- TOC entry 3518 (class 2606 OID 106071)
-- Name: strapi_releases strapi_releases_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_pkey PRIMARY KEY (id);


--
-- TOC entry 3588 (class 2606 OID 106239)
-- Name: strapi_sessions strapi_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3583 (class 2606 OID 106227)
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3690 (class 2606 OID 106442)
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3692 (class 2606 OID 106446)
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_uq UNIQUE (transfer_token_permission_id, transfer_token_id);


--
-- TOC entry 3578 (class 2606 OID 106215)
-- Name: strapi_transfer_tokens strapi_transfer_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3598 (class 2606 OID 106272)
-- Name: strapi_webhooks strapi_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_webhooks
    ADD CONSTRAINT strapi_webhooks_pkey PRIMARY KEY (id);


--
-- TOC entry 3528 (class 2606 OID 106095)
-- Name: strapi_workflows strapi_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_pkey PRIMARY KEY (id);


--
-- TOC entry 3633 (class 2606 OID 106346)
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3635 (class 2606 OID 106350)
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_uq UNIQUE (workflow_id, workflow_stage_id);


--
-- TOC entry 3647 (class 2606 OID 106369)
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3649 (class 2606 OID 106373)
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_uq UNIQUE (workflow_stage_id, permission_id);


--
-- TOC entry 3533 (class 2606 OID 106107)
-- Name: strapi_workflows_stages strapi_workflows_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_pkey PRIMARY KEY (id);


--
-- TOC entry 3640 (class 2606 OID 106357)
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3642 (class 2606 OID 106361)
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_uq UNIQUE (workflow_stage_id, workflow_id);


--
-- TOC entry 3538 (class 2606 OID 106119)
-- Name: up_permissions up_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3654 (class 2606 OID 106381)
-- Name: up_permissions_role_lnk up_permissions_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3656 (class 2606 OID 106385)
-- Name: up_permissions_role_lnk up_permissions_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_uq UNIQUE (permission_id, role_id);


--
-- TOC entry 3543 (class 2606 OID 106131)
-- Name: up_roles up_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_pkey PRIMARY KEY (id);


--
-- TOC entry 3548 (class 2606 OID 106143)
-- Name: up_users up_users_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_pkey PRIMARY KEY (id);


--
-- TOC entry 3661 (class 2606 OID 106393)
-- Name: up_users_role_lnk up_users_role_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3663 (class 2606 OID 106397)
-- Name: up_users_role_lnk up_users_role_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_uq UNIQUE (user_id, role_id);


--
-- TOC entry 3620 (class 2606 OID 106322)
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_pkey PRIMARY KEY (id);


--
-- TOC entry 3622 (class 2606 OID 106326)
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_uq; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_uq UNIQUE (folder_id, inv_folder_id);


--
-- TOC entry 3504 (class 2606 OID 106045)
-- Name: upload_folders upload_folders_path_id_index; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_id_index UNIQUE (path_id);


--
-- TOC entry 3506 (class 2606 OID 106047)
-- Name: upload_folders upload_folders_path_index; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_path_index UNIQUE (path);


--
-- TOC entry 3508 (class 2606 OID 106043)
-- Name: upload_folders upload_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_pkey PRIMARY KEY (id);


--
-- TOC entry 3550 (class 1259 OID 106157)
-- Name: admin_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_created_by_id_fk ON public.admin_permissions USING btree (created_by_id);


--
-- TOC entry 3551 (class 1259 OID 106156)
-- Name: admin_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_documents_idx ON public.admin_permissions USING btree (document_id, locale, published_at);


--
-- TOC entry 3664 (class 1259 OID 106406)
-- Name: admin_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_fk ON public.admin_permissions_role_lnk USING btree (permission_id);


--
-- TOC entry 3665 (class 1259 OID 106407)
-- Name: admin_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_ifk ON public.admin_permissions_role_lnk USING btree (role_id);


--
-- TOC entry 3666 (class 1259 OID 106410)
-- Name: admin_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_role_lnk_oifk ON public.admin_permissions_role_lnk USING btree (permission_ord);


--
-- TOC entry 3554 (class 1259 OID 106158)
-- Name: admin_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_permissions_updated_by_id_fk ON public.admin_permissions USING btree (updated_by_id);


--
-- TOC entry 3560 (class 1259 OID 106181)
-- Name: admin_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_created_by_id_fk ON public.admin_roles USING btree (created_by_id);


--
-- TOC entry 3561 (class 1259 OID 106180)
-- Name: admin_roles_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_documents_idx ON public.admin_roles USING btree (document_id, locale, published_at);


--
-- TOC entry 3564 (class 1259 OID 106182)
-- Name: admin_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_roles_updated_by_id_fk ON public.admin_roles USING btree (updated_by_id);


--
-- TOC entry 3555 (class 1259 OID 106169)
-- Name: admin_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_created_by_id_fk ON public.admin_users USING btree (created_by_id);


--
-- TOC entry 3556 (class 1259 OID 106168)
-- Name: admin_users_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_documents_idx ON public.admin_users USING btree (document_id, locale, published_at);


--
-- TOC entry 3671 (class 1259 OID 106418)
-- Name: admin_users_roles_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_fk ON public.admin_users_roles_lnk USING btree (user_id);


--
-- TOC entry 3672 (class 1259 OID 106419)
-- Name: admin_users_roles_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_ifk ON public.admin_users_roles_lnk USING btree (role_id);


--
-- TOC entry 3673 (class 1259 OID 106422)
-- Name: admin_users_roles_lnk_ofk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_ofk ON public.admin_users_roles_lnk USING btree (role_ord);


--
-- TOC entry 3674 (class 1259 OID 106423)
-- Name: admin_users_roles_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_roles_lnk_oifk ON public.admin_users_roles_lnk USING btree (user_ord);


--
-- TOC entry 3559 (class 1259 OID 106170)
-- Name: admin_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX admin_users_updated_by_id_fk ON public.admin_users USING btree (updated_by_id);


--
-- TOC entry 3490 (class 1259 OID 106033)
-- Name: files_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_created_by_id_fk ON public.files USING btree (created_by_id);


--
-- TOC entry 3491 (class 1259 OID 106032)
-- Name: files_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_documents_idx ON public.files USING btree (document_id, locale, published_at);


--
-- TOC entry 3609 (class 1259 OID 106311)
-- Name: files_folder_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_fk ON public.files_folder_lnk USING btree (file_id);


--
-- TOC entry 3610 (class 1259 OID 106312)
-- Name: files_folder_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_ifk ON public.files_folder_lnk USING btree (folder_id);


--
-- TOC entry 3611 (class 1259 OID 106315)
-- Name: files_folder_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_folder_lnk_oifk ON public.files_folder_lnk USING btree (file_ord);


--
-- TOC entry 3604 (class 1259 OID 106301)
-- Name: files_related_mph_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_fk ON public.files_related_mph USING btree (file_id);


--
-- TOC entry 3605 (class 1259 OID 106303)
-- Name: files_related_mph_idix; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_idix ON public.files_related_mph USING btree (related_id);


--
-- TOC entry 3606 (class 1259 OID 106302)
-- Name: files_related_mph_oidx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_related_mph_oidx ON public.files_related_mph USING btree ("order");


--
-- TOC entry 3494 (class 1259 OID 106034)
-- Name: files_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX files_updated_by_id_fk ON public.files USING btree (updated_by_id);


--
-- TOC entry 3510 (class 1259 OID 106061)
-- Name: i18n_locale_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_created_by_id_fk ON public.i18n_locale USING btree (created_by_id);


--
-- TOC entry 3511 (class 1259 OID 106060)
-- Name: i18n_locale_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_documents_idx ON public.i18n_locale USING btree (document_id, locale, published_at);


--
-- TOC entry 3514 (class 1259 OID 106062)
-- Name: i18n_locale_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX i18n_locale_updated_by_id_fk ON public.i18n_locale USING btree (updated_by_id);


--
-- TOC entry 3570 (class 1259 OID 106205)
-- Name: strapi_api_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_created_by_id_fk ON public.strapi_api_token_permissions USING btree (created_by_id);


--
-- TOC entry 3571 (class 1259 OID 106204)
-- Name: strapi_api_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_documents_idx ON public.strapi_api_token_permissions USING btree (document_id, locale, published_at);


--
-- TOC entry 3679 (class 1259 OID 106431)
-- Name: strapi_api_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_fk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_id);


--
-- TOC entry 3680 (class 1259 OID 106432)
-- Name: strapi_api_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_ifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_id);


--
-- TOC entry 3681 (class 1259 OID 106435)
-- Name: strapi_api_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_token_lnk_oifk ON public.strapi_api_token_permissions_token_lnk USING btree (api_token_permission_ord);


--
-- TOC entry 3574 (class 1259 OID 106206)
-- Name: strapi_api_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_token_permissions_updated_by_id_fk ON public.strapi_api_token_permissions USING btree (updated_by_id);


--
-- TOC entry 3565 (class 1259 OID 106193)
-- Name: strapi_api_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_created_by_id_fk ON public.strapi_api_tokens USING btree (created_by_id);


--
-- TOC entry 3566 (class 1259 OID 106192)
-- Name: strapi_api_tokens_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_documents_idx ON public.strapi_api_tokens USING btree (document_id, locale, published_at);


--
-- TOC entry 3569 (class 1259 OID 106194)
-- Name: strapi_api_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_api_tokens_updated_by_id_fk ON public.strapi_api_tokens USING btree (updated_by_id);


--
-- TOC entry 3590 (class 1259 OID 106253)
-- Name: strapi_audit_logs_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_created_by_id_fk ON public.strapi_audit_logs USING btree (created_by_id);


--
-- TOC entry 3591 (class 1259 OID 106252)
-- Name: strapi_audit_logs_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_documents_idx ON public.strapi_audit_logs USING btree (document_id, locale, published_at);


--
-- TOC entry 3594 (class 1259 OID 106254)
-- Name: strapi_audit_logs_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_updated_by_id_fk ON public.strapi_audit_logs USING btree (updated_by_id);


--
-- TOC entry 3693 (class 1259 OID 106455)
-- Name: strapi_audit_logs_user_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_user_lnk_fk ON public.strapi_audit_logs_user_lnk USING btree (audit_log_id);


--
-- TOC entry 3694 (class 1259 OID 106456)
-- Name: strapi_audit_logs_user_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_audit_logs_user_lnk_ifk ON public.strapi_audit_logs_user_lnk USING btree (user_id);


--
-- TOC entry 3599 (class 1259 OID 106282)
-- Name: strapi_history_versions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_history_versions_created_by_id_fk ON public.strapi_history_versions USING btree (created_by_id);


--
-- TOC entry 3520 (class 1259 OID 106085)
-- Name: strapi_release_actions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_created_by_id_fk ON public.strapi_release_actions USING btree (created_by_id);


--
-- TOC entry 3521 (class 1259 OID 106084)
-- Name: strapi_release_actions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_documents_idx ON public.strapi_release_actions USING btree (document_id, locale, published_at);


--
-- TOC entry 3623 (class 1259 OID 106335)
-- Name: strapi_release_actions_release_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_fk ON public.strapi_release_actions_release_lnk USING btree (release_action_id);


--
-- TOC entry 3624 (class 1259 OID 106336)
-- Name: strapi_release_actions_release_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_ifk ON public.strapi_release_actions_release_lnk USING btree (release_id);


--
-- TOC entry 3625 (class 1259 OID 106339)
-- Name: strapi_release_actions_release_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_release_lnk_oifk ON public.strapi_release_actions_release_lnk USING btree (release_action_ord);


--
-- TOC entry 3524 (class 1259 OID 106086)
-- Name: strapi_release_actions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_release_actions_updated_by_id_fk ON public.strapi_release_actions USING btree (updated_by_id);


--
-- TOC entry 3515 (class 1259 OID 106073)
-- Name: strapi_releases_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_created_by_id_fk ON public.strapi_releases USING btree (created_by_id);


--
-- TOC entry 3516 (class 1259 OID 106072)
-- Name: strapi_releases_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_documents_idx ON public.strapi_releases USING btree (document_id, locale, published_at);


--
-- TOC entry 3519 (class 1259 OID 106074)
-- Name: strapi_releases_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_releases_updated_by_id_fk ON public.strapi_releases USING btree (updated_by_id);


--
-- TOC entry 3585 (class 1259 OID 106241)
-- Name: strapi_sessions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_created_by_id_fk ON public.strapi_sessions USING btree (created_by_id);


--
-- TOC entry 3586 (class 1259 OID 106240)
-- Name: strapi_sessions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_documents_idx ON public.strapi_sessions USING btree (document_id, locale, published_at);


--
-- TOC entry 3589 (class 1259 OID 106242)
-- Name: strapi_sessions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_sessions_updated_by_id_fk ON public.strapi_sessions USING btree (updated_by_id);


--
-- TOC entry 3580 (class 1259 OID 106229)
-- Name: strapi_transfer_token_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_created_by_id_fk ON public.strapi_transfer_token_permissions USING btree (created_by_id);


--
-- TOC entry 3581 (class 1259 OID 106228)
-- Name: strapi_transfer_token_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_documents_idx ON public.strapi_transfer_token_permissions USING btree (document_id, locale, published_at);


--
-- TOC entry 3686 (class 1259 OID 106443)
-- Name: strapi_transfer_token_permissions_token_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_fk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_id);


--
-- TOC entry 3687 (class 1259 OID 106444)
-- Name: strapi_transfer_token_permissions_token_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_ifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_id);


--
-- TOC entry 3688 (class 1259 OID 106447)
-- Name: strapi_transfer_token_permissions_token_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_token_lnk_oifk ON public.strapi_transfer_token_permissions_token_lnk USING btree (transfer_token_permission_ord);


--
-- TOC entry 3584 (class 1259 OID 106230)
-- Name: strapi_transfer_token_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_token_permissions_updated_by_id_fk ON public.strapi_transfer_token_permissions USING btree (updated_by_id);


--
-- TOC entry 3575 (class 1259 OID 106217)
-- Name: strapi_transfer_tokens_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_created_by_id_fk ON public.strapi_transfer_tokens USING btree (created_by_id);


--
-- TOC entry 3576 (class 1259 OID 106216)
-- Name: strapi_transfer_tokens_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_documents_idx ON public.strapi_transfer_tokens USING btree (document_id, locale, published_at);


--
-- TOC entry 3579 (class 1259 OID 106218)
-- Name: strapi_transfer_tokens_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_transfer_tokens_updated_by_id_fk ON public.strapi_transfer_tokens USING btree (updated_by_id);


--
-- TOC entry 3525 (class 1259 OID 106097)
-- Name: strapi_workflows_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_created_by_id_fk ON public.strapi_workflows USING btree (created_by_id);


--
-- TOC entry 3526 (class 1259 OID 106096)
-- Name: strapi_workflows_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_documents_idx ON public.strapi_workflows USING btree (document_id, locale, published_at);


--
-- TOC entry 3630 (class 1259 OID 106347)
-- Name: strapi_workflows_stage_required_to_publish_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_fk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_id);


--
-- TOC entry 3631 (class 1259 OID 106348)
-- Name: strapi_workflows_stage_required_to_publish_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stage_required_to_publish_lnk_ifk ON public.strapi_workflows_stage_required_to_publish_lnk USING btree (workflow_stage_id);


--
-- TOC entry 3530 (class 1259 OID 106109)
-- Name: strapi_workflows_stages_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_created_by_id_fk ON public.strapi_workflows_stages USING btree (created_by_id);


--
-- TOC entry 3531 (class 1259 OID 106108)
-- Name: strapi_workflows_stages_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_documents_idx ON public.strapi_workflows_stages USING btree (document_id, locale, published_at);


--
-- TOC entry 3643 (class 1259 OID 106370)
-- Name: strapi_workflows_stages_permissions_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_fk ON public.strapi_workflows_stages_permissions_lnk USING btree (workflow_stage_id);


--
-- TOC entry 3644 (class 1259 OID 106371)
-- Name: strapi_workflows_stages_permissions_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ifk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_id);


--
-- TOC entry 3645 (class 1259 OID 106374)
-- Name: strapi_workflows_stages_permissions_lnk_ofk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_permissions_lnk_ofk ON public.strapi_workflows_stages_permissions_lnk USING btree (permission_ord);


--
-- TOC entry 3534 (class 1259 OID 106110)
-- Name: strapi_workflows_stages_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_updated_by_id_fk ON public.strapi_workflows_stages USING btree (updated_by_id);


--
-- TOC entry 3636 (class 1259 OID 106358)
-- Name: strapi_workflows_stages_workflow_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_fk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_id);


--
-- TOC entry 3637 (class 1259 OID 106359)
-- Name: strapi_workflows_stages_workflow_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_ifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_id);


--
-- TOC entry 3638 (class 1259 OID 106362)
-- Name: strapi_workflows_stages_workflow_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_stages_workflow_lnk_oifk ON public.strapi_workflows_stages_workflow_lnk USING btree (workflow_stage_ord);


--
-- TOC entry 3529 (class 1259 OID 106098)
-- Name: strapi_workflows_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX strapi_workflows_updated_by_id_fk ON public.strapi_workflows USING btree (updated_by_id);


--
-- TOC entry 3535 (class 1259 OID 106121)
-- Name: up_permissions_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_created_by_id_fk ON public.up_permissions USING btree (created_by_id);


--
-- TOC entry 3536 (class 1259 OID 106120)
-- Name: up_permissions_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_documents_idx ON public.up_permissions USING btree (document_id, locale, published_at);


--
-- TOC entry 3650 (class 1259 OID 106382)
-- Name: up_permissions_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_fk ON public.up_permissions_role_lnk USING btree (permission_id);


--
-- TOC entry 3651 (class 1259 OID 106383)
-- Name: up_permissions_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_ifk ON public.up_permissions_role_lnk USING btree (role_id);


--
-- TOC entry 3652 (class 1259 OID 106386)
-- Name: up_permissions_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_role_lnk_oifk ON public.up_permissions_role_lnk USING btree (permission_ord);


--
-- TOC entry 3539 (class 1259 OID 106122)
-- Name: up_permissions_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_permissions_updated_by_id_fk ON public.up_permissions USING btree (updated_by_id);


--
-- TOC entry 3540 (class 1259 OID 106133)
-- Name: up_roles_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_created_by_id_fk ON public.up_roles USING btree (created_by_id);


--
-- TOC entry 3541 (class 1259 OID 106132)
-- Name: up_roles_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_documents_idx ON public.up_roles USING btree (document_id, locale, published_at);


--
-- TOC entry 3544 (class 1259 OID 106134)
-- Name: up_roles_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_roles_updated_by_id_fk ON public.up_roles USING btree (updated_by_id);


--
-- TOC entry 3545 (class 1259 OID 106145)
-- Name: up_users_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_created_by_id_fk ON public.up_users USING btree (created_by_id);


--
-- TOC entry 3546 (class 1259 OID 106144)
-- Name: up_users_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_documents_idx ON public.up_users USING btree (document_id, locale, published_at);


--
-- TOC entry 3657 (class 1259 OID 106394)
-- Name: up_users_role_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_fk ON public.up_users_role_lnk USING btree (user_id);


--
-- TOC entry 3658 (class 1259 OID 106395)
-- Name: up_users_role_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_ifk ON public.up_users_role_lnk USING btree (role_id);


--
-- TOC entry 3659 (class 1259 OID 106398)
-- Name: up_users_role_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_role_lnk_oifk ON public.up_users_role_lnk USING btree (user_ord);


--
-- TOC entry 3549 (class 1259 OID 106146)
-- Name: up_users_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX up_users_updated_by_id_fk ON public.up_users USING btree (updated_by_id);


--
-- TOC entry 3495 (class 1259 OID 106027)
-- Name: upload_files_created_at_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_created_at_index ON public.files USING btree (created_at);


--
-- TOC entry 3496 (class 1259 OID 106031)
-- Name: upload_files_ext_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_ext_index ON public.files USING btree (ext);


--
-- TOC entry 3497 (class 1259 OID 106026)
-- Name: upload_files_folder_path_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_folder_path_index ON public.files USING btree (folder_path);


--
-- TOC entry 3498 (class 1259 OID 106029)
-- Name: upload_files_name_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_name_index ON public.files USING btree (name);


--
-- TOC entry 3499 (class 1259 OID 106030)
-- Name: upload_files_size_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_size_index ON public.files USING btree (size);


--
-- TOC entry 3500 (class 1259 OID 106028)
-- Name: upload_files_updated_at_index; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_files_updated_at_index ON public.files USING btree (updated_at);


--
-- TOC entry 3501 (class 1259 OID 106049)
-- Name: upload_folders_created_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_created_by_id_fk ON public.upload_folders USING btree (created_by_id);


--
-- TOC entry 3502 (class 1259 OID 106048)
-- Name: upload_folders_documents_idx; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_documents_idx ON public.upload_folders USING btree (document_id, locale, published_at);


--
-- TOC entry 3616 (class 1259 OID 106323)
-- Name: upload_folders_parent_lnk_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_fk ON public.upload_folders_parent_lnk USING btree (folder_id);


--
-- TOC entry 3617 (class 1259 OID 106324)
-- Name: upload_folders_parent_lnk_ifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_ifk ON public.upload_folders_parent_lnk USING btree (inv_folder_id);


--
-- TOC entry 3618 (class 1259 OID 106327)
-- Name: upload_folders_parent_lnk_oifk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_parent_lnk_oifk ON public.upload_folders_parent_lnk USING btree (folder_ord);


--
-- TOC entry 3509 (class 1259 OID 106050)
-- Name: upload_folders_updated_by_id_fk; Type: INDEX; Schema: public; Owner: arabiq
--

CREATE INDEX upload_folders_updated_by_id_fk ON public.upload_folders USING btree (updated_by_id);


--
-- TOC entry 3719 (class 2606 OID 106559)
-- Name: admin_permissions admin_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3755 (class 2606 OID 106739)
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3756 (class 2606 OID 106744)
-- Name: admin_permissions_role_lnk admin_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions_role_lnk
    ADD CONSTRAINT admin_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- TOC entry 3720 (class 2606 OID 106564)
-- Name: admin_permissions admin_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_permissions
    ADD CONSTRAINT admin_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3723 (class 2606 OID 106579)
-- Name: admin_roles admin_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3724 (class 2606 OID 106584)
-- Name: admin_roles admin_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_roles
    ADD CONSTRAINT admin_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3721 (class 2606 OID 106569)
-- Name: admin_users admin_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3757 (class 2606 OID 106749)
-- Name: admin_users_roles_lnk admin_users_roles_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_fk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- TOC entry 3758 (class 2606 OID 106754)
-- Name: admin_users_roles_lnk admin_users_roles_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users_roles_lnk
    ADD CONSTRAINT admin_users_roles_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.admin_roles(id) ON DELETE CASCADE;


--
-- TOC entry 3722 (class 2606 OID 106574)
-- Name: admin_users admin_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3699 (class 2606 OID 106459)
-- Name: files files_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3739 (class 2606 OID 106659)
-- Name: files_folder_lnk files_folder_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- TOC entry 3740 (class 2606 OID 106664)
-- Name: files_folder_lnk files_folder_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_folder_lnk
    ADD CONSTRAINT files_folder_lnk_ifk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- TOC entry 3738 (class 2606 OID 106654)
-- Name: files_related_mph files_related_mph_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files_related_mph
    ADD CONSTRAINT files_related_mph_fk FOREIGN KEY (file_id) REFERENCES public.files(id) ON DELETE CASCADE;


--
-- TOC entry 3700 (class 2606 OID 106464)
-- Name: files files_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3703 (class 2606 OID 106479)
-- Name: i18n_locale i18n_locale_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3704 (class 2606 OID 106484)
-- Name: i18n_locale i18n_locale_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.i18n_locale
    ADD CONSTRAINT i18n_locale_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3727 (class 2606 OID 106599)
-- Name: strapi_api_token_permissions strapi_api_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3759 (class 2606 OID 106759)
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_fk FOREIGN KEY (api_token_permission_id) REFERENCES public.strapi_api_token_permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3760 (class 2606 OID 106764)
-- Name: strapi_api_token_permissions_token_lnk strapi_api_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions_token_lnk
    ADD CONSTRAINT strapi_api_token_permissions_token_lnk_ifk FOREIGN KEY (api_token_id) REFERENCES public.strapi_api_tokens(id) ON DELETE CASCADE;


--
-- TOC entry 3728 (class 2606 OID 106604)
-- Name: strapi_api_token_permissions strapi_api_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_token_permissions
    ADD CONSTRAINT strapi_api_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3725 (class 2606 OID 106589)
-- Name: strapi_api_tokens strapi_api_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3726 (class 2606 OID 106594)
-- Name: strapi_api_tokens strapi_api_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_api_tokens
    ADD CONSTRAINT strapi_api_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3735 (class 2606 OID 106639)
-- Name: strapi_audit_logs strapi_audit_logs_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3736 (class 2606 OID 106644)
-- Name: strapi_audit_logs strapi_audit_logs_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs
    ADD CONSTRAINT strapi_audit_logs_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3763 (class 2606 OID 106779)
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_fk FOREIGN KEY (audit_log_id) REFERENCES public.strapi_audit_logs(id) ON DELETE CASCADE;


--
-- TOC entry 3764 (class 2606 OID 106784)
-- Name: strapi_audit_logs_user_lnk strapi_audit_logs_user_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_audit_logs_user_lnk
    ADD CONSTRAINT strapi_audit_logs_user_lnk_ifk FOREIGN KEY (user_id) REFERENCES public.admin_users(id) ON DELETE CASCADE;


--
-- TOC entry 3737 (class 2606 OID 106649)
-- Name: strapi_history_versions strapi_history_versions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_history_versions
    ADD CONSTRAINT strapi_history_versions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3707 (class 2606 OID 106499)
-- Name: strapi_release_actions strapi_release_actions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3743 (class 2606 OID 106679)
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_fk FOREIGN KEY (release_action_id) REFERENCES public.strapi_release_actions(id) ON DELETE CASCADE;


--
-- TOC entry 3744 (class 2606 OID 106684)
-- Name: strapi_release_actions_release_lnk strapi_release_actions_release_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions_release_lnk
    ADD CONSTRAINT strapi_release_actions_release_lnk_ifk FOREIGN KEY (release_id) REFERENCES public.strapi_releases(id) ON DELETE CASCADE;


--
-- TOC entry 3708 (class 2606 OID 106504)
-- Name: strapi_release_actions strapi_release_actions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_release_actions
    ADD CONSTRAINT strapi_release_actions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3705 (class 2606 OID 106489)
-- Name: strapi_releases strapi_releases_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3706 (class 2606 OID 106494)
-- Name: strapi_releases strapi_releases_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_releases
    ADD CONSTRAINT strapi_releases_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3733 (class 2606 OID 106629)
-- Name: strapi_sessions strapi_sessions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3734 (class 2606 OID 106634)
-- Name: strapi_sessions strapi_sessions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_sessions
    ADD CONSTRAINT strapi_sessions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3731 (class 2606 OID 106619)
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3761 (class 2606 OID 106769)
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_fk FOREIGN KEY (transfer_token_permission_id) REFERENCES public.strapi_transfer_token_permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3762 (class 2606 OID 106774)
-- Name: strapi_transfer_token_permissions_token_lnk strapi_transfer_token_permissions_token_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions_token_lnk
    ADD CONSTRAINT strapi_transfer_token_permissions_token_lnk_ifk FOREIGN KEY (transfer_token_id) REFERENCES public.strapi_transfer_tokens(id) ON DELETE CASCADE;


--
-- TOC entry 3732 (class 2606 OID 106624)
-- Name: strapi_transfer_token_permissions strapi_transfer_token_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_token_permissions
    ADD CONSTRAINT strapi_transfer_token_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3729 (class 2606 OID 106609)
-- Name: strapi_transfer_tokens strapi_transfer_tokens_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3730 (class 2606 OID 106614)
-- Name: strapi_transfer_tokens strapi_transfer_tokens_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_transfer_tokens
    ADD CONSTRAINT strapi_transfer_tokens_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3709 (class 2606 OID 106509)
-- Name: strapi_workflows strapi_workflows_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3745 (class 2606 OID 106689)
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_fk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- TOC entry 3746 (class 2606 OID 106694)
-- Name: strapi_workflows_stage_required_to_publish_lnk strapi_workflows_stage_required_to_publish_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stage_required_to_publish_lnk
    ADD CONSTRAINT strapi_workflows_stage_required_to_publish_lnk_ifk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- TOC entry 3711 (class 2606 OID 106519)
-- Name: strapi_workflows_stages strapi_workflows_stages_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3749 (class 2606 OID 106709)
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- TOC entry 3750 (class 2606 OID 106714)
-- Name: strapi_workflows_stages_permissions_lnk strapi_workflows_stages_permissions_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_permissions_lnk
    ADD CONSTRAINT strapi_workflows_stages_permissions_lnk_ifk FOREIGN KEY (permission_id) REFERENCES public.admin_permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3712 (class 2606 OID 106524)
-- Name: strapi_workflows_stages strapi_workflows_stages_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages
    ADD CONSTRAINT strapi_workflows_stages_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3747 (class 2606 OID 106699)
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_fk FOREIGN KEY (workflow_stage_id) REFERENCES public.strapi_workflows_stages(id) ON DELETE CASCADE;


--
-- TOC entry 3748 (class 2606 OID 106704)
-- Name: strapi_workflows_stages_workflow_lnk strapi_workflows_stages_workflow_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows_stages_workflow_lnk
    ADD CONSTRAINT strapi_workflows_stages_workflow_lnk_ifk FOREIGN KEY (workflow_id) REFERENCES public.strapi_workflows(id) ON DELETE CASCADE;


--
-- TOC entry 3710 (class 2606 OID 106514)
-- Name: strapi_workflows strapi_workflows_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.strapi_workflows
    ADD CONSTRAINT strapi_workflows_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3713 (class 2606 OID 106529)
-- Name: up_permissions up_permissions_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3751 (class 2606 OID 106719)
-- Name: up_permissions_role_lnk up_permissions_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_fk FOREIGN KEY (permission_id) REFERENCES public.up_permissions(id) ON DELETE CASCADE;


--
-- TOC entry 3752 (class 2606 OID 106724)
-- Name: up_permissions_role_lnk up_permissions_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions_role_lnk
    ADD CONSTRAINT up_permissions_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- TOC entry 3714 (class 2606 OID 106534)
-- Name: up_permissions up_permissions_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_permissions
    ADD CONSTRAINT up_permissions_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3715 (class 2606 OID 106539)
-- Name: up_roles up_roles_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3716 (class 2606 OID 106544)
-- Name: up_roles up_roles_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_roles
    ADD CONSTRAINT up_roles_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3717 (class 2606 OID 106549)
-- Name: up_users up_users_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3753 (class 2606 OID 106729)
-- Name: up_users_role_lnk up_users_role_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_fk FOREIGN KEY (user_id) REFERENCES public.up_users(id) ON DELETE CASCADE;


--
-- TOC entry 3754 (class 2606 OID 106734)
-- Name: up_users_role_lnk up_users_role_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users_role_lnk
    ADD CONSTRAINT up_users_role_lnk_ifk FOREIGN KEY (role_id) REFERENCES public.up_roles(id) ON DELETE CASCADE;


--
-- TOC entry 3718 (class 2606 OID 106554)
-- Name: up_users up_users_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.up_users
    ADD CONSTRAINT up_users_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3701 (class 2606 OID 106469)
-- Name: upload_folders upload_folders_created_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_created_by_id_fk FOREIGN KEY (created_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3741 (class 2606 OID 106669)
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_fk FOREIGN KEY (folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- TOC entry 3742 (class 2606 OID 106674)
-- Name: upload_folders_parent_lnk upload_folders_parent_lnk_ifk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders_parent_lnk
    ADD CONSTRAINT upload_folders_parent_lnk_ifk FOREIGN KEY (inv_folder_id) REFERENCES public.upload_folders(id) ON DELETE CASCADE;


--
-- TOC entry 3702 (class 2606 OID 106474)
-- Name: upload_folders upload_folders_updated_by_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: arabiq
--

ALTER TABLE ONLY public.upload_folders
    ADD CONSTRAINT upload_folders_updated_by_id_fk FOREIGN KEY (updated_by_id) REFERENCES public.admin_users(id) ON DELETE SET NULL;


--
-- TOC entry 3993 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO arabiq;


--
-- TOC entry 2234 (class 826 OID 105993)
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO arabiq;


--
-- TOC entry 2233 (class 826 OID 105992)
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO arabiq;


-- Completed on 2026-01-31 22:01:07 EET

--
-- PostgreSQL database dump complete
--

\unrestrict P655QeJ6aAWakh07DVgbU1eoNCO1JSamkq4wImUucZCGwlsNM4sgBCbJnzc36Ix

